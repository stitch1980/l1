/**
** \file main.cpp
** \brief Fichier contenant le main du decompilateur
**
** \author Joran HERVE
*/
#include    <sys/types.h>
#include    <libgen.h>
#include    <dirent.h>
#include    <limits.h>
#include    <stdlib.h>
#include    <stdio.h>

#include    <iostream>
#include    <set>

#include    "Info.hpp"
#include    "Plugin.hpp"

#define    NAME_PLUGINS_DIRECTORY    "/plugins/"


/**
** \fn void get_lib_name(std::set<std::string> &lib_name, int argc, const char **argv)
** \brief Gere la recuperation des noms des fichiers present dans le dossier des plugins
**
** \param lib_name Liste devant contenir les noms des plugins
** \param argv Tableau contenant les noms des plugins suplementaires
** \return Retourne rien
*/
void    get_lib_name(std::set<std::string> &lib_name, int argc, const char **argv)
{
    std::string      path;
    char             buffer[PATH_MAX + 1];
    DIR              *dir;
    struct dirent    *f;

    /* Identifie le chemin du dossier des plugins */
    if (realpath(argv[0], buffer) == NULL)
        fprintf(stderr, "ERROR:\tCannot find plugins directory\n");
    else
    {
        path = std::string(dirname(buffer)) + NAME_PLUGINS_DIRECTORY;

        /* Recupere les noms des fichiers present dans le dossier des plugins */
        if ((dir = opendir(path.c_str())) != NULL)
        {
            while ((f = readdir(dir)) != NULL)
            {
                if ((f->d_type & DT_REG) == DT_REG)
                {
                    if (realpath(std::string(path + f->d_name).c_str(), buffer) != NULL)
                        lib_name.insert(buffer);
                }
            }
            closedir(dir);
        }
        else
            fprintf(stderr, "ERROR:\tCannot open \"%s\"\n", path.c_str());
    }

    /* Recupere les noms de libs passes en parametres */
    for (int i=2; i<argc; i++)
    {
        if (realpath(argv[i], buffer) != NULL)
            lib_name.insert(buffer);
    }
}

/**
** \fn void get_lib(std::map<std::string, Plugin*> &lib, std::set<std::string> &lib_name)
** \brief Gere l'ouverture de plugins dont les noms ont ete passes en parametres
**
** \param lib Map contenant les plugins indexes par leur nom
** \param lib_name List contenant les noms des plugins a ouvrir
** \return Retourne rien
*/
void    get_lib(std::map<std::string, Plugin*> &lib, std::set<std::string> &lib_name)
{
    Plugin    *plugin;
    char      buffer[30];

    for (std::set<std::string>::iterator it=lib_name.begin(); it!=lib_name.end(); it++)
    {
        if ((plugin = Plugin::open_plugin(*it)) != NULL)
        {
            snprintf(buffer, 29, "%08lu", plugin->get_priorite());
            lib[std::string(buffer) + "-" + plugin->get_plugin_name()] = plugin;
        }
    }
}

/**
** \fn int execute_type_plugin(Info *info const std::string &type)
** \brief Gere l'execution de tout les plugins d'un meme type par ordre de priorite
**
** \param info Structure contenant les infos du programme a analyser
** \param type Type des plugins a executer
** \return Retourne -1 en cas d'erreur, 1 si au moins un des plugins a ete execute, 0 sinon
*/
int    execute_type_plugin(Info *info, const std::string &type)
{
    std::map<std::string, Plugin*>::iterator    it;
    int                                         ret;
    int                                         ok;

    ok = 0;

    /* Execution des plugins les uns apres les autres */
    for (it=info->plugin.begin(); it!=info->plugin.end(); it++)
    {
        if (it->second->get_type() == type)
        {
            if ((ret = it->second->execute(info)) > 0)
            {
                fprintf(stderr, "OK:\t%s\n", it->second->get_plugin_name());
                ok = 1;
            }
            else if (ret == 0)
                fprintf(stderr, "IGN:\t%s\n", it->second->get_plugin_name());
            else
            {
                fprintf(stderr, "KO:\t%s\n", it->second->get_plugin_name());
                return (-1);
            }
        }
    }

    return (ok);
}

/**
** \fn int main(int argc, const char **argv)
** \brief Main du decompilateur
**
** \param argc Nombre de parametres utilisateur
** \param argv Tableau contenant les parametres utilisateur
** \return Retourne 1 si OK, 0 sinon
*/
int    main(int argc, const char **argv)
{
    std::set<std::string>                                         lib_name;
    Info                                                          info;

    if (argc < 2)
    {
        fprintf(stderr, "Usage:\t%s <executable> [lib] [lib] ...\n", argv[0]);
        return (0);
    }
    info.filename = argv[1];

    /* Recupere le nom des libs a utiliser */
    get_lib_name(lib_name, argc, argv);

    /* Recupere les libs utiles */
    get_lib(info.plugin, lib_name);

    /* Execution des plugins les uns apres les autres */
//    execute_type_plugin(&info, PLUGIN_TYPE__TEST);
    execute_type_plugin(&info, PLUGIN_TYPE__OPEN);
    execute_type_plugin(&info, PLUGIN_TYPE__PARSING);
    execute_type_plugin(&info, PLUGIN_TYPE__DEASM);
 //    execute_type_plugin(&info, PLUGIN_TYPE__CLEAN);
//    execute_type_plugin(&info, PLUGIN_TYPE__DECOMPILE);

    return (1);
}

