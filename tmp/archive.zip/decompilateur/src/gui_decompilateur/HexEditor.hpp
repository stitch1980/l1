#ifndef    HEXEDITOR_HPP
#define    HEXEDITOR_HPP

#include    <QPlainTextEdit>
#include    <QObject>
#include    <QSlider>

#include    "Mutex.h"

class QPaintEvent;
class QResizeEvent;
class QSize;
class QWidget;

class LineNumberArea;

class HexEditor : public QPlainTextEdit
{
    Q_OBJECT
public:
    explicit HexEditor(QWidget *parent = 0);
    ~HexEditor();

    /**
    ** \fn void set_data_hex(QSlider *scrollbar, unsigned long addr=0, const unsigned char *data=NULL, unsigned long size=0)
    ** \brief Gere l'initialisation de l'editeur pour afficher les donnees correctement
    **
    ** \param scrollbar Pointeur sur la scrollbar permettant de gerer le defilement
    ** \param addr Adresse des donnees
    ** \param data Donnees a afficher
    ** \param size Taille des donnees a afficher
    ** \return Retourne rien
    */
    void    set_data_hex(QSlider *scrollbar, unsigned long addr, const unsigned char *data, unsigned long size);

    void    set_address(unsigned long addr);
    const std::vector<unsigned char> &get_data() const;

    void    lineNumberAreaPaintEvent(QPaintEvent *event);
    void    asciiAreaPaintEvent(QPaintEvent *event);
    int     lineNumberAreaWidth();
    int     asciiAreaWidth();
    int     nbs_char_area();


public slots:
    void     slot_show_up();
    void     slot_show_down();
    void     slot_resize();
    int     put_data();
    void    slot_text_changed();

protected:
    void resizeEvent(QResizeEvent *event);
    void keyPressEvent (QKeyEvent *e);
    void insertFromMimeData ( const QMimeData * source);

private slots:
    void updateLineNumberAreaWidth(int newBlockCount);
    void highlightCurrentLine();
    void updateLineNumberArea(const QRect &, int);

private:
    /** Taille des donnees a afficher */
    unsigned long                _addr;
    /** Pointeur sur les donnees a afficher */
    std::vector<unsigned char>   _data;

    /** Pointeur sur la scrollbar permettant de gerer le defilement */
    QSlider                      *_scrollbar;

    QWidget    *lineNumberArea;
    QWidget    *asciiArea;

    Mutex    _mutex;
};



class LineNumberArea : public QWidget
{
public:
     LineNumberArea(HexEditor *editor) : QWidget(editor)
     {
         this->_hexEditor = editor;
     }

     QSize    sizeHint() const
     {
         return QSize(this->_hexEditor->lineNumberAreaWidth(), 0);
     }

protected:
     void    paintEvent(QPaintEvent *event)
     {
         this->_hexEditor->lineNumberAreaPaintEvent(event);
     }

private:
     HexEditor    *_hexEditor;
};



class AsciiArea : public QWidget
{
public:
     AsciiArea(HexEditor *editor) : QWidget(editor)
     {
         this->_hexEditor = editor;
     }

     QSize    sizeHint() const
     {
         return QSize(this->_hexEditor->asciiAreaWidth(), 0);
     }

protected:
     void    paintEvent(QPaintEvent *event)
     {
         this->_hexEditor->asciiAreaPaintEvent(event);
     }

private:
     HexEditor    *_hexEditor;
};


#endif
