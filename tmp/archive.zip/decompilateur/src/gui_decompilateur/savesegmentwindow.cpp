#include    "savesegmentwindow.h"
#include    "ui_savesegmentwindow.h"


SaveSegmentWindow::SaveSegmentWindow(unsigned long addr, const unsigned char *data, unsigned long size, QWidget *parent): QDialog(parent),
    _addr(addr),
    _data(data),
    _size(size),
    ui(new Ui::Dialog3)
{
    this->ui->setupUi(this);
}

SaveSegmentWindow::~SaveSegmentWindow()
{
    delete ui;
}


/**
** \fn void slot_validate()
** \brief Gere la validation de l'enregistrement
**
** \return Retourne rien
*/
void    SaveSegmentWindow::slot_validate()
{
    qDebug("SaveSegmentWindow::slot_validate()\n");
    int    f;

    QString    filename = QFileDialog::getSaveFileName(this);
    if (filename.size() > 0)
    {
        if ((f = ::open(filename.toAscii(), O_RDWR | O_CREAT | O_TRUNC, 0644)) > 0)
        {
            if (this->ui->bt_binaire->isChecked())
                this->saveSegmentInBinaire(f);
            else if (this->ui->bt_hexdump->isChecked())
                this->saveSegmentInHexdump(f);
            else if (this->ui->bt_shellcode->isChecked())
                this->saveSegmentInShellcode(f);

            ::close(f);
        }
    }
}

/**
** \fn void saveSegmentInBinaire(int f) const
** \brief Gere l'enregistrement du segment au format binaire
**
** \param f Fichier ou enregister le segment
** \return Retourne rien
*/
void    SaveSegmentWindow::saveSegmentInBinaire(int f) const
{
    if (this->_data != NULL)
        ::write(f, this->_data, this->_size);
}

/**
** \fn void saveSegmentInHexdump(int f) const
** \brief Gere l'enregistrement du segment au format hexdump (adresse+hexa+ASCII)
**
** \param f Fichier ou enregister le segment
** \return Retourne rien
*/
void    SaveSegmentWindow::saveSegmentInHexdump(int f) const
{
    char             buffer[300];
    unsigned long    j;

    if (this->_data != NULL)
    {
        for (unsigned long i=0; i<this->_size; i+=16)
        {
            /* Adresse de la ligne */
            sprintf(buffer, "%lx:\t", this->_addr + i);

            /* Ajout des octets en hexa */
            for (j=0; (j<16) && (i+j<this->_size); j++)
                sprintf(&(buffer[strlen(buffer)]), "%02x ", this->_data[i+j]);
            for (; j<16; j++)
                strcat(buffer, "   ");

            strcat(buffer, "\t");

            /* Ajout des octets en hexa */
            for (j=0; (j<16) && (i+j<this->_size); j++)
            {
                if (isprint(this->_data[i+j]))
                    sprintf(&(buffer[strlen(buffer)]), "%c", this->_data[i+j]);
                else
                    strcat(buffer, ".");
            }

            strcat(buffer, "\n");
            ::write(f, buffer, strlen(buffer));
        }
    }

}

/**
** \fn void saveSegmentInShellcode(int f) const
** \brief Gere l'enregistrement du segment au shellcode ("\x00\xff\x11")
**
** \param f Fichier ou enregister le segment
** \return Retourne rien
*/
void    SaveSegmentWindow::saveSegmentInShellcode(int f) const
{
    char    buffer[5];

    if (this->_data != NULL)
    {
        for (unsigned long i=0; i<this->_size; i++)
        {
            ::sprintf(buffer, "\\x%02x", this->_data[i]);
            ::write(f, buffer, 4);
        }
    }
}
