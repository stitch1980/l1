#include "mainwindow.h"
#include "ui_mainwindow.h"


/**
** \fn void slot_anal__update()
** \brief Slot gerant l'actualisation de la description des analyses
**
** \return Retourne rien
*/
void    MainWindow::slot_anal__update()
{
    qDebug("MainWindow::slot_anal__update()\n");
    QList<QTreeWidgetItem*>    liste_type;
    QTreeWidgetItem            *widget_item;
    QStringList                str_list;

    this->_info.mutex.lock();

    this->ui->anal__tree_analyse->clear();
    this->ui->anal__tree_analyse->setColumnCount(2);
    if (this->ui->anal__tree_analyse->headerItem() != NULL)
    {
        this->ui->anal__tree_analyse->headerItem()->setText(0, "Analyse");
        this->ui->anal__tree_analyse->headerItem()->setText(1, QString::fromUtf8("Résultat"));
    }

    /* Pour tout les analyses */
    for (unsigned long i=0; i<this->_info.analyses.get_nbs_analyse_child(); i++)
    {
        /* Recupere le titre et le contenu de l'analyse */
        str_list.clear();
        str_list.append(QString::fromStdString(this->_info.analyses.get_title_analyse_child_num(i)));
        str_list.append(QString::fromStdString(this->_info.analyses.get_txt_analyse_child_num(i)));

        /* Creation de l'item */
        if ((widget_item = new QTreeWidgetItem(this->ui->anal__tree_analyse, str_list)) != NULL)
        {
            widget_item->setBackground(0, QBrush(QColor(200, 200, 200)));
            widget_item->setBackground(1, QBrush(QColor(200, 200, 200)));
            widget_item->setBackground(2, QBrush(QColor(200, 200, 200)));

            this->slot_anal__list_type_son(widget_item, this->_info.analyses.get_analyse_child_num(i), 1);
            liste_type.append(widget_item);
        }
    }

    this->ui->anal__tree_analyse->insertTopLevelItems(0, liste_type);

    this->_info.mutex.unlock();
    this->slot_anal__tree_analyse_clicked();
}

/**
** \fn void slot_anal__list_type_son(QTreeWidgetItem *item, const Analyse *analyse, unsigned int profondeur=1)
** \brief Permet d'ajouter les rapports d'analyses au tableau afin de les afficher
**
** \param item Classe contenant les infos du rapport a afficher
** \param analyse Analyse dont les analyses filles doivent etre affichees
** \param profondeur Profondeur de la recursion pour l'affichage
** \return Retourne rien
*/
void    MainWindow::slot_anal__list_type_son(QTreeWidgetItem *item, const Analyse *analyse, unsigned int profondeur)
{
    QTreeWidgetItem    *son;
    QStringList        str_list;
    unsigned int       color;

    if ((item != NULL) && (profondeur < 7))
    {
        /* Choix de la couleur de l'affichage en fonction de la profondeur */
        color = 200 + (profondeur * 15);
        if (color > 255)
            color = 255;

        for (unsigned long i=0; i<analyse->get_nbs_analyse_child(); i++)
        {
            str_list.clear();
            str_list.append(QString::fromStdString(analyse->get_title_analyse_child_num(i)));
            str_list.append(QString::fromStdString(analyse->get_txt_analyse_child_num(i)));

            /* Creation de l'item */
            if ((son = new QTreeWidgetItem(item, str_list)) != NULL)
            {
                son->setBackground(0, QBrush(QColor(color, color, color)));
                son->setBackground(1, QBrush(QColor(color, color, color)));
                son->setBackground(2, QBrush(QColor(color, color, color)));

                this->slot_anal__list_type_son(son, analyse->get_analyse_child_num(i), profondeur+1);
                item->insertChild(i, son);
            }
        }
    }
}

/**
** \fn void slot_anal__tree_analyse_clicked()
** \brief Gere les clics sur la liste des analyses
**
** \return Retourne rien
*/
void    MainWindow::slot_anal__tree_analyse_clicked()
{
    qDebug("MainWindow::slot_anal__tree_analyse_clicked()\n");

    /* Par defaut tout les boutons sont bloques */
    this->ui->anal__bt_save->setEnabled(false);
    this->ui->anal__bt_save_all->setEnabled(false);
    this->ui->anal__bt_delete->setEnabled(false);
    this->ui->anal__bt_delete_all->setEnabled(false);

    /* S'il y a au moins, une analyse, on peut tout enregister/supprimer */
    if (this->ui->anal__tree_analyse->topLevelItemCount() > 0)
    {
        this->ui->anal__bt_save_all->setEnabled(true);
        this->ui->anal__bt_delete_all->setEnabled(true);

        /* Si une analyse est selectionnee, on peut l'enregister/supprimer */
        if (this->ui->anal__tree_analyse->currentItem() != NULL)
        {
            this->ui->anal__bt_save->setEnabled(true);
            this->ui->anal__bt_delete->setEnabled(true);
        }
    }
}

/**
** \fn void slot_anal__bt_save()
** \brief Gere l'enregistrement de la partie de l'analyse selectionnees
**
** \return Retourne rien
*/
void    MainWindow::slot_anal__bt_save()
{
    qDebug("MainWindow::slot_anal__bt_save()\n");
    std::list<std::string>    list_name_analyse;
    QTreeWidgetItem           *item;
    Analyse                   *analyse;
    int                       f;

    this->_info.mutex.lock();

    if ((item = this->ui->anal__tree_analyse->currentItem()) != NULL)
    {
        QString    filename = QFileDialog::getSaveFileName(this);
        if (filename.size() > 0)
        {
            if ((f = ::open(filename.toAscii(), O_RDWR | O_CREAT | O_TRUNC, 0644)) > 0)
            {
                /* Recupere le nom de tout les items parents de l'analyse */
                while (item != NULL)
                {
                    list_name_analyse.push_back(item->text(0).toStdString());
                    item = item->parent();
                }

                /* Cherche le parent de l'analyse a enregister */
                analyse = &(this->_info.analyses);
                while ( (list_name_analyse.size() > 1) &&
                        ((analyse = analyse->get_analyse_child(list_name_analyse.back())) != NULL) )
                   list_name_analyse.pop_back();

                /* Enregistre l'analyse */
                if (analyse != NULL)
                    this->slot_anal__save_analyse_rec(f, analyse->get_analyse_child(list_name_analyse.back()), list_name_analyse.back(), 0);

                ::close(f);
            }
        }
    }

    this->_info.mutex.unlock();
}

/**
** \fn void slot_anal__bt_save_all()
** \brief Gere l'enregistrement de toute les analyses
**
** \return Retourne rien
*/
void    MainWindow::slot_anal__bt_save_all()
{
    qDebug("MainWindow::slot_anal__bt_save_all()\n");
    int    f;

    this->_info.mutex.lock();

    QString    filename = QFileDialog::getSaveFileName(this);
    if (filename.size() > 0)
    {
        if ((f = ::open(filename.toAscii(), O_RDWR | O_CREAT | O_TRUNC, 0644)) > 0)
        {
            for (unsigned long i=0; i<this->_info.analyses.get_nbs_analyse_child(); i++)
                this->slot_anal__save_analyse_rec(f, this->_info.analyses.get_analyse_child_num(i),
                                                  this->_info.analyses.get_title_analyse_child_num(i), 0);

            ::close(f);
        }
    }

    this->_info.mutex.unlock();
}

/**
** \fn void slot_anal__bt_delete()
** \brief Gere la suppression de la partie de l'analyse selectionnees
**
** \return Retourne rien
*/
void    MainWindow::slot_anal__bt_delete()
{
    qDebug("MainWindow::slot_anal__bt_delete()\n");
    std::list<std::string>    list_name_analyse;
    QTreeWidgetItem           *item;
    Analyse                   *analyse;

    this->_info.mutex.lock();

    if ((item = this->ui->anal__tree_analyse->currentItem()) != NULL)
    {
        /* Recupere le nom de tout les items parents de l'analyse */
        while (item != NULL)
        {
            list_name_analyse.push_back(item->text(0).toStdString());
            item = item->parent();
        }

        /* Cherche le parent de l'analyse a supprimer */
        analyse = &(this->_info.analyses);
        while ( (list_name_analyse.size() > 1) &&
                ((analyse = analyse->get_analyse_child(list_name_analyse.back())) != NULL) )
           list_name_analyse.pop_back();

        /* Supprime l'analyse */
        if (analyse != NULL)
            analyse->del_analyse_child(list_name_analyse.back());

        /* Supprime l'element courant (pour ne pas avoir a actualiser toute la liste) */
        delete this->ui->anal__tree_analyse->currentItem();
    }

    this->_info.mutex.unlock();
    this->slot_anal__tree_analyse_clicked();
}

/**
** \fn void slot_anal__bt_delete_all()
** \brief Gere la suppression de toute les analyses
**
** \return Retourne rien
*/
void    MainWindow::slot_anal__bt_delete_all()
{
    qDebug("MainWindow::slot_anal__bt_delete_all()\n");

    this->_info.mutex.lock();

    this->_info.analyses.clear();

    this->_info.mutex.unlock();
    this->slot_anal__update();
}

/**
** \fn void slot_anal__save_analyse_rec(int f, Analyse *analyse, const std::string &title, unsigned long profondeur)
** \brief Fonction recursif permettant l'enregistrement d'une analyse et de ses sous-analyses
**
** \param f Fichier ou enregistrer l'analyse
** \param analyse Analyse a enregistrer
** \param title Titre de l'ananlyse
** \param profondeur Profondeur de l'analyse/sous-analyse
** \return Retourne rien
*/
void    MainWindow::slot_anal__save_analyse_rec(int f, Analyse *analyse, const std::string &title, unsigned long profondeur)
{
    std::string      str;
    std::string      indent;
    unsigned long    pos;

    if ((f > 0) && (analyse != NULL))
    {
        /* Preparation de l'indentation */
        indent = "";
        for (unsigned long i=0; i<profondeur; i++)
            indent += "\t";

        /* Preparation et ecriture du titre de l'analyse */
        str = indent + title;
        pos = 0;
        while ((pos = str.find("\n", pos+1)) != std::string::npos)
            str.replace(pos, 1, "\n" + indent);
        ::write(f, str.c_str(), str.size());

        /* Preparation et ecriture du contenu de l'analyse */
        indent = "\t";
        str = "\t" + analyse->get_txt_analyse();
        pos = 0;
        while ((pos = str.find("\n", pos+1)) != std::string::npos)
            str.replace(pos, 1, "\n" + indent);
        ::write(f, str.c_str(), str.size());
        ::write(f, "\n", 1);

        /* Sauvegarde des analyses fille */
        if (analyse->get_nbs_analyse_child() > 0)
        {
            for (unsigned long i=0; i<analyse->get_nbs_analyse_child(); i++)
                this->slot_anal__save_analyse_rec(f, analyse->get_analyse_child_num(i),
                                                  analyse->get_title_analyse_child_num(i), profondeur+1);
            ::write(f, "\n", 1);
        }
    }
}
