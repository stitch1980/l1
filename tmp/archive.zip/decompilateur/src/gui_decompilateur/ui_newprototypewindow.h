/********************************************************************************
** Form generated from reading UI file 'newprototypewindow.ui'
**
** Created: Thu May 14 13:50:04 2015
**      by: Qt User Interface Compiler version 4.8.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_NEWPROTOTYPEWINDOW_H
#define UI_NEWPROTOTYPEWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QDialogButtonBox>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QTableWidget>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_DialogNewPrototype
{
public:
    QVBoxLayout *verticalLayout_5;
    QWidget *widget;
    QHBoxLayout *horizontalLayout;
    QWidget *widget_6;
    QHBoxLayout *horizontalLayout_2;
    QWidget *widget_num;
    QVBoxLayout *verticalLayout;
    QLabel *label;
    QLineEdit *field_num;
    QWidget *widget_3;
    QVBoxLayout *verticalLayout_2;
    QLabel *label_2;
    QLineEdit *field_ret;
    QWidget *widget_4;
    QVBoxLayout *verticalLayout_3;
    QLabel *label_3;
    QLineEdit *field_name;
    QWidget *widget_5;
    QVBoxLayout *verticalLayout_4;
    QLabel *label_4;
    QLineEdit *field_param;
    QWidget *widget_7;
    QHBoxLayout *horizontalLayout_3;
    QTableWidget *tab_param;
    QWidget *widget_8;
    QVBoxLayout *verticalLayout_6;
    QSpacerItem *verticalSpacer;
    QPushButton *tab_param__new;
    QPushButton *tab_param__edit;
    QPushButton *tab_param__up;
    QPushButton *tab_param__down;
    QSpacerItem *verticalSpacer_3;
    QPushButton *tab_param__delete;
    QSpacerItem *verticalSpacer_2;
    QDialogButtonBox *buttonBox;

    void setupUi(QDialog *DialogNewPrototype)
    {
        if (DialogNewPrototype->objectName().isEmpty())
            DialogNewPrototype->setObjectName(QString::fromUtf8("DialogNewPrototype"));
        DialogNewPrototype->resize(926, 417);
        verticalLayout_5 = new QVBoxLayout(DialogNewPrototype);
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        widget = new QWidget(DialogNewPrototype);
        widget->setObjectName(QString::fromUtf8("widget"));
        horizontalLayout = new QHBoxLayout(widget);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        widget_6 = new QWidget(widget);
        widget_6->setObjectName(QString::fromUtf8("widget_6"));
        horizontalLayout_2 = new QHBoxLayout(widget_6);
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        widget_num = new QWidget(widget_6);
        widget_num->setObjectName(QString::fromUtf8("widget_num"));
        widget_num->setMaximumSize(QSize(16777215, 16777215));
        verticalLayout = new QVBoxLayout(widget_num);
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        label = new QLabel(widget_num);
        label->setObjectName(QString::fromUtf8("label"));
        label->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(label);

        field_num = new QLineEdit(widget_num);
        field_num->setObjectName(QString::fromUtf8("field_num"));
        field_num->setMaximumSize(QSize(16777215, 16777215));

        verticalLayout->addWidget(field_num);


        horizontalLayout_2->addWidget(widget_num);

        widget_3 = new QWidget(widget_6);
        widget_3->setObjectName(QString::fromUtf8("widget_3"));
        verticalLayout_2 = new QVBoxLayout(widget_3);
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        label_2 = new QLabel(widget_3);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setAlignment(Qt::AlignCenter);

        verticalLayout_2->addWidget(label_2);

        field_ret = new QLineEdit(widget_3);
        field_ret->setObjectName(QString::fromUtf8("field_ret"));

        verticalLayout_2->addWidget(field_ret);


        horizontalLayout_2->addWidget(widget_3);

        widget_4 = new QWidget(widget_6);
        widget_4->setObjectName(QString::fromUtf8("widget_4"));
        verticalLayout_3 = new QVBoxLayout(widget_4);
        verticalLayout_3->setContentsMargins(0, 0, 0, 0);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        label_3 = new QLabel(widget_4);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setAlignment(Qt::AlignCenter);

        verticalLayout_3->addWidget(label_3);

        field_name = new QLineEdit(widget_4);
        field_name->setObjectName(QString::fromUtf8("field_name"));

        verticalLayout_3->addWidget(field_name);


        horizontalLayout_2->addWidget(widget_4);


        horizontalLayout->addWidget(widget_6);

        widget_5 = new QWidget(widget);
        widget_5->setObjectName(QString::fromUtf8("widget_5"));
        verticalLayout_4 = new QVBoxLayout(widget_5);
        verticalLayout_4->setContentsMargins(0, 0, 0, 0);
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        label_4 = new QLabel(widget_5);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setAlignment(Qt::AlignCenter);

        verticalLayout_4->addWidget(label_4);

        field_param = new QLineEdit(widget_5);
        field_param->setObjectName(QString::fromUtf8("field_param"));

        verticalLayout_4->addWidget(field_param);


        horizontalLayout->addWidget(widget_5);


        verticalLayout_5->addWidget(widget);

        widget_7 = new QWidget(DialogNewPrototype);
        widget_7->setObjectName(QString::fromUtf8("widget_7"));
        horizontalLayout_3 = new QHBoxLayout(widget_7);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        tab_param = new QTableWidget(widget_7);
        if (tab_param->columnCount() < 2)
            tab_param->setColumnCount(2);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        tab_param->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        tab_param->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        tab_param->setObjectName(QString::fromUtf8("tab_param"));
        tab_param->setEditTriggers(QAbstractItemView::NoEditTriggers);
        tab_param->horizontalHeader()->setStretchLastSection(true);

        horizontalLayout_3->addWidget(tab_param);

        widget_8 = new QWidget(widget_7);
        widget_8->setObjectName(QString::fromUtf8("widget_8"));
        verticalLayout_6 = new QVBoxLayout(widget_8);
        verticalLayout_6->setObjectName(QString::fromUtf8("verticalLayout_6"));
        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_6->addItem(verticalSpacer);

        tab_param__new = new QPushButton(widget_8);
        tab_param__new->setObjectName(QString::fromUtf8("tab_param__new"));

        verticalLayout_6->addWidget(tab_param__new);

        tab_param__edit = new QPushButton(widget_8);
        tab_param__edit->setObjectName(QString::fromUtf8("tab_param__edit"));

        verticalLayout_6->addWidget(tab_param__edit);

        tab_param__up = new QPushButton(widget_8);
        tab_param__up->setObjectName(QString::fromUtf8("tab_param__up"));

        verticalLayout_6->addWidget(tab_param__up);

        tab_param__down = new QPushButton(widget_8);
        tab_param__down->setObjectName(QString::fromUtf8("tab_param__down"));

        verticalLayout_6->addWidget(tab_param__down);

        verticalSpacer_3 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_6->addItem(verticalSpacer_3);

        tab_param__delete = new QPushButton(widget_8);
        tab_param__delete->setObjectName(QString::fromUtf8("tab_param__delete"));

        verticalLayout_6->addWidget(tab_param__delete);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_6->addItem(verticalSpacer_2);


        horizontalLayout_3->addWidget(widget_8);


        verticalLayout_5->addWidget(widget_7);

        buttonBox = new QDialogButtonBox(DialogNewPrototype);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);

        verticalLayout_5->addWidget(buttonBox);


        retranslateUi(DialogNewPrototype);
        QObject::connect(buttonBox, SIGNAL(accepted()), DialogNewPrototype, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), DialogNewPrototype, SLOT(reject()));
        QObject::connect(DialogNewPrototype, SIGNAL(accepted()), DialogNewPrototype, SLOT(slot_validate()));
        QObject::connect(field_num, SIGNAL(textEdited(QString)), DialogNewPrototype, SLOT(slot_check()));
        QObject::connect(field_ret, SIGNAL(textEdited(QString)), DialogNewPrototype, SLOT(slot_check()));
        QObject::connect(field_name, SIGNAL(textEdited(QString)), DialogNewPrototype, SLOT(slot_check()));
        QObject::connect(tab_param__new, SIGNAL(clicked()), DialogNewPrototype, SLOT(slot_param__new()));
        QObject::connect(tab_param__up, SIGNAL(clicked()), DialogNewPrototype, SLOT(slot_param__up()));
        QObject::connect(tab_param__down, SIGNAL(clicked()), DialogNewPrototype, SLOT(slot_param__down()));
        QObject::connect(tab_param__delete, SIGNAL(clicked()), DialogNewPrototype, SLOT(slot_param__delete()));
        QObject::connect(field_param, SIGNAL(editingFinished()), DialogNewPrototype, SLOT(slot_param__line_to_tab()));
        QObject::connect(field_param, SIGNAL(textEdited(QString)), DialogNewPrototype, SLOT(slot_check()));
        QObject::connect(tab_param, SIGNAL(currentCellChanged(int,int,int,int)), DialogNewPrototype, SLOT(slot_param__clicked()));
        QObject::connect(tab_param__edit, SIGNAL(clicked()), DialogNewPrototype, SLOT(slot_param__edit()));

        QMetaObject::connectSlotsByName(DialogNewPrototype);
    } // setupUi

    void retranslateUi(QDialog *DialogNewPrototype)
    {
        DialogNewPrototype->setWindowTitle(QApplication::translate("DialogNewPrototype", "Dialog", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("DialogNewPrototype", "Num\303\251ro", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("DialogNewPrototype", "type de retour", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("DialogNewPrototype", "Nom", 0, QApplication::UnicodeUTF8));
        label_4->setText(QApplication::translate("DialogNewPrototype", "Param\303\250tres", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem = tab_param->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QApplication::translate("DialogNewPrototype", "Type", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem1 = tab_param->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QApplication::translate("DialogNewPrototype", "Nom", 0, QApplication::UnicodeUTF8));
        tab_param__new->setText(QApplication::translate("DialogNewPrototype", "Nouveau", 0, QApplication::UnicodeUTF8));
        tab_param__edit->setText(QApplication::translate("DialogNewPrototype", "Editer", 0, QApplication::UnicodeUTF8));
        tab_param__up->setText(QApplication::translate("DialogNewPrototype", "\342\206\221", 0, QApplication::UnicodeUTF8));
        tab_param__down->setText(QApplication::translate("DialogNewPrototype", "\342\206\223", 0, QApplication::UnicodeUTF8));
        tab_param__delete->setText(QApplication::translate("DialogNewPrototype", "Supprimer", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class DialogNewPrototype: public Ui_DialogNewPrototype {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_NEWPROTOTYPEWINDOW_H
