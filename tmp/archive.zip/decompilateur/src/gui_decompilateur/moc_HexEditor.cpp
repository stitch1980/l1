/****************************************************************************
** Meta object code from reading C++ file 'HexEditor.hpp'
**
** Created: Thu May 14 13:50:57 2015
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "HexEditor.hpp"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'HexEditor.hpp' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_HexEditor[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       8,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      11,   10,   10,   10, 0x0a,
      26,   10,   10,   10, 0x0a,
      43,   10,   10,   10, 0x0a,
      61,   10,   57,   10, 0x0a,
      72,   10,   10,   10, 0x0a,
     106,   92,   10,   10, 0x08,
     137,   10,   10,   10, 0x08,
     162,  160,   10,   10, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_HexEditor[] = {
    "HexEditor\0\0slot_show_up()\0slot_show_down()\0"
    "slot_resize()\0int\0put_data()\0"
    "slot_text_changed()\0newBlockCount\0"
    "updateLineNumberAreaWidth(int)\0"
    "highlightCurrentLine()\0,\0"
    "updateLineNumberArea(QRect,int)\0"
};

void HexEditor::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        HexEditor *_t = static_cast<HexEditor *>(_o);
        switch (_id) {
        case 0: _t->slot_show_up(); break;
        case 1: _t->slot_show_down(); break;
        case 2: _t->slot_resize(); break;
        case 3: { int _r = _t->put_data();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 4: _t->slot_text_changed(); break;
        case 5: _t->updateLineNumberAreaWidth((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 6: _t->highlightCurrentLine(); break;
        case 7: _t->updateLineNumberArea((*reinterpret_cast< const QRect(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData HexEditor::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject HexEditor::staticMetaObject = {
    { &QPlainTextEdit::staticMetaObject, qt_meta_stringdata_HexEditor,
      qt_meta_data_HexEditor, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &HexEditor::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *HexEditor::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *HexEditor::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_HexEditor))
        return static_cast<void*>(const_cast< HexEditor*>(this));
    return QPlainTextEdit::qt_metacast(_clname);
}

int HexEditor::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QPlainTextEdit::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 8)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 8;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
