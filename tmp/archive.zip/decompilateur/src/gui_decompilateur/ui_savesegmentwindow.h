/********************************************************************************
** Form generated from reading UI file 'savesegmentwindow.ui'
**
** Created: Thu May 14 13:50:04 2015
**      by: Qt User Interface Compiler version 4.8.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SAVESEGMENTWINDOW_H
#define UI_SAVESEGMENTWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QDialogButtonBox>
#include <QtGui/QHeaderView>
#include <QtGui/QRadioButton>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Dialog3
{
public:
    QVBoxLayout *verticalLayout;
    QWidget *widget;
    QVBoxLayout *verticalLayout_2;
    QRadioButton *bt_binaire;
    QRadioButton *bt_hexdump;
    QRadioButton *bt_shellcode;
    QDialogButtonBox *buttonBox;

    void setupUi(QDialog *Dialog3)
    {
        if (Dialog3->objectName().isEmpty())
            Dialog3->setObjectName(QString::fromUtf8("Dialog3"));
        Dialog3->resize(400, 300);
        verticalLayout = new QVBoxLayout(Dialog3);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        widget = new QWidget(Dialog3);
        widget->setObjectName(QString::fromUtf8("widget"));
        verticalLayout_2 = new QVBoxLayout(widget);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        bt_binaire = new QRadioButton(widget);
        bt_binaire->setObjectName(QString::fromUtf8("bt_binaire"));
        bt_binaire->setChecked(true);

        verticalLayout_2->addWidget(bt_binaire);

        bt_hexdump = new QRadioButton(widget);
        bt_hexdump->setObjectName(QString::fromUtf8("bt_hexdump"));

        verticalLayout_2->addWidget(bt_hexdump);

        bt_shellcode = new QRadioButton(widget);
        bt_shellcode->setObjectName(QString::fromUtf8("bt_shellcode"));

        verticalLayout_2->addWidget(bt_shellcode);


        verticalLayout->addWidget(widget);

        buttonBox = new QDialogButtonBox(Dialog3);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        buttonBox->setCenterButtons(false);

        verticalLayout->addWidget(buttonBox);


        retranslateUi(Dialog3);
        QObject::connect(buttonBox, SIGNAL(accepted()), Dialog3, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), Dialog3, SLOT(reject()));
        QObject::connect(Dialog3, SIGNAL(accepted()), Dialog3, SLOT(slot_validate()));

        QMetaObject::connectSlotsByName(Dialog3);
    } // setupUi

    void retranslateUi(QDialog *Dialog3)
    {
        Dialog3->setWindowTitle(QApplication::translate("Dialog3", "Dialog", 0, QApplication::UnicodeUTF8));
        bt_binaire->setText(QApplication::translate("Dialog3", "Format binaire", 0, QApplication::UnicodeUTF8));
        bt_hexdump->setText(QApplication::translate("Dialog3", "Format Adresse+Hexa+ASCII", 0, QApplication::UnicodeUTF8));
        bt_shellcode->setText(QApplication::translate("Dialog3", "Format shellcode (x00xaax11xbb)", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class Dialog3: public Ui_Dialog3 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SAVESEGMENTWINDOW_H
