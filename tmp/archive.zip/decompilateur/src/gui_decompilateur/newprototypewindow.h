#ifndef NEWPROTOTYPEWINDOW_H
#define NEWPROTOTYPEWINDOW_H

#include    <QMainWindow>
#include    <QApplication>
#include    <QtGui>
#include    <QDialog>

#include    "Info.hpp"
#include    "Calcul.hpp"

namespace Ui
{
    class DialogNewPrototype;
}


class NewPrototypeWindow : public QDialog
{
    Q_OBJECT
public:
    explicit NewPrototypeWindow(unsigned long *num, std::string *ret, std::string *name,
                                std::vector<std::pair<std::string, std::string> > *param,
                                const Info *info, QWidget *parent=0);
    ~NewPrototypeWindow();

    /**
    ** \fn int is_ok()
    ** \brief Permet de le formulaire de creation de prototype a bien ete valide
    **
    ** \return Retourne 1 si le formulaire a ete valide, 0 sinon
    */
    int    is_ok();

public slots:
    /**
    ** \fn void slot_validate()
    ** \brief Permet de valider les modifications du prototype
    **
    ** \return Retourne rien
    */
    void    slot_validate();

    /**
    ** \fn void slot_check()
    ** \brief Permet de verifier que les champs sont valides
    **
    ** \return Retourne rien
    */
    void    slot_check();

    /**
    ** \fn void slot_param__clicked()
    ** \brief Gere les clics dans la liste des parametres
    **
    ** \return Retourne rien
    */
    void    slot_param__clicked();

    /**
    ** \fn void slot_param__new()
    ** \brief Ajoute un parametre a la fonction
    **
    ** \return Retourne rien
    */
    void    slot_param__new();

    /**
    ** \fn void slot_param__edit()
    ** \brief Modifie un parametre de la fonction
    **
    ** \return Retourne rien
    */
    void    slot_param__edit();

    /**
    ** \fn void slot_param__delete()
    ** \brief Supprime un parametre de la fonction
    **
    ** \return Retourne rien
    */
    void    slot_param__delete();

    /**
    ** \fn void slot_param__up()
    ** \brief Monte un parametre de la fonction
    **
    ** \return Retourne rien
    */
    void    slot_param__up();

    /**
    ** \fn void slot_param__down()
    ** \brief Descend un parametre de la fonction
    **
    ** \return Retourne rien
    */
    void    slot_param__down();

    /**
    ** \fn void slot_param__tab_to_line()
    ** \brief Extrait les parametres du tableau pour les mettre dans la ligne de parametres
    **
    ** \return Retourne rien
    */
    void    slot_param__tab_to_line();

    /**
    ** \fn void slot_param__line_to_tab()
    ** \brief Extrait les parametres de la ligne pour les mettre dans le tableau de parametres
    **
    ** \return Retourne rien
    */
    void    slot_param__line_to_tab();

protected:
    /** Permet de savoir si tout c'est bien passe */
    int                                                   _ok;

    /** Pointeur sur le numero de l'interruption (Vaut NULL si c'est un prototype de fonction) */
    unsigned long                                        *_num;
    /** Pointeur sur le type de la valeur de retour */
    std::string                                          *_ret;
    /** Pointeur sur le nom de la fonction */
    std::string                                          *_name;
    /** Pointeur sur les parametres <type_complet, nom> */
    std::vector<std::pair<std::string, std::string> >    *_param;
    /** Pointeur sur la structure contenant les infos du programme */
    const Info                                           *_info;

    /** Interface graphique du menu */
    Ui::DialogNewPrototype                               *ui;
};





namespace Ui
{
    class DialogNewParametreFonction;
}

class NewParametreFonctionWindow : public QDialog
{
    Q_OBJECT
public:
    explicit NewParametreFonctionWindow(std::string &type, std::string &name, const PrototypeT *proto, QWidget *parent = 0);
    ~NewParametreFonctionWindow();

public slots:
    /**
    ** \fn void slot_validate()
    ** \brief Gere la validation des changements effectuee par le menu
    **
    ** \return Retourne rien
    */
    void    slot_validate();

    /**
    ** \fn void slot_check_formulaire()
    ** \brief Slot Permettant de verifier que le contenu des champs est valide
    **
    ** \return Retourne rien
    */
    void    slot_check_formulaire();

protected:
    /** Type de la structure devant contenir l'attribut */
    std::string                       _parent_type;
    /** Type de l'attribut */
    std::string                       *_type;
    /** Nom de l'attribut */
    std::string                       *_name;
    /** Pointeur sur le gestionnaire de definition de type */
    const PrototypeT                  *_proto;

    /** Interface graphique du menu */
    Ui::DialogNewParametreFonction    *ui;

};

#endif
