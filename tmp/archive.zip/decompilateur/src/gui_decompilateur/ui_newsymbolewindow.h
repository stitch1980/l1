/********************************************************************************
** Form generated from reading UI file 'newsymbolewindow.ui'
**
** Created: Thu May 14 13:50:04 2015
**      by: Qt User Interface Compiler version 4.8.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_NEWSYMBOLEWINDOW_H
#define UI_NEWSYMBOLEWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QComboBox>
#include <QtGui/QDialog>
#include <QtGui/QDialogButtonBox>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Dialog4
{
public:
    QVBoxLayout *verticalLayout;
    QWidget *widget;
    QVBoxLayout *verticalLayout_2;
    QWidget *widget_2;
    QHBoxLayout *horizontalLayout;
    QLabel *label;
    QLineEdit *field_value;
    QWidget *widget_3;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_2;
    QLineEdit *field_name;
    QWidget *widget_4;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_3;
    QComboBox *field_type;
    QDialogButtonBox *buttonBox;

    void setupUi(QDialog *Dialog4)
    {
        if (Dialog4->objectName().isEmpty())
            Dialog4->setObjectName(QString::fromUtf8("Dialog4"));
        Dialog4->resize(417, 232);
        verticalLayout = new QVBoxLayout(Dialog4);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        widget = new QWidget(Dialog4);
        widget->setObjectName(QString::fromUtf8("widget"));
        verticalLayout_2 = new QVBoxLayout(widget);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        widget_2 = new QWidget(widget);
        widget_2->setObjectName(QString::fromUtf8("widget_2"));
        horizontalLayout = new QHBoxLayout(widget_2);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        label = new QLabel(widget_2);
        label->setObjectName(QString::fromUtf8("label"));

        horizontalLayout->addWidget(label);

        field_value = new QLineEdit(widget_2);
        field_value->setObjectName(QString::fromUtf8("field_value"));

        horizontalLayout->addWidget(field_value);


        verticalLayout_2->addWidget(widget_2);

        widget_3 = new QWidget(widget);
        widget_3->setObjectName(QString::fromUtf8("widget_3"));
        horizontalLayout_2 = new QHBoxLayout(widget_3);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        label_2 = new QLabel(widget_3);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        horizontalLayout_2->addWidget(label_2);

        field_name = new QLineEdit(widget_3);
        field_name->setObjectName(QString::fromUtf8("field_name"));

        horizontalLayout_2->addWidget(field_name);


        verticalLayout_2->addWidget(widget_3);

        widget_4 = new QWidget(widget);
        widget_4->setObjectName(QString::fromUtf8("widget_4"));
        horizontalLayout_3 = new QHBoxLayout(widget_4);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        label_3 = new QLabel(widget_4);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        horizontalLayout_3->addWidget(label_3);

        field_type = new QComboBox(widget_4);
        field_type->setObjectName(QString::fromUtf8("field_type"));

        horizontalLayout_3->addWidget(field_type);


        verticalLayout_2->addWidget(widget_4);


        verticalLayout->addWidget(widget);

        buttonBox = new QDialogButtonBox(Dialog4);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);

        verticalLayout->addWidget(buttonBox);


        retranslateUi(Dialog4);
        QObject::connect(buttonBox, SIGNAL(accepted()), Dialog4, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), Dialog4, SLOT(reject()));
        QObject::connect(Dialog4, SIGNAL(accepted()), Dialog4, SLOT(slot_validate()));
        QObject::connect(field_value, SIGNAL(textChanged(QString)), Dialog4, SLOT(slot_check_formulaire()));
        QObject::connect(field_name, SIGNAL(textChanged(QString)), Dialog4, SLOT(slot_check_formulaire()));

        QMetaObject::connectSlotsByName(Dialog4);
    } // setupUi

    void retranslateUi(QDialog *Dialog4)
    {
        Dialog4->setWindowTitle(QApplication::translate("Dialog4", "Editeur de symbole", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("Dialog4", "Valeur :", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("Dialog4", "Nom :", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("Dialog4", "Type :", 0, QApplication::UnicodeUTF8));
        field_type->clear();
        field_type->insertItems(0, QStringList()
         << QApplication::translate("Dialog4", "FUNC", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("Dialog4", "VAR", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("Dialog4", "NONE", 0, QApplication::UnicodeUTF8)
        );
    } // retranslateUi

};

namespace Ui {
    class Dialog4: public Ui_Dialog4 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_NEWSYMBOLEWINDOW_H
