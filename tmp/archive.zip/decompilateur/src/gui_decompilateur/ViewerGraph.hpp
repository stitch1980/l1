#ifndef    VIEWER_GRAPH_HPP_
#define    VIEWER_GRAPH_HPP_

#include    <cmath>

#include    <QtGui/QGraphicsView>
#include    <QtGui>

#include    "Calcul.hpp"
#include    "Info.hpp"
#include    "INode.hpp"

/** Nombre de graphes maximum pouvant etre gardes en memoire pour ne pas avoir a les regenerer */
#define    GRAPHE__NBS_GRAPH_MAX    10

/**
** \class ViewerGraph
** \brief Classe gerant l'affichage des graphes
*/
class    ViewerGraph: public QGraphicsView
{
    Q_OBJECT

public:
    /**
    ** \fn ViewerGraph(QWidget *parent)
    ** \brief Constructeur de l'afficheur de graphes
    **
    ** \param parent Pointeur sur le widget parent de l'afficheur
    */
    ViewerGraph(QWidget *parent);

    /**
    ** \fn ~ViewerScenario()
    ** \brief Destructeur de l'afficheur de graphes
    */
    ~ViewerGraph();

private:
    ViewerGraph(const ViewerGraph& c);
    ViewerGraph& operator = (const ViewerGraph& v);

public:
    /**
    ** \fn void clear()
    ** \brief Vide competement l'afficheur de graphes
    **
    ** \return Retourne rien
    */
    void              clear();

    /**
    ** \fn void del_scene(const std::string &name)
    ** \brief Gere la suppression d'une scene de la liste
    **
    ** \param name Nom de la scene a supprimer
    ** \return Retourne rien
    */
    void              del_scene(const std::string &name);

    /**
    ** \fn QGraphicsScene *find_scene(const std::string &name) const
    ** \brief Gere la suppression de la scene ayant ete utilisee il y a le plus longtemps
    **
    ** \return Retourne rien
    */
    void              del_one_scene();

    /**
    ** \fn std::string make_scene_name(unsigned long addr)
    ** \brief Gere la generation d'un nom de scene a partir d'une adresse
    **
    ** \param addr Adresse a utiliser pour generer le nom
    ** \return Retourne le nom de la scene
    */
    std::string       make_scene_name(unsigned long addr);

protected:
    /**
    ** \fn void wheelEvent(QWheelEvent *event)
    ** \brief Gestion de la molette de la souris
    **
    ** \param event Pointeur sur la description de l'evenement
    ** \return Retourne rien
    */
    void              wheelEvent(QWheelEvent *event);

    /**
    ** \fn void scaleView(qreal scaleFactor)
    ** \brief Gere le zoom sur la scene contenant le scenario
    **
    ** \param scaleFactor Valeur du zoom a effectuer
    ** \return Retourne rien
    */
    void              scaleView(qreal scaleFactor);

    /**
    ** \fn QGraphicsScene *find_scene(const std::string &name)
    ** \brief Cherche une scene dans la liste des scenes sauvegardees
    **
    ** \param name Nom de la scene a trouver
    ** \return Retourne un pointeur sur la scene si on la trouve, NULL sinon
    */
    QGraphicsScene    *find_scene(const std::string &name);

    /**
    ** \fn void add_scene(const std::string &name, QGraphicsScene *scene)
    ** \brief Gere l'ajout d'une scene dans la liste des scenes sauvegardees
    **
    ** \param name Nom de la scene
    ** \param scene Scene a ajouter a la liste
    ** \return Retourne rien
    */
    void              add_scene(const std::string &name, QGraphicsScene *scene);

protected:
    /** Pointeur sur la structure contenant les infos du programme a analyser */
    Info                                                    *_info;
    
    /** Liste contenant les graphes gerdes en memoire <nom, graphes> */
    std::list< std::pair<std::string, QGraphicsScene*> >    _saved_graph;
};

#endif

