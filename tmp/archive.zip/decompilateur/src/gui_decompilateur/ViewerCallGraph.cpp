#include    "ViewerCallGraph.hpp"
#include    "Edge.hpp"

#include    "mainwindow.h"

#include    "ui_GetDescriptionWindow.h"

#include "/usr/include/graphviz/gvc.h"


ViewerCallGraph::ViewerCallGraph(QWidget *parent): ViewerGraph(parent)
{
}

ViewerCallGraph::~ViewerCallGraph()
{
    this->ViewerGraph::clear();
}


/**
** \fn int show(Info *info, unsigned long entry, unsigned long profondeur, MainWindow *window)
** \brief Gere l'affichage d'un callgraphe
**
** \param info Structure contenant les infos du programme a analyser
** \param entry Adresse de la fonction a partir de laquelle tracer le callgraph
** \param profondeur Profondeur du callgraphe
** \param window Window contenant le graphe
** \return Retourne 1 si OK, 0 sinon
*/
int    ViewerCallGraph::show(Info *info, unsigned long entry, unsigned long profondeur, MainWindow *window)
{
    QGraphicsScene    *graphe;
    std::string       graphe_name;

    /* Preparation du nom du graphe */
    graphe_name = this->make_scene_name(entry);

    /* Si info est NULL, c'est pour qu'on clear l'affichage sans rien supprimer */
    this->_info = info;
    if (info == NULL)
        this->setScene(NULL);

    /* Si le graphe existe, on l'utilise directement */
    else if ((graphe = this->find_scene(graphe_name)) != NULL)
    {
        QTransform        transform;

        this->setScene(graphe);
        this->scene()->setItemIndexMethod(QGraphicsScene::NoIndex);
        this->setCacheMode(CacheBackground);
        this->setViewportUpdateMode(BoundingRectViewportUpdate);
        this->setRenderHint(QPainter::Antialiasing);
        this->setTransformationAnchor(AnchorUnderMouse);

        transform.scale(qreal(1), qreal(1));
        this->setTransform(transform);
    }

    /* Sinon, on le cree */
    else
    {
        QGraphicsScene                                        *scene;
        std::set<unsigned long>                               addr_func;
        std::set<std::pair<unsigned long, unsigned long> >    link_func;
        std::map<unsigned long, NodeFunction*>                nodes;

        /* S'il y a trop de graphes dans la liste des graphes sauvegardes, on en supprime */
        while (this->_saved_graph.size() > GRAPHE__NBS_GRAPH_MAX)
            this->del_one_scene();

        if ((scene = new QGraphicsScene(this)) != NULL)
        {
            /* Recuperation des adresses des fonctions a mettre dans le graphe */
            this->search_nodes_to_do(info, entry, profondeur, addr_func, link_func);

            /* Creation du contenu du graphe */
            this->make_nodes_function(scene, window, info, entry, addr_func, nodes);

            /* Placement des Nodes */
            this->put_nodes(nodes, link_func);

            /* Creation des liens entre fonctions */
            for (std::set<std::pair<unsigned long, unsigned long> >::const_iterator it_link=link_func.begin();
                 it_link!=link_func.end();
                 it_link++)
            {
                std::map<unsigned long, NodeFunction*>::const_iterator   it_src = nodes.find(it_link->first);
                std::map<unsigned long, NodeFunction*>::const_iterator   it_dst = nodes.find(it_link->second);

                if ((it_src != nodes.end()) && (it_dst != nodes.end()))
                {
                    Edge    *ptr_edge = new Edge(it_src->second, it_dst->second);

                    if (ptr_edge != NULL)
                        scene->addItem(ptr_edge);
                }
            }

            /* On ajoute le graphe a la liste des graphes sauvegardes et on l'affiche */
            this->add_scene(graphe_name, scene);
            return (this->show(info, entry, profondeur, window));
        }

        return (0);
    }

    return (1);
}

/**
** \fn int save(const std::string &name, unsigned long addr, unsigned long profondeur, Info *info, MainWindow *window)
** \brief Gere l'enregistrement d'un callgraph
**
** \param name Nom de l'image ou enregistrer la scene
** \param addr Adresse du point d'entree du callgraph
** \param profondeur Profondeur du callgraphe
** \param info Structure contenant les infos du programme a analyser
** \param window window Window contenant le graphe
** \return Retourne 1 si OK, 0 sinon
*/
int    ViewerCallGraph::save(const std::string &name, unsigned long addr, unsigned long profondeur, Info *info, MainWindow *window)
{
    if (this->scene() != NULL)
    {
        this->show(info, addr, profondeur, window);

        QImage      img(this->scene()->sceneRect().width(),
                        this->scene()->sceneRect().height(),
                        QImage::Format_ARGB32_Premultiplied);
        QPainter    p(&img);

        this->scene()->render(&p);
        p.end();
        img.save(QString::fromStdString(name));

        return (1);
    }

    return (0);
}

/**
** \fn int search_nodes_to_do(const Info *info, unsigned long entry,
**                            unsigned long profondeur_max,
**                            std::set<unsigned long> &addr_func,
**                            std::set<std::pair<unsigned long, unsigned long> > &link_func)
** \brief Cherche les adresses des fonctions a ajouter au callgraphe
**
** \param info Structure contenant les infos du programme a analyser
** \param entry Point d'entree d'ou effectuer la recherche des fonctions
** \param profondeur_max Profondeur max de l'analyse
** \param addr_func Adresse des fonctions a ajouter au callgraphe
** \param link_func Set des liens entre fonctions <addr_src, addr_dest>
** \return Retourne 1 si OK, 0 sinon
*/
int    ViewerCallGraph::search_nodes_to_do(const Info *info, unsigned long entry,
                                           unsigned long profondeur_max,
                                           std::set<unsigned long> &addr_func,
                                           std::set<std::pair<unsigned long, unsigned long> > &link_func)
{
    std::map<unsigned long, Fonction *>::const_iterator   it_func;

    if ((profondeur_max <= 0) || (addr_func.find(entry) != addr_func.end()))
        return (1);

    /* Ajout de la fonction a la profondeur courante */
    addr_func.insert(entry);

    if ((profondeur_max-1) <= 0)
        return (1);

    /* Si la fonction est deassemblee, on traite les sous-fonctions */
    if ((it_func = info->function.find(entry)) != info->function.end())
    {
        for (std::set<unsigned long>::const_iterator it_addr_call=it_func->second->get_addr_call().begin();
             it_addr_call!=it_func->second->get_addr_call().end();
             it_addr_call++)
        {
            /* Ajoute un lien entre les deux fonctions */
            link_func.insert(std::pair<unsigned long, unsigned long>(entry, *it_addr_call));

            this->search_nodes_to_do(info, *it_addr_call, profondeur_max-1, addr_func, link_func);
        }
    }

    return (1);
}

/**
** int make_nodes_function(QGraphicsScene *scene, MainWindow *window,
**                         Info *info, unsigned long entry,
**                         std::set<unsigned long> &addr_func,
**                         std::map<unsigned long, NodeFunction*> &nodes)
** \brief Gere la creation du callgraphe
**
** \param scene Scene ou mettre les Nodes correspondants aux fonction afin d'en faire un graphe
** \param window Window contenant le graphe
** \param info Structure contenant les infos du programme a analyser
** \param entry Point d'entree d'ou commencer le graphe
** \param addr_func Adresse des fonction a ajouter au callgraphe
** \param nodes Map devant contenir les Nodes correspondants aux fonctions <addr, Node*>
** \return Retourne 1 si OK, 0 sinon
*/
int    ViewerCallGraph::make_nodes_function(QGraphicsScene *scene, MainWindow *window,
                                            Info *info, unsigned long entry,
                                            std::set<unsigned long> &addr_func,
                                            std::map<unsigned long, NodeFunction*> &nodes)
{
    NodeFunction    *ptr_node;

    for (std::set<unsigned long>::iterator it_addr=addr_func.begin();
         it_addr!=addr_func.end();
         it_addr++)
    {
        ptr_node = NULL;

        /* Si la fonction correspond au point d'entree */
        if (*it_addr == entry)
            ptr_node = new NodeFunction(Fonction::get_name_function(*it_addr, info), *it_addr, info, 0, this, window);

        /* Si la fonction a deja ete deassemblee */
        else if (info->function.find(*it_addr) != info->function.end())
            ptr_node = new NodeFunction(Fonction::get_name_function(*it_addr, info), *it_addr, info, 1, this, window);

        /* Sinon */
        else
            ptr_node = new NodeFunction(Fonction::get_name_function(*it_addr, info), *it_addr, info, 2, this, window);

        if (ptr_node != NULL)
        {
            nodes[*it_addr] = ptr_node;
            scene->addItem(ptr_node);
        }
    }

    return (1);
}

/**
** \fn int put_nodes(std::map<unsigned long, NodeFunction*> &nodes)
** \brief Gere le placement des Nodes dans le graphe
**
** \param nodes Tableau contenant les nodes a placer <addr, Node>
** \param link_func Set des liens entre fonctions <addr_src, addr_dest>
** \return Retourne 1 si OK, 0 sinon
*/
int    ViewerCallGraph::put_nodes(std::map<unsigned long, NodeFunction*> &nodes,
                                  std::set<std::pair<unsigned long, unsigned long> > &link_func)
{
    /* set up a graphviz context - but only once even for multiple graphs */
    static GVC_t    *gvc;
    Agraph_t        *g;
    Agnode_t        *n;
    std::map<unsigned long, Agnode_t*>    map_node_dot;
    std::map<unsigned long, Agnode_t*>::iterator    it_node_dot1;
    std::map<unsigned long, Agnode_t*>::iterator    it_node_dot2;
    float                                           y_max;

    if (gvc == NULL)
        gvc = gvContext();

    if (gvc != NULL)
    {
        /* Create a simple digraph */
        if ((g = agopen(const_cast<char*>("g"), AGDIGRAPH)) != NULL)
        {
            /* Creation des nodes DOT */
            for (std::map<unsigned long, NodeFunction*>::const_iterator it_nodes=nodes.begin();
                 it_nodes!=nodes.end();
                 it_nodes++)
            {
                n = agnode(g, const_cast<char*>(Calcul::lto0x(it_nodes->first).c_str()));

                if (n != NULL)
                {
                    agsafeset(n, const_cast<char*>("width"),
                              const_cast<char*>(Calcul::ltos(it_nodes->second->boundingRect().width() / 72).c_str()),
                              const_cast<char*>(""));
                    agsafeset(n, const_cast<char*>("height"),
                              const_cast<char*>(Calcul::ltos(it_nodes->second->boundingRect().height() * 3 / 72).c_str()),
                              const_cast<char*>(""));
                    map_node_dot[it_nodes->first] = n;
                }
            }

            /* Creation des edges DOT */
            for (std::set<std::pair<unsigned long, unsigned long> >::const_iterator it_edge=link_func.begin();
                 it_edge!=link_func.end();
                 it_edge++)
            {
                it_node_dot1 = map_node_dot.find(it_edge->first);
                it_node_dot2 = map_node_dot.find(it_edge->second);
                if ((it_node_dot1 != map_node_dot.end()) && (it_node_dot2 != map_node_dot.end()))
                    agedge(g, it_node_dot1->second, it_node_dot2->second);
            }

            /* Generation du graphe */
            gvLayout(gvc, g, "dot");
            gvRender(gvc, g, "dot", NULL);

            /* Identification de la coordonnee Y max afin d'inverser les coordonnes */
            y_max = 0;
            for (std::map<unsigned long, Agnode_t*>::iterator it_nodes=map_node_dot.begin();
                 it_nodes!=map_node_dot.end();
                 it_nodes++)
            {
                if (ND_coord(it_nodes->second).y > y_max)
                    y_max = ND_coord(it_nodes->second).y;
            }

            /* Recuperation des coordonnees des Nodes */
            for (std::map<unsigned long, NodeFunction*>::iterator it_nodes=nodes.begin();
                 it_nodes!=nodes.end();
                 it_nodes++)
            {
                if ((it_node_dot1 = map_node_dot.find(it_nodes->first)) != map_node_dot.end())
                {
                    it_nodes->second->setPos(ND_coord(it_node_dot1->second).x, y_max - ND_coord(it_node_dot1->second).y);
                }
            }

            gvFreeLayout(gvc, g);
            agclose(g);
        }
    }

    return (1);
}





NodeFunction::NodeFunction(const std::string &name, unsigned long addr, Info *info,
                           int status, ViewerCallGraph *viewer, MainWindow *window): INode(viewer),
    _addr(addr),
    _name(name),
    _txt(),
    _rect(),
    _status(status),
    _info(info),
    _window(window)
{
    /* Preparation du texte */
    this->_txt = QString::fromStdString(this->_name + "\n" + Calcul::lto0x(this->_addr));
    this->update_rect();
}

NodeFunction::~NodeFunction()
{
}


void    NodeFunction::update_rect()
{
    QFont font;

    font.setBold(true);
    font.setPointSize(12);

    QFontMetrics    fm(font);

    this->_rect = fm.boundingRect(QRect(), Qt::AlignHCenter, this->_txt);

    this->_rect.setWidth(this->_rect.width()*2);
    this->_rect.setX(this->pos().x() - (this->_rect.width()/2));
    this->_rect.setY(this->pos().y()/* - (this->_rect.height()/2)*/);
}

/**
** \fn QRectF boundingRect() const
** \brief Modifie la zone d'affichage du Node
**
** \return Retourne les dimensions de la nouvelle zone d'affichage du Node
*/
QRectF       NodeFunction::boundingRect() const
{
    return (this->_rect);
}

/**
** \fn QPainterPath shape() const
** \brief Adapte la zone de selection du Node a ses dimensions
**
** \return Retourne la zone de selection du Node
*/
QPainterPath NodeFunction::shape() const
{
    QPainterPath    path;

    path.addRect(this->_rect);
    return (path);
}

/**
** \fn void paint(QPainter *painter, const QStyleOptionGraphicsItem*, QWidget *)
** \brief Fonction gerant l'affichage du Node
**
** \param painter Pointeur sur l'objet permettant de dessiner le Node
** \return Retourne rien
*/
void         NodeFunction::paint(QPainter *painter, const QStyleOptionGraphicsItem*, QWidget*)
{
    if (painter != NULL)
    {
        QFont      font;
        font.setBold(true);
        font.setPointSize(12);
        painter->setFont(font);

        /* Preparation du texte */
        this->_rect = painter->boundingRect(QRectF(), Qt::AlignHCenter, this->_txt);
        font.setBold(true);
        font.setPointSize(10);
        painter->setFont(font);

        /* Contour du node */
        painter->setPen(Qt::NoPen);
        painter->setBrush(Qt::black);
        painter->drawRect(this->_rect);

        /* Interieur du node */
        if (this->_status == 0)
            painter->setBrush(QBrush(QColor(150, 150, 255)));
        else if (this->_status == 1)
            painter->setBrush(QBrush(QColor(200, 200, 200)));
        else
            painter->setBrush(QBrush(QColor(255, 255, 255)));
        painter->drawRect(this->_rect.left()+1, this->_rect.top()+1, this->_rect.width()-2, this->_rect.height()-2);

        /* Texte du node */
        painter->setPen(Qt::black);
        painter->drawText(this->boundingRect(), Qt::AlignCenter, this->_txt);
    }
}

/**
** \fn QPointF get_posInput() const
** \brief Fonction permettant de connaitre la position relative du point d'entree du Node
**
** \return Retourne la position relative du point d'entree du Node
*/
QPointF      NodeFunction::get_posInput() const
{
    return (QPointF(this->pos().x(), this->pos().y()));
}

/**
** \fn QPointF get_posOutput() const
** \brief Fonction permettant de connaitre la position relative du point de sortie du Node
**
** \return Retourne la position relative du point d'entree du Node
*/
QPointF      NodeFunction::get_posOutput() const
{
    return (QPointF(this->pos().x(), this->pos().y() + this->_rect.height()));
}

/**
** \fn void slot_edit_description()
** \brief Permet d'editer la description de la fonction correspondant a ce Node
**
** \return Retourne rien
*/
void    NodeFunction::slot_edit_description()
{
    qDebug("NodeFunction::slot_edit_description()\n");
    std::map<unsigned long, Fonction*>::iterator    it_func;
    std::string                                     str;

    if ((it_func = this->_info->function.find(this->_addr)) != this->_info->function.end())
    {
        str = it_func->second->get_description();

        GetDescriptionWindow    w("Description de la fonction :", &str, this->_window);
        w.exec();

        it_func->second->set_description(str);
    }
}

/**
** \fn void slot_edit_prototype()
** \brief Permet d'editer le prototype de la fonction correspondant a ce Node
**
** \return Retourne rien
*/
void    NodeFunction::slot_edit_prototype()
{
    qDebug("NodeFunction::slot_edit_prototype()\n");

    if (this->_window != NULL)
        this->_window->slot_proto_func__edit_name(this->_name);
}

/**
** \fn void slot_show_callgraph()
** \brief Permet d'afficher le callgraph correspondant a ce Node
**
** \return Retourne rien
*/
void    NodeFunction::slot_show_callgraph()
{
    qDebug("NodeFunction::slot_show_callgraph()\n");

    if (this->_window != NULL)
        this->_window->slot_callgraph__select_an_entry(this->_addr);
}

/**
** \fn void slot_show_asm()
** \brief Permet d'afficher le graphe ASM correspondant a ce Node
**
** \return Retourne rien
*/
void    NodeFunction::slot_show_asm()
{
    qDebug("NodeFunction::slot_show_asm()\n");

    if (this->_window != NULL)
        this->_window->slot_func__select_an_entry_asm(this->_addr);
}

/**
** \fn void slot_show_c()
** \brief Permet d'afficher le code C correspondant a ce Node
**
** \return Retourne rien
*/
void    NodeFunction::slot_show_c()
{
    qDebug("NodeFunction::slot_show_c()\n");

    if (this->_window != NULL)
        this->_window->slot_func__select_an_entry_c(this->_addr);
}

/**
** \fn void slot_deassembler()
** \brief Permet de deassembler la fonction correspondant a ce Node
**
** \return Retourne rien
*/
void    NodeFunction::slot_deassembler()
{
    qDebug("NodeFunction::slot_deassembler()\n");

    if (this->_window != NULL)
        this->_window->slot_func__deassemble_an_entry(this->_addr);
}

/**
** \fn void slot_nettoyer()
** \brief Permet de nettoyer la fonction correspondant a ce Node
**
** \return Retourne rien
*/
void    NodeFunction::slot_nettoyer()
{
    qDebug("NodeFunction::slot_nettoyer()\n");

    if (this->_window != NULL)
        this->_window->slot_func__clean_an_entry(this->_addr);
}

/**
** \fn void slot_decompiler()
** \brief Permet de decompiler la fonction correspondant a ce Node
**
** \return Retourne rien
*/
void    NodeFunction::slot_decompiler()
{
    qDebug("NodeFunction::slot_decompiler()\n");

    if (this->_window != NULL)
        this->_window->slot_func__decompile_an_entry(this->_addr);
}

/**
** \fn void mousePressEvent(QGraphicsSceneMouseEvent *event)
** \brief Gestion des clics de la souris
**
** \param event Pointeur sur la description de l'evenement
** \return Retourne rien
*/
void              NodeFunction::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    qDebug("NodeFunction::mousePressEvent(QMouseEvent *event)\n");
    QMenu      m;
    QAction    *action;
    QCursor    cursor;

    /* Si l'evenement est un clic droit, on affiche un menu */
    if (event->button() == Qt::RightButton)
    {
        if (((this->_status == 0) || (this->_status == 1)) &&
            ((action = new QAction(QString::fromUtf8("Modifier la description de la fonction"), &m)) != NULL))
        {
            m.addAction(action);
            connect(action, SIGNAL(triggered()), this, SLOT(slot_edit_description()));
        }

        if ((action = new QAction(QString::fromUtf8("Modifier le prototype de la fonction"), &m)) != NULL)
        {
            m.addAction(action);
            connect(action, SIGNAL(triggered()), this, SLOT(slot_edit_prototype()));
        }

        if ((this->_status == 1) &&
            ((action = new QAction(QString::fromUtf8("Afficher le callgraphe"), &m)) != NULL))
        {
            m.addAction(action);
            connect(action, SIGNAL(triggered()), this, SLOT(slot_show_callgraph()));
        }

        if (((this->_status == 0) || (this->_status == 1)) &&
            ((action = new QAction(QString::fromUtf8("Afficher le graphe d'exécution"), &m)) != NULL))
        {
            m.addAction(action);
            connect(action, SIGNAL(triggered()), this, SLOT(slot_show_asm()));
        }

        if (((this->_status == 0) || (this->_status == 1)) &&
            ((action = new QAction(QString::fromUtf8("Afficher le code-source"), &m)) != NULL))
        {
            m.addAction(action);
            connect(action, SIGNAL(triggered()), this, SLOT(slot_show_c()));
        }

        if ((action = new QAction(QString::fromUtf8("(Re)déassembler"), &m)) != NULL)
        {
            m.addAction(action);
            connect(action, SIGNAL(triggered()), this, SLOT(slot_deassembler()));
        }

        if (((this->_status == 0) || (this->_status == 1)) &&
            ((action = new QAction(QString::fromUtf8("(Re)nettoyer"), &m)) != NULL))
        {
            m.addAction(action);
            connect(action, SIGNAL(triggered()), this, SLOT(slot_nettoyer()));
        }

        if (((this->_status == 0) || (this->_status == 1)) &&
            ((action = new QAction(QString::fromUtf8("(Re)décompiler"), &m)) != NULL))
        {
            m.addAction(action);
            connect(action, SIGNAL(triggered()), this, SLOT(slot_decompiler()));
        }

        m.move(cursor.pos());
        m.exec();
    }
    else
        QGraphicsObject::mousePressEvent(event);
}





GetDescriptionWindow::GetDescriptionWindow(const std::string &titre, std::string *descr, QWidget *parent): QDialog(parent),
    _descr(descr),
    ui(new Ui::GetDescriptionDialog)
{
    ui->setupUi(this);

    this->ui->label_titre->setText(QString::fromStdString(titre));

    if (this->_descr != NULL)
        this->ui->text_description->setText(QString::fromStdString(*(this->_descr)));
}

GetDescriptionWindow::~GetDescriptionWindow()
{
    delete ui;
}

/**
** \fn void slot_validate()
** \brief Gere la validation des changements effectuee par le menu
**
** \return Retourne rien
*/
void    GetDescriptionWindow::slot_validate()
{
    if (this->_descr != NULL)
        *(this->_descr) = this->ui->text_description->toPlainText().toStdString();
}
