#ifndef NEWSYMBOLEWINDOW_H
#define NEWSYMBOLEWINDOW_H

#include    <QMainWindow>
#include    <QApplication>
#include    <QtGui>
#include    <QDialog>

#include    "Info.hpp"
#include    "Calcul.hpp"

namespace Ui
{
    class Dialog4;
}

class NewSymboleWindow : public QDialog
{
    Q_OBJECT
public:
    explicit NewSymboleWindow(unsigned long value, const std::string &name, const std::string &type, Symbole *symboles, QWidget *parent = 0);
    ~NewSymboleWindow();


    /**
    ** \fn unsigned long get_value_symbole() const
    ** \brief Assesseur permettant de connaitre la derniere valeur du symbole dans le formulaire
    **
    ** \return Retourne la derniere adresse du segment dans le formulaire
    */
    unsigned long    get_value_symbole() const;
    
public slots:
    /**
    ** \fn void slot_validate()
    ** \brief Gere la validation des changements effectuee par le menu
    **
    ** \return Retourne rien
    */
    void    slot_validate();

    /**
    ** \fn void slot_check_formulaire()
    ** \brief Slot Permettant de verifier que le contenu des champs est valide
    **
    ** \return Retourne rien
    */
    void    slot_check_formulaire();

protected:
    /** Valeur du symbole */
    unsigned long    _value;
    /** Nom du symbole */
    std::string      _name;
    /** Type du symbole */
    std::string      _type;
    /** Pointeur sur le gestionnaire de symboles */
    Symbole          *_symbole;

    /** Interface graphique du menu */
    Ui::Dialog4      *ui;
    
};

#endif
