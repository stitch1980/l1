#ifndef    NEWSEGMENTWINDOW_H
#define    NEWSEGMENTWINDOW_H

#include    <string.h>
#include    <unistd.h>
#include    <sys/types.h>
#include    <sys/stat.h>
#include    <fcntl.h>

#include    <QMainWindow>
#include    <QApplication>
#include    <QtGui>
#include    <QDialog>

#include    "Info.hpp"
#include    "Calcul.hpp"

namespace Ui
{
    class Dialog2;
}

class NewSegmentWindow : public QDialog
{
    Q_OBJECT
public:
    explicit NewSegmentWindow(unsigned long addr, unsigned long size, int flags, Section *section, QWidget *parent = 0);
    ~NewSegmentWindow();

    /**
    ** \fn void actualisation()
    ** \brief Gere l'actualisation du  contenu du menu
    **
    ** \param info Structure contenant les infos du programme a analyser
    ** \return Retourne rien
    */
    void    actualisation();


    /**
    ** \fn unsigned long get_addr_segment() const
    ** \brief Assesseur permettant de connaitre la derniere adresse du segment dans le formulaire
    **
    ** \return Retourne la derniere adresse du segment dans le formulaire
    */
    unsigned long    get_addr_segment() const;

    /**
    ** \fn unsigned long get_size_segment() const
    ** \brief Assesseur permettant de connaitre la derniere taille du segment dans le formulaire
    **
    ** \return Retourne la derniere taille du segment dans le formulaire
    */
    unsigned long    get_size_segment() const;

    /**
    ** \fn int get_flags_segment() const
    ** \brief Assesseur permettant de connaitre les derniers flags du segment dans le formulaire
    **
    ** \return Retourne les derniers flags du segment dans le formulaire
    */
    int              get_flags_segment() const;
    
public slots:
    /**
    ** \fn void slot_validate()
    ** \brief Gere la validation des changements effectuee par le menu
    **
    ** \return Retourne rien
    */
    void    slot_validate();

    /**
    ** \fn void slot_get_filename()
    ** \brief Slot Permettant de recuperer le nom du fichier a utiliser comme contenu de segment
    **
    ** \return Retourne rien
    */
    void    slot_get_filename();

    /**
    ** \fn void slot_check_formulaire()
    ** \brief Slot Permettant de verifier que le contenu des champs est valide
    **
    ** \return Retourne rien
    */
    void    slot_check_formulaire();

protected:
    /** Adresse du segment */
    unsigned long    _addr;
    /** Taille du segment */
    unsigned long    _size;
    /** Flags du segment */
    int              _flags;
    /** Pointeur sur le gestionnaire de sections */
    Section          *_section;

    /** Interface graphique du menu */
    Ui::Dialog2                        *ui;
};

#endif
