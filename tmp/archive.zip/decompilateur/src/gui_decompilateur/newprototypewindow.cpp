#include    "newprototypewindow.h"

#include    "ui_newprototypewindow.h"
#include    "ui_newparametrefonctionwindow.h"


NewPrototypeWindow::NewPrototypeWindow(unsigned long *num, std::string *ret, std::string *name,
                                       std::vector<std::pair<std::string, std::string> > *param,
                                       const Info *info, QWidget *parent): QDialog(parent),
    _ok(0),
    _num(num),
    _ret(ret),
    _name(name),
    _param(param),
    _info(info),
    ui(new Ui::DialogNewPrototype)
{
    ui->setupUi(this);

    /* Initialisation du numero d'interruption si besoin est */
    this->ui->widget_num->setEnabled(false);
    if (num != NULL)
    {
        this->ui->widget_num->setEnabled(true);
        this->ui->field_num->setText(QString::number(*num));
    }

    /* Preparation des champs "ret" et "nom" */
    this->ui->field_ret->setText(QString::fromStdString(*ret));
    this->ui->field_name->setText(QString::fromStdString(*name));

    /* Preparation du tableau de parametres */
    this->ui->tab_param->setRowCount(param->size());
    for (unsigned long i=0; i<param->size(); i++)
    {
        this->ui->tab_param->setItem(i, 0, new QTableWidgetItem(QString::fromStdString((*param)[i].first)));
        this->ui->tab_param->setItem(i, 1, new QTableWidgetItem(QString::fromStdString((*param)[i].second)));
    }

    /* Preparation de la ligne des parametres grace au tableau */
    this->slot_param__tab_to_line();
    this->slot_check();
}

NewPrototypeWindow::~NewPrototypeWindow()
{
    delete ui;
}


/**
** \fn int is_ok()
** \brief Permet de le formulaire de creation de prototype a bien ete valide
**
** \return Retourne 1 si le formulaire a ete valide, 0 sinon
*/
int    NewPrototypeWindow::is_ok()
{
    return (this->_ok);
}


/**
** \fn void slot_validate()
** \brief Permet de valider les modifications du prototype
**
** \return Retourne rien
*/
void    NewPrototypeWindow::slot_validate()
{
    qDebug("NewPrototypeWindow::slot_validate()\n");
    std::string    type;
    std::string    name;

    if (this->_num != NULL)
        *(this->_num) = atol(this->ui->field_num->text().toAscii());
    *(this->_ret) = this->ui->field_ret->text().toStdString();
    *(this->_name) = this->ui->field_name->text().toStdString();

    /* Recuparation des parametres */
    this->_param->clear();
    for (int i=0; i<this->ui->tab_param->rowCount(); i++)
    {
        type = this->ui->tab_param->item(i, 0)->text().toStdString();
        name = this->ui->tab_param->item(i, 1)->text().toStdString();

        this->_param->push_back(std::pair<std::string, std::string>(type, name));
    }

    this->_ok = 1;
}

/**
** \fn void slot_check()
** \brief Permet de verifier que les champs sont valides
**
** \return Retourne rien
*/
void    NewPrototypeWindow::slot_check()
{
    qDebug("NewPrototypeWindow::slot_check()\n");
    QTableWidgetItem    *ptr_item;
    std::string         str;

    /* Par defaut, on peut valider */
    if (this->ui->buttonBox->button(QDialogButtonBox::Ok) != NULL)
        this->ui->buttonBox->button(QDialogButtonBox::Ok)->setEnabled(true);

    /* Verification du numero d'interruption */
    if (this->_num != NULL)
    {
        this->ui->field_num->setStyleSheet("");
        str = this->ui->field_num->text().toStdString();
        if ((str.size() <= 0) || (BNFcalcul::is_udecimal(str, NULL, NULL, 0, 0) != str.size()))
        {
            this->ui->field_num->setStyleSheet("background-color: red;");
            if (this->ui->buttonBox->button(QDialogButtonBox::Ok) != NULL)
                this->ui->buttonBox->button(QDialogButtonBox::Ok)->setEnabled(false);
        }
    }

    /* Verification des champs "ret" et "nom" */
    this->ui->field_ret->setStyleSheet("");
    if (0)
    {
        this->ui->field_ret->setStyleSheet("background-color: red;");
        if (this->ui->buttonBox->button(QDialogButtonBox::Ok) != NULL)
            this->ui->buttonBox->button(QDialogButtonBox::Ok)->setEnabled(false);
    }

    this->ui->field_name->setStyleSheet("");
    str = this->ui->field_name->text().toStdString();
    if ((str.size() <= 0) || (BNFc::is_var_name(str) != str.size()))
    {
        this->ui->field_name->setStyleSheet("background-color: red;");
        if (this->ui->buttonBox->button(QDialogButtonBox::Ok) != NULL)
            this->ui->buttonBox->button(QDialogButtonBox::Ok)->setEnabled(false);
    }

    /* Verification de la chaine de parametres */
    this->ui->field_param->setStyleSheet("");
    if (0)
    {
        this->ui->field_param->setStyleSheet("background-color: red;");
        if (this->ui->buttonBox->button(QDialogButtonBox::Ok) != NULL)
            this->ui->buttonBox->button(QDialogButtonBox::Ok)->setEnabled(false);
    }

    /* Verification des parametres du tableau */
    for (int i=0; i<this->ui->tab_param->rowCount(); i++)
    {
        /* Verification du champ type */
        if ((ptr_item = this->ui->tab_param->item(i, 0)) != NULL)
        {
            ptr_item->setBackground(Qt::transparent);
            str = ptr_item->text().toStdString();
            if (str.size() <= 0)
            {
                ptr_item->setBackground(Qt::red);
                if (this->ui->buttonBox->button(QDialogButtonBox::Ok) != NULL)
                    this->ui->buttonBox->button(QDialogButtonBox::Ok)->setEnabled(false);
            }
        }

        /* Verification du champ nom (il peut etre vide) */
        if ((ptr_item = this->ui->tab_param->item(i, 1)) != NULL)
        {
            ptr_item->setBackground(Qt::transparent);
            str = ptr_item->text().toStdString();
            if (BNFc::is_var_name(str) != str.size())
            {
                ptr_item->setBackground(Qt::red);
                if (this->ui->buttonBox->button(QDialogButtonBox::Ok) != NULL)
                    this->ui->buttonBox->button(QDialogButtonBox::Ok)->setEnabled(false);
            }
        }
    }

    this->slot_param__clicked();
}



/**
** \fn void slot_param__clicked()
** \brief Gere les clics dans la liste des parametres
**
** \return Retourne rien
*/
void    NewPrototypeWindow::slot_param__clicked()
{
    qDebug("NewTypeWindow::slot_param__clicked()\n");
    int    pos_row;

    /* Bloque les boutons "edit", "delete", ... */
    this->ui->tab_param__edit->setEnabled(false);
    this->ui->tab_param__delete->setEnabled(false);
    this->ui->tab_param__up->setEnabled(false);
    this->ui->tab_param__down->setEnabled(false);

    /* Si un attribut est selectionne */
    if ((pos_row = this->ui->tab_param->currentRow()) >= 0)
    {
        /* Secactionne toute la ligne et active les boutons "edit" et "delete" */
        this->ui->tab_param->selectRow(pos_row);
        this->ui->tab_param__edit->setEnabled(true);
        this->ui->tab_param__delete->setEnabled(true);

        /* Si l'attribut selectionne n'est pas le premier, on peut le monter */
        if (pos_row > 0)
            this->ui->tab_param__up->setEnabled(true);

        /* Si l'attribut selectionne n'est pas le dernier, on peut le descendre */
        if (pos_row < (this->ui->tab_param->rowCount() - 1))
            this->ui->tab_param__down->setEnabled(true);
    }
}

/**
** \fn void slot_param__new()
** \brief Ajoute un parametre a la fonction
**
** \return Retourne rien
*/
void    NewPrototypeWindow::slot_param__new()
{
    qDebug("NewPrototypeWindow::slot_param__new()\n");
    std::string      type;
    std::string      name;
    int              pos_row;

    /* Execution du menu demandant les infos de l'attribut */
    type = "";
    name = "";
    NewParametreFonctionWindow    w(type, name, &(this->_info->proto_var), this);
    w.exec();

    /* Creation d'un nouvel attribut si besoin est */
    if (type.size() > 0)
    {
        pos_row = this->ui->tab_param->rowCount();
        if (this->ui->tab_param->currentRow() >= 0)
            pos_row = this->ui->tab_param->currentRow() + 1;

        this->ui->tab_param->insertRow(pos_row);
        this->ui->tab_param->setItem(pos_row, 0, new QTableWidgetItem(QString::fromStdString(type)));
        this->ui->tab_param->setItem(pos_row, 1, new QTableWidgetItem(QString::fromStdString(name)));
        this->ui->tab_param->selectRow(pos_row);
    }

    this->slot_param__tab_to_line();
    this->slot_check();
}

/**
** \fn void slot_param__edit()
** \brief Modifie un parametre de la fonction
**
** \return Retourne rien
*/
void    NewPrototypeWindow::slot_param__edit()
{
    qDebug("NewPrototypeWindow::slot_param__edit()\n");
    std::string      type;
    std::string      name;
    int              pos_row;

    /* Si un attribut est selectionne */
    if ((pos_row = this->ui->tab_param->currentRow()) >= 0)
    {
        /* Recuperation des valeurs de l'attribut a modifier */
        type = this->ui->tab_param->item(pos_row, 0)->text().toStdString();
        name = this->ui->tab_param->item(pos_row, 1)->text().toStdString();

        /* Edition de l'attribut */
        NewParametreFonctionWindow    w(type, name, &(this->_info->proto_var), this);
        w.exec();

        /* Actualisation des valeurs de l'attribut */
        this->ui->tab_param->item(pos_row, 0)->setText(QString::fromStdString(type));
        this->ui->tab_param->item(pos_row, 1)->setText(QString::fromStdString(name));
    }

    this->slot_param__tab_to_line();
    this->slot_check();
}

/**
** \fn void slot_param__delete()
** \brief Supprime un parametre de la fonction
**
** \return Retourne rien
*/
void    NewPrototypeWindow::slot_param__delete()
{
    qDebug("NewPrototypeWindow::slot_param__delete()\n");

    /* Si un attribut est selectionne, on le supprime */
    if (this->ui->tab_param->currentRow() >= 0)
        this->ui->tab_param->removeRow(this->ui->tab_param->currentRow());

    this->slot_param__tab_to_line();
    this->slot_check();
}

/**
** \fn void slot_param__up()
** \brief Monte un parametre de la fonction
**
** \return Retourne rien
*/
void    NewPrototypeWindow::slot_param__up()
{
    qDebug("NewPrototypeWindow::slot_param__up()\n");
    QString      type;
    QString      name;
    int          pos_row;

    if ((pos_row = this->ui->tab_param->currentRow()) > 0)
    {
        type = this->ui->tab_param->item(pos_row, 0)->text();
        name = this->ui->tab_param->item(pos_row, 1)->text();

        this->ui->tab_param->item(pos_row, 0)->setText(this->ui->tab_param->item(pos_row-1, 0)->text());
        this->ui->tab_param->item(pos_row, 1)->setText(this->ui->tab_param->item(pos_row-1, 1)->text());

        this->ui->tab_param->item(pos_row-1, 0)->setText(type);
        this->ui->tab_param->item(pos_row-1, 1)->setText(name);

        this->ui->tab_param->selectRow(pos_row-1);
    }

    this->slot_param__tab_to_line();
    this->slot_check();
}

/**
** \fn void slot_param__down()
** \brief Descend un parametre de la fonction
**
** \return Retourne rien
*/
void    NewPrototypeWindow::slot_param__down()
{
    qDebug("NewPrototypeWindow::slot_param__down()\n");
    QString      type;
    QString      name;
    int          pos_row;

    if (((pos_row = this->ui->tab_param->currentRow()) >= 0) &&
        (pos_row < (this->ui->tab_param->rowCount()-1)))
    {
        type = this->ui->tab_param->item(pos_row, 0)->text();
        name = this->ui->tab_param->item(pos_row, 1)->text();

        this->ui->tab_param->item(pos_row, 0)->setText(this->ui->tab_param->item(pos_row+1, 0)->text());
        this->ui->tab_param->item(pos_row, 1)->setText(this->ui->tab_param->item(pos_row+1, 1)->text());

        this->ui->tab_param->item(pos_row+1, 0)->setText(type);
        this->ui->tab_param->item(pos_row+1, 1)->setText(name);

        this->ui->tab_param->selectRow(pos_row+1);
    }

    this->slot_param__tab_to_line();
    this->slot_check();
}

/**
** \fn void slot_param__tab_to_line()
** \brief Extrait les parametres du tableau pour les mettres dans la ligne de parametres
**
** \return Retourne rien
*/
void    NewPrototypeWindow::slot_param__tab_to_line()
{
    qDebug("NewPrototypeWindow::slot_param__tab_to_line()\n");
    std::string    str;
    int            i;

    for (i=0; i<this->ui->tab_param->rowCount(); i++)
    {
        if (i > 0)
            str += ", ";

        str += this->ui->tab_param->item(i, 0)->text().toStdString();
        str += " ";
        str += this->ui->tab_param->item(i, 1)->text().toStdString();
    }

    this->ui->field_param->setText(QString::fromStdString(str));
}

/**
** \fn void slot_param__line_to_tab()
** \brief Extrait les parametres de la ligne pour les mettre dans le tableau de parametres
**
** \return Retourne rien
*/
void    NewPrototypeWindow::slot_param__line_to_tab()
{
    qDebug("NewPrototypeWindow::slot_param__line_to_tab()\n");
}





NewParametreFonctionWindow::NewParametreFonctionWindow(std::string &type, std::string &name, const PrototypeT *proto, QWidget *parent): QDialog(parent),
    _type(&type),
    _name(&name),
    _proto(proto),
    ui(new Ui::DialogNewParametreFonction)
{
    this->ui->setupUi(this);

    this->ui->field_type->setText(QString::fromStdString(type));
    this->ui->field_name->setText(QString::fromStdString(name));

    this->slot_check_formulaire();
}

NewParametreFonctionWindow::~NewParametreFonctionWindow()
{
    delete this->ui;
}


/**
** \fn void slot_validate()
** \brief Gere la validation des changements effectuee par le menu
**
** \return Retourne rien
*/
void    NewParametreFonctionWindow::slot_validate()
{
    qDebug("NewParametreFonctionWindow::slot_validate()\n");

    *(this->_type) = this->ui->field_type->text().toStdString();
    *(this->_name) = this->ui->field_name->text().toStdString();
}

/**
** \fn void slot_check_formulaire()
** \brief Slot Permettant de verifier que le contenu des champs est valide
**
** \return Retourne rien
*/
void    NewParametreFonctionWindow::slot_check_formulaire()
{
    qDebug("NewParametreFonctionWindow::slot_check_formulaire()\n");

    /* Par defaut, on peut valider */
    if (this->ui->buttonBox->button(QDialogButtonBox::Ok) != NULL)
        this->ui->buttonBox->button(QDialogButtonBox::Ok)->setEnabled(true);

    /* Il faut que le type existe */
    this->ui->field_type->setStyleSheet("");
    if ((this->ui->field_type->text().toStdString().size() <= 0) ||
        (this->_proto->exist(this->ui->field_type->text().toStdString()) <= 0))
    {
        this->ui->field_type->setStyleSheet("background-color: red;");
        if (this->ui->buttonBox->button(QDialogButtonBox::Ok) != NULL)
            this->ui->buttonBox->button(QDialogButtonBox::Ok)->setEnabled(false);
    }

    /* Le nom doit etre valide */
    this->ui->field_name->setStyleSheet("");
    if ((this->ui->field_name->text().size() <= 0) ||
        (BNFc::is_var_name(this->ui->field_name->text().toStdString()) != this->ui->field_name->text().toStdString().size()))
    {
        this->ui->field_name->setStyleSheet("background-color: red;");
        if (this->ui->buttonBox->button(QDialogButtonBox::Ok) != NULL)
            this->ui->buttonBox->button(QDialogButtonBox::Ok)->setEnabled(false);
    }
}
