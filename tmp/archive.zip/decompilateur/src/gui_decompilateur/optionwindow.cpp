#include    "optionwindow.h"
#include    "ui_optionwindow.h"
#include    "ui_optionpluginwindow.h"


OptionWindow::OptionWindow(Info *info, std::map<std::string, Plugin*> *list_plugins, QWidget *parent): QDialog(parent),
    _info(info),
    _list_plugins(list_plugins),
    _list_plugins_tmp(*list_plugins),
    ui(new Ui::Dialog)
{
    ui->setupUi(this);

    this->actualisation(this->_info);
}


OptionWindow::~OptionWindow()
{
    this->_list_plugins_tmp.clear();
    delete ui;
}



/**
** \fn void actualisation(Info *info=NULL)
** \brief Gere l'actualisation du  contenu du menu
**
** \param info Structure contenant les infos du programme a analyser
** \return Retourne rien
*/
void    OptionWindow::actualisation(Info *info)
{
    unsigned int    i;
    QCheckBox       *check;

    if (info != NULL)
    {
        /* Actualisation du nom de l'executable a analyser */
        this->ui->option__name->setText(QString::fromStdString(info->filename));

        /* Actualisation du format de fichier */
        if (info->format == Info::FORMAT_ELF32)
            this->ui->option__format->setCurrentIndex(0);
        else if (info->format == Info::FORMAT_ELF64)
            this->ui->option__format->setCurrentIndex(1);
        else if (info->format == Info::FORMAT_PE32)
            this->ui->option__format->setCurrentIndex(2);
        else if (info->format == Info::FORMAT_PE64)
            this->ui->option__format->setCurrentIndex(3);
        else if (info->format == Info::FORMAT_MBR)
            this->ui->option__format->setCurrentIndex(4);
        else if (info->format == Info::FORMAT_BRAINFUCK)
            this->ui->option__format->setCurrentIndex(5);
        else
            this->ui->option__format->setCurrentIndex(6);

        /* Actualisation de l'architecture */
        if (info->archi == Info::ARCHI_I16)
            this->ui->option__archi->setCurrentIndex(0);
        else if (info->archi == Info::ARCHI_I32)
            this->ui->option__archi->setCurrentIndex(1);
        else if (info->archi == Info::ARCHI_I64)
            this->ui->option__archi->setCurrentIndex(2);
        else if (info->archi == Info::ARCHI_BRAINFUCK)
            this->ui->option__archi->setCurrentIndex(3);
        else
            this->ui->option__archi->setCurrentIndex(4);

        /* Actualisation de l'endian */
        if (info->endian == Info::ENDIAN_LITTLE)
            this->ui->option__endian->setCurrentIndex(0);
        if (info->endian == Info::ENDIAN_BIG)
            this->ui->option__endian->setCurrentIndex(1);
        else
            this->ui->option__endian->setCurrentIndex(2);
    }

    /* Actualisation de la liste des plugins */
    i = 0;
    this->ui->plugin__liste_plugin->clearContents();
    this->ui->plugin__liste_plugin->setRowCount(this->_list_plugins_tmp.size());
    for (std::map<std::string, Plugin*>::const_iterator it=this->_list_plugins_tmp.begin();
         it!=this->_list_plugins_tmp.end();
         it++)
    {
        if ((check = new QCheckBox) != NULL)
        {
            if (this->_info->plugin.find(it->first) != this->_info->plugin.end())
                check->setChecked(true);
            else
                check->setChecked(false);
            this->ui->plugin__liste_plugin->setCellWidget(i, 0, check);
        }
        this->ui->plugin__liste_plugin->setCellWidget(i, 1, new QLabel(QString::fromStdString(it->second->get_name())));
        this->ui->plugin__liste_plugin->setCellWidget(i, 2, new QLabel(QString::fromStdString(it->second->get_type())));
        this->ui->plugin__liste_plugin->setCellWidget(i, 3, new QLabel(QString::number(it->second->get_priorite())));
        this->ui->plugin__liste_plugin->setCellWidget(i, 4, new QLabel(QString::fromStdString(it->second->get_version())));

        i++;
    }
}

/**
** \fn void slot_validate()
** \brief Gere la validation des changements effectuee par le menu
**
** \return Retourne rien
*/
void    OptionWindow::slot_validate()
{
    qDebug("OptionWindow::slot_validate()\n");
    std::string    str;
    char           buffer[30];

    /* Actualisation du nom de l'executable a analyser */
    this->_info->filename = this->ui->option__name->text().toStdString();

    /* Actualisation du format de fichier */
    if (this->ui->option__format->currentIndex() == 0)
        this->_info->format = Info::FORMAT_ELF32;
    else if (this->ui->option__format->currentIndex() == 1)
        this->_info->format = Info::FORMAT_ELF64;
    else if (this->ui->option__format->currentIndex() == 2)
        this->_info->format = Info::FORMAT_PE32;
    else if (this->ui->option__format->currentIndex() == 3)
        this->_info->format = Info::FORMAT_PE64;
    else if (this->ui->option__format->currentIndex() == 4)
        this->_info->format = Info::FORMAT_MBR;
    else if (this->ui->option__format->currentIndex() == 5)
        this->_info->format = Info::FORMAT_BRAINFUCK;
    else
        this->_info->format = Info::FORMAT_NONE;

    /* Actualisation de l'architecture */
    if (this->ui->option__archi->currentIndex() == 0)
        this->_info->archi = Info::ARCHI_I16;
    else if (this->ui->option__archi->currentIndex() == 1)
        this->_info->archi = Info::ARCHI_I32;
    else if (this->ui->option__archi->currentIndex() == 2)
        this->_info->archi = Info::ARCHI_I64;
    else if (this->ui->option__archi->currentIndex() == 3)
        this->_info->archi = Info::ARCHI_BRAINFUCK;
    else
        this->_info->archi = Info::ARCHI_NONE;

    /* Actualisation de l'endian */
    if (this->ui->option__endian->currentIndex() == 0)
        this->_info->endian = Info::ENDIAN_LITTLE;
    else if (this->ui->option__endian->currentIndex() == 1)
        this->_info->endian = Info::ENDIAN_BIG;
    else
        this->_info->endian = Info::ENDIAN_NONE;

    /* Actualisation de la liste de tout les plugins */
    for (std::map<std::string, Plugin*>::iterator it=this->_list_plugins->begin();
         it!=this->_list_plugins->end(); )
    {
        if (this->_list_plugins_tmp.find(it->first) == this->_list_plugins_tmp.end())
        {
            /* Si on enleve un plugin, il faut supprimer les infos du programme */
            this->_info->clear_proto();
            this->_info->clear_function();
            this->_info->clear_segment();
            this->_info->clear_analyse();

            delete it->second;
            this->_list_plugins->erase(it);
            it = this->_list_plugins->begin();
        }
        else
            it++;
    }
    *(this->_list_plugins) = this->_list_plugins_tmp;

    /* Actualisation des plugins a executer */
    this->_info->plugin.clear();
    for (int i=0; i<this->ui->plugin__liste_plugin->rowCount(); i++)
    {
        /* Ajout du plugin a la liste des plugins a executer s'il existe */
        if (reinterpret_cast<QCheckBox*>(this->ui->plugin__liste_plugin->cellWidget(i, 0))->isChecked())
        {
            /* Preparation du nom servant a repertorier le plugin */
            snprintf(buffer, 29, "%08lu", reinterpret_cast<QLabel*>(this->ui->plugin__liste_plugin->cellWidget(i, 3))->text().toLong());
            str = std::string(buffer)
                + std::string("-") + reinterpret_cast<QLabel*>(this->ui->plugin__liste_plugin->cellWidget(i, 2))->text().toStdString()
                + std::string(".") + reinterpret_cast<QLabel*>(this->ui->plugin__liste_plugin->cellWidget(i, 3))->text().toStdString()
                + std::string(".") + reinterpret_cast<QLabel*>(this->ui->plugin__liste_plugin->cellWidget(i, 1))->text().toStdString()
                + std::string(".") + reinterpret_cast<QLabel*>(this->ui->plugin__liste_plugin->cellWidget(i, 4))->text().toStdString();
            qDebug(str.c_str());
           /* Si le plugin existe on l'ajoute a la liste des plugins a executer */
           if (this->_list_plugins_tmp.find(str) != this->_list_plugins_tmp.end())
                this->_info->plugin[str] = this->_list_plugins_tmp[str];
        }
    }
    this->slot_plugin__clicked();
}


/**
** \fn void slot_plugin__new()
** \brief Gere l'ajout d'un nouveau plugin
**
** \return Retourne rien
*/
void    OptionWindow::slot_plugin__new()
{
    qDebug("OptionWindow::slot_plugin__new()\n");
    Plugin          *plugin;
    char            buffer[30];
    QCheckBox       *check;
    int             num_line;

    QStringList    filenames = QFileDialog::getOpenFileNames(this);
    for (int i=0; i<filenames.size(); i++)
    {
        if (filenames.at(i).size() > 0)
        {
            if ((plugin = Plugin::open_plugin(filenames.at(i).toStdString())) != NULL)
            {
                snprintf(buffer, 29, "%08lu", plugin->get_priorite());
                this->_list_plugins_tmp[std::string(buffer) + "-" + plugin->get_plugin_name()] = plugin;

                /* Ajoute le plugin a la liste */
                num_line = this->ui->plugin__liste_plugin->rowCount();
                this->ui->plugin__liste_plugin->insertRow(num_line);

                if ((check = new QCheckBox) != NULL)
                {
                    check->setChecked(false);
                    this->ui->plugin__liste_plugin->setCellWidget(num_line, 0, check);
                }
                this->ui->plugin__liste_plugin->setCellWidget(num_line, 1, new QLabel(QString::fromStdString(plugin->get_name())));
                this->ui->plugin__liste_plugin->setCellWidget(num_line, 2, new QLabel(QString::fromStdString(plugin->get_type())));
                this->ui->plugin__liste_plugin->setCellWidget(num_line, 3, new QLabel(QString::number(plugin->get_priorite())));
                this->ui->plugin__liste_plugin->setCellWidget(num_line, 4, new QLabel(QString::fromStdString(plugin->get_version())));
            }
            else
            {
                QMessageBox    msg(QMessageBox::Warning, "Option", "Le fichier \"" + filenames.at(i) + "\" n'est pas un plugin");
                msg.exec();
            }
        }
    }

    this->slot_plugin__clicked();
}

/**
** \fn void slot_plugin__delete()
** \brief Gere la suppression d'un plugin
**
** \return Retourne rien
*/
void    OptionWindow::slot_plugin__delete()
{
    qDebug("OptionWindow::slot_plugin__delete()\n");
    Plugin    *plugin;

    if ((plugin = this->ident_selected_plugin()) != NULL)
    {
        this->ui->plugin__liste_plugin->removeRow(this->ui->plugin__liste_plugin->currentRow());

        for (std::map<std::string, Plugin*>::iterator it=this->_list_plugins_tmp.begin();
             it!=this->_list_plugins_tmp.end(); )
        {
            if (it->second == plugin)
            {
                this->_list_plugins_tmp.erase(it);
                it = this->_list_plugins_tmp.begin();
            }
            else
                it++;
        }
    }

    this->slot_plugin__clicked();
}

/**
** \fn void slot_plugin__option_plugin()
** \brief Gere la modification des options a passer aux plugins
**
** \return Retourne rien
*/
void    OptionWindow::slot_plugin__option_plugin()
{
    qDebug("OptionWindow::slot_plugin__option_plugin()\n");
    Plugin                                *plugin;
    std::map<std::string, std::string>    *ptr_option_plugin;

    if ((plugin = this->ident_selected_plugin()) != NULL)
    {
        /* Si la liste d'options de ce plugin n'existe pas, on la cree */
        if (this->_info->option_plugin.find(plugin->get_plugin_name()) == this->_info->option_plugin.end())
            this->_info->option_plugin[plugin->get_plugin_name()] = std::map<std::string, std::string>();

        if (this->_info->option_plugin.find(plugin->get_plugin_name()) != this->_info->option_plugin.end())
        {
            ptr_option_plugin = &(this->_info->option_plugin.find(plugin->get_plugin_name())->second);

            OptionPluginOptionWindow    w(ptr_option_plugin, this);
            w.exec();
        }
    }

    this->slot_plugin__clicked();
}

/**
** \fn void slot_plugin__execute()
** \brief Gere l'execution d'un plugin
**
** \return Retourne rien
*/
void    OptionWindow::slot_plugin__execute()
{
    qDebug("OptionWindow::slot_plugin__execute()\n");
    Plugin    *plugin;
    int       ret;

    if ((plugin = this->ident_selected_plugin()) != NULL)
    {
        ret = plugin->execute(this->_info);
        if (ret == 0)
        {
            QMessageBox    msg(QMessageBox::Warning, "Option", QString::fromUtf8("Le plugin a été ignoré"));
            msg.exec();
        }
        if (ret > 0)
        {
            QMessageBox    msg(QMessageBox::Warning, "Option", QString::fromUtf8("Le plugin a été exécuté normalement"));
            msg.exec();
        }
        if (ret < 0)
        {
            QMessageBox    msg(QMessageBox::Warning, "Option", QString::fromUtf8("Le plugin a rencontré une erreur lors de son exécution"));
            msg.exec();
        }
    }

    this->slot_plugin__clicked();
}

/**
** \fn void slot_plugin__new()
** \brief Gere le clic sur un plugin de la liste plugin
**
** \return Retourne rien
*/
void    OptionWindow::slot_plugin__clicked()
{
    qDebug("OptionWindow::slot_plugin__clicked()\n");
    Plugin    *plugin;

    this->ui->plugin__delete->setEnabled(false);
    this->ui->plugin__execute->setEnabled(false);
    this->ui->plugin__option_plugin->setEnabled(false);

    if ((plugin = this->ident_selected_plugin()) != NULL)
    {
        this->ui->plugin__delete->setEnabled(true);
        this->ui->plugin__execute->setEnabled(true);
        this->ui->plugin__option_plugin->setEnabled(true);

        this->ui->plugin__description->setPlainText(QString::fromStdString(plugin->apropos()));
    }
}


/**
** \fn void resizeEvent(QResizeEvent *event)
** \brief Gere l'actualisation du menu en cas de redimentionement
**
** \param event Event decrivant le redimentionement
** \return Retourne rien
*/
void    OptionWindow::resizeEvent(QResizeEvent *event)
{
    this->ui->plugin__liste_plugin->resizeColumnToContents(1);
    this->QDialog::resizeEvent(event);
}

/**
** \fn Plugin *ident_selected_plugin()
** \brief Gere l'identification du plugin selectionnee dans la liste
**
** \return Retourne un pointeur sur le plugin
*/
Plugin    *OptionWindow::ident_selected_plugin()
{
    std::string    str;
    char           buffer[30];
    int            row;

    if ((this->ui->plugin__liste_plugin->currentRow() < 0) ||
        (this->ui->plugin__liste_plugin->currentRow() >= this->ui->plugin__liste_plugin->rowCount()))
        return (NULL);

    /* Preparation du nom servant a repertorier le plugin */
    row = this->ui->plugin__liste_plugin->currentRow();
    snprintf(buffer, 29, "%08lu", reinterpret_cast<QLabel*>(this->ui->plugin__liste_plugin->cellWidget(row, 3))->text().toLong());
    str = std::string(buffer)
        + std::string("-") + reinterpret_cast<QLabel*>(this->ui->plugin__liste_plugin->cellWidget(row, 2))->text().toStdString()
        + std::string(".") + reinterpret_cast<QLabel*>(this->ui->plugin__liste_plugin->cellWidget(row, 3))->text().toStdString()
        + std::string(".") + reinterpret_cast<QLabel*>(this->ui->plugin__liste_plugin->cellWidget(row, 1))->text().toStdString()
        + std::string(".") + reinterpret_cast<QLabel*>(this->ui->plugin__liste_plugin->cellWidget(row, 4))->text().toStdString();

    if (this->_list_plugins_tmp.find(str) != this->_list_plugins_tmp.end())
        return (this->_list_plugins_tmp.find(str)->second);
    return (NULL);
}





OptionPluginOptionWindow::OptionPluginOptionWindow(std::map<std::string, std::string> *option_plugin, QWidget *parent): QDialog(parent),
    _option_plugin(option_plugin),
    ui(new Ui::DialogOptionPlugin)
{
    int    i;
    ui->setupUi(this);

    this->ui->field_values->setRowCount(option_plugin->size());
    i = 0;

    for (std::map<std::string, std::string>::iterator it=option_plugin->begin();
         it!=option_plugin->end();
         it++)
    {

        this->ui->field_values->setItem(i, 0, new QTableWidgetItem(QString::fromStdString(it->first)));
        this->ui->field_values->setItem(i, 1, new QTableWidgetItem(QString::fromStdString(it->second)));
        i++;
    }

    this->slot_check();
}

OptionPluginOptionWindow::~OptionPluginOptionWindow()
{
    delete ui;
}


/**
** \fn void slot_validate()
** \brief Gere la validation des changements effectuee par le menu
**
** \return Retourne rien
*/
void    OptionPluginOptionWindow::slot_validate()
{
    qDebug("OptionPluginOptionWindow::slot_validate()\n");

    this->_option_plugin->clear();

    for (int i=0; i<this->ui->field_values->rowCount(); i++)
    {
        (*(this->_option_plugin))[this->ui->field_values->item(i, 0)->text().toStdString()] = this->ui->field_values->item(i, 1)->text().toStdString();
    }
}

/**
** \fn void slot_check()
** \brief Gere la validation des champs
**
** \return Retourne rien
*/
void    OptionPluginOptionWindow::slot_check()
{
    qDebug("OptionPluginOptionWindow::slot_check()\n");
    int    pos_row;

    this->ui->bt_delete->setEnabled(false);

    pos_row = this->ui->field_values->currentRow();
    if ((pos_row >= 0) && (pos_row < this->ui->field_values->rowCount()))
        this->ui->bt_delete->setEnabled(true);
}

/**
** \fn void slot_option__new()
** \brief Gere l'ajout d'une option
**
** \return Retourne rien
*/
void    OptionPluginOptionWindow::slot_option__new()
{
    qDebug("OptionPluginOptionWindow::slot_option__new()\n");
    int    pos_row;

    pos_row =  this->ui->field_values->rowCount();
    this->ui->field_values->insertRow(pos_row);
    this->ui->field_values->setItem(pos_row, 0, new QTableWidgetItem(""));
    this->ui->field_values->setItem(pos_row, 1, new QTableWidgetItem(""));
    this->ui->field_values->selectRow(pos_row);

    this->slot_check();
}

/**
** \fn void slot_option__delete()
** \brief Gere la suppression d'une option
**
** \return Retourne rien
*/
void    OptionPluginOptionWindow::slot_option__delete()
{
    qDebug("OptionPluginOptionWindow::slot_option__delete()\n");
    int    pos_row;

    if ((pos_row =  this->ui->field_values->currentRow()) >= 0)
        this->ui->field_values->removeRow(pos_row);

    this->slot_check();
}
