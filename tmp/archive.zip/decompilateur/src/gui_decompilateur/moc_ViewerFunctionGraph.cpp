/****************************************************************************
** Meta object code from reading C++ file 'ViewerFunctionGraph.hpp'
**
** Created: Tue May 19 13:12:02 2015
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "ViewerFunctionGraph.hpp"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'ViewerFunctionGraph.hpp' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_NodeBloc[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       3,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      10,    9,    9,    9, 0x0a,
      34,    9,    9,    9, 0x0a,
      56,    9,    9,    9, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_NodeBloc[] = {
    "NodeBloc\0\0slot_edit_description()\0"
    "slot_edit_prototype()\0slot_open_or_close()\0"
};

void NodeBloc::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        NodeBloc *_t = static_cast<NodeBloc *>(_o);
        switch (_id) {
        case 0: _t->slot_edit_description(); break;
        case 1: _t->slot_edit_prototype(); break;
        case 2: _t->slot_open_or_close(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObjectExtraData NodeBloc::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject NodeBloc::staticMetaObject = {
    { &INode::staticMetaObject, qt_meta_stringdata_NodeBloc,
      qt_meta_data_NodeBloc, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &NodeBloc::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *NodeBloc::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *NodeBloc::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_NodeBloc))
        return static_cast<void*>(const_cast< NodeBloc*>(this));
    return INode::qt_metacast(_clname);
}

int NodeBloc::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = INode::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 3)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 3;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
