#ifndef    EDGE_HPP_
#define    EDGE_HPP_

#include    <cmath>

#include    <QGraphicsItem>
#include    <QPainter>

class INode;


/**
** \class Edge
** \brief Classe permettant de dessiner les liens entre les actions
*/
class    Edge: public QGraphicsItem
{
public:
    enum {Type = UserType + 2 };

public:
    /**
    ** \fn Edge(INode *sourceNode, INode *destNode)
    ** \brief Constructeur de la classe Edge permettant de tracer un trait entre daux actions
    **
    ** \param sourceNode Node d'ou part le lien entre les deux Nodes
    ** \param destNode Node ou arrive le lien entre les deux Nodes
    */
    Edge(INode *sourceNode, INode *destNod);

    /**
    ** \fn ~Edge()
    ** \brief Destructeur de la classe Edge
    */
    ~Edge();

private:
    Edge(const Edge& c);
    Edge& operator = (const Edge& e);

public:
    /**
    ** \fn INode *get_source_node() const
    ** \brief Assesseur permettant d'acceder au Node ayant cree la fleche
    **
    ** \return Retourne un pointeur sur le Node ayant cree la fleche
    */
    INode        *get_source_node() const;

    /**
    ** \fn INode *get_dest_node() const
    ** \brief Assesseur permettant d'acceder au Node cible
    **
    ** \return Retourne un pointeur sur le Node cible
    */
    INode        *get_dest_node() const;


    /**
    ** \fn int type() const
    ** \brief Fonction permettant de connaitre le type de l'objet
    **
    ** \return Retourne le type de l'objet
    */
    int          type() const;

    /**
    **
    ** \fn void adjust()
    ** \brief Gere l'actualisation des coordonnees de la fleche
    **
    ** \return Retourne rien
    */
    void         adjust();

protected:
    /**
    ** \fn boundingRect() const
    ** \brief Modifie la zone d'affichage de la fleche
    **
    ** \return Retourne les dimensions de la nouvelle zone d'affichage de la fleche
    */
    QRectF       boundingRect() const;

    /**
    ** \fn QPainterPath shape() const
    ** \brief Modifie la zone de selection de la fleche afin qu'on ne puisse pas la toucher
    **
    ** \return Retourne la zone de selection de la fleche
    */
    QPainterPath shape() const;

    /**
    ** \fn void paint(QPainter *painter, const QStyleOptionGraphicsItem *, QWidget *)
    ** \brief Gere l'affichage de la fleche
    **
    ** \param painter Objet permettant de dessiner la fleche
    ** \return Retourne rien
    */
    void         paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);

private:
    /** Pointeur sur le Node d'ou part la fleche */
    INode      *_source;
    /** Pointeur sur le Node ou arrive la fleche (peut etre NULL) */
    INode      *_dest;

    /** Coordonnees du debut de la fleche */
    QPointF    _sourcePoint;
    /** Coordonnees de la pointe de la fleche */
    QPointF    _destPoint;
    /** Taille de la pointe */
    qreal      _arrowSize;
};

#endif

