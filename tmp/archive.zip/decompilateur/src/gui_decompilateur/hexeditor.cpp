#include "HexEditor.hpp"

#include <QtGui>


HexEditor::HexEditor(QWidget *parent): QPlainTextEdit(parent),
    _addr(0),
    _data(),
    _scrollbar(NULL),
    lineNumberArea(NULL),
    asciiArea(NULL),
    _mutex()
{
    lineNumberArea = new LineNumberArea(this);
    asciiArea = new AsciiArea(this);

    connect(this, SIGNAL(blockCountChanged(int)), this, SLOT(updateLineNumberAreaWidth(int)));
    connect(this, SIGNAL(updateRequest(QRect,int)), this, SLOT(updateLineNumberArea(QRect,int)));
    connect(this, SIGNAL(cursorPositionChanged()), this, SLOT(highlightCurrentLine()));

    connect(this, SIGNAL(textChanged()), this, SLOT(slot_text_changed()));

    updateLineNumberAreaWidth(0);
    highlightCurrentLine();

    this->setOverwriteMode(true);
}

HexEditor::~HexEditor()
{
    if (this->lineNumberArea != NULL)
        delete this->lineNumberArea;
    if (this->asciiArea != NULL)
        delete this->asciiArea;
}



/**
** \fn void set_data_hex(QSlider *scrollbar, unsigned long addr=0, const unsigned char *data=NULL, unsigned long size=0)
** \brief Gere l'initialisation de l'editeur pour afficher les donnees correctement
**
** \param scrollbar Pointeur sur la scrollbar permettant de gerer le defilement
** \param addr Adresse des donnees
** \param data Donnees a afficher
** \param size Taille des donnees a afficher
** \return Retourne rien
*/
void    HexEditor::set_data_hex(QSlider *scrollbar, unsigned long addr, const unsigned char *data, unsigned long size)
{
    /* Actualisation de l'adresse des donnees */
    this->set_address(addr);
    this->_data.clear();

    /* Actualisation des donnees */
    if (data != NULL)
    {
        /* Copie du buffer dans le vector */
        this->_data.resize(size, 0);
        for (unsigned long i=0; i<size; i++)
            this->_data[i] = data[i];

        this->put_data();
    }

    /* Preparation de la scrollbar */
    if ((this->_scrollbar = scrollbar) != NULL)
    {
        /* La valeur maximum de la scrollber depend de la taille des donnees de l'editeur */
        int max = this->nbs_char_area();
        if (max > 0)
        {
            max = this->_data.size() / max;
            max = max - (this->height() / fontMetrics().height());
            if (max < 0)
                max = 0;
        }

        this->_scrollbar->setMinimum(0);
        this->_scrollbar->setMaximum(max);
        this->_scrollbar->setSliderPosition(0);
    }
}

/**
** \fn void set_address(unsigned long addr)
** \brief Assesseur permettant de modifier l'adresse du debut des donnes a afficher
**
** \param addr Addresse du debut des donnes a afficher
** \return Retourne rien
*/
void    HexEditor::set_address(unsigned long addr)
{
    this->_addr = addr;
    this->slot_resize();
}

/**
** \fn const std::vector<unsigned char> &get_data() const
** \brief Assesseur permettant d'acceder aux donnees affichees par l'editeur
**
** \return Retourne une reference sur les donnees affichees par l'editeur
*/
const std::vector<unsigned char> &HexEditor::get_data() const
{
    return (this->_data);
}


int    HexEditor::lineNumberAreaWidth()
{
    int              digits;
    unsigned long    max;

    digits = 1;
    max = qMax(1, blockCount()) + this->_addr + this->_data.size();
    while (max >= 16)
    {
        max /= 16;
        ++digits;
    }

    return (fontMetrics().width(QLatin1Char('9')) * (digits + 3));
}

int    HexEditor::asciiAreaWidth()
{
    return (3 + fontMetrics().width(QLatin1Char('9')) * (this->nbs_char_area() + 1));
}

int     HexEditor::nbs_char_area()
{
    int   res;

    res = (int)((double)(this->width() - this->lineNumberAreaWidth()) / (fontMetrics().width(QLatin1Char('9')) * 4)) - 1;
    if (res < 0)
        res = 0;
    return (res);
}



void    HexEditor::updateLineNumberAreaWidth(int /* newBlockCount */)
{
    setViewportMargins(this->lineNumberAreaWidth(), 0, this->asciiAreaWidth(), 0);
}



 void    HexEditor::updateLineNumberArea(const QRect &rect, int dy)
 {
     if (dy)
     {
         lineNumberArea->scroll(0, dy);
         asciiArea->scroll(0, dy);
     }
     else
     {
         lineNumberArea->update(0, rect.y(), lineNumberArea->width(), rect.height());
         asciiArea->update(0, rect.y(), asciiArea->width(), rect.height());
     }

     if (rect.contains(viewport()->rect()))
         updateLineNumberAreaWidth(0);
 }



void HexEditor::resizeEvent(QResizeEvent *e)
{
   QPlainTextEdit::resizeEvent(e);

   this->slot_resize();
}



void HexEditor::highlightCurrentLine()
{
    QTextCursor                         cursor;
    QChar                               c;
    QList<QTextEdit::ExtraSelection>    extraSelections;

    /* Si le curseur est sur un ' ' ou un '\n', il faut le deplacer d'une case en avant */
    cursor = this->textCursor();
    c = cursor.block().text().at( cursor.positionInBlock() );
    if ((c == ' ') || (c == '\n'))
    {
        cursor.setPosition(cursor.position() + 1);
        this->setTextCursor(cursor);
    }

    /*if (!isReadOnly()) */
    {
        QTextEdit::ExtraSelection    selection;

        QColor lineColor = QColor(230, 230, 230);

        selection.format.setBackground(lineColor);
        selection.format.setProperty(QTextFormat::FullWidthSelection, true);
        selection.cursor = textCursor();
        selection.cursor.clearSelection();
        extraSelections.append(selection);
    }

    setExtraSelections(extraSelections);
}

/**
** \fn void lineNumberAreaPaintEvent(QPaintEvent *event)
** \brief Gere l'affichage de l'offset des donnees
**
** \param event Event a utiliser pour situer la position actuelle dans les donnees
** \return Retourne rien
*/
void    HexEditor::lineNumberAreaPaintEvent(QPaintEvent *event)
{
    unsigned long    block_number;
    QTextBlock       block;

    /* Prepare la zone pour les offsets de donnees */
    QPainter    painter(lineNumberArea);
    painter.fillRect(event->rect(), Qt::lightGray);
    block = firstVisibleBlock();

    /* Calcul la position dans les donnees en fonction de la valeur de la scrollbar */
    block_number = block.blockNumber();
    if (this->_scrollbar != NULL)
        block_number += this->_addr + this->nbs_char_area() * this->_scrollbar->value();
    else
        block_number += this->_addr;

    /* Pour chaque ligne visible, affiche son offset */
    int top = (int) blockBoundingGeometry(block).translated(contentOffset()).top();
    int bottom = top + (int) blockBoundingRect(block).height();
    while (block.isValid() && top <= event->rect().bottom())
    {
        if (block.isVisible() && bottom >= event->rect().top())
        {
            QString number = QString::number(block_number, 16);
            painter.setPen(Qt::black);
            painter.drawText(0, top, lineNumberArea->width(), fontMetrics().height(),
                              Qt::AlignRight, number + ": ");
        }

        block = block.next();
        top = bottom;
        bottom = top + (int) blockBoundingRect(block).height();
        block_number += this->nbs_char_area();
    }
}

/**
** \fn void asciiAreaPaintEvent(QPaintEvent *event)
** \brief Gere l'affichage des valeurs ASCII des donnees affichees
**
** \param event Event a utiliser pour situer la position actuelle dans les donnees
** \return Retourne rien
*/
void    HexEditor::asciiAreaPaintEvent(QPaintEvent *event)
{
    QTextBlock    block;

    /* Prepare la zone pour les offsets de donnees */
    QPainter    painter(asciiArea);
    painter.fillRect(event->rect(), Qt::lightGray);

    /* Calcul la position dans les donnees en fonction de la valeur de la scrollbar */
    block = firstVisibleBlock();
    int top = (int) blockBoundingGeometry(block).translated(contentOffset()).top();
    int bottom = top + (int) blockBoundingRect(block).height();

    /* Affiche la valeur ASCII de toutes les donnees affichees */
    while (block.isValid() && top <= event->rect().bottom())
    {
        if (block.isVisible() && bottom >= event->rect().top())
        {
            char           c;
            char           car;
            QString        str = block.text();
            std::string    str2;

            car = 0;

            for (long i=0, nibble=0; i<str.size(); i++)
            {
                c = str.at(i).toAscii();
                if (isxdigit(c))
                {
                    if ((c >= '0') && (c <= '9'))
                        car = (car << 4) + c - '0';
                    else if ((c >= 'a') && (c <= 'f'))
                        car = (car << 4) + c - 'a' + 10;
                    else
                        car = (car << 4) + c - 'A' + 10;
                    nibble++;

                    if (((nibble % 2) == 0) && (nibble > 0))
                    {
                        if (isprint(car))
                            str2 += car;
                        else
                            str2 += ".";
                    }
                }
            }

            painter.setPen(Qt::black);
            painter.drawText(0, top, asciiArea->width(), fontMetrics().height(),
                             Qt::AlignLeft, QString::fromStdString(" " + str2));
        }

        block = block.next();
        top = bottom;
        bottom = top + (int) blockBoundingRect(block).height();
    }
}


 int     HexEditor::put_data()
 {
     QString          str;
     char             tmp[4];
     unsigned char    c;
     unsigned long    nbs_car_line;
     unsigned long    nbs_line;
     int              scrollbar_value;
     int              pos_cursor;
     QTextCursor      cursor;

     /* Sauvegarde de la position du curseur */
     disconnect(this, SIGNAL(textChanged()), this, SLOT(slot_text_changed()));
     cursor = this->textCursor();
     pos_cursor = cursor.position();

     strcpy(tmp, "00 ");

     nbs_car_line = this->nbs_char_area();
     nbs_line = (this->height() / fontMetrics().height());
     if (nbs_line > 0)
         nbs_line--;
     scrollbar_value = 0;
     if (this->_scrollbar != NULL)
         scrollbar_value = this->_scrollbar->value();


     for (unsigned long i=0; (i<nbs_car_line*nbs_line) && (i+scrollbar_value*nbs_car_line<this->_data.size()); i++)
     {
         c = this->_data[i+scrollbar_value*nbs_car_line];
         if ((c & 0xf) <= 9)
             tmp[1] = (c & 0xf) + '0';
         else
             tmp[1] = (c & 0xf) + 'a' - 10;

         c = c >> 4;
         if ((c & 0xf) <= 9)
             tmp[0] = (c & 0xf) + '0';
         else
             tmp[0] = (c & 0xf) + 'a' - 10;


         if ((((i+1) % nbs_car_line) == 0) && (i > 0) &&
             ((i+1)<nbs_car_line*nbs_line) && ((i+1)+scrollbar_value*nbs_car_line<this->_data.size()))
             tmp[2] = '\n';
         else
             tmp[2] = ' ';
         str.append(tmp);
     }
     this->setPlainText(str);

     /* Restauration du curseur */
     if (pos_cursor < 0)
         pos_cursor = 0;
     if ((str[pos_cursor] == ' ') || (str[pos_cursor] == '\n'))
         pos_cursor++;
     cursor.setPosition(pos_cursor);
     this->setTextCursor(cursor);
     connect(this, SIGNAL(textChanged()), this, SLOT(slot_text_changed()));

     return (1);
 }

void     HexEditor::slot_resize()
{
    if (this->_mutex.try_lock())
    {
        QRect cr = contentsRect();
        lineNumberArea->setGeometry(QRect(cr.left(), cr.top(), lineNumberAreaWidth(), cr.height()));
        asciiArea->setGeometry(QRect(cr.width()-asciiAreaWidth(), cr.top(), asciiAreaWidth(), cr.height()));

        this->verticalScrollBar()->setSliderPosition(0);
        updateLineNumberAreaWidth(0);

        /* Preparation de la scrollbar a chaque redimentionnement */
        if (this->_scrollbar != NULL)
        {
            this->_scrollbar->setMinimum(0);
            int max = nbs_char_area();
            if (max > 0)
                max = this->_data.size() / max;

            if (max < this->_scrollbar->value())
                this->_scrollbar->setSliderPosition(max);
            this->_scrollbar->setMaximum(max);
        }

        this->put_data();
        this->_mutex.unlock();
    }
}




void     HexEditor::slot_show_up()
{
    if (this->_scrollbar != NULL)
    {
        if (this->_scrollbar->value() > this->_scrollbar->minimum())
            this->_scrollbar->setValue(this->_scrollbar->value() - 1);
    }
}

void     HexEditor::slot_show_down()
{
    if (this->_scrollbar != NULL)
    {
        if (this->_scrollbar->value() < this->_scrollbar->maximum())
            this->_scrollbar->setValue(this->_scrollbar->value() + 1);
    }
}

void    HexEditor::slot_text_changed()
{
    unsigned long    offset;
    unsigned long    i;
    unsigned long    j;
    unsigned long    nibble;
    unsigned char    c;
    std::string      str;

    /* Decalage des donnees a modifier */
    offset = 0;
    if (this->_scrollbar != NULL)
        offset = this->_scrollbar->value() * this->nbs_char_area();

    str = this->toPlainText().toStdString();
    for (i=0, j=0, nibble=0, c=0; i<str.size(); i++)
    {
        if (isxdigit(str[i]))
        {
            if ((str[i] >= '0') && (str[i] <= '9'))
                c = (c << 4) + (str[i] - '0');
            if ((str[i] >= 'a') && (str[i] <= 'f'))
                c = (c << 4) + (str[i] - 'a' + 10);
            if ((str[i] >= 'A') && (str[i] <= 'F'))
                c = (c << 4) + (str[i] - 'A' + 10);
            nibble++;

            if ((nibble % 2) == 0)
            {
                if ((offset + j) < this->_data.size())
                    this->_data[offset + j] = c;
                else
                    this->_data.push_back(c);
                c = 0;
                j++;
            }
        }
    }

    /* Complete le dernier octet si besoin est */
    if ((nibble % 2) != 0)
    {
        if ((offset + j) < this->_data.size())
            this->_data[offset + j] = (c << 4) + (this->_data[offset + j] & 0xf);
        else
            this->_data.push_back(c << 4);
    }

    /* Actualisation de l'affichage */
    this->put_data();
}

void HexEditor::keyPressEvent(QKeyEvent *e)
{
    QMimeData        mime_data;
    unsigned long    position;
    int              ok;
    int key[] =
    {
        Qt::Key_0, Qt::Key_1, Qt::Key_2, Qt::Key_3, Qt::Key_4,
        Qt::Key_5, Qt::Key_6, Qt::Key_7, Qt::Key_8, Qt::Key_9,
        Qt::Key_A, Qt::Key_B, Qt::Key_C, Qt::Key_D, Qt::Key_E, Qt::Key_F
    };
    const char *value_key[] =
    {
        "0", "1", "2", "3", "4",
        "5", "6", "7", "8", "9",
        "A", "B", "C", "D", "E", "F"
    };

    if ((e != NULL) && (this->_scrollbar != NULL))
    {
        ok = 0;
        if (!this->isReadOnly())
        {
            /* Gestion des touche Hexadecimales */
            for (int i=0; (i<16) && (ok!=1); i++)
            {
                if ((key[i] == e->key()) && ((e->modifiers() & Qt::ControlModifier) != Qt::ControlModifier))
                {
                    mime_data.setText(value_key[i]);
                    this->insertFromMimeData(&mime_data);
                    ok = 1;
                }
            }

            /* Gestion de DELETE et BACKSPACE */
            if ((ok == 0) && ((e->key() == Qt::Key_Delete) || (e->key() == Qt::Key_Backspace)))
            {
                /* Calcul du numero de l'octet a supprimer */
                position = (this->textCursor().position() / 3) + (this->_scrollbar->value() * this->nbs_char_area());

                /* Suppression de l'octet dans le buffer et actualisation de l'affichage */
                if (position < this->_data.size())
                    this->_data.erase(this->_data.begin() + position);
                this->slot_resize();
                ok = 1;
            }

            /* En cas d'appuis sur la touche BAS : */
            /* Si on est sur la derniere ligne affichee -> on descend l'affichage */
            if ((e->key() == Qt::Key_Down) &&
                (this->textCursor().blockNumber() >= (this->blockCount()-1)))
                this->slot_show_down();

            /* En cas d'appuis sur la touche HAUT : */
            /* Si on est sur la premiere ligne affichee -> on monte l'affichage */
            else if ((e->key() == Qt::Key_Up) &&
                     (this->textCursor().blockNumber() <= 0))
                this->slot_show_up();

            /* En cas d'appuis sur la touche DROITE : */
            /* Si on est sur le dernier caractere de la derniere ligne affichee -> on descend l'affichage et on vas au debut de la ligne */
            else if ((e->key() == Qt::Key_Right) &&
                (this->textCursor().blockNumber() >= (this->blockCount()-1)) &&
                (this->textCursor().atBlockEnd()))
            {
                this->slot_show_down();

                QTextCursor cursor = this->textCursor();
                cursor.setPosition(cursor.block().position());
                this->setTextCursor(cursor);
                ok = 1;
            }

            /* En cas d'appuis sur la touche GAUCHE : */
            /* Si on est sur le premier caractere de la premiere ligne affichee -> on monte l'affichage et on vas a la fin de la ligne */
            else if ((e->key() == Qt::Key_Left) &&
                     (this->textCursor().blockNumber() <= 0) &&
                     (this->textCursor().atBlockStart()))
            {
                QTextCursor cursor = this->textCursor();

                this->slot_show_up();

                cursor.setPosition(cursor.block().length() - 2);
                this->setTextCursor(cursor);
                ok = 1;
            }

            /* En cas d'appuis sur la touche GAUCHE : */
            /* Si on est pas au debut de la ligne et avant un ' ' ou un '\n' -> on doit reculer de 2 caracteres */
            else if ((e->key() == Qt::Key_Left) &&
                     (this->textCursor().positionInBlock() > 2) &&
                     ((this->textCursor().positionInBlock() % 3) == 0))
            {
                QTextCursor cursor = this->textCursor();

                cursor.setPosition(cursor.position() - 2);
                this->setTextCursor(cursor);
                ok = 1;
            }
       }

        /* Si la touche n'est pas geree */
        if ((ok == 0) && ((e->modifiers() == Qt::ControlModifier) ||
                          (e->key() == Qt::Key_Up) || (e->key() == Qt::Key_Down) ||
                          (e->key() == Qt::Key_Left) || (e->key() == Qt::Key_Right)))
            QPlainTextEdit::keyPressEvent(e);
    }
}

void HexEditor::insertFromMimeData(const QMimeData *source)
{
    QString          text_content;
    std::string      txt_paste;
    std::string      data;
    unsigned long    pos;
    int              pos_cursor;
    QTextCursor      cursor;

    /* Sauvegarde de la position du curseur */
    disconnect(this, SIGNAL(textChanged()), this, SLOT(slot_text_changed()));
    cursor = this->textCursor();
    pos_cursor = cursor.position();

    if ((source != NULL) && (source->hasText()))
    {
        /* On ne garde que les caracteres ascii */
        txt_paste = source->text().toStdString();
        while ((pos = txt_paste.find_first_not_of("0123456789abcdefABCDEF")) != std::string::npos)
            txt_paste.erase(pos, 1);

        /* Recupere le contenu du QTextEdit */
        text_content = this->toPlainText();
        if (this->textCursor().position() > 0)
        {
            data = text_content.toStdString().substr(this->textCursor().position(), -1);
            text_content.resize(this->textCursor().position());
        }
        else
        {
            data = text_content.toStdString();
            text_content = "";
        }

        /* Epure le contenu du QTextEdit destinee a etre remplace */
        while ((pos = data.find_first_not_of("0123456789abcdefABCDEF")) != std::string::npos)
            data.erase(pos, 1);

        /* Insere les nouveaux caracteres dans le texte */
        data.replace(0, txt_paste.size(), txt_paste);

        /* Recree le contenu du QTextEdit et actualise les donnees */
        this->setPlainText(text_content + QString::fromStdString(data));
        this->slot_text_changed();
    }

    /* Restauration du curseur */
    pos_cursor += txt_paste.size() + (txt_paste.size() / 2);
    if (pos_cursor < 0)
        pos_cursor = 0;
    cursor.setPosition(pos_cursor);
    this->setTextCursor(cursor);
    connect(this, SIGNAL(textChanged()), this, SLOT(slot_text_changed()));
}
