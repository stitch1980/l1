/****************************************************************************
** Meta object code from reading C++ file 'newprototypewindow.h'
**
** Created: Thu May 14 13:51:04 2015
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "newprototypewindow.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'newprototypewindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_NewPrototypeWindow[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
      10,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      20,   19,   19,   19, 0x0a,
      36,   19,   19,   19, 0x0a,
      49,   19,   19,   19, 0x0a,
      71,   19,   19,   19, 0x0a,
      89,   19,   19,   19, 0x0a,
     108,   19,   19,   19, 0x0a,
     129,   19,   19,   19, 0x0a,
     146,   19,   19,   19, 0x0a,
     165,   19,   19,   19, 0x0a,
     191,   19,   19,   19, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_NewPrototypeWindow[] = {
    "NewPrototypeWindow\0\0slot_validate()\0"
    "slot_check()\0slot_param__clicked()\0"
    "slot_param__new()\0slot_param__edit()\0"
    "slot_param__delete()\0slot_param__up()\0"
    "slot_param__down()\0slot_param__tab_to_line()\0"
    "slot_param__line_to_tab()\0"
};

void NewPrototypeWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        NewPrototypeWindow *_t = static_cast<NewPrototypeWindow *>(_o);
        switch (_id) {
        case 0: _t->slot_validate(); break;
        case 1: _t->slot_check(); break;
        case 2: _t->slot_param__clicked(); break;
        case 3: _t->slot_param__new(); break;
        case 4: _t->slot_param__edit(); break;
        case 5: _t->slot_param__delete(); break;
        case 6: _t->slot_param__up(); break;
        case 7: _t->slot_param__down(); break;
        case 8: _t->slot_param__tab_to_line(); break;
        case 9: _t->slot_param__line_to_tab(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObjectExtraData NewPrototypeWindow::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject NewPrototypeWindow::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_NewPrototypeWindow,
      qt_meta_data_NewPrototypeWindow, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &NewPrototypeWindow::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *NewPrototypeWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *NewPrototypeWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_NewPrototypeWindow))
        return static_cast<void*>(const_cast< NewPrototypeWindow*>(this));
    return QDialog::qt_metacast(_clname);
}

int NewPrototypeWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 10)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 10;
    }
    return _id;
}
static const uint qt_meta_data_NewParametreFonctionWindow[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       2,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      28,   27,   27,   27, 0x0a,
      44,   27,   27,   27, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_NewParametreFonctionWindow[] = {
    "NewParametreFonctionWindow\0\0slot_validate()\0"
    "slot_check_formulaire()\0"
};

void NewParametreFonctionWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        NewParametreFonctionWindow *_t = static_cast<NewParametreFonctionWindow *>(_o);
        switch (_id) {
        case 0: _t->slot_validate(); break;
        case 1: _t->slot_check_formulaire(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObjectExtraData NewParametreFonctionWindow::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject NewParametreFonctionWindow::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_NewParametreFonctionWindow,
      qt_meta_data_NewParametreFonctionWindow, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &NewParametreFonctionWindow::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *NewParametreFonctionWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *NewParametreFonctionWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_NewParametreFonctionWindow))
        return static_cast<void*>(const_cast< NewParametreFonctionWindow*>(this));
    return QDialog::qt_metacast(_clname);
}

int NewParametreFonctionWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 2)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 2;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
