/********************************************************************************
** Form generated from reading UI file 'optionwindow.ui'
**
** Created: Thu May 14 13:50:04 2015
**      by: Qt User Interface Compiler version 4.8.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_OPTIONWINDOW_H
#define UI_OPTIONWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QComboBox>
#include <QtGui/QDialog>
#include <QtGui/QDialogButtonBox>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QTabWidget>
#include <QtGui/QTableWidget>
#include <QtGui/QTextEdit>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Dialog
{
public:
    QVBoxLayout *verticalLayout;
    QTabWidget *tabWidget;
    QWidget *tab;
    QVBoxLayout *verticalLayout_3;
    QWidget *widget_5;
    QHBoxLayout *horizontalLayout_5;
    QLabel *label_3;
    QLineEdit *option__name;
    QWidget *widget_2;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label;
    QComboBox *option__format;
    QWidget *widget_3;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_2;
    QComboBox *option__archi;
    QWidget *widget_6;
    QHBoxLayout *horizontalLayout_6;
    QLabel *label_4;
    QComboBox *option__endian;
    QSpacerItem *verticalSpacer;
    QWidget *tab_2;
    QVBoxLayout *verticalLayout_2;
    QWidget *widget_4;
    QHBoxLayout *horizontalLayout_4;
    QTableWidget *plugin__liste_plugin;
    QTextEdit *plugin__description;
    QWidget *widget;
    QHBoxLayout *horizontalLayout;
    QPushButton *plugin__new;
    QPushButton *plugin__delete;
    QSpacerItem *horizontalSpacer;
    QPushButton *plugin__option_plugin;
    QPushButton *plugin__execute;
    QDialogButtonBox *buttonBox;

    void setupUi(QDialog *Dialog)
    {
        if (Dialog->objectName().isEmpty())
            Dialog->setObjectName(QString::fromUtf8("Dialog"));
        Dialog->resize(954, 595);
        verticalLayout = new QVBoxLayout(Dialog);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        tabWidget = new QTabWidget(Dialog);
        tabWidget->setObjectName(QString::fromUtf8("tabWidget"));
        tab = new QWidget();
        tab->setObjectName(QString::fromUtf8("tab"));
        verticalLayout_3 = new QVBoxLayout(tab);
        verticalLayout_3->setSpacing(6);
        verticalLayout_3->setContentsMargins(11, 11, 11, 11);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        widget_5 = new QWidget(tab);
        widget_5->setObjectName(QString::fromUtf8("widget_5"));
        horizontalLayout_5 = new QHBoxLayout(widget_5);
        horizontalLayout_5->setSpacing(6);
        horizontalLayout_5->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        label_3 = new QLabel(widget_5);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        horizontalLayout_5->addWidget(label_3);

        option__name = new QLineEdit(widget_5);
        option__name->setObjectName(QString::fromUtf8("option__name"));

        horizontalLayout_5->addWidget(option__name);


        verticalLayout_3->addWidget(widget_5);

        widget_2 = new QWidget(tab);
        widget_2->setObjectName(QString::fromUtf8("widget_2"));
        horizontalLayout_2 = new QHBoxLayout(widget_2);
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        label = new QLabel(widget_2);
        label->setObjectName(QString::fromUtf8("label"));

        horizontalLayout_2->addWidget(label);

        option__format = new QComboBox(widget_2);
        option__format->setObjectName(QString::fromUtf8("option__format"));

        horizontalLayout_2->addWidget(option__format);


        verticalLayout_3->addWidget(widget_2);

        widget_3 = new QWidget(tab);
        widget_3->setObjectName(QString::fromUtf8("widget_3"));
        horizontalLayout_3 = new QHBoxLayout(widget_3);
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        label_2 = new QLabel(widget_3);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        horizontalLayout_3->addWidget(label_2);

        option__archi = new QComboBox(widget_3);
        option__archi->setObjectName(QString::fromUtf8("option__archi"));

        horizontalLayout_3->addWidget(option__archi);


        verticalLayout_3->addWidget(widget_3);

        widget_6 = new QWidget(tab);
        widget_6->setObjectName(QString::fromUtf8("widget_6"));
        horizontalLayout_6 = new QHBoxLayout(widget_6);
        horizontalLayout_6->setSpacing(6);
        horizontalLayout_6->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        label_4 = new QLabel(widget_6);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        horizontalLayout_6->addWidget(label_4);

        option__endian = new QComboBox(widget_6);
        option__endian->setObjectName(QString::fromUtf8("option__endian"));

        horizontalLayout_6->addWidget(option__endian);


        verticalLayout_3->addWidget(widget_6);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_3->addItem(verticalSpacer);

        tabWidget->addTab(tab, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QString::fromUtf8("tab_2"));
        verticalLayout_2 = new QVBoxLayout(tab_2);
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setContentsMargins(11, 11, 11, 11);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        widget_4 = new QWidget(tab_2);
        widget_4->setObjectName(QString::fromUtf8("widget_4"));
        horizontalLayout_4 = new QHBoxLayout(widget_4);
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        plugin__liste_plugin = new QTableWidget(widget_4);
        if (plugin__liste_plugin->columnCount() < 5)
            plugin__liste_plugin->setColumnCount(5);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        plugin__liste_plugin->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        plugin__liste_plugin->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        plugin__liste_plugin->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        plugin__liste_plugin->setHorizontalHeaderItem(3, __qtablewidgetitem3);
        QTableWidgetItem *__qtablewidgetitem4 = new QTableWidgetItem();
        plugin__liste_plugin->setHorizontalHeaderItem(4, __qtablewidgetitem4);
        plugin__liste_plugin->setObjectName(QString::fromUtf8("plugin__liste_plugin"));
        plugin__liste_plugin->horizontalHeader()->setVisible(false);
        plugin__liste_plugin->horizontalHeader()->setStretchLastSection(true);
        plugin__liste_plugin->verticalHeader()->setVisible(false);

        horizontalLayout_4->addWidget(plugin__liste_plugin);

        plugin__description = new QTextEdit(widget_4);
        plugin__description->setObjectName(QString::fromUtf8("plugin__description"));
        plugin__description->setReadOnly(true);

        horizontalLayout_4->addWidget(plugin__description);


        verticalLayout_2->addWidget(widget_4);

        widget = new QWidget(tab_2);
        widget->setObjectName(QString::fromUtf8("widget"));
        horizontalLayout = new QHBoxLayout(widget);
        horizontalLayout->setSpacing(6);
        horizontalLayout->setContentsMargins(11, 11, 11, 11);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        plugin__new = new QPushButton(widget);
        plugin__new->setObjectName(QString::fromUtf8("plugin__new"));

        horizontalLayout->addWidget(plugin__new);

        plugin__delete = new QPushButton(widget);
        plugin__delete->setObjectName(QString::fromUtf8("plugin__delete"));
        plugin__delete->setEnabled(false);

        horizontalLayout->addWidget(plugin__delete);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        plugin__option_plugin = new QPushButton(widget);
        plugin__option_plugin->setObjectName(QString::fromUtf8("plugin__option_plugin"));
        plugin__option_plugin->setEnabled(false);

        horizontalLayout->addWidget(plugin__option_plugin);

        plugin__execute = new QPushButton(widget);
        plugin__execute->setObjectName(QString::fromUtf8("plugin__execute"));
        plugin__execute->setEnabled(false);

        horizontalLayout->addWidget(plugin__execute);


        verticalLayout_2->addWidget(widget);

        tabWidget->addTab(tab_2, QString());

        verticalLayout->addWidget(tabWidget);

        buttonBox = new QDialogButtonBox(Dialog);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);

        verticalLayout->addWidget(buttonBox);


        retranslateUi(Dialog);
        QObject::connect(buttonBox, SIGNAL(accepted()), Dialog, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), Dialog, SLOT(reject()));
        QObject::connect(Dialog, SIGNAL(accepted()), Dialog, SLOT(slot_validate()));
        QObject::connect(plugin__new, SIGNAL(clicked()), Dialog, SLOT(slot_plugin__new()));
        QObject::connect(plugin__delete, SIGNAL(clicked()), Dialog, SLOT(slot_plugin__delete()));
        QObject::connect(plugin__execute, SIGNAL(clicked()), Dialog, SLOT(slot_plugin__execute()));
        QObject::connect(plugin__liste_plugin, SIGNAL(currentCellChanged(int,int,int,int)), Dialog, SLOT(slot_plugin__clicked()));
        QObject::connect(plugin__option_plugin, SIGNAL(clicked()), Dialog, SLOT(slot_plugin__option_plugin()));

        tabWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(Dialog);
    } // setupUi

    void retranslateUi(QDialog *Dialog)
    {
        Dialog->setWindowTitle(QApplication::translate("Dialog", "Options", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("Dialog", "Nom de l'ex\303\251cutable \303\240 analyser :", 0, QApplication::UnicodeUTF8));
        option__name->setText(QString());
        label->setText(QApplication::translate("Dialog", "Format de fichier :", 0, QApplication::UnicodeUTF8));
        option__format->clear();
        option__format->insertItems(0, QStringList()
         << QApplication::translate("Dialog", "ELF32", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("Dialog", "ELF64", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("Dialog", "PE32", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("Dialog", "PE64", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("Dialog", "MBR", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("Dialog", "Brainfuck", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("Dialog", "NONE", 0, QApplication::UnicodeUTF8)
        );
        label_2->setText(QApplication::translate("Dialog", "Architecture :", 0, QApplication::UnicodeUTF8));
        option__archi->clear();
        option__archi->insertItems(0, QStringList()
         << QApplication::translate("Dialog", "i386 (16 bits)", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("Dialog", "i386", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("Dialog", "x86_64", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("Dialog", "Brainfuck", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("Dialog", "NONE", 0, QApplication::UnicodeUTF8)
        );
        label_4->setText(QApplication::translate("Dialog", "Endian :", 0, QApplication::UnicodeUTF8));
        option__endian->clear();
        option__endian->insertItems(0, QStringList()
         << QApplication::translate("Dialog", "Little endian", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("Dialog", "Big endian", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("Dialog", "NONE", 0, QApplication::UnicodeUTF8)
        );
        tabWidget->setTabText(tabWidget->indexOf(tab), QApplication::translate("Dialog", "Options", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem = plugin__liste_plugin->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QApplication::translate("Dialog", "Selectionn\303\251", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem1 = plugin__liste_plugin->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QApplication::translate("Dialog", "Nom", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem2 = plugin__liste_plugin->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QApplication::translate("Dialog", "Type", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem3 = plugin__liste_plugin->horizontalHeaderItem(3);
        ___qtablewidgetitem3->setText(QApplication::translate("Dialog", "Priorit\303\251", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem4 = plugin__liste_plugin->horizontalHeaderItem(4);
        ___qtablewidgetitem4->setText(QApplication::translate("Dialog", "Version", 0, QApplication::UnicodeUTF8));
        plugin__new->setText(QApplication::translate("Dialog", "Ajouter un plugin", 0, QApplication::UnicodeUTF8));
        plugin__delete->setText(QApplication::translate("Dialog", "Supprimer le plugin", 0, QApplication::UnicodeUTF8));
        plugin__option_plugin->setText(QApplication::translate("Dialog", "Options \303\240 passer au plugin", 0, QApplication::UnicodeUTF8));
        plugin__execute->setText(QApplication::translate("Dialog", "Ex\303\251cuter le plugin", 0, QApplication::UnicodeUTF8));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QApplication::translate("Dialog", "Plugins", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class Dialog: public Ui_Dialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_OPTIONWINDOW_H
