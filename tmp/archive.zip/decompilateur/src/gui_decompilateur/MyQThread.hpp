#ifndef MYQTHREAD_HPP
#define MYQTHREAD_HPP

#include <QThread>

#include "Mutex.h"

class    MainWindow;

/**
** \class MyQThread
** \brief Classe permettant d'executer des fonctions de MainWindow dans un thread
*/
class MyQThread : public QThread
{
    Q_OBJECT

public:
    /**
    ** \fn MyQThread()
    ** \brief Constructeur par defaut du Thread
    */
    MyQThread();

    /**
    ** \fn MyQThread(MainWindow *ptr, void (MainWindow::*func)(), QObject *parent=0)
    ** \brief Constructeur du Thread
    **
    ** \param ptr Objet a utiliser pour executet la fonction
    ** \param func Fonction a executer
    ** \param parent Parent du thread
    */
    MyQThread(MainWindow *ptr, void (MainWindow::*func)(), QObject *parent=0);

    /**
    ** \fn MyQThread(const MyQThread &t)
    ** \brief Constructeur par copie du Thread
    **
    ** \param t Thread a copier
    */
    MyQThread(const MyQThread &t);


    /**
    ** \fn MyQThread &operator = (const MyQThread &t)
    ** \brief Surcharge de l'operateur = pour le thread
    **
    ** \param t Thread a copier
    ** \return Retourne une reference sur le thread
    */
    MyQThread     &operator = (const MyQThread &t);


    /**
    ** \fn void set_ptr(MainWindow *ptr)
    ** \brief Assesseur permettant de modifier l'objet a utiliser pour appeler la fonction
    **
    ** \param ptr Objet a utiliser pour appeler la fonction
    ** \return Retourne rien
    */
    void    set_ptr(MainWindow *ptr);

    /**
    ** \fn void set_func(void (MainWindow::*func)())
    ** \brief Assesseur permettant de modifier la fonction a appeler durant l'execution du thread
    **
    ** \param func Fonction a appeler durant l'execution du thread
    ** \return Retourne rien
    */
    void    set_func(void (MainWindow::*func)());

protected:
    /**
    ** \fn void run()
    ** \brief Permet d'executer la fonction passee en perametre lors de la construction
    **
    ** \return Retourne rien
    */
    void    run();

protected:
    /** Objet parmettant d'executer la fonction */
    MainWindow    *_ptr;
    /** Fonction a executer */
    void          (MainWindow::*_func)();
    /** Mutex permettant d'eviter les appels de thread multiple */
    Mutex         _mutex;
};

#endif // MYQTHREAD_HPP
