#include    "ViewerGraph.hpp"
#include    "Edge.hpp"


/**
** \fn ViewerGraph(QWidget *parent)
** \brief Constructeur de l'afficheur de graphe
**
** \param parent Pointeur sur le widget parent de l'afficheur
** \param l Pointeur sur le layout gerant l'affichage de l'editeur de scenario
*/
ViewerGraph::ViewerGraph(QWidget *parent): QGraphicsView(parent),
    _info(),
    _saved_graph()
{
    this->clear();
}

/**
** \fn ~ViewerGraph()
** \brief Destructeur de l'afficheur de scenario
*/
ViewerGraph::~ViewerGraph()
{
    this->clear();
}


/**
** \fn void clear()
** \brief Vide la fenetre afin de commencer un nouveau scenario (Ne laisse qu'un BEGIN)
**
** \return Retourne rien
*/
void              ViewerGraph::clear()
{    
    this->setScene(NULL);
    
    for (std::list<std::pair<std::string, QGraphicsScene*> >::iterator it=this->_saved_graph.begin();
         it!=this->_saved_graph.end();
         it++)
        delete it->second;
        
    this->_saved_graph.clear();
}

/**
** \fn void del_scene(const std::string &name)
** \brief Gere la suppression d'une scene de la liste
**
** \param name Nom de la scene a supprimer
** \return Retourne rien
*/
void              ViewerGraph::del_scene(const std::string &name)
{
    for (std::list<std::pair<std::string, QGraphicsScene*> >::iterator it=this->_saved_graph.begin();
         it!=this->_saved_graph.end();
         it++)
    {
        if (it->first == name)
        {
            if (it->second == this->scene())
                this->setScene(NULL);

            delete it->second;
            this->_saved_graph.erase(it);
            return ;
        }
    }
}

/**
** \fn QGraphicsScene *find_scene(const std::string &name) const
** \brief Gere la suppression de la scene ayant ete utilisee il y a le plus longtemps
**
** \return Retourne rien
*/
void              ViewerGraph::del_one_scene()
{
    std::list<std::pair<std::string, QGraphicsScene*> >::iterator    it;

    if ((it = this->_saved_graph.begin()) != this->_saved_graph.end())
    {
        if (it->second == this->scene())
            this->setScene(NULL);

        delete it->second;
        this->_saved_graph.erase(it);
    }
}

/**
** \fn std::string make_scene_name(unsigned long addr)
** \brief Gere la generation d'un nom de scene a partir d'une adresse
**
** \param addr Adresse a utiliser pour generer le nom
** \return Retourne le nom de la scene
*/
std::string       ViewerGraph::make_scene_name(unsigned long addr)
{
    return (Calcul::ltox(addr));
}

/**
** \fn void wheelEvent(QWheelEvent *event)
** \brief Gestion de la molette de la souris
**
** \param event Pointeur sur la description de l'evenement
** \return Retourne rien
*/
void              ViewerGraph::wheelEvent(QWheelEvent *event)
{
    this->scaleView(pow((double)2, -event->delta() / 240.0));
}


/**
** \fn void scaleView(qreal scaleFactor)
** \brief Gere le zoom sur la scene contenant le scenario
**
** \param scaleFactor Valeur du zoom a effectuer
** \return Retourne rien
*/
void              ViewerGraph::scaleView(qreal scaleFactor)
{
    QTransform    transform;
    qreal factor = this->transform().scale(scaleFactor, scaleFactor).mapRect(QRectF(0, 0, 1, 1)).width();
    if ((factor < 0.07) || (factor > 100))
        return;

    transform.scale(scaleFactor, scaleFactor);
    this->setTransform(this->transform() * transform);
}


/**
** \fn QGraphicsScene *find_scene(const std::string &name)
** \brief Cherche une scene dans la liste des scenes sauvegardees
**
** \param name Nom de la scene a trouver
** \return Retourne un pointeur sur la scene si on la trouve, NULL sinon
*/
QGraphicsScene    *ViewerGraph::find_scene(const std::string &name)
{
    QGraphicsScene    *scene;

    for (std::list<std::pair<std::string, QGraphicsScene*> >::iterator it=this->_saved_graph.begin();
         it!=this->_saved_graph.end();
         it++)
    {
        if (it->first == name)
        {
            scene = it->second;

            this->_saved_graph.erase(it);
            this->_saved_graph.push_back(std::pair<std::string, QGraphicsScene*>(name, scene));

            return (scene);
        }
    }

    return (NULL);
}

/**
** \fn void add_scene(const std::string &name, QGraphicsScene *scene)
** \brief Gere l'ajout d'une scene dans la liste des scenes sauvegardees
**
** \param name Nom de la scene
** \param scene Scene a ajouter a la liste
** \return Retourne rien
*/
void              ViewerGraph::add_scene(const std::string &name, QGraphicsScene *scene)
{
    if (scene != NULL)
    {
        this->del_scene(name);
        this->_saved_graph.push_back(std::pair<std::string, QGraphicsScene*>(name, scene));
    }
}
