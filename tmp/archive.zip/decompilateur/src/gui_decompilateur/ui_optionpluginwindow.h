/********************************************************************************
** Form generated from reading UI file 'optionpluginwindow.ui'
**
** Created: Thu May 14 13:50:04 2015
**      by: Qt User Interface Compiler version 4.8.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_OPTIONPLUGINWINDOW_H
#define UI_OPTIONPLUGINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QDialogButtonBox>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QPushButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QTableWidget>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_DialogOptionPlugin
{
public:
    QVBoxLayout *verticalLayout;
    QLabel *label;
    QLabel *label_2;
    QTableWidget *field_values;
    QWidget *widget;
    QHBoxLayout *horizontalLayout;
    QPushButton *bt_new;
    QPushButton *bt_delete;
    QSpacerItem *horizontalSpacer;
    QDialogButtonBox *buttonBox;

    void setupUi(QDialog *DialogOptionPlugin)
    {
        if (DialogOptionPlugin->objectName().isEmpty())
            DialogOptionPlugin->setObjectName(QString::fromUtf8("DialogOptionPlugin"));
        DialogOptionPlugin->resize(669, 426);
        verticalLayout = new QVBoxLayout(DialogOptionPlugin);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        label = new QLabel(DialogOptionPlugin);
        label->setObjectName(QString::fromUtf8("label"));

        verticalLayout->addWidget(label);

        label_2 = new QLabel(DialogOptionPlugin);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        verticalLayout->addWidget(label_2);

        field_values = new QTableWidget(DialogOptionPlugin);
        if (field_values->columnCount() < 2)
            field_values->setColumnCount(2);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        field_values->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        field_values->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        field_values->setObjectName(QString::fromUtf8("field_values"));
        field_values->horizontalHeader()->setCascadingSectionResizes(false);
        field_values->horizontalHeader()->setStretchLastSection(true);

        verticalLayout->addWidget(field_values);

        widget = new QWidget(DialogOptionPlugin);
        widget->setObjectName(QString::fromUtf8("widget"));
        horizontalLayout = new QHBoxLayout(widget);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        bt_new = new QPushButton(widget);
        bt_new->setObjectName(QString::fromUtf8("bt_new"));

        horizontalLayout->addWidget(bt_new);

        bt_delete = new QPushButton(widget);
        bt_delete->setObjectName(QString::fromUtf8("bt_delete"));

        horizontalLayout->addWidget(bt_delete);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        buttonBox = new QDialogButtonBox(widget);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);

        horizontalLayout->addWidget(buttonBox);


        verticalLayout->addWidget(widget);


        retranslateUi(DialogOptionPlugin);
        QObject::connect(buttonBox, SIGNAL(accepted()), DialogOptionPlugin, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), DialogOptionPlugin, SLOT(reject()));
        QObject::connect(bt_new, SIGNAL(clicked()), DialogOptionPlugin, SLOT(slot_option__new()));
        QObject::connect(bt_delete, SIGNAL(clicked()), DialogOptionPlugin, SLOT(slot_option__delete()));
        QObject::connect(DialogOptionPlugin, SIGNAL(accepted()), DialogOptionPlugin, SLOT(slot_validate()));
        QObject::connect(field_values, SIGNAL(currentCellChanged(int,int,int,int)), DialogOptionPlugin, SLOT(slot_check()));

        QMetaObject::connectSlotsByName(DialogOptionPlugin);
    } // setupUi

    void retranslateUi(QDialog *DialogOptionPlugin)
    {
        DialogOptionPlugin->setWindowTitle(QApplication::translate("DialogOptionPlugin", "Dialog", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("DialogOptionPlugin", "Options \303\240 passer au plugin lors de son ex\303\251cution", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("DialogOptionPlugin", "(le nom et la valeur des options doivent \303\252tre exactes)", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem = field_values->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QApplication::translate("DialogOptionPlugin", "Nom de l'option", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem1 = field_values->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QApplication::translate("DialogOptionPlugin", "Valeur", 0, QApplication::UnicodeUTF8));
        bt_new->setText(QApplication::translate("DialogOptionPlugin", "Nouveau", 0, QApplication::UnicodeUTF8));
        bt_delete->setText(QApplication::translate("DialogOptionPlugin", "Supprimer", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class DialogOptionPlugin: public Ui_DialogOptionPlugin {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_OPTIONPLUGINWINDOW_H
