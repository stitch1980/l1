#ifndef OPTIONWINDOW_H
#define OPTIONWINDOW_H

#include    <QMainWindow>
#include    <QApplication>
#include    <QtGui>
#include    <QDialog>

#include    "Info.hpp"

namespace Ui
{
    class Dialog;
}


class OptionWindow : public QDialog
{
    Q_OBJECT
public:
    explicit OptionWindow(Info *info, std::map<std::string, Plugin*> *list_plugins, QWidget *parent = 0);
    ~OptionWindow();
    
protected:
    /**
    ** \fn void actualisation(Info *info=NULL)
    ** \brief Gere l'actualisation du  contenu du menu
    **
    ** \param info Structure contenant les infos du programme a analyser
    ** \return Retourne rien
    */
    void    actualisation(Info *info=NULL);
    
public slots:
    /**
    ** \fn void slot_validate()
    ** \brief Gere la validation des changements effectuee par le menu
    **
    ** \return Retourne rien
    */
    void    slot_validate();


    /**
    ** \fn void slot_plugin__new()
    ** \brief Gere l'ajout d'un nouveau plugin
    **
    ** \return Retourne rien
    */
    void    slot_plugin__new();

    /**
    ** \fn void slot_plugin__delete()
    ** \brief Gere la suppression d'un plugin
    **
    ** \return Retourne rien
    */
    void    slot_plugin__delete();

    /**
    ** \fn void slot_plugin__option_plugin()
    ** \brief Gere la modification des options a passer aux plugins
    **
    ** \return Retourne rien
    */
    void    slot_plugin__option_plugin();

    /**
    ** \fn void slot_plugin__execute()
    ** \brief Gere l'execution d'un plugin
    **
    ** \return Retourne rien
    */
    void    slot_plugin__execute();

    /**
    ** \fn void slot_plugin__new()
    ** \brief Gere le clic sur un plugin de la liste plugin
    **
    ** \return Retourne rien
    */
    void    slot_plugin__clicked();

protected:
    /**
    ** \fn void resizeEvent(QResizeEvent *event)
    ** \brief Gere l'actualisation du menu en cas de redimentionement
    **
    ** \param event Event decrivant le redimentionement
    ** \return Retourne rien
    c*/
    void    resizeEvent(QResizeEvent *event);

    /**
    ** \fn Plugin *ident_selected_plugin()
    ** \brief Gere l'identification du plugin selectionnee dans la liste
    **
    ** \return Retourne un pointeur sur le plugin
    */
    Plugin    *ident_selected_plugin();

protected:
    /** Pointeur sur la structure contenant les infos du programme */
    Info                              *_info;
    /** Pointeur sur la liste complete des plugins */
    std::map<std::string, Plugin*>    *_list_plugins;

    /** Structure contenant les infos du programme en cours de modification */
    Info                              _info_tmp;
    /** Liste complete des plugins en cours de modification */
    std::map<std::string, Plugin*>    _list_plugins_tmp;

    /** Interface graphique du menu */
    Ui::Dialog                        *ui;
};



namespace Ui
{
    class DialogOptionPlugin;
}

class OptionPluginOptionWindow: public QDialog
{
    Q_OBJECT
public:
    explicit OptionPluginOptionWindow(std::map<std::string, std::string> *option_plugin, QWidget *parent = 0);
    ~OptionPluginOptionWindow();


public slots:
    /**
    ** \fn void slot_validate()
    ** \brief Gere la validation des changements effectuee par le menu
    **
    ** \return Retourne rien
    */
    void    slot_validate();

    /**
    ** \fn void slot_check()
    ** \brief Gere la validation des champs
    **
    ** \return Retourne rien
    */
    void    slot_check();

    /**
    ** \fn void slot_option__new()
    ** \brief Gere l'ajout d'une option
    **
    ** \return Retourne rien
    */
    void    slot_option__new();

    /**
    ** \fn void slot_option__delete()
    ** \brief Gere la suppression d'une option
    **
    ** \return Retourne rien
    */
    void    slot_option__delete();

protected:
    /** Pointeur sur les options du plugin a modifier <nom_option, valeur> */
    std::map<std::string, std::string>    *_option_plugin;

    /** Interface graphique du menu */
    Ui::DialogOptionPlugin                *ui;
};

#endif
