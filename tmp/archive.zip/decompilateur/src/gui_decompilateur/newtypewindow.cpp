#include    "newtypewindow.h"
#include    "ui_newtypewindow.h"
#include    "ui_newattributtypewindow.h"


NewTypeWindow::NewTypeWindow(const std::string &name, PrototypeT *proto, QWidget *parent): QDialog(parent),
    _name(name),
    _proto(proto),
    ui(new Ui::DialogNewType)
{
    std::string      type_tmp;
    std::string      name_tmp;
    unsigned long    nbs_elem_tmp;
    unsigned long    size_tmp;

    this->ui->setupUi(this);

    /* Preparation du nom du type de variable */
    if (proto->exist(this->_name) <= 0)
        this->_name = "";
    this->ui->field_name->setText(QString::fromStdString(this->_name));

    /* Si c'est une variable simple */
    if (this->_proto->get_nbs_attribut(name) <= 0)
    {
        if (this->_proto->exist(name))
            this->ui->field_name->setText(QString::fromStdString(this->_name));
        this->ui->bt_type_simple->setChecked(true);
        this->ui->bt_type_structure->setChecked(false);

        /* Taille de la variable */
        this->ui->field_size->setText(QString::number(this->_proto->get_size(this->_name), 10));
    }
    /* Sinon, c'est une structure */
    else
    {
        this->ui->bt_type_simple->setChecked(false);
        this->ui->bt_type_structure->setChecked(true);

        /* Creation du tableau contenant les attributs de la structure */
        this->ui->table_attributs->setRowCount(this->_proto->get_nbs_attribut(this->_name));
        for (unsigned long i=0; i<this->_proto->get_nbs_attribut(this->_name); i++)
        {
            type_tmp = this->_proto->get_type_attribut_num(this->_name, i);
            name_tmp = this->_proto->get_name_attribut_num(this->_name, i);
            nbs_elem_tmp = this->_proto->get_nbs_element_attribut_num(this->_name, i);
            size_tmp = (this->_proto->get_size(type_tmp) * nbs_elem_tmp);

            /* Affiche le nombre d'elements si c'est un tableau */
            if (nbs_elem_tmp > 1)
                name_tmp += "[" + Calcul::ltos(nbs_elem_tmp) + "]";

            this->ui->table_attributs->setItem(i, 0, new QTableWidgetItem(QString::fromStdString(type_tmp)));
            this->ui->table_attributs->setItem(i, 1, new QTableWidgetItem(QString::fromStdString(name_tmp)));
            this->ui->table_attributs->setItem(i, 2, new QTableWidgetItem(QString::number(size_tmp, 10)));
        }
    }

    this->slot_check_formulaire();
}

NewTypeWindow::~NewTypeWindow()
{
    delete ui;
}


/**
** \fn void slot_validate()
** \brief Gere la validation des changements effectuee par le menu
**
** \return Retourne rien
*/
void    NewTypeWindow::slot_validate()
{
    qDebug("NewTypeWindow::slot_validate()\n");
    std::vector<std::string>      type_attributs;
    std::vector<std::string>      name_attributs;
    std::vector<unsigned long>    nbs_elem_attributs;

    /* Suppression du precedent type si c'est une edition */
    if (this->_name.size() > 0)
        this->_proto->del_definition(this->_name);

    /* En cas de variable simple */
    if (this->ui->bt_type_simple->isChecked())
    {
        this->_proto->add_definition(this->ui->field_name->text().toStdString(), this->ui->field_size->text().toLong());
    }
    /* En cas de structure */
    else
    {
        /* Recupere les caracteristique de tout les attributs */
        for (int i=0; i<this->ui->table_attributs->rowCount(); i++)
        {
            type_attributs.push_back(this->ui->table_attributs->item(i, 0)->text().toStdString());
            name_attributs.push_back(this->extract_name_from_tablename(this->ui->table_attributs->item(i, 1)->text().toStdString()));
            nbs_elem_attributs.push_back(this->extract_nbs_from_tablename(this->ui->table_attributs->item(i, 1)->text().toStdString()));
        }

        /* Cree le nouveau type */
        this->_proto->add_definition(this->ui->field_name->text().toStdString(), type_attributs, name_attributs, nbs_elem_attributs);
    }
}

/**
** \fn void slot_check_formulaire()
** \brief Slot Permettant de verifier que le contenu des champs est valide
**
** \return Retourne rien
*/
void    NewTypeWindow::slot_check_formulaire()
{
    qDebug("NewTypeWindow::slot_check_formulaire()\n");

    /* Par defaut, on peut valider */
    if (this->ui->buttonBox->button(QDialogButtonBox::Ok) != NULL)
        this->ui->buttonBox->button(QDialogButtonBox::Ok)->setEnabled(true);
    this->ui->field_size->setStyleSheet("");
    this->ui->table_attributs->setStyleSheet("");

    /* Verification du type de la variable */

    /* Choisi le sous-menu a utiliser en fonction du type de variable */
    if (this->ui->bt_type_simple->isChecked())
    {
        this->ui->widget_simple->setEnabled(true);
        this->ui->widget_structure->setEnabled(false);

        /* Verification de la taille de la variable */
        if ((this->ui->field_size->text().size() <= 0) ||
            (BNFcalcul::is_udecimal(this->ui->field_size->text().toStdString(), NULL, NULL, 0, 0) != this->ui->field_size->text().toStdString().size()) ||
            (atol(this->ui->field_size->text().toAscii()) <= 0))
        {
            this->ui->field_size->setStyleSheet("background-color: red;");
            if (this->ui->buttonBox->button(QDialogButtonBox::Ok) != NULL)
                this->ui->buttonBox->button(QDialogButtonBox::Ok)->setEnabled(false);
        }
    }
    else
    {
        this->ui->widget_simple->setEnabled(false);
        this->ui->widget_structure->setEnabled(true);

        /* Il doit y avoir au moins un attribut */
        if (this->ui->table_attributs->rowCount() <= 0)
        {
            this->ui->table_attributs->setStyleSheet("background-color: red;");
            if (this->ui->buttonBox->button(QDialogButtonBox::Ok) != NULL)
                this->ui->buttonBox->button(QDialogButtonBox::Ok)->setEnabled(false);
        }

        /* Verification des attributs de la variables */
        for (int i=0; i<this->ui->table_attributs->rowCount(); i++)
        {
            this->ui->table_attributs->item(i, 0)->setBackground(Qt::transparent);
            this->ui->table_attributs->item(i, 1)->setBackground(Qt::transparent);
            this->ui->table_attributs->item(i, 2)->setBackground(Qt::transparent);

            /* Si le type de l'attribut n'existe pas, il y a un soucis */
            if (this->_proto->can_be_an_attribute_of_struct(this->ui->field_name->text().toStdString(),
                                                    this->ui->table_attributs->item(i, 0)->text().toStdString(),
                                                    NULL) <= 0)
            {
                this->ui->table_attributs->item(i, 0)->setBackground(Qt::red);
                this->ui->table_attributs->item(i, 1)->setBackground(Qt::red);
                this->ui->table_attributs->item(i, 2)->setBackground(Qt::red);

                if (this->ui->buttonBox->button(QDialogButtonBox::Ok) != NULL)
                    this->ui->buttonBox->button(QDialogButtonBox::Ok)->setEnabled(false);
            }
        }
    }

    this->slot_attribut_clicked();
}

/**
** \fn void slot_bt_attribut_clicked()
** \brief Gere les clics dans la liste des attributs
**
** \return Retourne rien
*/
void    NewTypeWindow::slot_attribut_clicked()
{
    qDebug("NewTypeWindow::slot_attribut_clicked()\n");
    int    pos_row;

    /* Bloque les boutons "edit", "delete", ... */
    this->ui->bt_attribut_edit->setEnabled(false);
    this->ui->bt_attribut_delete->setEnabled(false);
    this->ui->bt_attribut_up->setEnabled(false);
    this->ui->bt_attribut_down->setEnabled(false);

    /* Si un attribut est selectionne */
    if ((pos_row = this->ui->table_attributs->currentRow()) >= 0)
    {
        /* Secactionne toute la ligne et active les boutons "edit" et "delete" */
        this->ui->table_attributs->selectRow(pos_row);
        this->ui->bt_attribut_edit->setEnabled(true);
        this->ui->bt_attribut_delete->setEnabled(true);

        /* Si l'attribut selectionne n'est pas le premier, on peut le monter */
        if (pos_row > 0)
            this->ui->bt_attribut_up->setEnabled(true);

        /* Si l'attribut selectionne n'est pas le dernier, on peut le descendre */
        if (pos_row < (this->ui->table_attributs->rowCount() - 1))
            this->ui->bt_attribut_down->setEnabled(true);
    }
}

/**
** \fn void slot_bt_new()
** \brief Gere l'ajout d'un attribut
**
** \return Retourne rien
*/
void    NewTypeWindow::slot_bt_new()
{
    qDebug("NewTypeWindow::slot_bt_new()\n");
    std::string      type;
    std::string      name;
    unsigned long    nbs;
    int              pos_row;

    /* Execution du menu demandant les infos de l'attribut */
    type = "";
    name = "";
    nbs = 1;
    NewAttributTypeWindow    w(this->ui->field_name->text().toStdString(), type, name, nbs, this->_proto, this);
    w.exec();

    /* Creation d'un nouvel attribut si besoin est */
    if (type.size() > 0)
    {
        /* Preparation du nom si c'est un tableau */
        if (nbs > 1)
            name += "[" + Calcul::ltos(nbs) + "]";

        pos_row = this->ui->table_attributs->rowCount();
        if (this->ui->table_attributs->currentRow() >= 0)
            pos_row = this->ui->table_attributs->currentRow() + 1;

        this->ui->table_attributs->insertRow(pos_row);
        this->ui->table_attributs->setItem(pos_row, 0, new QTableWidgetItem(QString::fromStdString(type)));
        this->ui->table_attributs->setItem(pos_row, 1, new QTableWidgetItem(QString::fromStdString(name)));
        this->ui->table_attributs->setItem(pos_row, 2, new QTableWidgetItem(QString::number(nbs * this->_proto->get_size(type), 10)));
        this->ui->table_attributs->selectRow(pos_row);
    }

    this->slot_check_formulaire();
}

/**
** \fn void slot_bt_edit()
** \brief Gere la modification d'un attribut
**
** \return Retourne rien
*/
void    NewTypeWindow::slot_bt_edit()
{
    qDebug("NewTypeWindow::slot_bt_edit()\n");
    std::string      type;
    std::string      name;
    unsigned long    nbs;
    int              pos_row;

    /* Si un attribut est selectionne */
    if ((pos_row = this->ui->table_attributs->currentRow()) >= 0)
    {
        /* Recuperation des valeurs de l'attribut a modifier */
        type = this->ui->table_attributs->item(pos_row, 0)->text().toStdString();
        name = this->extract_name_from_tablename(this->ui->table_attributs->item(pos_row, 1)->text().toStdString());
        nbs = this->extract_nbs_from_tablename(this->ui->table_attributs->item(pos_row, 1)->text().toStdString());

        /* Edition de l'attribut */
        NewAttributTypeWindow    w(this->ui->field_name->text().toStdString(), type, name, nbs, this->_proto, this);
        w.exec();

        /* Preparation du nom si c'est un tableau */
        if (nbs > 1)
            name += "[" + Calcul::ltos(nbs) + "]";

        /* Actualisation des valeurs de l'attribut */
        this->ui->table_attributs->item(pos_row, 0)->setText(QString::fromStdString(type));
        this->ui->table_attributs->item(pos_row, 1)->setText(QString::fromStdString(name));
        this->ui->table_attributs->item(pos_row, 2)->setText(QString::number(nbs * this->_proto->get_size(type), 10));
    }

    this->slot_check_formulaire();
}

/**
** \fn void slot_bt_delete()
** \brief Gere la suppression d'un attribut
**
** \return Retourne rien
*/
void    NewTypeWindow::slot_bt_delete()
{
    qDebug("NewTypeWindow::slot_bt_delete()\n");

    /* Si un attribut est selectionne, on le supprime */
    if (this->ui->table_attributs->currentRow() >= 0)
        this->ui->table_attributs->removeRow(this->ui->table_attributs->currentRow());

    this->slot_check_formulaire();
}

/**
** \fn void slot_bt_up()
** \brief Gere le deplacement d'un attribut vers le haut
**
** \return Retourne rien
*/
void    NewTypeWindow::slot_bt_up()
{
    qDebug("NewTypeWindow::slot_bt_up()\n");
    QString      type;
    QString      name;
    QString      size;
    int          pos_row;

    if ((pos_row = this->ui->table_attributs->currentRow()) > 0)
    {
        type = this->ui->table_attributs->item(pos_row, 0)->text();
        name = this->ui->table_attributs->item(pos_row, 1)->text();
        size = this->ui->table_attributs->item(pos_row, 2)->text();

        this->ui->table_attributs->item(pos_row, 0)->setText(this->ui->table_attributs->item(pos_row-1, 0)->text());
        this->ui->table_attributs->item(pos_row, 1)->setText(this->ui->table_attributs->item(pos_row-1, 1)->text());
        this->ui->table_attributs->item(pos_row, 2)->setText(this->ui->table_attributs->item(pos_row-1, 2)->text());

        this->ui->table_attributs->item(pos_row-1, 0)->setText(type);
        this->ui->table_attributs->item(pos_row-1, 1)->setText(name);
        this->ui->table_attributs->item(pos_row-1, 2)->setText(size);

        this->ui->table_attributs->selectRow(pos_row-1);
    }

    this->slot_check_formulaire();
}

/**
** \fn void slot_bt_down()
** \brief Gere le deplacement d'un attribut vers le bas
**
** \return Retourne rien
*/
void    NewTypeWindow::slot_bt_down()
{
    qDebug("NewTypeWindow::slot_bt_down()\n");
    QString      type;
    QString      name;
    QString      size;
    int          pos_row;

    if (((pos_row = this->ui->table_attributs->currentRow()) >= 0) &&
        (pos_row < (this->ui->table_attributs->rowCount()-1)))
    {
        type = this->ui->table_attributs->item(pos_row, 0)->text();
        name = this->ui->table_attributs->item(pos_row, 1)->text();
        size = this->ui->table_attributs->item(pos_row, 2)->text();

        this->ui->table_attributs->item(pos_row, 0)->setText(this->ui->table_attributs->item(pos_row+1, 0)->text());
        this->ui->table_attributs->item(pos_row, 1)->setText(this->ui->table_attributs->item(pos_row+1, 1)->text());
        this->ui->table_attributs->item(pos_row, 2)->setText(this->ui->table_attributs->item(pos_row+1, 2)->text());

        this->ui->table_attributs->item(pos_row+1, 0)->setText(type);
        this->ui->table_attributs->item(pos_row+1, 1)->setText(name);
        this->ui->table_attributs->item(pos_row+1, 2)->setText(size);

        this->ui->table_attributs->selectRow(pos_row+1);
    }

    this->slot_check_formulaire();
}

/**
** \fn std::string extract_name_from_tablename(const std::string &s)
** \brief Gere l'extraction d'un nom de variable de chaines comme "mon_nom[42]"
**
** \param Nom de variable a traiter
** \return Retourne le nom de variable epure
*/
std::string    NewTypeWindow::extract_name_from_tablename(const std::string &s) const
{
    unsigned long    pos;

    if ((pos = s.find_last_of("[")) != std::string::npos)
        return (s.substr(0, pos));

    return (s);
}

/**
** \fn unsigned long extract_nbs_from_tablename(const std::string &s)
** \brief Gere l'extraction du nombre d'elements de chaines comme "mon_nom[42]"
**
** \param Nom de variable a traiter
** \return Retourne le nombre d'elements du tableau si OK, 1 sinon
*/
unsigned long    NewTypeWindow::extract_nbs_from_tablename(const std::string &s) const
{
    unsigned long    pos_begin;
    unsigned long    pos_end;

    if (((pos_begin = s.find_last_of("[")) != std::string::npos) &&
        ((pos_end = s.find_last_of("]")) != std::string::npos))
    {
        if (pos_begin < pos_end)
            return (atol(s.substr(pos_begin+1, pos_end-pos_begin-1).c_str()));
    }

    return (1);
}





NewAttributTypeWindow::NewAttributTypeWindow(const std::string &parent_type, std::string &type, std::string &name, unsigned long &nbs, PrototypeT *proto, QWidget *parent): QDialog(parent),
    _parent_type(parent_type),
    _type(&type),
    _name(&name),
    _nbs(&nbs),
    _proto(proto),
    ui(new Ui::DialogNewAttributType)
{
    this->ui->setupUi(this);

    this->ui->field_type->setText(QString::fromStdString(type));
    this->ui->field_name->setText(QString::fromStdString(name));
    this->ui->field_nbs->setText(QString::number(nbs, 10));

    this->slot_check_formulaire();
}

NewAttributTypeWindow::~NewAttributTypeWindow()
{
    delete this->ui;
}


/**
** \fn void slot_validate()
** \brief Gere la validation des changements effectuee par le menu
**
** \return Retourne rien
*/
void    NewAttributTypeWindow::slot_validate()
{
    qDebug("NewAttributTypeWindow::slot_validate()\n");

    *(this->_type) = this->ui->field_type->text().toStdString();
    *(this->_name) = this->ui->field_name->text().toStdString();
    *(this->_nbs) = this->ui->field_nbs->text().toLong();
}

/**
** \fn void slot_check_formulaire()
** \brief Slot Permettant de verifier que le contenu des champs est valide
**
** \return Retourne rien
*/
void    NewAttributTypeWindow::slot_check_formulaire()
{
    qDebug("NewAttributTypeWindow::slot_check_formulaire()\n");

    /* Par defaut, on peut valider */
    if (this->ui->buttonBox->button(QDialogButtonBox::Ok) != NULL)
        this->ui->buttonBox->button(QDialogButtonBox::Ok)->setEnabled(true);

    /* Il faut que le type existe */
    this->ui->field_type->setStyleSheet("");
    if (this->_proto->can_be_an_attribute_of_struct(this->_parent_type,
                                                    this->ui->field_type->text().toStdString(),
                                                    NULL) <= 0)
    {
        this->ui->field_type->setStyleSheet("background-color: red;");
        if (this->ui->buttonBox->button(QDialogButtonBox::Ok) != NULL)
            this->ui->buttonBox->button(QDialogButtonBox::Ok)->setEnabled(false);
    }

    /* Le nom doit etre valide */
    this->ui->field_name->setStyleSheet("");
    if ((this->ui->field_name->text().size() <= 0) ||
        (BNFc::is_var_name(this->ui->field_name->text().toStdString()) != this->ui->field_name->text().toStdString().size()))
    {
        this->ui->field_name->setStyleSheet("background-color: red;");
        if (this->ui->buttonBox->button(QDialogButtonBox::Ok) != NULL)
            this->ui->buttonBox->button(QDialogButtonBox::Ok)->setEnabled(false);
    }

    /* Il doit y avoir au moins un element */
    this->ui->field_nbs->setStyleSheet("");
    if ((this->ui->field_nbs->text().size() <= 0) ||
        (BNFcalcul::is_udecimal(this->ui->field_nbs->text().toStdString(), NULL, NULL, 0, 0) != this->ui->field_nbs->text().toStdString().size()) ||
        (atol(this->ui->field_nbs->text().toAscii()) <= 0))
    {
        this->ui->field_nbs->setStyleSheet("background-color: red;");
        if (this->ui->buttonBox->button(QDialogButtonBox::Ok) != NULL)
            this->ui->buttonBox->button(QDialogButtonBox::Ok)->setEnabled(false);
    }
}
