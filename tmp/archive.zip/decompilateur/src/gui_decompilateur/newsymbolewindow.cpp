#include    "newsymbolewindow.h"
#include    "ui_newsymbolewindow.h"


NewSymboleWindow::NewSymboleWindow(unsigned long value, const std::string &name, const std::string &type, Symbole *symboles, QWidget *parent): QDialog(parent),
    _value(value),
    _name(name),
    _type(type),
    _symbole(symboles),
    ui(new Ui::Dialog4)
{
    this->ui->setupUi(this);

    this->ui->field_value->setText(QString::fromStdString(Calcul::lto0x(value)));
    this->ui->field_name->setText(QString::fromStdString(name));

    if (type == "FUNC")
        this->ui->field_type->setCurrentIndex(0);
    else if (type == "VAR")
        this->ui->field_type->setCurrentIndex(1);
    else
        this->ui->field_type->setCurrentIndex(2);
}

NewSymboleWindow::~NewSymboleWindow()
{
    delete ui;
}


/**
** \fn unsigned long get_value_symbole() const
** \brief Assesseur permettant de connaitre la derniere valeur du symbole dans le formulaire
**
** \return Retourne la derniere adresse du segment dans le formulaire
*/
unsigned long    NewSymboleWindow::get_value_symbole() const
{
    unsigned long    value;
    std::string      str_value;

    value = 0;
    str_value = this->ui->field_value->text().toStdString();
    if (BNFcalcul::is_decimal(str_value, NULL, NULL, 0, 0) == str_value.size())
        value = strtol(str_value.c_str(), NULL, 10);
    else if (BNFcalcul::is_hexa_sans_0x( str_value, NULL, NULL, 0, 0) == str_value.size())
        value = Calcul::xtol(str_value.c_str());
    else if (BNFcalcul::is_hexadecimal( str_value, NULL, NULL, 0, 0) == str_value.size())
        value = Calcul::xtol(&(str_value.c_str()[2]));
    return (value);
}

/**
** \fn void slot_validate()
** \brief Gere la validation des changements effectuee par le menu
**
** \return Retourne rien
*/
void    NewSymboleWindow::slot_validate()
{
    qDebug("NewSymboleWindow::slot_validate()\n");
    unsigned long     value;
    std::string       name;
    Symbole::eType    type;

    /* Recupere les valeurs des differents champs */
    value = this->get_value_symbole();
    name = this->ui->field_name->text().toStdString();

    if (this->ui->field_type->currentIndex() == 0)
        type = Symbole::FUNC;
    else if (this->ui->field_type->currentIndex() == 1)
        type = Symbole::VAR;
    else
        type = Symbole::NONE;

    /* Si c'est une edition de symbole, on supprime l'ancien */
    if (this->_name.size() > 0)
        this->_symbole->del_symbole(this->_value);

    /* Cree le nouveau symbole */
    this->_symbole->add_symbole(value, name, type);
}

/**
** \fn void slot_check_formulaire()
** \brief Slot Permettant de verifier que le contenu des champs est valide
**
** \return Retourne rien
*/
void    NewSymboleWindow::slot_check_formulaire()
{
    qDebug("NewSymboleWindow::slot_check_formulaire()\n");
    std::string       str_value;

    /* Par defaut, on peut valider */
    if (this->ui->buttonBox->button(QDialogButtonBox::Ok) != NULL)
        this->ui->buttonBox->button(QDialogButtonBox::Ok)->setEnabled(true);

    /* Verifie le champ "value" */
    this->ui->field_value->setStyleSheet("");
    str_value = this->ui->field_value->text().toStdString();
    if ((this->ui->field_value->text().size() <= 0) ||
            ((BNFcalcul::is_decimal(str_value, NULL, NULL, 0, 0) != str_value.size()) &&
             (BNFcalcul::is_hexa_sans_0x(str_value, NULL, NULL, 0, 0) != str_value.size()) &&
             (BNFcalcul::is_hexadecimal( str_value, NULL, NULL, 0, 0) != str_value.size())))
    {
        this->ui->field_value->setStyleSheet("background-color: red;");
        if (this->ui->buttonBox->button(QDialogButtonBox::Ok) != NULL)
            this->ui->buttonBox->button(QDialogButtonBox::Ok)->setEnabled(false);
    }

    /* Verifie le champ "name" */
    this->ui->field_name->setStyleSheet("");
    if ((this->ui->field_name->text().size() <= 0) ||
        (BNFc::is_var_name(this->ui->field_name->text().toStdString()) != this->ui->field_name->text().toStdString().size()))
    {
        this->ui->field_name->setStyleSheet("background-color: red;");
        if (this->ui->buttonBox->button(QDialogButtonBox::Ok) != NULL)
            this->ui->buttonBox->button(QDialogButtonBox::Ok)->setEnabled(false);
    }
}
