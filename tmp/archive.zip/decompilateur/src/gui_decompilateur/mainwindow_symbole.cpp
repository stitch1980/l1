#include "mainwindow.h"
#include "ui_mainwindow.h"

#include    "newsymbolewindow.h"



/**
** \fn void slot_sym__liste_symboles__update()
** \brief Slot gerant l'actualisation de la liste de symboles
**
** \return Retourne rien
*/
void    MainWindow::slot_sym__liste_symboles__update()
{
    qDebug("MainWindow::slot_sym__liste_symboles__update()\n");
    int        column;
    int        row;

    this->_info.mutex.lock();

    /* Sauvegarde de l'element actuellement selectionne */
    column = this->ui->sym__liste_symboles->currentColumn();
    row = this->ui->sym__liste_symboles->currentRow();
    this->ui->sym__liste_symboles->setSortingEnabled(false);

    /* Preparation des symboles */
    disconnect(this->ui->sym__liste_symboles, SIGNAL(cellChanged(int, int)), this, SLOT(slot_sym__liste_symboles__edit()));

    this->ui->sym__liste_symboles->clearContents();
    this->ui->sym__liste_symboles->setRowCount(this->_info.sym.get_nbs_symbole());
    for (unsigned long i=0; i<this->_info.sym.get_nbs_symbole(); i++)
    {
        this->ui->sym__liste_symboles->setItem(i, 0, new QTableWidgetItem(QString::fromStdString(this->_info.sym.get_name_nieme_symbole(i))));
        this->ui->sym__liste_symboles->setItem(i, 1, new QTableWidgetItem(QString::fromStdString(Calcul::lto0x(this->_info.sym.get_addr_nieme_symbole(i)))));

        if (this->_info.sym.get_type_nieme_symbole(i) == Symbole::FUNC)
            this->ui->sym__liste_symboles->setItem(i, 2, new QTableWidgetItem("FUNC"));
        else if (this->_info.sym.get_type_nieme_symbole(i) == Symbole::VAR)
            this->ui->sym__liste_symboles->setItem(i, 2, new QTableWidgetItem("VAR"));
        else
            this->ui->sym__liste_symboles->setItem(i, 2, new QTableWidgetItem("NONE"));
    }

    connect(this->ui->sym__liste_symboles, SIGNAL(cellChanged(int, int)), this, SLOT(slot_sym__liste_symboles__edit()));

    /* Re-selection de l'element autrefois selectionne */
    this->ui->sym__liste_symboles->setSortingEnabled(true);
    this->ui->sym__liste_symboles->setCurrentCell(row, column);
    this->slot_sym__liste_symboles__clicked();

    this->_info.mutex.unlock();
    this->slot_func__liste_entry__update();
}

/**
** \fn void slot_sym__change_selected_symbol(unsigned long value)
** \brief Gere la selection d'un segment precis
**
** \param valeur Valeur du symbole a selectionner
** \return Retourne rien
*/
void    MainWindow::slot_sym__change_selected_symbol(unsigned long value)
{
    qDebug("MainWindow::slot_sym__change_selected_symbol(unsigned long value)\n");
    QTableWidgetItem          *item_value;
    std::string               str;
    unsigned long             pos;
    unsigned long             value_tmp;
    int                       column;

    this->_info.mutex.lock();
    this->ui->sym__liste_symboles->setSortingEnabled(false);

    if ((column = this->ui->sym__liste_symboles->currentColumn()) < 0)
        column = 0;

    for (int i=0; i<this->ui->sym__liste_symboles->rowCount(); i++)
    {
        if ((item_value = this->ui->sym__liste_symboles->item(i, 1)) != NULL)
        {
            str = item_value->text().toStdString();
            if ((pos = str.find("0x")) != std::string::npos)
            {
                value_tmp = Calcul::xtol(&(str.c_str()[pos + 2]));
                if (value == value_tmp)
                {
                    this->ui->sym__liste_symboles->setCurrentCell(i, column);
                    i = this->ui->sym__liste_symboles->rowCount();
                }
            }
        }
    }

    this->ui->sym__liste_symboles->setSortingEnabled(true);
    this->_info.mutex.unlock();
}

/**
** \fn void slot_sym__liste_symboles__clicked()
** \brief Slot gerant le clic sur un symbole
**
** \return Retourne rien
*/
void    MainWindow::slot_sym__liste_symboles__clicked()
{
    qDebug("MainWindow::slot_sym__liste_symboles__clicked()\n");

    this->ui->sym__bt_delete->setEnabled(false);
    this->ui->sym__bt_edit->setEnabled(false);
    if (this->ui->sym__liste_symboles->currentItem() != NULL)
    {
        this->ui->sym__bt_delete->setEnabled(true);
        this->ui->sym__bt_edit->setEnabled(true);
        this->ui->sym__liste_symboles->selectRow(this->ui->sym__liste_symboles->currentRow());
    }
}

/**
** \fn void slot_sym__bt_new()
** \brief Slot gerant la creation d'un nouveau symbole
**
** \return Retourne rien
*/
void    MainWindow::slot_sym__bt_new()
{
    qDebug("MainWindow::slot_sym__bt_new()\n");
    unsigned long       value;

    this->_info.mutex.lock();

    NewSymboleWindow    w(0, "", "", &(this->_info.sym), this);
    w.exec();
    value = w.get_value_symbole();

    this->_info.mutex.unlock();
    this->slot_sym__liste_symboles__update();
    this->slot_sym__change_selected_symbol(value);
}

/**
** \fn void slot_sym__bt_edit()
** \brief Slot gerant la modification d'un symbole
**
** \return Retourne rien
*/
void    MainWindow::slot_sym__bt_edit()
{
    qDebug("MainWindow::slot_sym__bt_edit()\n");
    QTableWidgetItem          *item_name;
    QTableWidgetItem          *item_value;
    QTableWidgetItem          *item_type;
    std::string               name;
    std::string               type;
    unsigned long             value;
    std::string               str_value;

    this->_info.mutex.lock();

    value = 0;
    if (this->ui->sym__liste_symboles->currentRow() >= 0)
    {
        item_name = this->ui->sym__liste_symboles->item(this->ui->sym__liste_symboles->currentRow(), 0);
        item_value = this->ui->sym__liste_symboles->item(this->ui->sym__liste_symboles->currentRow(), 1);
        item_type = this->ui->sym__liste_symboles->item(this->ui->sym__liste_symboles->currentRow(), 2);

        if ((item_name != NULL) && (item_value != NULL) & (item_type != NULL))
        {
            /* Recuperation des diferents champs du symbole */
            str_value = item_value->text().toStdString();
            if (BNFcalcul::is_decimal(str_value, NULL, NULL, 0, 0) == str_value.size())
                value = strtol(str_value.c_str(), NULL, 10);
            else if (BNFcalcul::is_hexa_sans_0x(str_value, NULL, NULL, 0, 0) == str_value.size())
                value = Calcul::xtol(str_value.c_str());
            else if (BNFcalcul::is_hexadecimal(str_value, NULL, NULL, 0, 0) == str_value.size())
                value = Calcul::xtol(&(str_value.c_str()[2]));

            name = item_name->text().toStdString();
            type = item_type->text().toStdString();

            /* Edition du symbole */
            NewSymboleWindow    w(value, name, type, &(this->_info.sym), this);
            w.exec();
            value = w.get_value_symbole();
        }
    }

    this->_info.mutex.unlock();
    this->slot_sym__liste_symboles__update();
    this->slot_sym__change_selected_symbol(value);
}

/**
** \fn void slot_sym__bt_delete()
** \brief Slot gerant la suppression d'un symbole
**
** \return Retourne rien
*/
void    MainWindow::slot_sym__bt_delete()
{
    qDebug("MainWindow::slot_sym__bt_delete()\n");
    QTableWidgetItem    *item;
    std::string         str;
    unsigned long       addr;
    unsigned long       pos;

    this->_info.mutex.lock();

    if ((item = this->ui->sym__liste_symboles->item(this->ui->sym__liste_symboles->currentRow(), 1)) != NULL)
    {
        /* Recuperation de l'adresse de la section courante */
        str = item->text().toStdString();
        if ((pos = str.find("0x")) != std::string::npos)
        {
            addr = Calcul::xtol(&(str.c_str()[pos + 2]));
            this->_info.sym.del_symbole(addr);
        }
    }

    this->_info.mutex.unlock();
    this->slot_sym__liste_symboles__update();
}
