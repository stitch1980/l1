#ifndef    INODE_HPP_
#define    INODE_HPP_

#include    <QtGui>
#include    <QGraphicsScene>
#include    <QGraphicsSceneMouseEvent>
#include    <QPainter>
#include    <QStyleOption>
#include    <QGraphicsObject>
#include    <QList>
#include    <QMenu>

#include    <set>

class    Edge;
class    ViewerGraph;
class    INode;

QT_BEGIN_NAMESPACE
class    QGraphicsSceneMouseEvent;
QT_END_NAMESPACE


/**
** \class INode
** \brief Classe gerant les Nodes des graphes
*/
class    INode: public QGraphicsObject
{
    Q_OBJECT

public:
    /**
    ** \fn INode(ViewerGraph *viewer)
    ** \brief Constructeur d'une Node basique
    **
    ** \param viewer Pointeur sur la classe gerant l'affichage du graphe
    */
    INode(ViewerGraph *viewer);

    /**
    ** \fn ~INode()
    ** \brief Destructeur de la Node
    */
    ~INode();

private:
    INode(const INode& c);
    INode& operator = (const INode& n);

public:
    /**
    ** \fn QRectF boundingRect() const
    ** \brief Modifie la zone d'affichage du Node
    **
    ** \return Retourne les dimensions de la nouvelle zone d'affichage du Node
    */
    virtual QRectF       boundingRect() const = 0;

    /**
    ** \fn QPainterPath shape() const
    ** \brief Adapte la zone de selection du Node a ses dimensions
    **
    ** \return Retourne la zone de selection du Node
    */
    virtual QPainterPath shape() const = 0;

    /**
    ** \fn void paint(QPainter *painter, const QStyleOptionGraphicsItem*, QWidget *)
    ** \brief Fonction gerant l'affichage du Node
    **
    ** \param painter Pointeur sur l'objet permettant de dessiner le Node
    ** \return Retourne rien
    */
    virtual void         paint(QPainter *painter, const QStyleOptionGraphicsItem*, QWidget *) = 0;

    /**
    ** \fn QPointF get_posInput() const
    ** \brief Fonction permettant de connaitre la position relative du point d'entree du Node
    **
    ** \return Retourne la position relative du point d'entree du Node
    */
    virtual QPointF      get_posInput() const = 0;

    /**
    ** \fn QPointF get_posOutput() const
    ** \brief Fonction permettant de connaitre la position relative du point de sortie du Node
    **
    ** \return Retourne la position relative du point d'entree du Node
    */
    virtual QPointF      get_posOutput() const = 0;

    /**
    ** \fn void add_edge(Edge *e)
    ** \brief Gere l'ajout d'un edge connecte au Node
    **
    ** \brief e Edge a ajouter a la liste des edges connectes au Node
    ** \return Retourne rien
    */
    void    add_edge(Edge *e);

    /**
    ** \fn void del_edge(Edge *e)
    ** \brief Gere la suppression d'un edge connecte au Node
    **
    ** \brief e Edge a supprimer de la liste des edges connectes au Node
    ** \return Retourne rien
    */
    void    del_edge(Edge *e);

protected:
    /**
    ** \fn QVariant itemChange(GraphicsItemChange change, const QVariant &value)
    ** \brief Gere l'actualisation des Edge lorsqu'un Node est deplace
    **
    ** \param change Description du type de changement
    ** \param value Reference sur la variation
    ** \return Retourne la variation
    */
    QVariant             itemChange(GraphicsItemChange change, const QVariant &value);

    /**
    ** \fn void mousePressEvent(QGraphicsSceneMouseEvent *event)
    ** \brief Gestion des clics de la souris
    **
    ** \param event Pointeur sur la description de l'evenement
    ** \return Retourne rien
    */
    virtual void         mousePressEvent(QGraphicsSceneMouseEvent *event);

public slots:
    /**
    ** \fn void mouseReleaseEvent(QGraphicsSceneMouseEvent *event)
    ** \brief Fonction gerant les clics de la souris
    **
    ** \param event Pointeur sur la description de l'evenement
    ** \return Retourne rien
    */
    void                 mouseReleaseEvent(QGraphicsSceneMouseEvent *event);

protected:
    /** Liste des edges connectes au Node */
    std::set<Edge*>                       _list_edge;

    /** Pointeur sur l'objet gerant l'affichage du graphe */
    ViewerGraph                           *_graph;
};

#endif

