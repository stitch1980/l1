#ifndef    DEFINE_HPP_
#define    DEFINE_HPP_

/** Nom de l'interface graphique */
#define    GUI_PROGRAMME_NAME    "Lecter"

/** Nom du sous-dossier ou sont stockes les plugins standards */
#define    GUI_NAME_PLUGINS_DIRECTORY    "/plugins/"

#endif
