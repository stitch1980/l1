#include    "mainwindow.h"
#include    "ui_mainwindow.h"

#include    "optionwindow.h"


/**
** \fn void get_lib_name(std::set<std::string> &lib_name, int argc, const char **argv)
** \brief Gere la recuperation des noms des fichiers present dans le dossier des plugins
**
** \param lib_name Liste devant contenir les noms des plugins
** \param argv Tableau contenant les noms des plugins suplementaires
** \return Retourne rien
*/
void    get_lib_name(std::set<std::string> &lib_name, int argc, const char **argv)
{
    std::string      path;
    char             buffer[PATH_MAX + 1];
    DIR              *dir;
    struct dirent    *f;

    /* Identifie le chemin du dossier des plugins */
    if (realpath(argv[0], buffer) == NULL)
        fprintf(stderr, "ERROR:\tCannot find plugins directory\n");
    else
    {
        path = std::string(dirname(buffer)) + GUI_NAME_PLUGINS_DIRECTORY;

        /* Recupere les noms des fichiers present dans le dossier des plugins */
        if ((dir = opendir(path.c_str())) != NULL)
        {
            while ((f = readdir(dir)) != NULL)
            {
                if ((f->d_type & DT_REG) == DT_REG)
                {
                    if (realpath(std::string(path + f->d_name).c_str(), buffer) != NULL)
                        lib_name.insert(buffer);
                }
            }
            closedir(dir);
        }
        else
            fprintf(stderr, "ERROR:\tCannot open \"%s\"\n", path.c_str());
    }

    /* Recupere les noms de libs passes en parametres */
    for (int i=2; i<argc; i++)
    {
        if (realpath(argv[i], buffer) != NULL)
            lib_name.insert(buffer);
    }
}

/**
** \fn void get_lib(std::map<std::string, Plugin*> &lib, std::set<std::string> &lib_name)
** \brief Gere l'ouverture de plugins dont les noms ont ete passes en parametres
**
** \param lib Map contenant les plugins indexes par leur nom
** \param lib_name List contenant les noms des plugins a ouvrir
** \return Retourne rien
*/
void    get_lib(std::map<std::string, Plugin*> &lib, std::set<std::string> &lib_name)
{
    Plugin    *plugin;
    char      buffer[30];

    for (std::set<std::string>::iterator it=lib_name.begin(); it!=lib_name.end(); it++)
    {
        if ((plugin = Plugin::open_plugin(*it)) != NULL)
        {
            snprintf(buffer, 29, "%08lu", plugin->get_priorite());
            lib[std::string(buffer) + "-" + plugin->get_plugin_name()] = plugin;
        }
    }
}


MainWindow::MainWindow(int argc, const char **argv, QWidget *parent): QMainWindow(parent),
    ui(new Ui::MainWindow),
    _info(),
    _list_plugins(),
    _timer(),
    _thread(NULL, NULL, this),
    _statut(MainWindow::STATUT_DONE),
    _last_statut(MainWindow::STATUT_DONE),
    _entry_save(),
    _function_save(),
    _title_error(),
    _text_error()
{
    std::set<std::string>    lib_name;

    ui->setupUi(this);

    /* Prepare le timer */
    this->_timer.setInterval(100);
    connect(&(this->_timer), SIGNAL(timeout()), this, SLOT(slot_timer()), Qt::DirectConnection);
    this->_timer.start();

    /* Chargement des plugins */
    get_lib_name(lib_name, argc, argv);
    get_lib(this->_list_plugins, lib_name);
    this->_info.plugin = this->_list_plugins;

    this->actualisation();
}

MainWindow::~MainWindow()
{
    this->_timer.stop();

    delete ui;

    this->_info.plugin = this->_list_plugins;
    this->_info.clear();
}



/**
** \fn void put_message(const QString &title, const QString &txt)
** \brief Gere l'affichage d'un popup
**
** \param title Nom du popup
** \param txt Contenu du popup
** \return Retourne rien
*/
void    MainWindow::put_message(const QString &title, const QString &txt)
{
    QMessageBox    msg(QMessageBox::Warning, title, txt);
    msg.exec();
}

/**
** \fn void actualisation()
** \brief Gere l'actualisation de tout les champs de la fenetre
**
** \return Retourne rien
*/
void    MainWindow::actualisation()
{
    QString             str;

    this->_info.mutex.lock();

    /* Actualisation du nom de la fenetre */
    str = QString::fromUtf8(GUI_PROGRAMME_NAME);
    if (this->_info.filename.size() > 0)
    {
        char    tmp[this->_info.filename.size() + 1];
        char    *ptr;

        strcpy(tmp, this->_info.filename.c_str());
        if ((ptr = basename(tmp)) != NULL)
            str = " " + QString(ptr);
    }
    str += " [ ";
    if (this->_info.data != NULL)
        str += QString::number(this->_info.size) + " octets ";

    if (this->_info.format == Info::FORMAT_ELF32)
        str += "ELF32 ";
    else if (this->_info.format == Info::FORMAT_ELF64)
        str += "ELF64 ";
    else if (this->_info.format == Info::FORMAT_PE32)
        str += "PE32 ";
    else if (this->_info.format == Info::FORMAT_PE64)
        str += "PE64 ";
    else if (this->_info.format == Info::FORMAT_BRAINFUCK)
        str += "Brainfuck ";

    if (this->_info.endian == Info::ENDIAN_LITTLE)
        str += "LITTLE_ENDIAN ";
    else if (this->_info.endian == Info::ENDIAN_BIG)
        str += "BIG_ENDIAN ";

    if (this->_info.archi == Info::ARCHI_I32)
        str += "i386 ";
    else if (this->_info.archi == Info::ARCHI_I64)
        str += "x86_64 ";
    str += "]";
    this->setWindowTitle(str);

    this->_info.mutex.unlock();

    this->slot_seg__list_segment__update();
    this->slot_sym__liste_symboles__update();
    this->slot_type__list_type__update();
    this->slot_proto_func__liste_prototype__update();
    this->slot_proto_int__liste_prototype__update();
    this->slot_func__liste_entry__update();
    this->slot_callgraph__list_entry__update();
    this->slot_anal__update();
}

/**
** \fn void slot_timer()
** \brief Slot permettant d'actualiser le log en temps reel
**
** \return Retourne rien
*/
void    MainWindow::slot_timer()
{
    //qDebug("MainWindow::slot_timer()\n");

    /* Activation des boutons principaux si besoin est */
    if ((this->_info.data != NULL) && (this->_info.size > 0))
        this->ui->bt__parsing->setEnabled(true);
    else
        this->ui->bt__parsing->setEnabled(false);
    if (this->_info.sec.get_nbs_section() > 0)
        this->ui->bt__deassemble->setEnabled(true);
    else
        this->ui->bt__deassemble->setEnabled(false);
    if (this->_info.function.size() > 0)
        this->ui->bt__clean->setEnabled(true);
    else
        this->ui->bt__clean->setEnabled(false);
    if ((this->_info.function.size() > 0))
        this->ui->bt__decompile->setEnabled(true);
    else
        this->ui->bt__decompile->setEnabled(false);
    if (((this->_info.data != NULL) && (this->_info.size > 0)) ||
        (this->_info.sec.get_nbs_section() > 0) ||
        (this->_info.entry.size() > 0) ||
        (this->_info.function.size() > 0))
        this->ui->bt__analyze->setEnabled(true);
    else
        this->ui->bt__analyze->setEnabled(false);


    /* Affichage d'un popup d'erreur si besoin est */
    if (this->_statut == MainWindow::STATUT_ERROR)
    {
        this->put_message(this->_title_error, this->_text_error);
        this->_statut = MainWindow::STATUT_DONE;
    }

    /* Actualisation des menus si besoin est */
    if (this->_statut == MainWindow::STATUT_DONE)
    {
        if (this->_last_statut == MainWindow::STATUT_PARSING)
            this->actualisation();
        else if (this->_last_statut == MainWindow::STATUT_DEASM)
        {
            this->slot_func__liste_entry__update();
            this->slot_callgraph__list_entry__update();
        }
        else if (this->_last_statut == MainWindow::STATUT_CLEAN)
        {
            this->slot_func__liste_entry__update();
            this->slot_callgraph__list_entry__update();
        }
        else if (this->_last_statut == MainWindow::STATUT_DECOMPILE)
            this->slot_func_c__text__update();
        else if (this->_last_statut == MainWindow::STATUT_ANALYSE)
            this->slot_anal__update();

        this->setEnabled(true);
        this->statusBar()->showMessage("Done.");
        this->_last_statut = this->_statut;
    }
    else
    {
        /* Affichage du statut lors du parsing du contenu d'un fichier */
        if (this->_statut == MainWindow::STATUT_PARSING)
            this->statusBar()->showMessage("Analyse en cours... ("
                                           + QString::number(this->_info.sec.get_nbs_section()) + " section(s) et "
                                           + QString::number(this->_info.sym.get_nbs_symbole()) + " symboles(s))");

        /* Affichage du statut lors du deassemblage */
        else if (this->_statut == MainWindow::STATUT_DEASM)
            this->statusBar()->showMessage("Deassemblage en cours... (" + QString::number(this->_info.function.size()) + " fonction(s))");

        /* Affichage du statut lors du nettoyage */
        else if (this->_statut == MainWindow::STATUT_CLEAN)
            this->statusBar()->showMessage("Nottoyage en cours...");

        /* Affichage du statut lors de la decompilation */
        else if (this->_statut == MainWindow::STATUT_DECOMPILE)
            this->statusBar()->showMessage("Decompilation en cours...");

        /* Affichage du statut lors des analyses */
        else if (this->_statut == MainWindow::STATUT_ANALYSE)
            this->statusBar()->showMessage("Analyse en cours... (" + QString::number(this->_info.analyses.get_nbs_analyse_child()) + " analyse(s))");

        /* Affichage du statut lors de l'actualisation de la fenetre */
        else if (this->_statut == MainWindow::STATUT_UPDATE)
            this->statusBar()->showMessage("Actualisation...");

        this->setEnabled(false);
    }
}

/**
** \fn void slot_bt_open()
** \brief Slot permettant de charger le contenu d'un fichier afin de l'analyser
**
** \return Retourne rien
*/
void    MainWindow::slot_bt_open()
{
    qDebug("MainWindow::slot_bt_open()\n");
    int    ok;

    QString    filename = QFileDialog::getOpenFileName(this);
    if (filename.size() > 0)
    {
        /* Supprime les infos du binaire et le contenu des formulaires */
        this->_info.clear_proto();
        this->_info.clear_function();
        this->_info.clear_segment();
        this->_info.clear_file();
        this->_info.filename = filename.toStdString();

        ok = 0;
        for (std::map<std::string, Plugin*>::const_iterator it=this->_info.plugin.begin();
             it!=this->_info.plugin.end();
             it++)
        {
            if (it->second->get_type() == PLUGIN_TYPE__OPEN)
            {
                if (it->second->execute(&(this->_info)) <= 0)
                    this->_info.filename == "";
                ok = 1;
            }
        }

        /* Affichage d'un message d'erreur */
        if (ok == 0)
            this->put_message("ERROR", "Pas de plugin pour ouvrir le fichier");
    }

    this->actualisation();
}

/**
** \fn void slot_bt_option()
** \brief Slot permettant de d'afficher le menu d'options
**
** \return Retourne rien
*/
void    MainWindow::slot_bt_option()
{
    qDebug("MainWindow::slot_bt_option()\n");

    OptionWindow      w(&(this->_info), &(this->_list_plugins), this);

    w.exec();
    this->actualisation();
}

/**
** \fn void slot_bt_parsing()
** \brief Slot permettant de parser le fichier a analyser afin d'extraire ses infos
**
** \return Retourne rien
*/
void    MainWindow::slot_bt_parsing()
{
    qDebug("MainWindow::slot_bt_parsing()\n");

    this->_thread.set_ptr(this);
    this->_thread.set_func(&MainWindow::fonction_parsing);
    this->_thread.start();
}

/**
** \fn void slot_bt_definition()
** \brief Slot permettant de charger un fichier contenant des prototypes/definitions
**
** \return Retourne rien
*/
void    MainWindow::slot_bt_definition()
{
    qDebug("MainWindow::slot_bt_definition()\n");
    std::map<std::string, std::string>    def;
    std::vector<std::string>              lines;
    std::string                           content;

    this->_info.proto_func.add_function("exit", "", "int");
    this->_info.proto_func.add_function("__stack_chk_fail", "");

    QString    filename = QFileDialog::getOpenFileName(this);
    if (filename.size() > 0)
    {
        /* Parsing preprocesseur */
        if (ParsingPreprocesseur::open_and_parse(filename.toStdString(), lines, def, 10) > 0)
        {
            for (unsigned long i=0; i<lines.size(); i++)
            {
                printf("->.%s.\n", lines[i].c_str());
                content += lines[i];
            }
        }

        /* Parsing C */
    }
    this->slot_proto_func__liste_prototype__update();
    this->slot_proto_int__liste_prototype__update();
}

/**
** \fn void slot_bt_deassemble()
** \brief Slot permettant de generer un arbre ASM pour toutes les fonctions
**
** \return Retourne rien
*/
void    MainWindow::slot_bt_deassemble()
{
    qDebug("MainWindow::slot_bt_deassemble()\n");

    /* Sauvegarde des points d'entrees et suppression des fonctions */
    this->_info.mutex.lock();
    this->_entry_save = this->_info.entry;
    this->_info.mutex.unlock();
    this->_info.clear_function();

    /* Supprime les graphes de toutes les fonctions traitees */
    for (std::set<unsigned long>::const_iterator it_entry=this->_info.entry.begin();
         it_entry!=this->_info.entry.end();
         it_entry++)
    {
        this->ui->func_asm__arbre->del_scene(this->ui->func_asm__arbre->make_scene_name(*it_entry));
        this->ui->callgraph__view->del_scene(this->ui->callgraph__view->make_scene_name(*it_entry));
    }

    /* Deassemblage des fonctions */
    this->_thread.set_ptr(this);
    this->_thread.set_func(&MainWindow::fonction_deasm);
    this->_thread.start();
}

/**
** \fn void slot_bt_clean()
** \brief Slot permettant d'epurer l'arbre ASM de toutes les fonctions
**
** \return Retourne rien
*/
void    MainWindow::slot_bt_clean()
{
    qDebug("MainWindow::slot_bt_clean()\n");

    /* Sauvegarde de la liste des points d'entrees et des fonctions */
    this->_info.mutex.lock();
    this->_entry_save = this->_info.entry;
    this->_function_save = this->_info.function;
    this->_info.mutex.unlock();

    /* Supprime les graphes de toutes les fonctions traitees */
    for (std::set<unsigned long>::const_iterator it_entry=this->_info.entry.begin();
         it_entry!=this->_info.entry.end();
         it_entry++)
    {
        this->ui->func_asm__arbre->del_scene(this->ui->func_asm__arbre->make_scene_name(*it_entry));
        this->ui->callgraph__view->del_scene(this->ui->callgraph__view->make_scene_name(*it_entry));
    }

    this->_thread.set_ptr(this);
    this->_thread.set_func(&MainWindow::fonction_clean);
    this->_thread.start();
}

/**
** \fn void slot_bt_decompile()
** \brief Slot gerant la conversion ASM en C de toutes les fonctions
**
** \return Retourne rien
*/
void    MainWindow::slot_bt_decompile()
{
    qDebug("MainWindow::slot_bt_decompile()\n");

    this->_info.mutex.lock();
    this->_entry_save = this->_info.entry;
    this->_function_save = this->_info.function;
    this->_info.mutex.unlock();

    this->_thread.set_ptr(this);
    this->_thread.set_func(&MainWindow::fonction_decompile);
    this->_thread.start();
}

/**
** \fn void slot_bt_analyse()
** \brief Slot gerant l'analyse des donnees produites par les plugins
**
** \return Retourne rien
*/
void    MainWindow::slot_bt_analyse()
{
    qDebug("MainWindow::slot_bt_analyse()\n");

    this->_thread.set_ptr(this);
    this->_thread.set_func(&MainWindow::fonction_analyse);
    this->_thread.start();
}



/**
** \fn void fonction_parsing()
** \brief Gere l'execution des plugins de parsing
*/
void     MainWindow::fonction_parsing()
{
    int    ok;

    this->_last_statut = this->_statut;
    this->_statut = MainWindow::STATUT_PARSING;

    /* Supprime les infos du binaire et le contenu des formulaires */
    ok = 0;
    if (this->_info.data != NULL)
    {
        this->_info.clear_proto();
        this->_info.clear_function();
        this->_info.clear_segment();

        for (std::map<std::string, Plugin*>::const_iterator it=this->_info.plugin.begin();
             it!=this->_info.plugin.end();
             it++)
        {
            if (it->second->get_type() == PLUGIN_TYPE__PARSING)
            {
                if (it->second->execute(&(this->_info)) > 0)
                    ok = 1;
            }
        }
    }

    this->_info.mutex.lock();
    this->_last_statut = this->_statut;
    this->_statut = MainWindow::STATUT_DONE;
    if (ok == 0)
    {
        this->_title_error = "ERROR";
        this->_text_error = "Pas de plugin pour parser le fichier";
        this->_statut = MainWindow::STATUT_ERROR;
    }
    this->_info.mutex.unlock();
}

/**
** \fn void fonction_deasm()
** \brief Gere l'execution des plugins de deassemblage
*/
void     MainWindow::fonction_deasm()
{
    int    ok;

    this->_last_statut = this->_statut;
    this->_statut = MainWindow::STATUT_DEASM;

    ok = 0;
    if (this->_info.data != NULL)
    {
        for (std::map<std::string, Plugin*>::const_iterator it=this->_info.plugin.begin();
             it!=this->_info.plugin.end();
             it++)
        {
            if (it->second->get_type() == PLUGIN_TYPE__DEASM)
            {
                if (it->second->execute(&(this->_info)) > 0)
                    ok = 1;
            }
        }
    }

    /* Restauration des points d'entrees */
    this->_info.mutex.lock();
    this->_info.entry.insert(this->_entry_save.begin(), this->_entry_save.end());

    this->_last_statut = this->_statut;
    this->_statut = MainWindow::STATUT_DONE;
    if (ok == 0)
    {
        this->_title_error = "ERROR";
        this->_text_error = "Pas de plugin pour deassembler le fichier";
        this->_statut = MainWindow::STATUT_ERROR;
    }
    this->_info.mutex.unlock();
}



/**
** \fn void fonction_clean()
** \brief Gere l'execution des plugins de nettoyage
*/
void     MainWindow::fonction_clean()
{
    int    ok;

    this->_last_statut = this->_statut;
    this->_statut = MainWindow::STATUT_CLEAN;

    ok = 0;
    if (this->_info.data != NULL)
    {
        for (std::map<std::string, Plugin*>::const_iterator it=this->_info.plugin.begin();
             it!=this->_info.plugin.end();
             it++)
        {
            if (it->second->get_type() == PLUGIN_TYPE__CLEAN)
            {
                if (it->second->execute(&(this->_info)) > 0)
                    ok = 1;
            }
        }
    }

    /* Restauration des points d'entrees et des fonctions */
    this->_info.mutex.lock();
    this->_info.entry = this->_entry_save;
    this->_info.function = this->_function_save;

    this->_last_statut = this->_statut;
    this->_statut = MainWindow::STATUT_DONE;
    if (ok == 0)
    {
        this->_title_error = "ERROR";
        this->_text_error = "Pas de plugin pour nettoyer les fonctions";
        this->_statut = MainWindow::STATUT_ERROR;
    }
    this->_info.mutex.unlock();
}

/**
** \fn void fonction_decompile()
** \brief Gere l'execution des plugins de decompilation
*/
void     MainWindow::fonction_decompile()
{
    int    ok;

    this->_last_statut = this->_statut;
    this->_statut = MainWindow::STATUT_DECOMPILE;

    ok = 0;
    if (this->_info.data != NULL)
    {
        for (std::map<std::string, Plugin*>::const_iterator it=this->_info.plugin.begin();
             it!=this->_info.plugin.end();
             it++)
        {
            if (it->second->get_type() == PLUGIN_TYPE__DECOMPILE)
            {
                if (it->second->execute(&(this->_info)) > 0)
                    ok = 1;
            }
        }
    }

    /* Restauration des points d'entrees et des fonctions */
    this->_info.mutex.lock();
    this->_info.entry = this->_entry_save;
    this->_info.function = this->_function_save;

    this->_last_statut = this->_statut;
    this->_statut = MainWindow::STATUT_DONE;
    if (ok == 0)
    {
        this->_title_error = "ERROR";
        this->_text_error = "Pas de plugin pour decompiler les fonctions";
        this->_statut = MainWindow::STATUT_ERROR;
    }
    this->_info.mutex.unlock();
}


/**
** \fn void fonction_analyse()
** \brief Gere l'execution des plugins d'analyse
*/
void     MainWindow::fonction_analyse()
{
    int    ok;

    /* Actualisation du status de la GUI et suppression des analyses existantes */
    this->_info.mutex.lock();
    this->_last_statut = this->_statut;
    this->_statut = MainWindow::STATUT_ANALYSE;
    this->_info.analyses.clear();
    this->_info.mutex.unlock();

    ok = 0;
    if (this->_info.data != NULL)
    {
        for (std::map<std::string, Plugin*>::const_iterator it=this->_info.plugin.begin();
             it!=this->_info.plugin.end();
             it++)
        {
            if (it->second->get_type() == PLUGIN_TYPE__ANALYSE)
            {
                if (it->second->execute(&(this->_info)) > 0)
                    ok = 1;
            }
        }
    }

    /* Actualisation du status de la GUI */
    this->_info.mutex.lock();
    this->_last_statut = this->_statut;
    this->_statut = MainWindow::STATUT_DONE;
    if (ok == 0)
    {
        this->_title_error = "ERROR";
        this->_text_error = "Pas de plugin pour analyser les donnees";
        this->_statut = MainWindow::STATUT_ERROR;
    }
    this->_info.mutex.unlock();
}
