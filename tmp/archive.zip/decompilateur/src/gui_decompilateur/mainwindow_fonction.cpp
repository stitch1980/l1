#include "mainwindow.h"
#include "ui_mainwindow.h"


/**
** \fn void slot_func__liste_entry__update()
** \brief Slot gere l'actualisation de la liste des points d'entrees
**
** \return Retourne rien
*/
void    MainWindow::slot_func__liste_entry__update()
{
    qDebug("MainWindow::slot_func__liste_entry__update()\n");
    int        column;
    int        row;

    if (this->_info.mutex.try_lock() == 0)
        return ;

    /* Sauvegarde de l'element actuellement selectionne */
    column = this->ui->func__liste_entry->currentColumn();
    row = this->ui->func__liste_entry->currentRow();

    /* Preparation des symboles */
    disconnect(this->ui->func__liste_entry, SIGNAL(cellChanged(int, int)), this, SLOT(slot_func__liste_entry__edit()));

    /* Preparation de la liste des points d'entrees */
    this->ui->func__liste_entry->clearContents();
    this->ui->func__liste_entry->setRowCount(this->_info.entry.size());
    unsigned long    i = 0;
    for (std::set<unsigned long>::const_iterator it=this->_info.entry.begin(); it!=this->_info.entry.end(); it++)
    {
        this->ui->func__liste_entry->setItem(i, 0, new QTableWidgetItem(QString::fromStdString(Calcul::lto0x(*it))));
        if (this->_info.sym.get_name(*it).size() > 0)
            this->ui->func__liste_entry->setItem(i, 1, new QTableWidgetItem(QString::fromStdString(this->_info.sym.get_name(*it))));
        else
            this->ui->func__liste_entry->setItem(i, 1, new QTableWidgetItem(""));

        /* Les noms de fonctions ne sont pas editable */
        if (this->ui->func__liste_entry->item(i, 1) != NULL)
            this->ui->func__liste_entry->item(i, 1)->setFlags(this->ui->func__liste_entry->item(i, 1)->flags()  & ~Qt::ItemIsEditable);
        i++;
    }

    connect(this->ui->func__liste_entry, SIGNAL(cellChanged(int, int)), this, SLOT(slot_func__liste_entry__edit()));

    /* Re-selection de l'element autrefois selectionne */
    this->ui->func__liste_entry->setCurrentCell(row, column);

    this->_info.mutex.unlock();
    this->slot_func__liste_entry__clicked();
}

/**
** \fn void slot_func_asm__arbre__option_changed()
** \brief Slot gerant l'actualisation de l'arbre ASM en cas de changement d'options (Adresse, Octets, Instr)
**
** \return Retourne rien
*/
void    MainWindow::slot_func_asm__arbre__option_changed()
{
    qDebug("MainWindow::slot_func_asm__arbre__option_changed()\n");

    this->ui->func_asm__arbre->clear();
    this->slot_func_asm__arbre__update();
}

/**
** \fn void slot_func__liste_entry__edit()
** \brief Slot gere la modification d'un point d'entree
**
** \return Retourne rien
*/
void    MainWindow::slot_func__liste_entry__edit()
{
    qDebug("MainWindow::slot_func__liste_entry__edit()\n");
    QTableWidgetItem          *item_value;
    std::string               str_value;

    this->_info.mutex.lock();

    /* Suppression de tout les point d'entree */
    this->_info.entry.clear();

    for (int i=0; i<this->ui->func__liste_entry->rowCount(); i++)
    {
        item_value = this->ui->func__liste_entry->item(i, 0);

        if (item_value != NULL)
        {
            /* Creation du point d'entree grace a l'adresse */
            str_value = item_value->text().toStdString();
            if (BNFcalcul::is_decimal(str_value, NULL, NULL, 0, 0) == str_value.size())
                this->_info.entry.insert(strtol(str_value.c_str(), NULL, 10));
            else if (BNFcalcul::is_hexa_sans_0x(str_value, NULL, NULL, 0, 0) == str_value.size())
                this->_info.entry.insert(Calcul::xtol(str_value.c_str()));
            else if (BNFcalcul::is_hexadecimal(str_value, NULL, NULL, 0, 0) == str_value.size())
                this->_info.entry.insert(Calcul::xtol(&(str_value.c_str()[2])));
        }
    }

    /* On supprime les fonctions qui ne font pas partis des points d'entrees */
    for (std::map<unsigned long, Fonction*>::iterator it=this->_info.function.begin();
         it!=this->_info.function.end(); )
    {
        if (this->_info.entry.find(it->first) == this->_info.entry.end())
        {
            delete it->second;
            this->_info.function.erase(it);
            it = this->_info.function.begin();
        }
        else
            it++;
    }

    this->_info.mutex.unlock();
    this->slot_func__liste_entry__update();
}

/**
** \fn void lot_func__liste_entry__clicked()
** \brief Slot gere le clic sur un point d'entree
**
** \return Retourne rien
*/
void    MainWindow::slot_func__liste_entry__clicked()
{
    qDebug("MainWindow::slot_func__liste_entry__edit()\n");

    ui->func__bt_delete->setEnabled(false);
    ui->tab_fonction->setEnabled(false);
    if (this->ui->func__liste_entry->currentItem() != NULL)
    {
        ui->func__bt_delete->setEnabled(true);
        ui->tab_fonction->setEnabled(true);
    }

    this->slot_func_value__list_value__update();
    this->slot_func_c__text__update();
    this->slot_func_asm__arbre__update();
}

/**
** \fn void lot_func__bt_new()
** \brief Slot gerant la creation d'un point d'entree
**
** \return Retourne rien
*/
void    MainWindow::slot_func__bt_new()
{
    qDebug("MainWindow::slot_func__bt_new()\n");
    unsigned long    new_value;

    this->_info.mutex.lock();

    /* Cherche une valeur de symboles non utilisee */
    new_value = 0;
    while (this->_info.entry.find(new_value) != this->_info.entry.end())
        new_value++;

    /* Ajout du symbole avec un nom et un type par defaut */
    this->_info.entry.insert(new_value);

    this->_info.mutex.unlock();
    this->slot_func__liste_entry__update();
}

/**
** \fn void lot_func__bt_delete()
** \brief Slot gere la suppression d'un point d'entree
**
** \return Retourne rien
*/
void    MainWindow::slot_func__bt_delete()
{
    qDebug("MainWindow::slot_func__bt_delete()\n");
    QTableWidgetItem    *item;
    std::string         str;
    unsigned long       addr;
    unsigned long       pos;

    this->_info.mutex.lock();

    if ((item = this->ui->func__liste_entry->item(this->ui->func__liste_entry->currentRow(), 0)) != NULL)
    {
        /* Recuperation de l'adresse de la section courante */
        str = item->text().toStdString();
        if ((pos = str.find("0x")) != std::string::npos)
        {
            addr = Calcul::xtol(&(str.c_str()[pos + 2]));
            this->_info.entry.erase(addr);
            if (this->_info.function.find(addr) != this->_info.function.end())
            {
                delete this->_info.function.find(addr)->second;
                this->_info.function.erase(this->_info.function.find(addr));
            }
        }
    }

    this->_info.mutex.unlock();
    this->slot_func__liste_entry__update();
}





/**
** \fn void slot_func_value__list_value__update()
** \brief Slot gere l'actualisation des valeurs de contexte predefinie
**
** \return Retourne rien
*/
void    MainWindow::slot_func_value__list_value__update()
{
    qDebug("MainWindow::slot_func_value__list_value__update()\n");
    std::map<unsigned long, std::map<std::string, ContentContexte> >::iterator    it_contexte;
    QTableWidgetItem                                                              *item_value;
    std::string                                                                   str;
    unsigned long                                                                 addr;
    unsigned long                                                                 pos;
    int                                                                           column;
    int                                                                           row;
    QString                                                                       str_value;

    if (this->_info.mutex.try_lock() == 0)
        return ;

    disconnect(this->ui->func_value__liste_values, SIGNAL(cellChanged(int, int)), this, SLOT(slot_func_value__list_value__edit()));

    /* Sauvegarde de l'element actuellement selectionne */
    column = this->ui->func_value__liste_values->currentColumn();
    row = this->ui->func_value__liste_values->currentRow();
    this->ui->func_value__liste_values->clearContents();
    this->ui->func_value__liste_values->setRowCount(0);

    /* Identification de l'adresse de la fonction courante */
    if ((item_value = this->ui->func__liste_entry->item(this->ui->func__liste_entry->currentRow(), 0)) != NULL)
    {
        str = item_value->text().toStdString();
        if ((pos = str.find("0x")) != std::string::npos)
        {
            addr = Calcul::xtol(&(str.c_str()[pos + 2]));

            /* On s'assure d'abord que cette fonction a des valeurs predefinies */
            if ((it_contexte = this->_info.value_of_register_at_begining_of_function.find(addr))
                 != this->_info.value_of_register_at_begining_of_function.end())
            {
                this->ui->func_value__liste_values->setRowCount(it_contexte->second.size());

                /* On recupere toutes les valeurs predefinies */
                unsigned long    i = 0;
                for (std::map<std::string, ContentContexte>::iterator it=it_contexte->second.begin();
                     it!=it_contexte->second.end();
                     it++)
                {
                    this->ui->func_value__liste_values->setItem(i, 0, new QTableWidgetItem(QString::fromStdString(it->first)));
//                    this->ui->func_value__liste_values->setItem(i, 1, new QTableWidgetItem(QString::fromStdString(it->second._name)));
                    this->ui->func_value__liste_values->setItem(i, 2, new QTableWidgetItem(QString::fromStdString(it->second.get_type())));
                    this->ui->func_value__liste_values->setItem(i, 3, new QTableWidgetItem(QString::number(it->second.get_size())));
                    
                    str_value = "";
                    for (std::set<std::string>::const_iterator it_value=it->second.get_values().begin();
                         it_value!=it->second.get_values().end();
                         it_value++)
                    {
                        if (it_value != it->second.get_values().end())
                            str_value += " ; ";
                        str_value += QString::fromStdString(*it_value);
                    }
                    this->ui->func_value__liste_values->setItem(i, 4, new QTableWidgetItem(str_value));
                    i++;
                }
            }
        }
    }

    connect(this->ui->func_value__liste_values, SIGNAL(cellChanged(int, int)), this, SLOT(slot_func_value__list_value__edit()));

    /* Re-selection de l'element autrefois selectionne */
    this->ui->func_value__liste_values->setCurrentCell(row, column);

    this->_info.mutex.unlock();
    this->slot_func_value__list_value__clicked();
}

/**
** \fn void slot_func_value__list_value__edit()
** \brief Slot gere l'edition d'une valeur de contexte predefinie
**
** \return Retourne rien
*/
void    MainWindow::slot_func_value__list_value__edit()
{
    qDebug("MainWindow::slot_func_value__list_value__edit()\n");
    std::map<unsigned long, std::map<std::string, ContentContexte> >::iterator    it_contexte;
    QTableWidgetItem                                                              *item_var;
    QTableWidgetItem                                                              *item_name;
    QTableWidgetItem                                                              *item_type;
    QTableWidgetItem                                                              *item_size;
    QTableWidgetItem                                                              *item_value;
    std::string                                                                   str;
    unsigned long                                                                 addr;
    unsigned long                                                                 pos;

    this->_info.mutex.lock();

    /* Identification de l'adresse de la fonction courante */
    if ((item_value = this->ui->func__liste_entry->item(this->ui->func__liste_entry->currentRow(), 0)) != NULL)
    {
        str = item_value->text().toStdString();
        if ((pos = str.find("0x")) != std::string::npos)
        {
            addr = Calcul::xtol(&(str.c_str()[pos + 2]));

            /* On s'assure d'abord que cette fonction a des valeurs predefinies */
            if ((it_contexte = this->_info.value_of_register_at_begining_of_function.find(addr))
                 != this->_info.value_of_register_at_begining_of_function.end())
            {
                /* Vide le contexte d'execution prevu pour cette fonction */
                it_contexte->second.clear();

                /* Re-initialise le contexte d'execution avec les valeur de la liste */
                for (int i=0; i<this->ui->func_value__liste_values->rowCount(); i++)
                {
                    item_var = this->ui->func_value__liste_values->item(i, 0);
                    item_name = this->ui->func_value__liste_values->item(i, 1);
                    item_type = this->ui->func_value__liste_values->item(i, 2);
                    item_size = this->ui->func_value__liste_values->item(i, 3);
                    item_value = this->ui->func_value__liste_values->item(i, 4);

                    if ((item_var != NULL) && (item_name != NULL) && (item_type != NULL) && (item_size != NULL) && (item_value != NULL))
                    {
                        if ((BNFcalcul::is_dest(item_var->text().toStdString(), NULL, this->_info.ptr_func.deasm, 0, 0) == item_var->text().toStdString().size()) &&
                            /* Validite du nom */
                            /* Validite du type */
                            (strtol(item_size->text().toAscii(), NULL, 10) > 0) && (strtol(item_size->text().toAscii(), NULL, 10) < 8))
                        {
                            it_contexte->second[item_var->text().toStdString()].set_value(item_value->text().toStdString());
//                            it_contexte->second[item_var->text().toStdString()]._name = item_name->text().toStdString();
                            it_contexte->second[item_var->text().toStdString()].set_type(item_type->text().toStdString());
                            it_contexte->second[item_var->text().toStdString()].set_size(strtol(item_size->text().toAscii(), NULL, 10));
                        }
                    }
                }
            }
        }
    }

    this->_info.mutex.unlock();
    this->slot_func_value__list_value__update();
}

/**
** \fn void slot_func_value__list_value__clicked()
** \brief Slot gere les clics sur les valeurs de contexte predefinie
**
** \return Retourne rien
*/
void    MainWindow::slot_func_value__list_value__clicked()
{
    qDebug("MainWindow::slot_func_value__list_value__clicked()\n");

    this->ui->func_value__bt_delete->setEnabled(false);
    if (this->ui->func_value__liste_values->currentItem() != NULL)
        this->ui->func_value__bt_delete->setEnabled(true);
}

/**
** \fn void slot_func_value__bt_new()
** \brief Slot gere l'ajout d'une valeur de contexte predefinie
**
** \return Retourne rien
*/
void    MainWindow::slot_func_value__bt_new()
{
    qDebug("MainWindow::slot_func_value__bt_new()\n");
    std::map<unsigned long, std::map<std::string, ContentContexte> >::iterator    it_contexte;
    QTableWidgetItem                                                              *item_value;
    std::string                                                                   str;
    unsigned long                                                                 addr;
    unsigned long                                                                 pos;

    this->_info.mutex.lock();

    /* Identification de l'adresse de la fonction courante */
    if ((item_value = this->ui->func__liste_entry->item(this->ui->func__liste_entry->currentRow(), 0)) != NULL)
    {
        str = item_value->text().toStdString();
        if ((pos = str.find("0x")) != std::string::npos)
        {
            addr = Calcul::xtol(&(str.c_str()[pos + 2]));

            /* On s'assure d'abord que cette fonction a des valeurs predefinies */
            if ((it_contexte = this->_info.value_of_register_at_begining_of_function.find(addr))
                 != this->_info.value_of_register_at_begining_of_function.end())
            {
                /* On cherche un nouveau nom de variable */
                unsigned long    i = 0;
                while (it_contexte->second.find("[" + Calcul::lto0x(i) + "]") != it_contexte->second.end())
                    i++;
                it_contexte->second["[" + Calcul::lto0x(i) + "]"].set_size(4);
            }

            /* Sinon, on ajoute une valeur par defaut */
            else
                this->_info.value_of_register_at_begining_of_function[addr]["[0x0]"].set_size(4);
        }
    }

    this->_info.mutex.unlock();
    this->slot_func_value__list_value__update();
}

/**
** \fn void slot_func_value__bt_delete()
** \brief Slot gere la suppression d'une valeur de contexte predefinie
**
** \return Retourne rien
*/
void    MainWindow::slot_func_value__bt_delete()
{
    qDebug("MainWindow::slot_func_value__bt_delete()\n");
    std::map<unsigned long, std::map<std::string, ContentContexte> >::iterator    it_contexte;
    QTableWidgetItem                                                              *item_value;
    std::string                                                                   str;
    unsigned long                                                                 addr;
    unsigned long                                                                 pos;

    this->_info.mutex.lock();

    /* Identification de l'adresse de la fonction courante */
    if ((item_value = this->ui->func__liste_entry->item(this->ui->func__liste_entry->currentRow(), 0)) != NULL)
    {
        str = item_value->text().toStdString();
        if ((pos = str.find("0x")) != std::string::npos)
        {
            addr = Calcul::xtol(&(str.c_str()[pos + 2]));

            /* On s'assure d'abord que cette fonction a des valeurs predefinies */
            if ((it_contexte = this->_info.value_of_register_at_begining_of_function.find(addr))
                 != this->_info.value_of_register_at_begining_of_function.end())
            {
                /* On cherche le nom de la variable a eliminer */
                if ((item_value = this->ui->func_value__liste_values->item(this->ui->func_value__liste_values->currentRow(), 0)) != NULL)
                {
                    if (it_contexte->second.find(item_value->text().toStdString()) != it_contexte->second.end())
                        it_contexte->second.erase(it_contexte->second.find(item_value->text().toStdString()));
                }
            }
        }
    }

    this->_info.mutex.unlock();
    this->slot_func_value__list_value__update();
}




/**
** \fn void slot_func_asm__arbre__update()
** \brief Slot gerant l'actualisation de l'arbre ASM
**
** \return Retourne rien
*/
void    MainWindow::slot_func_asm__arbre__update()
{
     qDebug("MainWindow::slot_func_asm__arbre__update()\n");
     std::map<unsigned long, Fonction*>::iterator    it;
     QTableWidgetItem                                *item;
     std::string                                     str;
     unsigned long                                   addr;
     unsigned long                                   pos;
     int                                             put_addr;
     int                                             put_opcode;
     int                                             put_instr;

     /* Juste un try-lock pour eviter les inter-bloquages */
     if (this->_info.mutex.try_lock() == 0)
         return ;

     /* Clear le graphe */
     this->ui->func_asm__arbre->show(NULL, 0, this, 0, 0, 0);

     /* Choisi ce qu'il faut mettre dans l'arbre en fonction des checkbox */
     put_addr = 0;
     put_opcode = 0;
     put_instr = 0;
     if (this->ui->func_asm__check_deasm__addr->isChecked())
         put_addr = 1;
     if (this->ui->func_asm__check_deasm__opcode->isChecked())
         put_opcode = 1;
     if (this->ui->func_asm__check_deasm__instr->isChecked())
         put_instr = 1;

     if ((item = this->ui->func__liste_entry->item(this->ui->func__liste_entry->currentRow(), 0)) != NULL)
     {
         /* Recuperation de l'adresse de la fonction courante */
         str = item->text().toStdString();
         if ((pos = str.find("0x")) != std::string::npos)
         {
             addr = Calcul::xtol(&(str.c_str()[pos + 2]));

             /* Identification de la fonction a transformer en graphe */
             if ((it = this->_info.function.find(addr)) != this->_info.function.end())
             {
                 this->ui->func_asm__arbre->show(&(this->_info), addr, this, put_addr, put_opcode, put_instr);
             }
         }
     }

     this->_info.mutex.unlock();
}

/**
** \fn void slot_func_asm__bt_deassemble()
** \brief Slot gerant le deassemblage d'une fonction
**
** \return Retourne rien
*/
void    MainWindow::slot_func_asm__bt_deassemble()
{
    qDebug("MainWindow::slot_func_asm__bt_deassemble()\n");
    QTableWidgetItem           *item;
    std::string                str;
    unsigned long              addr;
    unsigned long              pos;

    if ((item = this->ui->func__liste_entry->item(this->ui->func__liste_entry->currentRow(), 0)) != NULL)
    {
        this->_info.mutex.lock();

        /* Recuperation de l'adresse de la section courante */
        str = item->text().toStdString();
        if ((pos = str.find("0x")) != std::string::npos)
        {
            addr = Calcul::xtol(&(str.c_str()[pos + 2]));
            this->slot_func__deassemble_an_entry(addr);
        }
        this->_info.mutex.unlock();
    }
    else
        this->slot_func_asm__arbre__update();
}

/**
** \fn void slot_func_asm__bt_clean()
** \brief Slot gerant le nettoyage d'une fonction
**
** \return Retourne rien
*/
void    MainWindow::slot_func_asm__bt_clean()
{
    qDebug("MainWindow::slot_func_asm__bt_clean()\n");
    QTableWidgetItem                      *item;
    std::string                           str;
    unsigned long                         addr;
    unsigned long                         pos;

    if ((item = this->ui->func__liste_entry->item(this->ui->func__liste_entry->currentRow(), 0)) != NULL)
    {
        this->_info.mutex.lock();

        /* Recuperation de l'adresse de la section courante */
        str = item->text().toStdString();
        if ((pos = str.find("0x")) != std::string::npos)
        {
            addr = Calcul::xtol(&(str.c_str()[pos + 2]));
            this->slot_func__clean_an_entry(addr);
        }

        this->_info.mutex.unlock();
    }
    else
        this->slot_func_asm__arbre__update();
}

/**
** \fn void slot_func_asm__bt_save()
** \brief Slot gerant l'enregistrement de l'arbre ASM d'une fonction
**
** \return Retourne rien
*/
void    MainWindow::slot_func_asm__bt_save()
{
    qDebug("MainWindow::slot_func_asm__bt_save()\n");
    std::map<unsigned long, Fonction*>::iterator    it;
    QTableWidgetItem                                *item;
    std::string                                     str;
    unsigned long                                   addr;
    unsigned long                                   pos;
    int                                             put_addr;
    int                                             put_opcode;
    int                                             put_instr;

    this->_info.mutex.lock();

    /* Choisi ce qu'il faut mettre dans l'arbre en fonction des checkbox */
    put_addr = 0;
    put_opcode = 0;
    put_instr = 0;
    if (this->ui->func_asm__check_deasm__addr->isChecked())
        put_addr = 1;
    if (this->ui->func_asm__check_deasm__opcode->isChecked())
        put_opcode = 1;
    if (this->ui->func_asm__check_deasm__instr->isChecked())
        put_instr = 1;

    if ((item = this->ui->func__liste_entry->item(this->ui->func__liste_entry->currentRow(), 0)) != NULL)
    {
        /* Recuperation de l'adresse de la fonction courante */
        str = item->text().toStdString();
        if ((pos = str.find("0x")) != std::string::npos)
        {
            addr = Calcul::xtol(&(str.c_str()[pos + 2]));

            /* Identification de la fonction a transformer en graphe */
            if ((it = this->_info.function.find(addr)) != this->_info.function.end())
            {
                QString    filename = QFileDialog::getSaveFileName(this);
                if (filename.size() > 0)
                {
                    this->ui->func_asm__arbre->save(filename.toStdString(), addr, &(this->_info), this, put_addr, put_opcode, put_instr);
                }
            }
        }
    }

    this->_info.mutex.unlock();
}

/**
** \fn void slot_func__select_an_entry_asm(unsigned long addr)
** \brief Gere la selction d'une fonction afin d'afficher son callgraphe
**
** \param addr Adresse de la fonction a selectionner
** \return Retourne rien
*/
void    MainWindow::slot_func__select_an_entry_asm(unsigned long addr)
{
    qDebug("MainWindow::slot_func__select_an_entry_asm(unsigned long addr)\n");
    QTableWidgetItem    *item;
    std::string         str;
    unsigned long       pos;

    for (int i=0; i<this->ui->func__liste_entry->rowCount(); i++)
    {
        if ((item = this->ui->func__liste_entry->item(i, 0)) != NULL)
        {
            /* Recuperation de l'adresse de la fonction courante */
            str = item->text().toStdString();
            if ((pos = str.find("0x")) != std::string::npos)
            {
                if (Calcul::xtol(&(str.c_str()[pos + 2])) == static_cast<long>(addr))
                {
                    this->ui->tab__main->setCurrentIndex(4);
                    this->ui->tab_fonction->setCurrentIndex(2);
                    this->ui->func__liste_entry->selectRow(i);
                    return ;
                }
            }
        }
    }
}
/**
** \fn void slot_func__deassemble_an_entry_asm(unsigned long addr)
** \brief Gere le deassemblage d'une fonction si elle est situe dans un segment executable
**
** \param addr Adresse de la fonction a deassembler
** \return Retourne rien
*/
void    MainWindow::slot_func__deassemble_an_entry(unsigned long addr)
{
    qDebug("MainWindow::slot_func__deassemble_an_entry(unsigned long addr)\n");

    /* Si l'adresse est dans une zone executable */
    if ((this->_info.sec.get_flag(addr) & SECTION_X) == SECTION_X)
    {
        /* On l'ajoute aux points d'entree */
        this->_info.entry.insert(addr);

        /* Sauvegarde de la liste des points d'entrees et suppression de la fonction a re-deassembler */
        this->_entry_save = this->_info.entry;
        this->_info.entry.clear();
        this->_info.entry.insert(addr);
        if (this->_info.function.find(addr) != this->_info.function.end())
        {
            delete this->_info.function.find(addr)->second;
            this->_info.function.erase(this->_info.function.find(addr));
        }

        /* Supprime les graphes de toutes les fonctions traitees */
        for (std::set<unsigned long>::const_iterator it_entry=this->_info.entry.begin();
             it_entry!=this->_info.entry.end();
             it_entry++)
        {
            this->ui->func_asm__arbre->del_scene( this->ui->func_asm__arbre->make_scene_name(*it_entry));
            this->ui->callgraph__view->del_scene( this->ui->callgraph__view->make_scene_name(*it_entry));
        }

        /* Deassemblage des fonctions */
        this->_thread.set_ptr(this);
        this->_thread.set_func(&MainWindow::fonction_deasm);
        this->_thread.start();
    }
}

/**
** \fn void slot_func__clean_an_entry_asm(unsigned long addr)
** \brief Gere le nettoyage d'une fonction prealablement deassemblee
**
** \param addr Adresse de la fonction a deassembler
** \return Retourne rien
*/
void    MainWindow::slot_func__clean_an_entry(unsigned long addr)
{
    qDebug("MainWindow::slot_func__clean_an_entry(unsigned long addr)\n");

    /* Si l'adresse correspond a une fonction deja deassemblee */
    if (this->_info.entry.find(addr) != this->_info.entry.end())
    {
        /* Sauvegarde de la liste des points d'entrees et des fonctions */
        this->_entry_save = this->_info.entry;
        this->_info.entry.clear();
        this->_info.entry.insert(addr);
        this->_function_save = this->_info.function;
        this->_info.function.clear();
        if (this->_function_save.find(addr) != this->_function_save.end())
            this->_info.function[addr] = this->_function_save[addr];

        /* Supprime les graphes de toutes les fonctions traitees */
        for (std::set<unsigned long>::const_iterator it_entry=this->_info.entry.begin();
             it_entry!=this->_info.entry.end();
             it_entry++)
        {
            this->ui->func_asm__arbre->del_scene( this->ui->func_asm__arbre->make_scene_name(*it_entry));
            this->ui->callgraph__view->del_scene( this->ui->callgraph__view->make_scene_name(*it_entry));
        }

        this->_thread.set_ptr(this);
        this->_thread.set_func(&MainWindow::fonction_clean);
        this->_thread.start();
    }
}




/**
** \fn void slot_func_c__text__update()
** \brief Gere l'actualisation du code decompile
**
** \return Retourne rien
*/
void    MainWindow::slot_func_c__text__update()
{
    qDebug("MainWindow::slot_func_c__text__update()\n");
    std::map<unsigned long, Fonction*>::iterator    it;
    QTableWidgetItem                                *item;
    std::string                                     str;
    unsigned long                                   addr;
    unsigned long                                   pos;

    if (this->_info.mutex.try_lock() == 0)
        return ;

    /* Vide le champ contenant le code de la fonction */
    this->ui->func_c__text->setPlainText("");

    if ((item = this->ui->func__liste_entry->item(this->ui->func__liste_entry->currentRow(), 0)) != NULL)
    {
        /* Recuperation de l'adresse de la fonction courante */
        str = item->text().toStdString();
        if ((pos = str.find("0x")) != std::string::npos)
        {
            addr = Calcul::xtol(&(str.c_str()[pos + 2]));

            /* Identification de la fonction a afficher */
            if ((it = this->_info.function.find(addr)) != this->_info.function.end())
            {
                if (it->second->get_source_code() != NULL)
                    this->ui->func_c__text->setPlainText(QString::fromStdString(it->second->get_source_code()->to_string(str)));
            }
        }
    }
    this->_info.mutex.unlock();
}

/**
** \fn void slot_func_c__bt_decompile()
** \brief Gere la re-decompilation d'une fonction deja deassemblee
**
** \return Retourne rien
*/
void    MainWindow::slot_func_c__bt_decompile()
{
    qDebug("MainWindow::slot_func_c__bt_decompile()\n");
    QTableWidgetItem                      *item;
    std::string                           str;
    unsigned long                         addr;
    unsigned long                         pos;

    if ((item = this->ui->func__liste_entry->item(this->ui->func__liste_entry->currentRow(), 0)) != NULL)
    {
        this->_info.mutex.lock();

        /* Recuperation de l'adresse de la section courante */
        str = item->text().toStdString();
        if ((pos = str.find("0x")) != std::string::npos)
        {
            addr = Calcul::xtol(&(str.c_str()[pos + 2]));
            this->slot_func__decompile_an_entry(addr);
        }
        this->_info.mutex.unlock();
    }
    else
        this->slot_func_c__text__update();
}

/**
** \fn void slot_func_c__bt_save()
** \brief Gere l'enregistrement du code decompile
**
** \return Retourne rien
*/
void    MainWindow::slot_func_c__bt_save()
{
    qDebug("MainWindow::slot_func_c__bt_save()\n");

    this->_info.mutex.lock();

    QString    filename = QFileDialog::getSaveFileName(this);
    if (filename.size() > 0)
    {
        std::ofstream    file(filename.toAscii(), std::ios::out | std::ios::trunc);

        if (file)
        {
             file << this->ui->func_c__text->toPlainText().toStdString();
             file.close();
        }
        else
            this->put_message("File error", "Impossible d'ouvrir le fichier");
    }

    this->_info.mutex.unlock();
}

/**
** \fn void slot_func__select_an_entry_c(unsigned long addr)
** \brief Gere la selction d'une fonction afin d'afficher son callgraphe
**
** \param addr Adresse de la fonction a selectionner
** \return Retourne rien
*/
void    MainWindow::slot_func__select_an_entry_c(unsigned long addr)
{
    qDebug("MainWindow::slot_func__select_an_entry_c(unsigned long addr)\n");
    QTableWidgetItem    *item;
    std::string         str;
    unsigned long       pos;

    for (int i=0; i<this->ui->func__liste_entry->rowCount(); i++)
    {
        if ((item = this->ui->func__liste_entry->item(i, 0)) != NULL)
        {
            /* Recuperation de l'adresse de la fonction courante */
            str = item->text().toStdString();
            if ((pos = str.find("0x")) != std::string::npos)
            {
                if (Calcul::xtol(&(str.c_str()[pos + 2])) == static_cast<long>(addr))
                {
                    this->ui->tab__main->setCurrentIndex(4);
                    this->ui->tab_fonction->setCurrentIndex(3);
                    this->ui->func__liste_entry->selectRow(i);
                    return ;
                }
            }
        }
    }
}

/**
** \fn void slot_func__decompile_an_entry_asm(unsigned long addr)
** \brief Gere la decompilation d'une fonction prealablement deassemblee
**
** \param addr Adresse de la fonction a decompiler
** \return Retourne rien
*/
void   MainWindow::slot_func__decompile_an_entry(unsigned long addr)
{
    qDebug("MainWindow:: slot_func__decompile_an_entry(unsigned long addr)\n");

    /* Si l'adresse correspond a une fonction deja deassemblee */
    if (this->_info.entry.find(addr) != this->_info.entry.end())
    {
        /* Sauvegarde de la liste des points d'entrees et des fonctions */
        this->_entry_save = this->_info.entry;
        this->_info.entry.clear();
        this->_info.entry.insert(addr);
        this->_function_save = this->_info.function;
        this->_info.function.clear();
        if (this->_function_save.find(addr) != this->_function_save.end())
            this->_info.function[addr] = this->_function_save[addr];

        this->_thread.set_ptr(this);
        this->_thread.set_func(&MainWindow::fonction_decompile);
        this->_thread.start();
    }
}
