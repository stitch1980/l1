#include    "mainwindow.h"
#include    "ui_mainwindow.h"

#include    "newtypewindow.h"


/**
** \fn void slot_type__list_type__update()
** \brief Slot gerant l'actualisation de la liste de type
**
** \return Retourne rien
*/
void    MainWindow::slot_type__list_type__update()
{
    qDebug("MainWindow::slot_type__list_type__update()\n");
    QList<QTreeWidgetItem*>    liste_type;
    QTreeWidgetItem            *widget_item;
    QStringList                str_list;
    std::string                type_var;
    unsigned long              size_var;

    if (this->_info.proto_var.get_nbs_type() <= 0)
    {
        this->_info.proto_var.add_definition("char", 1);
        this->_info.proto_var.add_definition("short", 2);
        this->_info.proto_var.add_definition("int", 4);
        this->_info.proto_var.add_definition("long", 8);
        this->_info.proto_var.add_definition("uint16_t", 2);
        this->_info.proto_var.add_definition("uint32_t", 4);
        this->_info.proto_var.add_definition("uint64_t", 8);

        this->_info.proto_var.add_definition("char_pair", "char", "a", "char", "b");
        this->_info.proto_var.add_definition("chor_pair", "chor", "a", "chor", "b");
        this->_info.proto_var.add_definition("short_pair", "short", "a", "short", "b");
        this->_info.proto_var.add_definition("popipop", "char_pair", "attr1", "short_pair", "attr2", "char_pair", "attr3", "short_pair", "attr4");

        std::vector<std::string>    type_attr;
        std::vector<std::string>    name_attr;
        std::vector<unsigned long>  nbs_elem_attr;
        type_attr.push_back("char");
        type_attr.push_back("uint16_t");
        type_attr.push_back("uint16_t");
        type_attr.push_back("uint32_t");
        type_attr.push_back("uint32_t");
        type_attr.push_back("uint32_t");
        type_attr.push_back("uint32_t");
        type_attr.push_back("uint32_t");
        type_attr.push_back("uint16_t");
        type_attr.push_back("uint16_t");
        type_attr.push_back("uint16_t");
        type_attr.push_back("uint16_t");
        type_attr.push_back("uint16_t");
        type_attr.push_back("uint16_t");

        name_attr.push_back("e_ident");
        name_attr.push_back("e_type");
        name_attr.push_back("e_machine");
        name_attr.push_back("e_version");
        name_attr.push_back("e_entry");
        name_attr.push_back("e_phoff");
        name_attr.push_back("e_shoff");
        name_attr.push_back("e_flags");
        name_attr.push_back("e_ehsize");
        name_attr.push_back("e_phentsize");
        name_attr.push_back("e_phnum");
        name_attr.push_back("e_shentsize");
        name_attr.push_back("e_shnum");
        name_attr.push_back("e_shstrndx");

        nbs_elem_attr.push_back(16);
        nbs_elem_attr.push_back(1);
        nbs_elem_attr.push_back(1);
        nbs_elem_attr.push_back(1);
        nbs_elem_attr.push_back(1);
        nbs_elem_attr.push_back(1);
        nbs_elem_attr.push_back(1);
        nbs_elem_attr.push_back(1);
        nbs_elem_attr.push_back(1);
        nbs_elem_attr.push_back(1);
        nbs_elem_attr.push_back(1);
        nbs_elem_attr.push_back(1);
        nbs_elem_attr.push_back(1);
        nbs_elem_attr.push_back(1);
        this->_info.proto_var.add_definition("Elf32_Ehdr", type_attr, name_attr, nbs_elem_attr);
    }

    this->_info.mutex.lock();

    this->ui->type__treeview->clear();
    this->ui->type__treeview->setColumnCount(3);
    if (this->ui->type__treeview->headerItem() != NULL)
    {
        this->ui->type__treeview->headerItem()->setText(0, "Type");
        this->ui->type__treeview->headerItem()->setText(1, "Nom");
        this->ui->type__treeview->headerItem()->setText(2, "Taille");
    }

    /* Pour tout les types existants */
    for (unsigned long i=0; i<this->_info.proto_var.get_nbs_type(); i++)
    {
        /* Recupere le type et la taille de la variable */
        type_var = this->_info.proto_var.get_type_num(i);
        size_var = this->_info.proto_var.get_size(type_var);

        str_list.clear();
        str_list.append(QString::fromStdString(type_var));
        str_list.append("");
        str_list.append(QString::number(size_var, 10));

        /* Creation de l'item */
        if ((widget_item = new QTreeWidgetItem(this->ui->type__treeview, str_list)) != NULL)
        {
            /* Si la structure est invalide, on la colore en rouge */
            if (this->_info.proto_var.is_valid(type_var) <= 0)
            {
                widget_item->setBackground(0, Qt::red);
                widget_item->setBackground(1, Qt::red);
                widget_item->setBackground(2, Qt::red);
            }
            else
            {
                widget_item->setBackground(0, QBrush(QColor(200, 200, 200)));
                widget_item->setBackground(1, QBrush(QColor(200, 200, 200)));
                widget_item->setBackground(2, QBrush(QColor(200, 200, 200)));
            }

            this->slot_type__list_type_son(widget_item, type_var, 1);
            liste_type.append(widget_item);
        }
    }

    this->ui->type__treeview->insertTopLevelItems(0, liste_type);

    this->_info.mutex.unlock();
    this->slot_type__liste_type_clicked();
}

/**
** \fn void slot_type__list_type_son(QTreeWidgetItem *item, const std::string &type_var, unsigned int profondeur)
** \brief Permet d'ajouter les attributs d'une structure lors de son affichage
**
** \param item Classe contenant les infos de la structure a afficher
** \param type_var Type de la structure dont le contenu doit etre affiche
** \param profondeur Profondeur de la recursion pour l'affichage
** \return Retourne rien
*/
void    MainWindow::slot_type__list_type_son(QTreeWidgetItem *item, const std::string &type_var, unsigned int profondeur)
{
    QTreeWidgetItem    *son;
    QStringList        str_list;
    std::string        type_son;
    std::string        name_son;
    unsigned long      nbs_elem_son;
    unsigned long      size_son;
    unsigned int       color;

    if ((item != NULL) && (this->_info.proto_var.exist(type_var)) && (profondeur < 7))
    {
        /* Choix de la couleur de l'affichage en fonction de la profondeur */
        color = 200 + (profondeur * 15);
        if (color > 255)
            color = 255;

        for (unsigned long i=0; i<this->_info.proto_var.get_nbs_attribut(type_var); i++)
        {
            /* Recupere le type, le nom et la taille de la sous-variable */
            type_son = this->_info.proto_var.get_type_attribut_num(type_var, i);
            name_son = this->_info.proto_var.get_name_attribut_num(type_var, i);
            nbs_elem_son = this->_info.proto_var.get_nbs_element_attribut_num(type_var, i);
            size_son = (this->_info.proto_var.get_size(type_son) * nbs_elem_son);

            /* Si c'est un tableau, on l'affiche */
            if (nbs_elem_son > 1)
                name_son += "[" + Calcul::ltos(nbs_elem_son) + "]";

            str_list.clear();
            str_list.append(QString::fromStdString(type_son));
            str_list.append(QString::fromStdString(name_son));
            str_list.append(QString::number(size_son, 10));

            /* Creation de l'item */
            if ((son = new QTreeWidgetItem(item, str_list)) != NULL)
            {
                /* Si la structure est invalide, on la colore en rouge */
                if (this->_info.proto_var.is_valid(type_son) <= 0)
                {
                    son->setBackground(0, Qt::red);
                    son->setBackground(1, Qt::red);
                    son->setBackground(2, Qt::red);
                }
                else
                {
                    son->setBackground(0, QBrush(QColor(color, color, color)));
                    son->setBackground(1, QBrush(QColor(color, color, color)));
                    son->setBackground(2, QBrush(QColor(color, color, color)));
                }

                this->slot_type__list_type_son(son, type_son, profondeur+1);
                item->insertChild(i, son);
            }
        }
    }
}

/**
** \fn void slot_type__liste_type_clicked
** \brief Slot gerant le clic sur un type de variable
**
** \return Retourne rien
*/
void    MainWindow::slot_type__liste_type_clicked()
{
    qDebug("MainWindow::slot_type__liste_type_clicked()\n");

    this->ui->type__bt_edit->setEnabled(false);
    this->ui->type__bt_delete->setEnabled(false);
    if (this->ui->type__treeview->currentItem() != NULL)
    {
        this->ui->type__bt_edit->setEnabled(true);
        this->ui->type__bt_delete->setEnabled(true);
    }
}

/**
** \fn void slot_type__bt_new()
** \brief Gere la creation d'un nouveau type de variable
**
** \return Retourne rien
*/
void   MainWindow::slot_type__bt_new()
{
    qDebug("MainWindow::slot_type__bt_new()\n");
    //std::string        name_type;

    this->_info.mutex.lock();

    NewTypeWindow    w("", &(this->_info.proto_var), this);
    w.exec();

    this->_info.mutex.unlock();
    this->slot_type__list_type__update();
}

/**
** \fn void slot_type__bt_edit()
** \brief Gere la modification d'un type de variable
**
** \return Retourne rien
*/
void   MainWindow::slot_type__bt_edit()
{
    qDebug("MainWindow::slot_type__bt_edit()\n");
    QTreeWidgetItem    *item;
    std::string        name_type;

    this->_info.mutex.lock();

    if ((item = this->ui->type__treeview->currentItem()) != NULL)
    {
        /* On identifie l'item "principal" (utile en cas de structure) */
        while (item->parent() != NULL)
            item = item->parent();

        name_type = item->text(0).toStdString();

        NewTypeWindow    w(name_type, &(this->_info.proto_var), this);
        w.exec();
    }

    this->_info.mutex.unlock();
    this->slot_type__list_type__update();
}

/**
** \fn void slot_type__bt_delete()
** \brief Gere la suppression d'un type de variable
**
** \return Retourne rien
*/
void   MainWindow::slot_type__bt_delete()
{
    qDebug("MainWindow::slot_type__bt_delete()\n");
    QTreeWidgetItem    *item;

    this->_info.mutex.lock();
    if ((item = this->ui->type__treeview->currentItem()) != NULL)
    {
        /* On identifie l'item "principal" (utile en cas de structure) */
        while (item->parent() != NULL)
            item = item->parent();

        /* On supprime le type */
        this->_info.proto_var.del_definition(item->text(0).toStdString());
    }

    this->_info.mutex.unlock();
    this->slot_type__list_type__update();
}
