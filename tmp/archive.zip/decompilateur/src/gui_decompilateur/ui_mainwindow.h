/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created: Wed May 20 12:53:36 2015
**      by: Qt User Interface Compiler version 4.8.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCheckBox>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QMainWindow>
#include <QtGui/QPushButton>
#include <QtGui/QSlider>
#include <QtGui/QSpacerItem>
#include <QtGui/QSpinBox>
#include <QtGui/QStatusBar>
#include <QtGui/QTabWidget>
#include <QtGui/QTableWidget>
#include <QtGui/QTextEdit>
#include <QtGui/QTreeWidget>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>
#include "HexEditor.hpp"
#include "ViewerCallGraph.hpp"
#include "ViewerFunctionGraph.hpp"

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QVBoxLayout *verticalLayout;
    QWidget *widget;
    QHBoxLayout *horizontalLayout;
    QPushButton *bt__open;
    QPushButton *bt__option;
    QSpacerItem *horizontalSpacer_12;
    QPushButton *bt__parsing;
    QPushButton *bt__definition;
    QPushButton *bt__deassemble;
    QPushButton *bt__clean;
    QPushButton *bt__decompile;
    QPushButton *bt__analyze;
    QTabWidget *tab__main;
    QWidget *tab_main__segments;
    QHBoxLayout *horizontalLayout_17;
    QWidget *widget_15;
    QVBoxLayout *verticalLayout_14;
    QLabel *label;
    QTableWidget *seg__liste_segments;
    QWidget *widget_16;
    QHBoxLayout *horizontalLayout_16;
    QPushButton *seg__bt_new;
    QPushButton *seg__bt_edit;
    QPushButton *seg__bt_save;
    QSpacerItem *horizontalSpacer_11;
    QPushButton *seg__bt_delete;
    HexEditor *seg__content;
    QWidget *widget_12;
    QVBoxLayout *verticalLayout_16;
    QPushButton *seg__scrollbar_up;
    QSlider *seg__scrollbar_content;
    QPushButton *seg__scrollbar_down;
    QWidget *tab_3main__symboles;
    QVBoxLayout *verticalLayout_13;
    QLabel *label_2;
    QTableWidget *sym__liste_symboles;
    QWidget *widget_14;
    QHBoxLayout *horizontalLayout_15;
    QPushButton *sym__bt_new;
    QPushButton *sym__bt_edit;
    QSpacerItem *horizontalSpacer_10;
    QPushButton *sym__bt_delete;
    QWidget *tab_main__definitions;
    QVBoxLayout *verticalLayout_12;
    QLabel *label_3;
    QTreeWidget *type__treeview;
    QWidget *widget_13;
    QHBoxLayout *horizontalLayout_14;
    QPushButton *type__bt_new;
    QPushButton *type__bt_edit;
    QSpacerItem *horizontalSpacer_9;
    QPushButton *type__bt_delete;
    QWidget *tab_main__prototypes;
    QVBoxLayout *verticalLayout_6;
    QTabWidget *tabWidget;
    QWidget *tab_3;
    QVBoxLayout *verticalLayout_10;
    QTableWidget *proto_func__liste_prototypes;
    QWidget *widget_6;
    QHBoxLayout *horizontalLayout_7;
    QPushButton *proto_func__bt_new;
    QPushButton *proto_func__bt_edit;
    QSpacerItem *horizontalSpacer_4;
    QPushButton *proto_func__bt_delete;
    QWidget *tab_5;
    QVBoxLayout *verticalLayout_11;
    QTableWidget *proto_inter__liste_prototypes;
    QWidget *widget_10;
    QHBoxLayout *horizontalLayout_11;
    QPushButton *proto_inter__bt_new;
    QPushButton *proto_inter__bt_edit;
    QSpacerItem *horizontalSpacer_8;
    QPushButton *proto_inter__bt_delete;
    QWidget *tab_4;
    QVBoxLayout *verticalLayout_15;
    QTableWidget *proto_syscall__liste_prototypes;
    QWidget *widget_11;
    QHBoxLayout *horizontalLayout_12;
    QPushButton *proto_syscall__bt_new;
    QPushButton *proto_syscall__bt_edit;
    QSpacerItem *horizontalSpacer_14;
    QPushButton *proto_syscall__bt_delete;
    QWidget *tab_main__fonctions;
    QHBoxLayout *horizontalLayout_3;
    QWidget *widget_2;
    QVBoxLayout *verticalLayout_2;
    QLabel *label_5;
    QTableWidget *func__liste_entry;
    QWidget *widget1;
    QHBoxLayout *horizontalLayout_2;
    QPushButton *func__bt_new;
    QPushButton *func__bt_delete;
    QTabWidget *tab_fonction;
    QWidget *tab_fonction__tab_valeurs;
    QVBoxLayout *verticalLayout_3;
    QLabel *label_6;
    QTableWidget *func_value__liste_values;
    QWidget *widget_18;
    QHBoxLayout *horizontalLayout_18;
    QLabel *label_4;
    QLineEdit *func_value__ret;
    QWidget *widget_5;
    QHBoxLayout *horizontalLayout_6;
    QPushButton *func_value__bt_new;
    QSpacerItem *horizontalSpacer_3;
    QPushButton *func_value__bt_delete;
    QWidget *tab;
    QVBoxLayout *verticalLayout_7;
    QTableWidget *func_param__liste_param;
    QWidget *widget2;
    QHBoxLayout *horizontalLayout_8;
    QPushButton *func_param__bt_new;
    QSpacerItem *horizontalSpacer_6;
    QPushButton *func_param__bt_delete;
    QWidget *tab_fonction__tab_asm;
    QVBoxLayout *verticalLayout_4;
    QLabel *label_7;
    ViewerFunctionGraph *func_asm__arbre;
    QWidget *widget_4;
    QHBoxLayout *horizontalLayout_5;
    QPushButton *func_asm__bt_deassemble;
    QPushButton *func_asm__bt_clean;
    QSpacerItem *horizontalSpacer_2;
    QCheckBox *func_asm__check_deasm__addr;
    QCheckBox *func_asm__check_deasm__opcode;
    QCheckBox *func_asm__check_deasm__instr;
    QSpacerItem *horizontalSpacer_5;
    QPushButton *func_asm__bt_save;
    QWidget *tab_6;
    QVBoxLayout *verticalLayout_5;
    QLabel *label_8;
    QTextEdit *func_c__text;
    QWidget *widget_3;
    QHBoxLayout *horizontalLayout_4;
    QPushButton *func_c__bt_decompile;
    QSpacerItem *horizontalSpacer;
    QPushButton *func_c__bt_save;
    QWidget *tab_2;
    QHBoxLayout *horizontalLayout_10;
    QWidget *widget_9;
    QVBoxLayout *verticalLayout_9;
    QLabel *label_9;
    QTableWidget *callgraph__list_entry;
    QWidget *widget_7;
    QVBoxLayout *verticalLayout_8;
    ViewerCallGraph *callgraph__view;
    QWidget *widget_8;
    QHBoxLayout *horizontalLayout_9;
    QPushButton *callgraph__bt_generate;
    QSpacerItem *horizontalSpacer_7;
    QLabel *label_10;
    QSpinBox *callgraph__nbs_rec;
    QSpacerItem *horizontalSpacer_13;
    QPushButton *callgraph__bt_save;
    QWidget *tab_7;
    QVBoxLayout *verticalLayout_17;
    QTreeWidget *anal__tree_analyse;
    QWidget *widget_17;
    QHBoxLayout *horizontalLayout_13;
    QPushButton *anal__bt_save_all;
    QPushButton *anal__bt_save;
    QSpacerItem *horizontalSpacer_15;
    QPushButton *anal__bt_delete;
    QPushButton *anal__bt_delete_all;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(1005, 625);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/new/prefix1/icone1"), QSize(), QIcon::Normal, QIcon::Off);
        MainWindow->setWindowIcon(icon);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        centralWidget->setEnabled(true);
        verticalLayout = new QVBoxLayout(centralWidget);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        widget = new QWidget(centralWidget);
        widget->setObjectName(QString::fromUtf8("widget"));
        horizontalLayout = new QHBoxLayout(widget);
        horizontalLayout->setSpacing(6);
        horizontalLayout->setContentsMargins(11, 11, 11, 11);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        bt__open = new QPushButton(widget);
        bt__open->setObjectName(QString::fromUtf8("bt__open"));

        horizontalLayout->addWidget(bt__open);

        bt__option = new QPushButton(widget);
        bt__option->setObjectName(QString::fromUtf8("bt__option"));

        horizontalLayout->addWidget(bt__option);

        horizontalSpacer_12 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_12);

        bt__parsing = new QPushButton(widget);
        bt__parsing->setObjectName(QString::fromUtf8("bt__parsing"));
        bt__parsing->setEnabled(false);
        bt__parsing->setMaximumSize(QSize(200, 16777215));

        horizontalLayout->addWidget(bt__parsing);

        bt__definition = new QPushButton(widget);
        bt__definition->setObjectName(QString::fromUtf8("bt__definition"));
        bt__definition->setEnabled(false);

        horizontalLayout->addWidget(bt__definition);

        bt__deassemble = new QPushButton(widget);
        bt__deassemble->setObjectName(QString::fromUtf8("bt__deassemble"));
        bt__deassemble->setEnabled(false);
        bt__deassemble->setMaximumSize(QSize(200, 16777215));

        horizontalLayout->addWidget(bt__deassemble);

        bt__clean = new QPushButton(widget);
        bt__clean->setObjectName(QString::fromUtf8("bt__clean"));
        bt__clean->setEnabled(false);
        bt__clean->setMaximumSize(QSize(200, 16777215));

        horizontalLayout->addWidget(bt__clean);

        bt__decompile = new QPushButton(widget);
        bt__decompile->setObjectName(QString::fromUtf8("bt__decompile"));
        bt__decompile->setEnabled(false);
        bt__decompile->setMaximumSize(QSize(200, 16777215));

        horizontalLayout->addWidget(bt__decompile);

        bt__analyze = new QPushButton(widget);
        bt__analyze->setObjectName(QString::fromUtf8("bt__analyze"));
        bt__analyze->setEnabled(false);

        horizontalLayout->addWidget(bt__analyze);


        verticalLayout->addWidget(widget);

        tab__main = new QTabWidget(centralWidget);
        tab__main->setObjectName(QString::fromUtf8("tab__main"));
        tab_main__segments = new QWidget();
        tab_main__segments->setObjectName(QString::fromUtf8("tab_main__segments"));
        horizontalLayout_17 = new QHBoxLayout(tab_main__segments);
        horizontalLayout_17->setSpacing(6);
        horizontalLayout_17->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_17->setObjectName(QString::fromUtf8("horizontalLayout_17"));
        widget_15 = new QWidget(tab_main__segments);
        widget_15->setObjectName(QString::fromUtf8("widget_15"));
        widget_15->setMaximumSize(QSize(400, 16777215));
        verticalLayout_14 = new QVBoxLayout(widget_15);
        verticalLayout_14->setSpacing(6);
        verticalLayout_14->setContentsMargins(0, 0, 0, 0);
        verticalLayout_14->setObjectName(QString::fromUtf8("verticalLayout_14"));
        label = new QLabel(widget_15);
        label->setObjectName(QString::fromUtf8("label"));

        verticalLayout_14->addWidget(label);

        seg__liste_segments = new QTableWidget(widget_15);
        if (seg__liste_segments->columnCount() < 3)
            seg__liste_segments->setColumnCount(3);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        seg__liste_segments->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        seg__liste_segments->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        seg__liste_segments->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        seg__liste_segments->setObjectName(QString::fromUtf8("seg__liste_segments"));
        seg__liste_segments->setEnabled(true);
        seg__liste_segments->setEditTriggers(QAbstractItemView::NoEditTriggers);
        seg__liste_segments->setSortingEnabled(true);
        seg__liste_segments->setColumnCount(3);
        seg__liste_segments->horizontalHeader()->setCascadingSectionResizes(false);
        seg__liste_segments->horizontalHeader()->setStretchLastSection(true);

        verticalLayout_14->addWidget(seg__liste_segments);

        widget_16 = new QWidget(widget_15);
        widget_16->setObjectName(QString::fromUtf8("widget_16"));
        horizontalLayout_16 = new QHBoxLayout(widget_16);
        horizontalLayout_16->setSpacing(6);
        horizontalLayout_16->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_16->setObjectName(QString::fromUtf8("horizontalLayout_16"));
        horizontalLayout_16->setContentsMargins(0, -1, 0, 0);
        seg__bt_new = new QPushButton(widget_16);
        seg__bt_new->setObjectName(QString::fromUtf8("seg__bt_new"));

        horizontalLayout_16->addWidget(seg__bt_new);

        seg__bt_edit = new QPushButton(widget_16);
        seg__bt_edit->setObjectName(QString::fromUtf8("seg__bt_edit"));
        seg__bt_edit->setEnabled(false);

        horizontalLayout_16->addWidget(seg__bt_edit);

        seg__bt_save = new QPushButton(widget_16);
        seg__bt_save->setObjectName(QString::fromUtf8("seg__bt_save"));
        seg__bt_save->setEnabled(false);

        horizontalLayout_16->addWidget(seg__bt_save);

        horizontalSpacer_11 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_16->addItem(horizontalSpacer_11);

        seg__bt_delete = new QPushButton(widget_16);
        seg__bt_delete->setObjectName(QString::fromUtf8("seg__bt_delete"));
        seg__bt_delete->setEnabled(false);

        horizontalLayout_16->addWidget(seg__bt_delete);


        verticalLayout_14->addWidget(widget_16);


        horizontalLayout_17->addWidget(widget_15);

        seg__content = new HexEditor(tab_main__segments);
        seg__content->setObjectName(QString::fromUtf8("seg__content"));
        QFont font;
        font.setFamily(QString::fromUtf8("FreeMono"));
        font.setBold(true);
        font.setItalic(false);
        font.setWeight(75);
        seg__content->setFont(font);
        seg__content->setReadOnly(true);

        horizontalLayout_17->addWidget(seg__content);

        widget_12 = new QWidget(tab_main__segments);
        widget_12->setObjectName(QString::fromUtf8("widget_12"));
        verticalLayout_16 = new QVBoxLayout(widget_12);
        verticalLayout_16->setSpacing(6);
        verticalLayout_16->setContentsMargins(0, 0, 0, 0);
        verticalLayout_16->setObjectName(QString::fromUtf8("verticalLayout_16"));
        seg__scrollbar_up = new QPushButton(widget_12);
        seg__scrollbar_up->setObjectName(QString::fromUtf8("seg__scrollbar_up"));
        seg__scrollbar_up->setMaximumSize(QSize(20, 16777215));
        seg__scrollbar_up->setAutoRepeat(true);

        verticalLayout_16->addWidget(seg__scrollbar_up);

        seg__scrollbar_content = new QSlider(widget_12);
        seg__scrollbar_content->setObjectName(QString::fromUtf8("seg__scrollbar_content"));
        seg__scrollbar_content->setMaximum(0);
        seg__scrollbar_content->setOrientation(Qt::Vertical);
        seg__scrollbar_content->setInvertedAppearance(true);

        verticalLayout_16->addWidget(seg__scrollbar_content);

        seg__scrollbar_down = new QPushButton(widget_12);
        seg__scrollbar_down->setObjectName(QString::fromUtf8("seg__scrollbar_down"));
        seg__scrollbar_down->setMaximumSize(QSize(20, 16777215));
        seg__scrollbar_down->setAutoRepeat(true);

        verticalLayout_16->addWidget(seg__scrollbar_down);


        horizontalLayout_17->addWidget(widget_12);

        tab__main->addTab(tab_main__segments, QString());
        tab_3main__symboles = new QWidget();
        tab_3main__symboles->setObjectName(QString::fromUtf8("tab_3main__symboles"));
        verticalLayout_13 = new QVBoxLayout(tab_3main__symboles);
        verticalLayout_13->setSpacing(6);
        verticalLayout_13->setContentsMargins(11, 11, 11, 11);
        verticalLayout_13->setObjectName(QString::fromUtf8("verticalLayout_13"));
        label_2 = new QLabel(tab_3main__symboles);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        verticalLayout_13->addWidget(label_2);

        sym__liste_symboles = new QTableWidget(tab_3main__symboles);
        if (sym__liste_symboles->columnCount() < 3)
            sym__liste_symboles->setColumnCount(3);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        sym__liste_symboles->setHorizontalHeaderItem(0, __qtablewidgetitem3);
        QTableWidgetItem *__qtablewidgetitem4 = new QTableWidgetItem();
        sym__liste_symboles->setHorizontalHeaderItem(1, __qtablewidgetitem4);
        QTableWidgetItem *__qtablewidgetitem5 = new QTableWidgetItem();
        sym__liste_symboles->setHorizontalHeaderItem(2, __qtablewidgetitem5);
        sym__liste_symboles->setObjectName(QString::fromUtf8("sym__liste_symboles"));
        sym__liste_symboles->setEditTriggers(QAbstractItemView::NoEditTriggers);
        sym__liste_symboles->setSortingEnabled(true);
        sym__liste_symboles->horizontalHeader()->setCascadingSectionResizes(false);
        sym__liste_symboles->horizontalHeader()->setStretchLastSection(true);

        verticalLayout_13->addWidget(sym__liste_symboles);

        widget_14 = new QWidget(tab_3main__symboles);
        widget_14->setObjectName(QString::fromUtf8("widget_14"));
        horizontalLayout_15 = new QHBoxLayout(widget_14);
        horizontalLayout_15->setSpacing(6);
        horizontalLayout_15->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_15->setObjectName(QString::fromUtf8("horizontalLayout_15"));
        horizontalLayout_15->setContentsMargins(0, -1, 0, 0);
        sym__bt_new = new QPushButton(widget_14);
        sym__bt_new->setObjectName(QString::fromUtf8("sym__bt_new"));

        horizontalLayout_15->addWidget(sym__bt_new);

        sym__bt_edit = new QPushButton(widget_14);
        sym__bt_edit->setObjectName(QString::fromUtf8("sym__bt_edit"));

        horizontalLayout_15->addWidget(sym__bt_edit);

        horizontalSpacer_10 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_15->addItem(horizontalSpacer_10);

        sym__bt_delete = new QPushButton(widget_14);
        sym__bt_delete->setObjectName(QString::fromUtf8("sym__bt_delete"));

        horizontalLayout_15->addWidget(sym__bt_delete);


        verticalLayout_13->addWidget(widget_14);

        tab__main->addTab(tab_3main__symboles, QString());
        tab_main__definitions = new QWidget();
        tab_main__definitions->setObjectName(QString::fromUtf8("tab_main__definitions"));
        verticalLayout_12 = new QVBoxLayout(tab_main__definitions);
        verticalLayout_12->setSpacing(6);
        verticalLayout_12->setContentsMargins(11, 11, 11, 11);
        verticalLayout_12->setObjectName(QString::fromUtf8("verticalLayout_12"));
        label_3 = new QLabel(tab_main__definitions);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        verticalLayout_12->addWidget(label_3);

        type__treeview = new QTreeWidget(tab_main__definitions);
        QTreeWidgetItem *__qtreewidgetitem = new QTreeWidgetItem();
        __qtreewidgetitem->setText(0, QString::fromUtf8("1"));
        type__treeview->setHeaderItem(__qtreewidgetitem);
        type__treeview->setObjectName(QString::fromUtf8("type__treeview"));
        type__treeview->setSortingEnabled(false);
        type__treeview->setAnimated(true);

        verticalLayout_12->addWidget(type__treeview);

        widget_13 = new QWidget(tab_main__definitions);
        widget_13->setObjectName(QString::fromUtf8("widget_13"));
        horizontalLayout_14 = new QHBoxLayout(widget_13);
        horizontalLayout_14->setSpacing(6);
        horizontalLayout_14->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_14->setObjectName(QString::fromUtf8("horizontalLayout_14"));
        horizontalLayout_14->setContentsMargins(0, -1, 0, 0);
        type__bt_new = new QPushButton(widget_13);
        type__bt_new->setObjectName(QString::fromUtf8("type__bt_new"));

        horizontalLayout_14->addWidget(type__bt_new);

        type__bt_edit = new QPushButton(widget_13);
        type__bt_edit->setObjectName(QString::fromUtf8("type__bt_edit"));

        horizontalLayout_14->addWidget(type__bt_edit);

        horizontalSpacer_9 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_14->addItem(horizontalSpacer_9);

        type__bt_delete = new QPushButton(widget_13);
        type__bt_delete->setObjectName(QString::fromUtf8("type__bt_delete"));

        horizontalLayout_14->addWidget(type__bt_delete);


        verticalLayout_12->addWidget(widget_13);

        tab__main->addTab(tab_main__definitions, QString());
        tab_main__prototypes = new QWidget();
        tab_main__prototypes->setObjectName(QString::fromUtf8("tab_main__prototypes"));
        verticalLayout_6 = new QVBoxLayout(tab_main__prototypes);
        verticalLayout_6->setSpacing(6);
        verticalLayout_6->setContentsMargins(11, 11, 11, 11);
        verticalLayout_6->setObjectName(QString::fromUtf8("verticalLayout_6"));
        tabWidget = new QTabWidget(tab_main__prototypes);
        tabWidget->setObjectName(QString::fromUtf8("tabWidget"));
        tab_3 = new QWidget();
        tab_3->setObjectName(QString::fromUtf8("tab_3"));
        verticalLayout_10 = new QVBoxLayout(tab_3);
        verticalLayout_10->setSpacing(6);
        verticalLayout_10->setContentsMargins(11, 11, 11, 11);
        verticalLayout_10->setObjectName(QString::fromUtf8("verticalLayout_10"));
        proto_func__liste_prototypes = new QTableWidget(tab_3);
        if (proto_func__liste_prototypes->columnCount() < 3)
            proto_func__liste_prototypes->setColumnCount(3);
        QTableWidgetItem *__qtablewidgetitem6 = new QTableWidgetItem();
        proto_func__liste_prototypes->setHorizontalHeaderItem(0, __qtablewidgetitem6);
        QTableWidgetItem *__qtablewidgetitem7 = new QTableWidgetItem();
        proto_func__liste_prototypes->setHorizontalHeaderItem(1, __qtablewidgetitem7);
        QTableWidgetItem *__qtablewidgetitem8 = new QTableWidgetItem();
        proto_func__liste_prototypes->setHorizontalHeaderItem(2, __qtablewidgetitem8);
        proto_func__liste_prototypes->setObjectName(QString::fromUtf8("proto_func__liste_prototypes"));
        proto_func__liste_prototypes->setEditTriggers(QAbstractItemView::NoEditTriggers);
        proto_func__liste_prototypes->setSortingEnabled(true);
        proto_func__liste_prototypes->horizontalHeader()->setVisible(false);
        proto_func__liste_prototypes->horizontalHeader()->setCascadingSectionResizes(false);
        proto_func__liste_prototypes->horizontalHeader()->setDefaultSectionSize(150);
        proto_func__liste_prototypes->horizontalHeader()->setStretchLastSection(true);
        proto_func__liste_prototypes->verticalHeader()->setCascadingSectionResizes(false);

        verticalLayout_10->addWidget(proto_func__liste_prototypes);

        widget_6 = new QWidget(tab_3);
        widget_6->setObjectName(QString::fromUtf8("widget_6"));
        horizontalLayout_7 = new QHBoxLayout(widget_6);
        horizontalLayout_7->setSpacing(6);
        horizontalLayout_7->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_7->setObjectName(QString::fromUtf8("horizontalLayout_7"));
        horizontalLayout_7->setContentsMargins(0, -1, 0, 0);
        proto_func__bt_new = new QPushButton(widget_6);
        proto_func__bt_new->setObjectName(QString::fromUtf8("proto_func__bt_new"));

        horizontalLayout_7->addWidget(proto_func__bt_new);

        proto_func__bt_edit = new QPushButton(widget_6);
        proto_func__bt_edit->setObjectName(QString::fromUtf8("proto_func__bt_edit"));

        horizontalLayout_7->addWidget(proto_func__bt_edit);

        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_7->addItem(horizontalSpacer_4);

        proto_func__bt_delete = new QPushButton(widget_6);
        proto_func__bt_delete->setObjectName(QString::fromUtf8("proto_func__bt_delete"));

        horizontalLayout_7->addWidget(proto_func__bt_delete);


        verticalLayout_10->addWidget(widget_6);

        tabWidget->addTab(tab_3, QString());
        tab_5 = new QWidget();
        tab_5->setObjectName(QString::fromUtf8("tab_5"));
        verticalLayout_11 = new QVBoxLayout(tab_5);
        verticalLayout_11->setSpacing(6);
        verticalLayout_11->setContentsMargins(11, 11, 11, 11);
        verticalLayout_11->setObjectName(QString::fromUtf8("verticalLayout_11"));
        proto_inter__liste_prototypes = new QTableWidget(tab_5);
        if (proto_inter__liste_prototypes->columnCount() < 4)
            proto_inter__liste_prototypes->setColumnCount(4);
        QTableWidgetItem *__qtablewidgetitem9 = new QTableWidgetItem();
        proto_inter__liste_prototypes->setHorizontalHeaderItem(0, __qtablewidgetitem9);
        QTableWidgetItem *__qtablewidgetitem10 = new QTableWidgetItem();
        proto_inter__liste_prototypes->setHorizontalHeaderItem(1, __qtablewidgetitem10);
        QTableWidgetItem *__qtablewidgetitem11 = new QTableWidgetItem();
        proto_inter__liste_prototypes->setHorizontalHeaderItem(2, __qtablewidgetitem11);
        QTableWidgetItem *__qtablewidgetitem12 = new QTableWidgetItem();
        proto_inter__liste_prototypes->setHorizontalHeaderItem(3, __qtablewidgetitem12);
        proto_inter__liste_prototypes->setObjectName(QString::fromUtf8("proto_inter__liste_prototypes"));
        proto_inter__liste_prototypes->setEditTriggers(QAbstractItemView::NoEditTriggers);
        proto_inter__liste_prototypes->setSortingEnabled(true);
        proto_inter__liste_prototypes->horizontalHeader()->setVisible(false);
        proto_inter__liste_prototypes->horizontalHeader()->setCascadingSectionResizes(false);
        proto_inter__liste_prototypes->horizontalHeader()->setDefaultSectionSize(150);
        proto_inter__liste_prototypes->horizontalHeader()->setStretchLastSection(true);
        proto_inter__liste_prototypes->verticalHeader()->setVisible(false);
        proto_inter__liste_prototypes->verticalHeader()->setCascadingSectionResizes(false);

        verticalLayout_11->addWidget(proto_inter__liste_prototypes);

        widget_10 = new QWidget(tab_5);
        widget_10->setObjectName(QString::fromUtf8("widget_10"));
        horizontalLayout_11 = new QHBoxLayout(widget_10);
        horizontalLayout_11->setSpacing(6);
        horizontalLayout_11->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_11->setObjectName(QString::fromUtf8("horizontalLayout_11"));
        horizontalLayout_11->setContentsMargins(0, -1, 0, 0);
        proto_inter__bt_new = new QPushButton(widget_10);
        proto_inter__bt_new->setObjectName(QString::fromUtf8("proto_inter__bt_new"));

        horizontalLayout_11->addWidget(proto_inter__bt_new);

        proto_inter__bt_edit = new QPushButton(widget_10);
        proto_inter__bt_edit->setObjectName(QString::fromUtf8("proto_inter__bt_edit"));

        horizontalLayout_11->addWidget(proto_inter__bt_edit);

        horizontalSpacer_8 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_11->addItem(horizontalSpacer_8);

        proto_inter__bt_delete = new QPushButton(widget_10);
        proto_inter__bt_delete->setObjectName(QString::fromUtf8("proto_inter__bt_delete"));

        horizontalLayout_11->addWidget(proto_inter__bt_delete);


        verticalLayout_11->addWidget(widget_10);

        tabWidget->addTab(tab_5, QString());
        tab_4 = new QWidget();
        tab_4->setObjectName(QString::fromUtf8("tab_4"));
        verticalLayout_15 = new QVBoxLayout(tab_4);
        verticalLayout_15->setSpacing(6);
        verticalLayout_15->setContentsMargins(11, 11, 11, 11);
        verticalLayout_15->setObjectName(QString::fromUtf8("verticalLayout_15"));
        proto_syscall__liste_prototypes = new QTableWidget(tab_4);
        if (proto_syscall__liste_prototypes->columnCount() < 4)
            proto_syscall__liste_prototypes->setColumnCount(4);
        QTableWidgetItem *__qtablewidgetitem13 = new QTableWidgetItem();
        proto_syscall__liste_prototypes->setHorizontalHeaderItem(0, __qtablewidgetitem13);
        QTableWidgetItem *__qtablewidgetitem14 = new QTableWidgetItem();
        proto_syscall__liste_prototypes->setHorizontalHeaderItem(1, __qtablewidgetitem14);
        QTableWidgetItem *__qtablewidgetitem15 = new QTableWidgetItem();
        proto_syscall__liste_prototypes->setHorizontalHeaderItem(2, __qtablewidgetitem15);
        QTableWidgetItem *__qtablewidgetitem16 = new QTableWidgetItem();
        proto_syscall__liste_prototypes->setHorizontalHeaderItem(3, __qtablewidgetitem16);
        proto_syscall__liste_prototypes->setObjectName(QString::fromUtf8("proto_syscall__liste_prototypes"));
        proto_syscall__liste_prototypes->setEditTriggers(QAbstractItemView::NoEditTriggers);
        proto_syscall__liste_prototypes->setSortingEnabled(true);
        proto_syscall__liste_prototypes->horizontalHeader()->setVisible(false);
        proto_syscall__liste_prototypes->horizontalHeader()->setCascadingSectionResizes(false);
        proto_syscall__liste_prototypes->horizontalHeader()->setDefaultSectionSize(150);
        proto_syscall__liste_prototypes->horizontalHeader()->setMinimumSectionSize(20);
        proto_syscall__liste_prototypes->horizontalHeader()->setStretchLastSection(true);
        proto_syscall__liste_prototypes->verticalHeader()->setVisible(false);
        proto_syscall__liste_prototypes->verticalHeader()->setCascadingSectionResizes(false);

        verticalLayout_15->addWidget(proto_syscall__liste_prototypes);

        widget_11 = new QWidget(tab_4);
        widget_11->setObjectName(QString::fromUtf8("widget_11"));
        horizontalLayout_12 = new QHBoxLayout(widget_11);
        horizontalLayout_12->setSpacing(6);
        horizontalLayout_12->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_12->setObjectName(QString::fromUtf8("horizontalLayout_12"));
        horizontalLayout_12->setContentsMargins(0, -1, 0, 0);
        proto_syscall__bt_new = new QPushButton(widget_11);
        proto_syscall__bt_new->setObjectName(QString::fromUtf8("proto_syscall__bt_new"));

        horizontalLayout_12->addWidget(proto_syscall__bt_new);

        proto_syscall__bt_edit = new QPushButton(widget_11);
        proto_syscall__bt_edit->setObjectName(QString::fromUtf8("proto_syscall__bt_edit"));

        horizontalLayout_12->addWidget(proto_syscall__bt_edit);

        horizontalSpacer_14 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_12->addItem(horizontalSpacer_14);

        proto_syscall__bt_delete = new QPushButton(widget_11);
        proto_syscall__bt_delete->setObjectName(QString::fromUtf8("proto_syscall__bt_delete"));

        horizontalLayout_12->addWidget(proto_syscall__bt_delete);


        verticalLayout_15->addWidget(widget_11);

        tabWidget->addTab(tab_4, QString());

        verticalLayout_6->addWidget(tabWidget);

        tab__main->addTab(tab_main__prototypes, QString());
        tab_main__fonctions = new QWidget();
        tab_main__fonctions->setObjectName(QString::fromUtf8("tab_main__fonctions"));
        horizontalLayout_3 = new QHBoxLayout(tab_main__fonctions);
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        widget_2 = new QWidget(tab_main__fonctions);
        widget_2->setObjectName(QString::fromUtf8("widget_2"));
        widget_2->setMaximumSize(QSize(600, 16777215));
        verticalLayout_2 = new QVBoxLayout(widget_2);
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        label_5 = new QLabel(widget_2);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        verticalLayout_2->addWidget(label_5);

        func__liste_entry = new QTableWidget(widget_2);
        if (func__liste_entry->columnCount() < 2)
            func__liste_entry->setColumnCount(2);
        QTableWidgetItem *__qtablewidgetitem17 = new QTableWidgetItem();
        func__liste_entry->setHorizontalHeaderItem(0, __qtablewidgetitem17);
        QTableWidgetItem *__qtablewidgetitem18 = new QTableWidgetItem();
        func__liste_entry->setHorizontalHeaderItem(1, __qtablewidgetitem18);
        func__liste_entry->setObjectName(QString::fromUtf8("func__liste_entry"));
        func__liste_entry->setEditTriggers(QAbstractItemView::AnyKeyPressed|QAbstractItemView::DoubleClicked|QAbstractItemView::EditKeyPressed);
        func__liste_entry->setSortingEnabled(true);
        func__liste_entry->horizontalHeader()->setStretchLastSection(true);

        verticalLayout_2->addWidget(func__liste_entry);

        widget1 = new QWidget(widget_2);
        widget1->setObjectName(QString::fromUtf8("widget1"));
        horizontalLayout_2 = new QHBoxLayout(widget1);
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        func__bt_new = new QPushButton(widget1);
        func__bt_new->setObjectName(QString::fromUtf8("func__bt_new"));

        horizontalLayout_2->addWidget(func__bt_new);

        func__bt_delete = new QPushButton(widget1);
        func__bt_delete->setObjectName(QString::fromUtf8("func__bt_delete"));

        horizontalLayout_2->addWidget(func__bt_delete);


        verticalLayout_2->addWidget(widget1);


        horizontalLayout_3->addWidget(widget_2);

        tab_fonction = new QTabWidget(tab_main__fonctions);
        tab_fonction->setObjectName(QString::fromUtf8("tab_fonction"));
        tab_fonction__tab_valeurs = new QWidget();
        tab_fonction__tab_valeurs->setObjectName(QString::fromUtf8("tab_fonction__tab_valeurs"));
        verticalLayout_3 = new QVBoxLayout(tab_fonction__tab_valeurs);
        verticalLayout_3->setSpacing(6);
        verticalLayout_3->setContentsMargins(11, 11, 11, 11);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        label_6 = new QLabel(tab_fonction__tab_valeurs);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        verticalLayout_3->addWidget(label_6);

        func_value__liste_values = new QTableWidget(tab_fonction__tab_valeurs);
        if (func_value__liste_values->columnCount() < 5)
            func_value__liste_values->setColumnCount(5);
        QTableWidgetItem *__qtablewidgetitem19 = new QTableWidgetItem();
        func_value__liste_values->setHorizontalHeaderItem(0, __qtablewidgetitem19);
        QTableWidgetItem *__qtablewidgetitem20 = new QTableWidgetItem();
        func_value__liste_values->setHorizontalHeaderItem(1, __qtablewidgetitem20);
        QTableWidgetItem *__qtablewidgetitem21 = new QTableWidgetItem();
        func_value__liste_values->setHorizontalHeaderItem(2, __qtablewidgetitem21);
        QTableWidgetItem *__qtablewidgetitem22 = new QTableWidgetItem();
        func_value__liste_values->setHorizontalHeaderItem(3, __qtablewidgetitem22);
        QTableWidgetItem *__qtablewidgetitem23 = new QTableWidgetItem();
        func_value__liste_values->setHorizontalHeaderItem(4, __qtablewidgetitem23);
        func_value__liste_values->setObjectName(QString::fromUtf8("func_value__liste_values"));
        func_value__liste_values->setSortingEnabled(true);
        func_value__liste_values->horizontalHeader()->setStretchLastSection(true);

        verticalLayout_3->addWidget(func_value__liste_values);

        widget_18 = new QWidget(tab_fonction__tab_valeurs);
        widget_18->setObjectName(QString::fromUtf8("widget_18"));
        horizontalLayout_18 = new QHBoxLayout(widget_18);
        horizontalLayout_18->setSpacing(6);
        horizontalLayout_18->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_18->setObjectName(QString::fromUtf8("horizontalLayout_18"));
        label_4 = new QLabel(widget_18);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        horizontalLayout_18->addWidget(label_4);

        func_value__ret = new QLineEdit(widget_18);
        func_value__ret->setObjectName(QString::fromUtf8("func_value__ret"));

        horizontalLayout_18->addWidget(func_value__ret);


        verticalLayout_3->addWidget(widget_18);

        widget_5 = new QWidget(tab_fonction__tab_valeurs);
        widget_5->setObjectName(QString::fromUtf8("widget_5"));
        horizontalLayout_6 = new QHBoxLayout(widget_5);
        horizontalLayout_6->setSpacing(6);
        horizontalLayout_6->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        func_value__bt_new = new QPushButton(widget_5);
        func_value__bt_new->setObjectName(QString::fromUtf8("func_value__bt_new"));

        horizontalLayout_6->addWidget(func_value__bt_new);

        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_6->addItem(horizontalSpacer_3);

        func_value__bt_delete = new QPushButton(widget_5);
        func_value__bt_delete->setObjectName(QString::fromUtf8("func_value__bt_delete"));

        horizontalLayout_6->addWidget(func_value__bt_delete);


        verticalLayout_3->addWidget(widget_5);

        tab_fonction->addTab(tab_fonction__tab_valeurs, QString());
        tab = new QWidget();
        tab->setObjectName(QString::fromUtf8("tab"));
        verticalLayout_7 = new QVBoxLayout(tab);
        verticalLayout_7->setSpacing(6);
        verticalLayout_7->setContentsMargins(11, 11, 11, 11);
        verticalLayout_7->setObjectName(QString::fromUtf8("verticalLayout_7"));
        func_param__liste_param = new QTableWidget(tab);
        if (func_param__liste_param->columnCount() < 1)
            func_param__liste_param->setColumnCount(1);
        QTableWidgetItem *__qtablewidgetitem24 = new QTableWidgetItem();
        func_param__liste_param->setHorizontalHeaderItem(0, __qtablewidgetitem24);
        func_param__liste_param->setObjectName(QString::fromUtf8("func_param__liste_param"));
        func_param__liste_param->horizontalHeader()->setStretchLastSection(true);

        verticalLayout_7->addWidget(func_param__liste_param);

        widget2 = new QWidget(tab);
        widget2->setObjectName(QString::fromUtf8("widget2"));
        horizontalLayout_8 = new QHBoxLayout(widget2);
        horizontalLayout_8->setSpacing(6);
        horizontalLayout_8->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_8->setObjectName(QString::fromUtf8("horizontalLayout_8"));
        func_param__bt_new = new QPushButton(widget2);
        func_param__bt_new->setObjectName(QString::fromUtf8("func_param__bt_new"));

        horizontalLayout_8->addWidget(func_param__bt_new);

        horizontalSpacer_6 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_8->addItem(horizontalSpacer_6);

        func_param__bt_delete = new QPushButton(widget2);
        func_param__bt_delete->setObjectName(QString::fromUtf8("func_param__bt_delete"));

        horizontalLayout_8->addWidget(func_param__bt_delete);


        verticalLayout_7->addWidget(widget2);

        tab_fonction->addTab(tab, QString());
        tab_fonction__tab_asm = new QWidget();
        tab_fonction__tab_asm->setObjectName(QString::fromUtf8("tab_fonction__tab_asm"));
        verticalLayout_4 = new QVBoxLayout(tab_fonction__tab_asm);
        verticalLayout_4->setSpacing(6);
        verticalLayout_4->setContentsMargins(11, 11, 11, 11);
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        label_7 = new QLabel(tab_fonction__tab_asm);
        label_7->setObjectName(QString::fromUtf8("label_7"));

        verticalLayout_4->addWidget(label_7);

        func_asm__arbre = new ViewerFunctionGraph(tab_fonction__tab_asm);
        func_asm__arbre->setObjectName(QString::fromUtf8("func_asm__arbre"));

        verticalLayout_4->addWidget(func_asm__arbre);

        widget_4 = new QWidget(tab_fonction__tab_asm);
        widget_4->setObjectName(QString::fromUtf8("widget_4"));
        horizontalLayout_5 = new QHBoxLayout(widget_4);
        horizontalLayout_5->setSpacing(6);
        horizontalLayout_5->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        func_asm__bt_deassemble = new QPushButton(widget_4);
        func_asm__bt_deassemble->setObjectName(QString::fromUtf8("func_asm__bt_deassemble"));

        horizontalLayout_5->addWidget(func_asm__bt_deassemble);

        func_asm__bt_clean = new QPushButton(widget_4);
        func_asm__bt_clean->setObjectName(QString::fromUtf8("func_asm__bt_clean"));

        horizontalLayout_5->addWidget(func_asm__bt_clean);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_5->addItem(horizontalSpacer_2);

        func_asm__check_deasm__addr = new QCheckBox(widget_4);
        func_asm__check_deasm__addr->setObjectName(QString::fromUtf8("func_asm__check_deasm__addr"));
        func_asm__check_deasm__addr->setChecked(true);

        horizontalLayout_5->addWidget(func_asm__check_deasm__addr);

        func_asm__check_deasm__opcode = new QCheckBox(widget_4);
        func_asm__check_deasm__opcode->setObjectName(QString::fromUtf8("func_asm__check_deasm__opcode"));
        func_asm__check_deasm__opcode->setChecked(true);

        horizontalLayout_5->addWidget(func_asm__check_deasm__opcode);

        func_asm__check_deasm__instr = new QCheckBox(widget_4);
        func_asm__check_deasm__instr->setObjectName(QString::fromUtf8("func_asm__check_deasm__instr"));
        func_asm__check_deasm__instr->setChecked(true);

        horizontalLayout_5->addWidget(func_asm__check_deasm__instr);

        horizontalSpacer_5 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_5->addItem(horizontalSpacer_5);

        func_asm__bt_save = new QPushButton(widget_4);
        func_asm__bt_save->setObjectName(QString::fromUtf8("func_asm__bt_save"));

        horizontalLayout_5->addWidget(func_asm__bt_save);


        verticalLayout_4->addWidget(widget_4);

        tab_fonction->addTab(tab_fonction__tab_asm, QString());
        tab_6 = new QWidget();
        tab_6->setObjectName(QString::fromUtf8("tab_6"));
        verticalLayout_5 = new QVBoxLayout(tab_6);
        verticalLayout_5->setSpacing(6);
        verticalLayout_5->setContentsMargins(11, 11, 11, 11);
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        label_8 = new QLabel(tab_6);
        label_8->setObjectName(QString::fromUtf8("label_8"));

        verticalLayout_5->addWidget(label_8);

        func_c__text = new QTextEdit(tab_6);
        func_c__text->setObjectName(QString::fromUtf8("func_c__text"));

        verticalLayout_5->addWidget(func_c__text);

        widget_3 = new QWidget(tab_6);
        widget_3->setObjectName(QString::fromUtf8("widget_3"));
        horizontalLayout_4 = new QHBoxLayout(widget_3);
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        func_c__bt_decompile = new QPushButton(widget_3);
        func_c__bt_decompile->setObjectName(QString::fromUtf8("func_c__bt_decompile"));

        horizontalLayout_4->addWidget(func_c__bt_decompile);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer);

        func_c__bt_save = new QPushButton(widget_3);
        func_c__bt_save->setObjectName(QString::fromUtf8("func_c__bt_save"));

        horizontalLayout_4->addWidget(func_c__bt_save);


        verticalLayout_5->addWidget(widget_3);

        tab_fonction->addTab(tab_6, QString());

        horizontalLayout_3->addWidget(tab_fonction);

        tab__main->addTab(tab_main__fonctions, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QString::fromUtf8("tab_2"));
        horizontalLayout_10 = new QHBoxLayout(tab_2);
        horizontalLayout_10->setSpacing(6);
        horizontalLayout_10->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_10->setObjectName(QString::fromUtf8("horizontalLayout_10"));
        widget_9 = new QWidget(tab_2);
        widget_9->setObjectName(QString::fromUtf8("widget_9"));
        widget_9->setMinimumSize(QSize(300, 0));
        widget_9->setMaximumSize(QSize(500, 16777215));
        verticalLayout_9 = new QVBoxLayout(widget_9);
        verticalLayout_9->setSpacing(1);
        verticalLayout_9->setContentsMargins(1, 1, 1, 1);
        verticalLayout_9->setObjectName(QString::fromUtf8("verticalLayout_9"));
        label_9 = new QLabel(widget_9);
        label_9->setObjectName(QString::fromUtf8("label_9"));

        verticalLayout_9->addWidget(label_9);

        callgraph__list_entry = new QTableWidget(widget_9);
        if (callgraph__list_entry->columnCount() < 2)
            callgraph__list_entry->setColumnCount(2);
        QTableWidgetItem *__qtablewidgetitem25 = new QTableWidgetItem();
        callgraph__list_entry->setHorizontalHeaderItem(0, __qtablewidgetitem25);
        QTableWidgetItem *__qtablewidgetitem26 = new QTableWidgetItem();
        callgraph__list_entry->setHorizontalHeaderItem(1, __qtablewidgetitem26);
        callgraph__list_entry->setObjectName(QString::fromUtf8("callgraph__list_entry"));
        callgraph__list_entry->setEditTriggers(QAbstractItemView::NoEditTriggers);
        callgraph__list_entry->horizontalHeader()->setStretchLastSection(true);

        verticalLayout_9->addWidget(callgraph__list_entry);


        horizontalLayout_10->addWidget(widget_9);

        widget_7 = new QWidget(tab_2);
        widget_7->setObjectName(QString::fromUtf8("widget_7"));
        verticalLayout_8 = new QVBoxLayout(widget_7);
        verticalLayout_8->setSpacing(1);
        verticalLayout_8->setContentsMargins(1, 1, 1, 1);
        verticalLayout_8->setObjectName(QString::fromUtf8("verticalLayout_8"));
        callgraph__view = new ViewerCallGraph(widget_7);
        callgraph__view->setObjectName(QString::fromUtf8("callgraph__view"));

        verticalLayout_8->addWidget(callgraph__view);

        widget_8 = new QWidget(widget_7);
        widget_8->setObjectName(QString::fromUtf8("widget_8"));
        horizontalLayout_9 = new QHBoxLayout(widget_8);
        horizontalLayout_9->setSpacing(6);
        horizontalLayout_9->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_9->setObjectName(QString::fromUtf8("horizontalLayout_9"));
        horizontalLayout_9->setContentsMargins(0, 9, 0, 0);
        callgraph__bt_generate = new QPushButton(widget_8);
        callgraph__bt_generate->setObjectName(QString::fromUtf8("callgraph__bt_generate"));

        horizontalLayout_9->addWidget(callgraph__bt_generate);

        horizontalSpacer_7 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_9->addItem(horizontalSpacer_7);

        label_10 = new QLabel(widget_8);
        label_10->setObjectName(QString::fromUtf8("label_10"));

        horizontalLayout_9->addWidget(label_10);

        callgraph__nbs_rec = new QSpinBox(widget_8);
        callgraph__nbs_rec->setObjectName(QString::fromUtf8("callgraph__nbs_rec"));
        callgraph__nbs_rec->setValue(10);

        horizontalLayout_9->addWidget(callgraph__nbs_rec);

        horizontalSpacer_13 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_9->addItem(horizontalSpacer_13);

        callgraph__bt_save = new QPushButton(widget_8);
        callgraph__bt_save->setObjectName(QString::fromUtf8("callgraph__bt_save"));

        horizontalLayout_9->addWidget(callgraph__bt_save);


        verticalLayout_8->addWidget(widget_8);


        horizontalLayout_10->addWidget(widget_7);

        tab__main->addTab(tab_2, QString());
        tab_7 = new QWidget();
        tab_7->setObjectName(QString::fromUtf8("tab_7"));
        verticalLayout_17 = new QVBoxLayout(tab_7);
        verticalLayout_17->setSpacing(6);
        verticalLayout_17->setContentsMargins(11, 11, 11, 11);
        verticalLayout_17->setObjectName(QString::fromUtf8("verticalLayout_17"));
        anal__tree_analyse = new QTreeWidget(tab_7);
        anal__tree_analyse->setObjectName(QString::fromUtf8("anal__tree_analyse"));

        verticalLayout_17->addWidget(anal__tree_analyse);

        widget_17 = new QWidget(tab_7);
        widget_17->setObjectName(QString::fromUtf8("widget_17"));
        horizontalLayout_13 = new QHBoxLayout(widget_17);
        horizontalLayout_13->setSpacing(6);
        horizontalLayout_13->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_13->setObjectName(QString::fromUtf8("horizontalLayout_13"));
        horizontalLayout_13->setContentsMargins(0, -1, 0, 0);
        anal__bt_save_all = new QPushButton(widget_17);
        anal__bt_save_all->setObjectName(QString::fromUtf8("anal__bt_save_all"));

        horizontalLayout_13->addWidget(anal__bt_save_all);

        anal__bt_save = new QPushButton(widget_17);
        anal__bt_save->setObjectName(QString::fromUtf8("anal__bt_save"));

        horizontalLayout_13->addWidget(anal__bt_save);

        horizontalSpacer_15 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_13->addItem(horizontalSpacer_15);

        anal__bt_delete = new QPushButton(widget_17);
        anal__bt_delete->setObjectName(QString::fromUtf8("anal__bt_delete"));

        horizontalLayout_13->addWidget(anal__bt_delete);

        anal__bt_delete_all = new QPushButton(widget_17);
        anal__bt_delete_all->setObjectName(QString::fromUtf8("anal__bt_delete_all"));

        horizontalLayout_13->addWidget(anal__bt_delete_all);


        verticalLayout_17->addWidget(widget_17);

        tab__main->addTab(tab_7, QString());

        verticalLayout->addWidget(tab__main);

        MainWindow->setCentralWidget(centralWidget);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);
        QObject::connect(bt__open, SIGNAL(clicked()), MainWindow, SLOT(slot_bt_open()));
        QObject::connect(bt__parsing, SIGNAL(clicked()), MainWindow, SLOT(slot_bt_parsing()));
        QObject::connect(bt__definition, SIGNAL(clicked()), MainWindow, SLOT(slot_bt_definition()));
        QObject::connect(bt__deassemble, SIGNAL(clicked()), MainWindow, SLOT(slot_bt_deassemble()));
        QObject::connect(bt__clean, SIGNAL(clicked()), MainWindow, SLOT(slot_bt_clean()));
        QObject::connect(bt__decompile, SIGNAL(clicked()), MainWindow, SLOT(slot_bt_decompile()));
        QObject::connect(seg__bt_new, SIGNAL(clicked()), MainWindow, SLOT(slot_seg__bt_new()));
        QObject::connect(seg__bt_edit, SIGNAL(clicked()), MainWindow, SLOT(slot_seg__bt_edit()));
        QObject::connect(seg__bt_delete, SIGNAL(clicked()), MainWindow, SLOT(slot_seg__bt_delete()));
        QObject::connect(seg__liste_segments, SIGNAL(itemSelectionChanged()), MainWindow, SLOT(slot_seg__list_segment__clicked()));
        QObject::connect(func_asm__bt_deassemble, SIGNAL(clicked()), MainWindow, SLOT(slot_func_asm__bt_deassemble()));
        QObject::connect(sym__bt_new, SIGNAL(clicked()), MainWindow, SLOT(slot_sym__bt_new()));
        QObject::connect(sym__bt_delete, SIGNAL(clicked()), MainWindow, SLOT(slot_sym__bt_delete()));
        QObject::connect(func__bt_delete, SIGNAL(clicked()), MainWindow, SLOT(slot_func__bt_delete()));
        QObject::connect(func__bt_new, SIGNAL(clicked()), MainWindow, SLOT(slot_func__bt_new()));
        QObject::connect(func__liste_entry, SIGNAL(cellChanged(int,int)), MainWindow, SLOT(slot_func__liste_entry__edit()));
        QObject::connect(func_value__bt_new, SIGNAL(clicked()), MainWindow, SLOT(slot_func_value__bt_new()));
        QObject::connect(func_value__bt_delete, SIGNAL(clicked()), MainWindow, SLOT(slot_func_value__bt_delete()));
        QObject::connect(func_value__liste_values, SIGNAL(cellChanged(int,int)), MainWindow, SLOT(slot_func_value__list_value__edit()));
        QObject::connect(func_asm__bt_clean, SIGNAL(clicked()), MainWindow, SLOT(slot_func_asm__bt_clean()));
        QObject::connect(func_asm__bt_save, SIGNAL(clicked()), MainWindow, SLOT(slot_func_asm__bt_save()));
        QObject::connect(func_c__bt_decompile, SIGNAL(clicked()), MainWindow, SLOT(slot_func_c__bt_decompile()));
        QObject::connect(func_c__bt_save, SIGNAL(clicked()), MainWindow, SLOT(slot_func_c__bt_save()));
        QObject::connect(func_asm__check_deasm__addr, SIGNAL(clicked()), MainWindow, SLOT(slot_func_asm__arbre__option_changed()));
        QObject::connect(func_asm__check_deasm__opcode, SIGNAL(clicked()), MainWindow, SLOT(slot_func_asm__arbre__option_changed()));
        QObject::connect(func_asm__check_deasm__instr, SIGNAL(clicked()), MainWindow, SLOT(slot_func_asm__arbre__option_changed()));
        QObject::connect(callgraph__list_entry, SIGNAL(itemSelectionChanged()), MainWindow, SLOT(slot_callgraph__list_entry__clicked()));
        QObject::connect(bt__option, SIGNAL(clicked()), MainWindow, SLOT(slot_bt_option()));
        QObject::connect(func__liste_entry, SIGNAL(itemSelectionChanged()), MainWindow, SLOT(slot_func__liste_entry__clicked()));
        QObject::connect(func_value__liste_values, SIGNAL(itemSelectionChanged()), MainWindow, SLOT(slot_func_value__list_value__clicked()));
        QObject::connect(seg__scrollbar_content, SIGNAL(valueChanged(int)), seg__content, SLOT(slot_resize()));
        QObject::connect(seg__scrollbar_up, SIGNAL(clicked()), seg__content, SLOT(slot_show_up()));
        QObject::connect(seg__scrollbar_down, SIGNAL(clicked()), seg__content, SLOT(slot_show_down()));
        QObject::connect(bt__analyze, SIGNAL(clicked()), MainWindow, SLOT(slot_bt_analyse()));
        QObject::connect(seg__bt_save, SIGNAL(clicked()), MainWindow, SLOT(slot_seg__bt_save()));
        QObject::connect(sym__bt_edit, SIGNAL(clicked()), MainWindow, SLOT(slot_sym__bt_edit()));
        QObject::connect(type__bt_new, SIGNAL(clicked()), MainWindow, SLOT(slot_type__bt_new()));
        QObject::connect(type__bt_edit, SIGNAL(clicked()), MainWindow, SLOT(slot_type__bt_edit()));
        QObject::connect(type__bt_delete, SIGNAL(clicked()), MainWindow, SLOT(slot_type__bt_delete()));
        QObject::connect(sym__liste_symboles, SIGNAL(itemSelectionChanged()), MainWindow, SLOT(slot_sym__liste_symboles__clicked()));
        QObject::connect(type__treeview, SIGNAL(itemSelectionChanged()), MainWindow, SLOT(slot_type__liste_type_clicked()));
        QObject::connect(anal__tree_analyse, SIGNAL(currentItemChanged(QTreeWidgetItem*,QTreeWidgetItem*)), MainWindow, SLOT(slot_anal__tree_analyse_clicked()));
        QObject::connect(anal__bt_save_all, SIGNAL(clicked()), MainWindow, SLOT(slot_anal__bt_save_all()));
        QObject::connect(anal__bt_save, SIGNAL(clicked()), MainWindow, SLOT(slot_anal__bt_save()));
        QObject::connect(anal__bt_delete, SIGNAL(clicked()), MainWindow, SLOT(slot_anal__bt_delete()));
        QObject::connect(anal__bt_delete_all, SIGNAL(clicked()), MainWindow, SLOT(slot_anal__bt_delete_all()));
        QObject::connect(proto_func__bt_new, SIGNAL(clicked()), MainWindow, SLOT(slot_proto_func__bt_new()));
        QObject::connect(proto_func__bt_edit, SIGNAL(clicked()), MainWindow, SLOT(slot_proto_func__bt_edit()));
        QObject::connect(proto_func__bt_delete, SIGNAL(clicked()), MainWindow, SLOT(slot_proto_func__bt_delete()));
        QObject::connect(proto_func__liste_prototypes, SIGNAL(currentCellChanged(int,int,int,int)), MainWindow, SLOT(slot_proto_func__liste_prototype__clicked()));
        QObject::connect(proto_func__liste_prototypes, SIGNAL(cellDoubleClicked(int,int)), MainWindow, SLOT(slot_proto_func__bt_edit()));
        QObject::connect(proto_inter__bt_new, SIGNAL(clicked()), MainWindow, SLOT(slot_proto_int__bt_new()));
        QObject::connect(proto_inter__bt_delete, SIGNAL(clicked()), MainWindow, SLOT(slot_proto_int__bt_delete()));
        QObject::connect(proto_inter__bt_edit, SIGNAL(clicked()), MainWindow, SLOT(slot_proto_int__bt_edit()));
        QObject::connect(proto_inter__liste_prototypes, SIGNAL(cellDoubleClicked(int,int)), MainWindow, SLOT(slot_proto_int__bt_edit()));
        QObject::connect(proto_inter__liste_prototypes, SIGNAL(currentCellChanged(int,int,int,int)), MainWindow, SLOT(slot_proto_int__liste_prototype__clicked()));
        QObject::connect(proto_syscall__bt_new, SIGNAL(clicked()), MainWindow, SLOT(slot_proto_syscall__bt_new()));
        QObject::connect(proto_syscall__bt_edit, SIGNAL(clicked()), MainWindow, SLOT(slot_proto_syscall__bt_edit()));
        QObject::connect(proto_syscall__bt_delete, SIGNAL(clicked()), MainWindow, SLOT(slot_proto_syscall__bt_delete()));
        QObject::connect(proto_syscall__liste_prototypes, SIGNAL(cellDoubleClicked(int,int)), MainWindow, SLOT(slot_proto_syscall__bt_edit()));
        QObject::connect(proto_syscall__liste_prototypes, SIGNAL(currentCellChanged(int,int,int,int)), MainWindow, SLOT(slot_proto_int__liste_prototype__clicked()));
        QObject::connect(callgraph__bt_generate, SIGNAL(clicked()), MainWindow, SLOT(slot_callgraph__bt_generate()));
        QObject::connect(callgraph__bt_save, SIGNAL(clicked()), MainWindow, SLOT(slot_callgraph__bt_save()));
        QObject::connect(callgraph__nbs_rec, SIGNAL(valueChanged(QString)), MainWindow, SLOT(slot_callgraph__bt_generate()));

        tab__main->setCurrentIndex(4);
        tabWidget->setCurrentIndex(0);
        tab_fonction->setCurrentIndex(2);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "Lecter", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        bt__open->setToolTip(QApplication::translate("MainWindow", "<html><head/><body><p>Chargement d'un fichier en vue de l'analyser</p></body></html>", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        bt__open->setText(QApplication::translate("MainWindow", "Ouvrir", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        bt__option->setToolTip(QApplication::translate("MainWindow", "Options de d\303\251compilation", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        bt__option->setText(QApplication::translate("MainWindow", "Options", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        bt__parsing->setToolTip(QApplication::translate("MainWindow", "<html><head/><body><p>Parsing du fichier \303\240 analyser</p></body></html>", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        bt__parsing->setText(QApplication::translate("MainWindow", "Parser", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        bt__definition->setToolTip(QApplication::translate("MainWindow", "<html><head/><body><p>Charger des d\303\251clarations de structures/fonctions \303\240 partir d'un fichier C</p></body></html>", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        bt__definition->setText(QApplication::translate("MainWindow", "Charger des d\303\251finitions/prototypes", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        bt__deassemble->setToolTip(QApplication::translate("MainWindow", "<html><head/><body><p>Analyser l'ensemble des fonctions (peut \303\252tre tr\303\250s long)</p></body></html>", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        bt__deassemble->setText(QApplication::translate("MainWindow", "D\303\251assembler", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        bt__clean->setToolTip(QApplication::translate("MainWindow", "<html><head/><body><p>Nettoyer l'ensemble des arbres ASM (peut \303\252tre tr\303\250s long)</p></body></html>", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        bt__clean->setText(QApplication::translate("MainWindow", "Nettoyer", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        bt__decompile->setToolTip(QApplication::translate("MainWindow", "<html><head/><body><p>Convertir l'ensemble des arbres ASM en code C (peut \303\252tre tr\303\250s long)</p></body></html>", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        bt__decompile->setText(QApplication::translate("MainWindow", "D\303\251compiler", 0, QApplication::UnicodeUTF8));
        bt__analyze->setText(QApplication::translate("MainWindow", "Analyser", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        tab__main->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        label->setText(QApplication::translate("MainWindow", "Segments pr\303\251sents en m\303\251moire lors de l'ex\303\251cution", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem = seg__liste_segments->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QApplication::translate("MainWindow", "Adresse", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem1 = seg__liste_segments->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QApplication::translate("MainWindow", "Taille", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem2 = seg__liste_segments->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QApplication::translate("MainWindow", "Permissions", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        seg__bt_new->setToolTip(QApplication::translate("MainWindow", "Cr\303\251er un segment", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        seg__bt_new->setText(QApplication::translate("MainWindow", "Nouveau", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        seg__bt_edit->setToolTip(QApplication::translate("MainWindow", "Modifier le segment", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        seg__bt_edit->setText(QApplication::translate("MainWindow", "Editer", 0, QApplication::UnicodeUTF8));
        seg__bt_save->setText(QApplication::translate("MainWindow", "Enregistrer", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        seg__bt_delete->setToolTip(QApplication::translate("MainWindow", "Supprimer le segment", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        seg__bt_delete->setText(QApplication::translate("MainWindow", "Supprimer", 0, QApplication::UnicodeUTF8));
        seg__scrollbar_up->setText(QApplication::translate("MainWindow", "\342\206\221", 0, QApplication::UnicodeUTF8));
        seg__scrollbar_down->setText(QApplication::translate("MainWindow", "\342\206\223", 0, QApplication::UnicodeUTF8));
        tab__main->setTabText(tab__main->indexOf(tab_main__segments), QApplication::translate("MainWindow", "Segments", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("MainWindow", "Symboles pr\303\251sents dans le programme", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem3 = sym__liste_symboles->horizontalHeaderItem(0);
        ___qtablewidgetitem3->setText(QApplication::translate("MainWindow", "Nom", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem4 = sym__liste_symboles->horizontalHeaderItem(1);
        ___qtablewidgetitem4->setText(QApplication::translate("MainWindow", "Valeur", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem5 = sym__liste_symboles->horizontalHeaderItem(2);
        ___qtablewidgetitem5->setText(QApplication::translate("MainWindow", "Type", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        sym__bt_new->setToolTip(QApplication::translate("MainWindow", "Ajouter un symbole", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        sym__bt_new->setText(QApplication::translate("MainWindow", "Nouveau symbole", 0, QApplication::UnicodeUTF8));
        sym__bt_edit->setText(QApplication::translate("MainWindow", "Editer le symbole", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        sym__bt_delete->setToolTip(QApplication::translate("MainWindow", "Supprimer le symbole", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        sym__bt_delete->setText(QApplication::translate("MainWindow", "Supprimer le symbole", 0, QApplication::UnicodeUTF8));
        tab__main->setTabText(tab__main->indexOf(tab_3main__symboles), QApplication::translate("MainWindow", "Symboles", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("MainWindow", "Type de variables et de structures", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        type__bt_new->setToolTip(QApplication::translate("MainWindow", "Ajouter un type de variable", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        type__bt_new->setText(QApplication::translate("MainWindow", "Nouvelle d\303\251finition", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        type__bt_edit->setToolTip(QApplication::translate("MainWindow", "Modifier le type de variable", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        type__bt_edit->setText(QApplication::translate("MainWindow", "Editer la d\303\251finition", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        type__bt_delete->setToolTip(QApplication::translate("MainWindow", "Supprimer le type de variable", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        type__bt_delete->setText(QApplication::translate("MainWindow", "Supprimer la d\303\251finition", 0, QApplication::UnicodeUTF8));
        tab__main->setTabText(tab__main->indexOf(tab_main__definitions), QApplication::translate("MainWindow", "Definition types", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem6 = proto_func__liste_prototypes->horizontalHeaderItem(0);
        ___qtablewidgetitem6->setText(QApplication::translate("MainWindow", "Type de retour", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem7 = proto_func__liste_prototypes->horizontalHeaderItem(1);
        ___qtablewidgetitem7->setText(QApplication::translate("MainWindow", "Nom de la fonction", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem8 = proto_func__liste_prototypes->horizontalHeaderItem(2);
        ___qtablewidgetitem8->setText(QApplication::translate("MainWindow", "Param\303\250tres 1, Param\303\250tres 2, ...", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        proto_func__bt_new->setToolTip(QApplication::translate("MainWindow", "Ajouter un prototype de fonction", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        proto_func__bt_new->setText(QApplication::translate("MainWindow", "Nouveau prototype de fonction", 0, QApplication::UnicodeUTF8));
        proto_func__bt_edit->setText(QApplication::translate("MainWindow", "Editer le prototype", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        proto_func__bt_delete->setToolTip(QApplication::translate("MainWindow", "Supprimer le prototype de fonction", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        proto_func__bt_delete->setText(QApplication::translate("MainWindow", "Supprimer le prototype", 0, QApplication::UnicodeUTF8));
        tabWidget->setTabText(tabWidget->indexOf(tab_3), QApplication::translate("MainWindow", "Prototypes des fonctions", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem9 = proto_inter__liste_prototypes->horizontalHeaderItem(0);
        ___qtablewidgetitem9->setText(QApplication::translate("MainWindow", "Num\303\251ro", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem10 = proto_inter__liste_prototypes->horizontalHeaderItem(1);
        ___qtablewidgetitem10->setText(QApplication::translate("MainWindow", "Type de retour", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem11 = proto_inter__liste_prototypes->horizontalHeaderItem(2);
        ___qtablewidgetitem11->setText(QApplication::translate("MainWindow", "Nom de l'interruption", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem12 = proto_inter__liste_prototypes->horizontalHeaderItem(3);
        ___qtablewidgetitem12->setText(QApplication::translate("MainWindow", "Param\303\250tres 1, Param\303\250tres 2, ...", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        proto_inter__bt_new->setToolTip(QApplication::translate("MainWindow", "Ajouter un prototype de fonction", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        proto_inter__bt_new->setText(QApplication::translate("MainWindow", "Nouveau prototype d'interruption", 0, QApplication::UnicodeUTF8));
        proto_inter__bt_edit->setText(QApplication::translate("MainWindow", "Editer le prototype", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        proto_inter__bt_delete->setToolTip(QApplication::translate("MainWindow", "Supprimer le prototype de fonction", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        proto_inter__bt_delete->setText(QApplication::translate("MainWindow", "Supprimer le prototype", 0, QApplication::UnicodeUTF8));
        tabWidget->setTabText(tabWidget->indexOf(tab_5), QApplication::translate("MainWindow", "Prototypes des interruptions", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem13 = proto_syscall__liste_prototypes->horizontalHeaderItem(0);
        ___qtablewidgetitem13->setText(QApplication::translate("MainWindow", "Num\303\251ro", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem14 = proto_syscall__liste_prototypes->horizontalHeaderItem(1);
        ___qtablewidgetitem14->setText(QApplication::translate("MainWindow", "Type de retour", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem15 = proto_syscall__liste_prototypes->horizontalHeaderItem(2);
        ___qtablewidgetitem15->setText(QApplication::translate("MainWindow", "Nom du syscall", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem16 = proto_syscall__liste_prototypes->horizontalHeaderItem(3);
        ___qtablewidgetitem16->setText(QApplication::translate("MainWindow", "Param\303\250tres 1, Param\303\250tres 2, ...", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        proto_syscall__bt_new->setToolTip(QApplication::translate("MainWindow", "Ajouter un prototype de fonction", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        proto_syscall__bt_new->setText(QApplication::translate("MainWindow", "Nouveau prototype de syscall", 0, QApplication::UnicodeUTF8));
        proto_syscall__bt_edit->setText(QApplication::translate("MainWindow", "Editer le prototype", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        proto_syscall__bt_delete->setToolTip(QApplication::translate("MainWindow", "Supprimer le prototype de fonction", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        proto_syscall__bt_delete->setText(QApplication::translate("MainWindow", "Supprimer le prototype", 0, QApplication::UnicodeUTF8));
        tabWidget->setTabText(tabWidget->indexOf(tab_4), QApplication::translate("MainWindow", "Prototypes des syscalls", 0, QApplication::UnicodeUTF8));
        tab__main->setTabText(tab__main->indexOf(tab_main__prototypes), QApplication::translate("MainWindow", "Prototype fonctions", 0, QApplication::UnicodeUTF8));
        label_5->setText(QApplication::translate("MainWindow", "Fonctions \303\240 analyser", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem17 = func__liste_entry->horizontalHeaderItem(0);
        ___qtablewidgetitem17->setText(QApplication::translate("MainWindow", "Adresse", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem18 = func__liste_entry->horizontalHeaderItem(1);
        ___qtablewidgetitem18->setText(QApplication::translate("MainWindow", "Nom (Symboles)", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        func__bt_new->setToolTip(QApplication::translate("MainWindow", "Ajouter un point d'entr\303\251e \303\240 analyser", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        func__bt_new->setText(QApplication::translate("MainWindow", "Ajouter fonction", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        func__bt_delete->setToolTip(QApplication::translate("MainWindow", "Supprimer le point d'entr\303\251e", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        func__bt_delete->setText(QApplication::translate("MainWindow", "Supprimer fonction", 0, QApplication::UnicodeUTF8));
        label_6->setText(QApplication::translate("MainWindow", "Valeur des registres/m\303\251moire au d\303\251but de la fonction", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem19 = func_value__liste_values->horizontalHeaderItem(0);
        ___qtablewidgetitem19->setText(QApplication::translate("MainWindow", "Var/reg", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem20 = func_value__liste_values->horizontalHeaderItem(1);
        ___qtablewidgetitem20->setText(QApplication::translate("MainWindow", "Nom", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem21 = func_value__liste_values->horizontalHeaderItem(2);
        ___qtablewidgetitem21->setText(QApplication::translate("MainWindow", "Type", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem22 = func_value__liste_values->horizontalHeaderItem(3);
        ___qtablewidgetitem22->setText(QApplication::translate("MainWindow", "Taille", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem23 = func_value__liste_values->horizontalHeaderItem(4);
        ___qtablewidgetitem23->setText(QApplication::translate("MainWindow", "Valeur", 0, QApplication::UnicodeUTF8));
        label_4->setText(QApplication::translate("MainWindow", "Emplacement de la valeur de retour : ", 0, QApplication::UnicodeUTF8));
        func_value__bt_new->setText(QApplication::translate("MainWindow", "Nouvelle valeur", 0, QApplication::UnicodeUTF8));
        func_value__bt_delete->setText(QApplication::translate("MainWindow", "Supprimer la valeur", 0, QApplication::UnicodeUTF8));
        tab_fonction->setTabText(tab_fonction->indexOf(tab_fonction__tab_valeurs), QApplication::translate("MainWindow", "Valeurs pr\303\251d\303\251finies", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem24 = func_param__liste_param->horizontalHeaderItem(0);
        ___qtablewidgetitem24->setText(QApplication::translate("MainWindow", "Emplacement des param\303\250tres pass\303\251s \303\240 la fonction", 0, QApplication::UnicodeUTF8));
        func_param__bt_new->setText(QApplication::translate("MainWindow", "Ajouter param\303\250tre", 0, QApplication::UnicodeUTF8));
        func_param__bt_delete->setText(QApplication::translate("MainWindow", "supprimer param\303\250tre", 0, QApplication::UnicodeUTF8));
        tab_fonction->setTabText(tab_fonction->indexOf(tab), QApplication::translate("MainWindow", "Param\303\250tres", 0, QApplication::UnicodeUTF8));
        label_7->setText(QApplication::translate("MainWindow", "Arbre ASM produit lors du d\303\251assemblage", 0, QApplication::UnicodeUTF8));
        func_asm__bt_deassemble->setText(QApplication::translate("MainWindow", "Re-d\303\251assembler", 0, QApplication::UnicodeUTF8));
        func_asm__bt_clean->setText(QApplication::translate("MainWindow", "Re-nettoyer", 0, QApplication::UnicodeUTF8));
        func_asm__check_deasm__addr->setText(QApplication::translate("MainWindow", "Adresse", 0, QApplication::UnicodeUTF8));
        func_asm__check_deasm__opcode->setText(QApplication::translate("MainWindow", "Opcode", 0, QApplication::UnicodeUTF8));
        func_asm__check_deasm__instr->setText(QApplication::translate("MainWindow", "ASM", 0, QApplication::UnicodeUTF8));
        func_asm__bt_save->setText(QApplication::translate("MainWindow", "Enregistrer", 0, QApplication::UnicodeUTF8));
        tab_fonction->setTabText(tab_fonction->indexOf(tab_fonction__tab_asm), QApplication::translate("MainWindow", "Arbre ASM", 0, QApplication::UnicodeUTF8));
        label_8->setText(QApplication::translate("MainWindow", "Code C produit lors de la d\303\251compilation", 0, QApplication::UnicodeUTF8));
        func_c__bt_decompile->setText(QApplication::translate("MainWindow", "Re-d\303\251compiler", 0, QApplication::UnicodeUTF8));
        func_c__bt_save->setText(QApplication::translate("MainWindow", "Enregistrer", 0, QApplication::UnicodeUTF8));
        tab_fonction->setTabText(tab_fonction->indexOf(tab_6), QApplication::translate("MainWindow", "Code source", 0, QApplication::UnicodeUTF8));
        tab__main->setTabText(tab__main->indexOf(tab_main__fonctions), QApplication::translate("MainWindow", "Fonctions", 0, QApplication::UnicodeUTF8));
        label_9->setText(QApplication::translate("MainWindow", "Racine du graphe", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem25 = callgraph__list_entry->horizontalHeaderItem(0);
        ___qtablewidgetitem25->setText(QApplication::translate("MainWindow", "Adresse", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem26 = callgraph__list_entry->horizontalHeaderItem(1);
        ___qtablewidgetitem26->setText(QApplication::translate("MainWindow", "Nom (Symboles)", 0, QApplication::UnicodeUTF8));
        callgraph__bt_generate->setText(QApplication::translate("MainWindow", "Re-g\303\251n\303\251rer", 0, QApplication::UnicodeUTF8));
        label_10->setText(QApplication::translate("MainWindow", "Profondeur de l'analyse : ", 0, QApplication::UnicodeUTF8));
        callgraph__bt_save->setText(QApplication::translate("MainWindow", "Enregistrer", 0, QApplication::UnicodeUTF8));
        tab__main->setTabText(tab__main->indexOf(tab_2), QApplication::translate("MainWindow", "Callgraph", 0, QApplication::UnicodeUTF8));
        QTreeWidgetItem *___qtreewidgetitem = anal__tree_analyse->headerItem();
        ___qtreewidgetitem->setText(1, QApplication::translate("MainWindow", "R\303\251sultat", 0, QApplication::UnicodeUTF8));
        ___qtreewidgetitem->setText(0, QApplication::translate("MainWindow", "Analyse", 0, QApplication::UnicodeUTF8));
        anal__bt_save_all->setText(QApplication::translate("MainWindow", "Tout enregister", 0, QApplication::UnicodeUTF8));
        anal__bt_save->setText(QApplication::translate("MainWindow", "Enregister", 0, QApplication::UnicodeUTF8));
        anal__bt_delete->setText(QApplication::translate("MainWindow", "Supprimer", 0, QApplication::UnicodeUTF8));
        anal__bt_delete_all->setText(QApplication::translate("MainWindow", "Tout supprimer", 0, QApplication::UnicodeUTF8));
        tab__main->setTabText(tab__main->indexOf(tab_7), QApplication::translate("MainWindow", "Analyses", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
