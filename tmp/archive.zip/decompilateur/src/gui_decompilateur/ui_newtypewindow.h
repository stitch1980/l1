/********************************************************************************
** Form generated from reading UI file 'newtypewindow.ui'
**
** Created: Thu May 14 13:50:04 2015
**      by: Qt User Interface Compiler version 4.8.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_NEWTYPEWINDOW_H
#define UI_NEWTYPEWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QDialogButtonBox>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QRadioButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QTableWidget>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_DialogNewType
{
public:
    QVBoxLayout *verticalLayout;
    QWidget *widget_4;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_2;
    QLineEdit *field_name;
    QWidget *widget;
    QHBoxLayout *horizontalLayout;
    QLabel *label;
    QRadioButton *bt_type_simple;
    QRadioButton *bt_type_structure;
    QWidget *widget_simple;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_3;
    QLineEdit *field_size;
    QWidget *widget_structure;
    QVBoxLayout *verticalLayout_2;
    QLabel *label_4;
    QTableWidget *table_attributs;
    QWidget *widget_5;
    QHBoxLayout *horizontalLayout_4;
    QPushButton *bt_attribut_new;
    QPushButton *bt_attribut_edit;
    QPushButton *bt_attribut_up;
    QPushButton *bt_attribut_down;
    QSpacerItem *horizontalSpacer;
    QPushButton *bt_attribut_delete;
    QDialogButtonBox *buttonBox;

    void setupUi(QDialog *DialogNewType)
    {
        if (DialogNewType->objectName().isEmpty())
            DialogNewType->setObjectName(QString::fromUtf8("DialogNewType"));
        DialogNewType->resize(466, 488);
        verticalLayout = new QVBoxLayout(DialogNewType);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        widget_4 = new QWidget(DialogNewType);
        widget_4->setObjectName(QString::fromUtf8("widget_4"));
        horizontalLayout_2 = new QHBoxLayout(widget_4);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        label_2 = new QLabel(widget_4);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        horizontalLayout_2->addWidget(label_2);

        field_name = new QLineEdit(widget_4);
        field_name->setObjectName(QString::fromUtf8("field_name"));

        horizontalLayout_2->addWidget(field_name);


        verticalLayout->addWidget(widget_4);

        widget = new QWidget(DialogNewType);
        widget->setObjectName(QString::fromUtf8("widget"));
        horizontalLayout = new QHBoxLayout(widget);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        label = new QLabel(widget);
        label->setObjectName(QString::fromUtf8("label"));

        horizontalLayout->addWidget(label);

        bt_type_simple = new QRadioButton(widget);
        bt_type_simple->setObjectName(QString::fromUtf8("bt_type_simple"));
        bt_type_simple->setChecked(true);

        horizontalLayout->addWidget(bt_type_simple);

        bt_type_structure = new QRadioButton(widget);
        bt_type_structure->setObjectName(QString::fromUtf8("bt_type_structure"));

        horizontalLayout->addWidget(bt_type_structure);


        verticalLayout->addWidget(widget);

        widget_simple = new QWidget(DialogNewType);
        widget_simple->setObjectName(QString::fromUtf8("widget_simple"));
        horizontalLayout_3 = new QHBoxLayout(widget_simple);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        label_3 = new QLabel(widget_simple);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        horizontalLayout_3->addWidget(label_3);

        field_size = new QLineEdit(widget_simple);
        field_size->setObjectName(QString::fromUtf8("field_size"));

        horizontalLayout_3->addWidget(field_size);


        verticalLayout->addWidget(widget_simple);

        widget_structure = new QWidget(DialogNewType);
        widget_structure->setObjectName(QString::fromUtf8("widget_structure"));
        widget_structure->setEnabled(true);
        verticalLayout_2 = new QVBoxLayout(widget_structure);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        label_4 = new QLabel(widget_structure);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        verticalLayout_2->addWidget(label_4);

        table_attributs = new QTableWidget(widget_structure);
        if (table_attributs->columnCount() < 3)
            table_attributs->setColumnCount(3);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        table_attributs->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        table_attributs->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        table_attributs->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        table_attributs->setObjectName(QString::fromUtf8("table_attributs"));
        table_attributs->setEditTriggers(QAbstractItemView::NoEditTriggers);
        table_attributs->horizontalHeader()->setStretchLastSection(true);

        verticalLayout_2->addWidget(table_attributs);

        widget_5 = new QWidget(widget_structure);
        widget_5->setObjectName(QString::fromUtf8("widget_5"));
        horizontalLayout_4 = new QHBoxLayout(widget_5);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        bt_attribut_new = new QPushButton(widget_5);
        bt_attribut_new->setObjectName(QString::fromUtf8("bt_attribut_new"));

        horizontalLayout_4->addWidget(bt_attribut_new);

        bt_attribut_edit = new QPushButton(widget_5);
        bt_attribut_edit->setObjectName(QString::fromUtf8("bt_attribut_edit"));

        horizontalLayout_4->addWidget(bt_attribut_edit);

        bt_attribut_up = new QPushButton(widget_5);
        bt_attribut_up->setObjectName(QString::fromUtf8("bt_attribut_up"));
        bt_attribut_up->setMaximumSize(QSize(20, 16777215));

        horizontalLayout_4->addWidget(bt_attribut_up);

        bt_attribut_down = new QPushButton(widget_5);
        bt_attribut_down->setObjectName(QString::fromUtf8("bt_attribut_down"));
        bt_attribut_down->setMaximumSize(QSize(20, 16777215));

        horizontalLayout_4->addWidget(bt_attribut_down);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer);

        bt_attribut_delete = new QPushButton(widget_5);
        bt_attribut_delete->setObjectName(QString::fromUtf8("bt_attribut_delete"));

        horizontalLayout_4->addWidget(bt_attribut_delete);


        verticalLayout_2->addWidget(widget_5);


        verticalLayout->addWidget(widget_structure);

        buttonBox = new QDialogButtonBox(DialogNewType);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);

        verticalLayout->addWidget(buttonBox);


        retranslateUi(DialogNewType);
        QObject::connect(buttonBox, SIGNAL(accepted()), DialogNewType, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), DialogNewType, SLOT(reject()));
        QObject::connect(field_name, SIGNAL(textChanged(QString)), DialogNewType, SLOT(slot_check_formulaire()));
        QObject::connect(bt_type_structure, SIGNAL(clicked()), DialogNewType, SLOT(slot_check_formulaire()));
        QObject::connect(bt_type_simple, SIGNAL(clicked()), DialogNewType, SLOT(slot_check_formulaire()));
        QObject::connect(field_size, SIGNAL(textChanged(QString)), DialogNewType, SLOT(slot_check_formulaire()));
        QObject::connect(DialogNewType, SIGNAL(accepted()), DialogNewType, SLOT(slot_validate()));
        QObject::connect(bt_attribut_new, SIGNAL(clicked()), DialogNewType, SLOT(slot_bt_new()));
        QObject::connect(bt_attribut_edit, SIGNAL(clicked()), DialogNewType, SLOT(slot_bt_edit()));
        QObject::connect(bt_attribut_up, SIGNAL(clicked()), DialogNewType, SLOT(slot_bt_up()));
        QObject::connect(bt_attribut_down, SIGNAL(clicked()), DialogNewType, SLOT(slot_bt_down()));
        QObject::connect(bt_attribut_delete, SIGNAL(clicked()), DialogNewType, SLOT(slot_bt_delete()));
        QObject::connect(table_attributs, SIGNAL(currentCellChanged(int,int,int,int)), DialogNewType, SLOT(slot_attribut_clicked()));

        QMetaObject::connectSlotsByName(DialogNewType);
    } // setupUi

    void retranslateUi(QDialog *DialogNewType)
    {
        DialogNewType->setWindowTitle(QApplication::translate("DialogNewType", "Dialog", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("DialogNewType", "Nom de la variable :", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("DialogNewType", "Type de variable :", 0, QApplication::UnicodeUTF8));
        bt_type_simple->setText(QApplication::translate("DialogNewType", "Simple", 0, QApplication::UnicodeUTF8));
        bt_type_structure->setText(QApplication::translate("DialogNewType", "Structure", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("DialogNewType", "Taille de la variable :", 0, QApplication::UnicodeUTF8));
        label_4->setText(QApplication::translate("DialogNewType", "Attributs de la structure :", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem = table_attributs->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QApplication::translate("DialogNewType", "Type", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem1 = table_attributs->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QApplication::translate("DialogNewType", "Nom", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem2 = table_attributs->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QApplication::translate("DialogNewType", "Taille", 0, QApplication::UnicodeUTF8));
        bt_attribut_new->setText(QApplication::translate("DialogNewType", "Nouveau", 0, QApplication::UnicodeUTF8));
        bt_attribut_edit->setText(QApplication::translate("DialogNewType", "Editer", 0, QApplication::UnicodeUTF8));
        bt_attribut_up->setText(QApplication::translate("DialogNewType", "\342\206\221", 0, QApplication::UnicodeUTF8));
        bt_attribut_down->setText(QApplication::translate("DialogNewType", "\342\206\223", 0, QApplication::UnicodeUTF8));
        bt_attribut_delete->setText(QApplication::translate("DialogNewType", "Supprimer", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class DialogNewType: public Ui_DialogNewType {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_NEWTYPEWINDOW_H
