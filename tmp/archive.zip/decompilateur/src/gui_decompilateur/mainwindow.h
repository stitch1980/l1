#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include    <QMainWindow>
#include    <QApplication>
#include    <QtGui>
#include    <QTimer>

#include    <sys/types.h>
#include    <libgen.h>
#include    <dirent.h>
#include    <limits.h>
#include    <stdlib.h>
#include    <stdio.h>
#include    <string.h>
#include    <unistd.h>
#include    <sys/wait.h>
#include    <sys/stat.h>
#include    <fcntl.h>

#include    <iostream>
#include    <set>

#include    "Info.hpp"
#include    "Plugin.hpp"
#include    "Calcul.hpp"
#include    "ParsingPreprocesseur.hpp"
#include    "ParsingC.hpp"

#include    "define.hpp"
#include    "MyQThread.hpp"


namespace Ui
{
    class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

    /**
    ** \enum eStatut
    ** \brief Etat du decompilateur
    */
    enum    eStatut
    {
        STATUT_UPDATE,       /* Mise a jour de l'affichage, d'un graphe... */
        STATUT_PARSING,      /* Parsing du contenu d'un executable */
        STATUT_LOAD_INFO,    /* Chargement d'infos annexes (prototype, typdef...) */
        STATUT_DEASM,        /* Deassemblage en cours */
        STATUT_CLEAN,        /* Nettoyage des fonctions en cours */
        STATUT_DECOMPILE,    /* Decompilation en cours */
        STATUT_ANALYSE  ,    /* Analyse en cours */
        STATUT_ERROR,        /* Doit afficher un popup d'erreur */
        STATUT_DONE          /* Ne fait rien */
    };
    
public:
    explicit MainWindow(int argc, const char **argv, QWidget *parent = 0);
    ~MainWindow();

    /**
    ** \fn void put_message(const QString &title, const QString &txt)
    ** \brief Gere l'affichage d'un popup
    **
    ** \param title Nom du popup
    ** \param txt Contenu du popup
    ** \return Retourne rien
    */
    void    put_message(const QString &title, const QString &txt);

    /**
    ** \fn void actualisation()
    ** \brief Gere l'actualisation de tout les champs de la fenetre
    **
    ** \return Retourne rien
    */
    void    actualisation();

public slots:
    /**
    ** \fn void slot_timer()
    ** \brief Slot permettant d'actualiser le log en temps reel
    **
    ** \return Retourne rien
    */
    void    slot_timer();

    /**
    ** \fn void slot_bt_open()
    ** \brief Slot permettant de charger le contenu d'un fichier afin de l'analyser
    **
    ** \return Retourne rien
    */
    void    slot_bt_open();

    /**
    ** \fn void slot_bt_option()
    ** \brief Slot permettant d'afficher le menu d'option
    **
    ** \return Retourne rien
    */
    void    slot_bt_option();

    /**
    ** \fn void slot_bt_parsing()
    ** \brief Slot permettant de parser le fichier a analyser afin d'extraire ses infos
    **
    ** \return Retourne rien
    */
    void    slot_bt_parsing();

    /**
    ** \fn void slot_bt_definition()
    ** \brief Slot permettant de charger un fichier contenant des prototypes/definitions
    **
    ** \return Retourne rien
    */
    void    slot_bt_definition();

    /**
    ** \fn void slot_bt_deassemble()
    ** \brief Slot permettant de generer un arbre ASM pour toutes les fonctions
    **
    ** \return Retourne rien
    */
    void    slot_bt_deassemble();

    /**
    ** \fn void slot_bt_clean()
    ** \brief Slot permettant d'epurer l'arbre ASM de toutes les fonctions
    **
    ** \return Retourne rien
    */
    void    slot_bt_clean();

    /**
    ** \fn void slot_bt_decompile()
    ** \brief Slot gerant la conversion ASM en C de toutes les fonctions
    **
    ** \return Retourne rien
    */
    void    slot_bt_decompile();

    /**
    ** \fn void slot_bt_analyse()
    ** \brief Slot gerant l'analyse des donnees produites par les plugins
    **
    ** \return Retourne rien
    */
    void    slot_bt_analyse();



    /**
    ** \fn void slot_seg__list_segment__update()
    ** \brief Slot gerant l'actualisation de la liste des segments
    **
    ** \return Retourne rien
    */
    void    slot_seg__list_segment__update();

    /**
    ** \fn void slot_seg__list_segment__clicked()
    ** \brief Slot gerant l'affichage du contenu d'un segment
    **
    ** \return Retourne rien
    */
    void    slot_seg__list_segment__clicked();

    /**
    ** \fn void slot_seg__change_selected_segment(unsigned long addr, unsigned long size, int flags)
    ** \brief Gere la selection d'un segment precis
    **
    ** \param addr Adresse du segment a selectionner
    ** \param size Taille du segment a selectionner
    ** \param flags Flags du segment a selectionner
    ** \return Retourne rien
    */
    void    slot_seg__change_selected_segment(unsigned long addr, unsigned long size, int flags);

    /**
    ** \fn void slot_seg__bt_new()
    ** \brief Slot gerant la creation d'un nouveau segment
    **
    ** \return Retourne rien
    */
    void    slot_seg__bt_new();

    /**
    ** \fn void slot_seg__bt_edit()
    ** \brief Slot permettant d'editer l'adresse, la taille et les droits d'un segment
    **
    ** \return Retourne rien
    */
    void    slot_seg__bt_edit();

    /**
    ** \fn void slot_seg__bt_delete()
    ** \brief Slot gerant la suppression du segment selectionne
    **
    ** \return Retourne rien
    */
    void    slot_seg__bt_delete();

    /**
    ** \fn void slot_seg__bt_save()
    ** \brief Slot gerant l'enregistrement dans un fichier du segment selectionne
    **
    ** \return Retourne rien
    */
    void    slot_seg__bt_save();

    /**
    ** \fn int slot_seg__get_infos_selected_segment(int row, unsigned long &addr, unsigned long &size, int &flags)
    ** \brief Gere la recuperation des infos d'un segment dans la liste des segments
    **
    ** \param row Ligne contenant les infos du segment a recuperer
    ** \param addr Reference sur un long ou mettre l'adresse du segment selectionne
    ** \param size Reference sur un long ou mettre la taille du segment selectionne
    ** \param flags Reference sur un int ou mettre les flags du segment selectionne
    ** \return Retourne 1 si OK, 0 sinon
    */
    int    slot_seg__get_infos_selected_segment(int row, unsigned long &addr, unsigned long &size, int &flags);


    /**
    ** \fn void slot_sym__liste_symboles__update()
    ** \brief Slot gerant l'actualisation de la liste de symboles
    **
    ** \return Retourne rien
    */
    void    slot_sym__liste_symboles__update();

    /**
    ** \fn void slot_sym__change_selected_symbol(unsigned long value)
    ** \brief Gere la selection d'un segment precis
    **
    ** \param valeur Valeur du symbole a selectionner
    ** \return Retourne rien
    */
    void    slot_sym__change_selected_symbol(unsigned long value);

    /**
    ** \fn void slot_sym__liste_symboles__clicked()
    ** \brief Slot gerant le clic sur un symbole
    **
    ** \return Retourne rien
    */
    void    slot_sym__liste_symboles__clicked();

    /**
    ** \fn void slot_sym__bt_new()
    ** \brief Slot gerant la creation d'un nouveau symbole
    **
    ** \return Retourne rien
    */
    void    slot_sym__bt_new();

    /**
    ** \fn void slot_sym__bt_edit()
    ** \brief Slot gerant la modification d'un symbole
    **
    ** \return Retourne rien
    */
    void    slot_sym__bt_edit();

    /**
    ** \fn void slot_sym__bt_delete()
    ** \brief Slot gerant la suppression d'un symbole
    **
    ** \return Retourne rien
    */
    void    slot_sym__bt_delete();



    /**
    ** \fn void slot_type__list_type__update()
    ** \brief Slot gerant l'actualisation de la liste de type
    **
    ** \return Retourne rien
    */
    void    slot_type__list_type__update();

    /**
    ** \fn void slot_type__list_type_son(QTreeWidgetItem *item, const std::string &type_var, unsigned int profondeur=1)
    ** \brief Permet d'ajouter les attributs d'une structure lors de son affichage
    **
    ** \param item Classe contenant les infos de la structure a afficher
    ** \param type_var Type de la structure dont le contenu doit etre affiche
    ** \param profondeur Profondeur de la recursion pour l'affichage
    ** \return Retourne rien
    */
    void    slot_type__list_type_son(QTreeWidgetItem *item, const std::string &type_var, unsigned int profondeur=1);

    /**
    ** \fn void slot_type__liste_type_clicked
    ** \brief Slot gerant le clic sur un type de variable
    **
    ** \return Retourne rien
    */
    void    slot_type__liste_type_clicked();

    /**
    ** \fn void slot_type__bt_new()
    ** \brief Gere la creation d'un nouveau type de variable
    **
    ** \return Retourne rien
    */
    void   slot_type__bt_new();

    /**
    ** \fn void slot_type__bt_edit()
    ** \brief Gere la modification d'un type de variable
    **
    ** \return Retourne rien
    */
    void   slot_type__bt_edit();

    /**
    ** \fn void slot_type__bt_delete()
    ** \brief Gere la suppression d'un type de variable
    **
    ** \return Retourne rien
    */
    void   slot_type__bt_delete();



    /**
    ** \fn void slot_proto_func__liste_prototype__update()
    ** \brief Slot gerant l'actualisation de la liste des prototypes
    **
    ** \return Retourne rien
    */
    void    slot_proto_func__liste_prototype__update();

    /**
    ** \fn void slot_proto_func__liste_prototype__clicked()
    ** \brief Slot gerant le clic sur un prototype
    **
    ** \return Retourne rien
    */
    void    slot_proto_func__liste_prototype__clicked();

    /**
    ** \fn void slot_proto_func__bt_new()
    ** \brief Slot gerant la creation d'un nouveau prototype
    **
    ** \return Retourne rien
    */
    void    slot_proto_func__bt_new();

    /**
    ** \fn void slot_proto_func__bt_edit()
    ** \brief Slot gerant la modification d'un prototype
    **
    ** \return Retourne rien
    */
    void    slot_proto_func__bt_edit();

    /**
    ** \fn void slot_proto_func__bt_delete()
    ** \brief Slot gerant la suppression d'un prototype
    **
    ** \return Retourne rien
    */
    void    slot_proto_func__bt_delete();

    /**
    ** \fn void slot_proto_func__edit_name(const std::string &n)
    ** \brief Gere l'edition du prototype d'une fonction
    **
    ** \param n Nom de la fonction dont le prototype est a editer
    ** \return Retourne rien
    */
    void    slot_proto_func__edit_name(const std::string &n);


    /**
    ** \fn void slot_proto_int__liste_prototype__update()
    ** \brief Slot gerant l'actualisation de la liste des prototypes
    **
    ** \return Retourne rien
    */
    void    slot_proto_int__liste_prototype__update();

    /**
    ** \fn void slot_proto_int__liste_prototype__clicked()
    ** \brief Slot gerant le clic sur un prototype
    **
    ** \return Retourne rien
    */
    void    slot_proto_int__liste_prototype__clicked();

    /**
    ** \fn void slot_proto_int__bt_new()
    ** \brief Slot gerant la creation d'un nouveau prototype
    **
    ** \return Retourne rien
    */
    void    slot_proto_int__bt_new();

    /**
    ** \fn void slot_proto_int__bt_edit()
    ** \brief Slot gerant la modification d'un prototype
    **
    ** \return Retourne rien
    */
    void    slot_proto_int__bt_edit();

    /**
    ** \fn void slot_proto_int__bt_delete()
    ** \brief Slot gerant la suppression d'un prototype
    **
    ** \return Retourne rien
    */
    void    slot_proto_int__bt_delete();


    /**
    ** \fn void slot_proto_syscall__liste_prototype__update()
    ** \brief Slot gerant l'actualisation de la liste des prototypes
    **
    ** \return Retourne rien
    */
    void    slot_proto_syscall__liste_prototype__update();

    /**
    ** \fn void slot_proto_syscall__liste_prototype__clicked()
    ** \brief Slot gerant le clic sur un prototype
    **
    ** \return Retourne rien
    */
    void    slot_proto_syscall__liste_prototype__clicked();

    /**
    ** \fn void slot_proto_syscall__bt_new()
    ** \brief Slot gerant la creation d'un nouveau prototype
    **
    ** \return Retourne rien
    */
    void    slot_proto_syscall__bt_new();

    /**
    ** \fn void slot_proto_syscall__bt_edit()
    ** \brief Slot gerant la modification d'un prototype
    **
    ** \return Retourne rien
    */
    void    slot_proto_syscall__bt_edit();

    /**
    ** \fn void slot_proto_syscall__bt_delete()
    ** \brief Slot gerant la suppression d'un prototype
    **
    ** \return Retourne rien
    */
    void    slot_proto_syscall__bt_delete();


    /**
    ** \fn void slot_func__liste_entry__update()
    ** \brief Slot gere l'actualisation de la liste des points d'entrees
    **
    ** \return Retourne rien
    */
    void    slot_func__liste_entry__update();

    /**
    ** \fn void slot_func__liste_entry__edit()
    ** \brief Slot gere la modification d'un point d'entree
    **
    ** \return Retourne rien
    */
    void    slot_func__liste_entry__edit();

    /**
    ** \fn void lot_func__liste_entry__clicked()
    ** \brief Slot gere le clic sur un point d'entree
    **
    ** \return Retourne rien
    */
    void    slot_func__liste_entry__clicked();

    /**
    ** \fn void lot_func__bt_new()
    ** \brief Slot gerant la creation d'un point d'entree
    **
    ** \return Retourne rien
    */
    void    slot_func__bt_new();

    /**
    ** \fn void lot_func__bt_delete()
    ** \brief Slot gere la suppression d'un point d'entree
    **
    ** \return Retourne rien
    */
    void    slot_func__bt_delete();



    /**
    ** \fn void slot_func_value__list_value__update()
    ** \brief Slot gere l'actualisation des valeurs de contexte predefinie
    **
    ** \return Retourne rien
    */
    void    slot_func_value__list_value__update();

    /**
    ** \fn void slot_func_value__list_value__edit()
    ** \brief Slot gere l'edition d'une valeur de contexte predefinie
    **
    ** \return Retourne rien
    */
    void    slot_func_value__list_value__edit();

    /**
    ** \fn void slot_func_value__list_value__clicked()
    ** \brief Slot gere les clics sur les valeurs de contexte predefinie
    **
    ** \return Retourne rien
    */
    void    slot_func_value__list_value__clicked();

    /**
    ** \fn void slot_func_value__bt_new()
    ** \brief Slot gere l'ajout d'une valeur de contexte predefinie
    **
    ** \return Retourne rien
    */
    void    slot_func_value__bt_new();

    /**
    ** \fn void slot_func_value__bt_delete()
    ** \brief Slot gere la suppression d'une valeur de contexte predefinie
    **
    ** \return Retourne rien
    */
    void    slot_func_value__bt_delete();


    /**
    ** \fn void slot_func_asm__arbre__update()
    ** \brief Slot gerant l'actualisation de l'arbre ASM
    **
    ** \return Retourne rien
    */
    void    slot_func_asm__arbre__update();

    /**
    ** \fn void slot_func_asm__arbre__option_changed()
    ** \brief Slot gerant l'actualisation de l'arbre ASM en cas de changement d'options (Adresse, Octets, Instr)
    **
    ** \return Retourne rien
    */
    void    slot_func_asm__arbre__option_changed();

    /**
    ** \fn void slot_func_asm__bt_deassemble()
    ** \brief Slot gerant le deassemblage d'une fonction
    **
    ** \return Retourne rien
    */
    void    slot_func_asm__bt_deassemble();

    /**
    ** \fn void slot_func_asm__bt_clean()
    ** \brief Slot gerant le nettoyage d'une fonction
    **
    ** \return Retourne rien
    */
    void    slot_func_asm__bt_clean();

    /**
    ** \fn void slot_func_asm__bt_save()
    ** \brief Slot gerant l'enregistrement de l'arbre ASM d'une fonction
    **
    ** \return Retourne rien
    */
    void    slot_func_asm__bt_save();

    /**
    ** \fn void slot_func__select_an_entry_asm(unsigned long addr)
    ** \brief Gere la selction d'une fonction afin d'afficher son callgraphe
    **
    ** \param addr Adresse de la fonction a selectionner
    ** \return Retourne rien
    */
    void    slot_func__select_an_entry_asm(unsigned long addr);

    /**
    ** \fn void slot_func__deassemble_an_entry_asm(unsigned long addr)
    ** \brief Gere le deassemblage d'une fonction si elle est situe dans un segment executable
    **
    ** \param addr Adresse de la fonction a deassembler
    ** \return Retourne rien
    */
    void    slot_func__deassemble_an_entry(unsigned long addr);

    /**
    ** \fn void slot_func__clean_an_entry_asm(unsigned long addr)
    ** \brief Gere le nettoyage d'une fonction prealablement deassemblee
    **
    ** \param addr Adresse de la fonction a nettoyer
    ** \return Retourne rien
    */
    void    slot_func__clean_an_entry(unsigned long addr);





    /**
    ** \fn void slot_func_c__text__update()
    ** \brief Gere l'actualisation du code decompile
    **
    ** \return Retourne rien
    */
    void    slot_func_c__text__update();

    /**
    ** \fn void slot_func_c__bt_decompile()
    ** \brief Gere la re-decompilation d'une fonction deja deassemblee
    **
    ** \return Retourne rien
    */
    void    slot_func_c__bt_decompile();

    /**
    ** \fn void slot_func_c__bt_save()
    ** \brief Gere l'enregistrement du code decompile
    **
    ** \return Retourne rien
    */
    void    slot_func_c__bt_save();

    /**
    ** \fn void slot_func__select_an_entry_c(unsigned long addr)
    ** \brief Gere la selction d'une fonction afin d'afficher son callgraphe
    **
    ** \param addr Adresse de la fonction a selectionner
    ** \return Retourne rien
    */
    void    slot_func__select_an_entry_c(unsigned long addr);

    /**
    ** \fn void slot_func__decompile_an_entry_asm(unsigned long addr)
    ** \brief Gere la decompilation d'une fonction prealablement deassemblee
    **
    ** \param addr Adresse de la fonction a decompiler
    ** \return Retourne rien
    */
    void    slot_func__decompile_an_entry(unsigned long addr);



    /**
    ** \fn void slot_callgraph__list_entry__update()
    ** \brief Gere l'actualisation de la liste des fonctions dans l'onglet callgraph
    **
    ** \return Retourne rien
    */
    void    slot_callgraph__list_entry__update();

    /**
    ** \fn void slot_callgraph__list_entry__clicked()
    ** \brief Gere l'affichage du call-graph d'une fonction
    **
    ** \return Retourne rien
    */
    void    slot_callgraph__list_entry__clicked();

    /**
    ** \fn void slot_callgraph__bt_generate()
    ** \brief Gere l'affichage du call-graph d'une fonction
    **
    ** \return Retourne rien
    */
    void    slot_callgraph__bt_generate();

    /**
    ** \fn void slot_callgraph__bt_save()
    ** \brief Gere la sauvegarde du call-graph d'une fonction deassemblee
    **
    ** \return Retourne rien
    */
    void    slot_callgraph__bt_save();

    /**
    ** \fn void slot_callgraph__select_an_entry(unsigned long addr)
    ** \brief Gere la selction d'une fonction afin d'afficher son callgraphe
    **
    ** \param addr Adresse de la fonction a selectionner
    ** \return Retourne rien
    */
    void    slot_callgraph__select_an_entry(unsigned long addr);





    /**
    ** \fn void slot_anal__update()
    ** \brief Slot gerant l'actualisation de la description des analyses
    **
    ** \return Retourne rien
    */
    void    slot_anal__update();

    /**
    ** \fn void slot_anal__list_type_son(QTreeWidgetItem *item, const Analyse *analyse, unsigned int profondeur=1)
    ** \brief Permet d'ajouter les rapports d'analyses au tableau afin de les afficher
    **
    ** \param item Classe contenant les infos du rapport a afficher
    ** \param analyse Analyse dont les analyses filles doivent etre affichees
    ** \param profondeur Profondeur de la recursion pour l'affichage
    ** \return Retourne rien
    */
    void    slot_anal__list_type_son(QTreeWidgetItem *item, const Analyse *analyse, unsigned int profondeur=1);

    /**
    ** \fn void slot_anal__tree_analyse_clicked()
    ** \brief Gere les clics sur la liste des analyses
    **
    ** \return Retourne rien
    */
    void    slot_anal__tree_analyse_clicked();

    /**
    ** \fn void slot_anal__bt_save()
    ** \brief Gere l'enregistrement de la partie de l'analyse selectionnees
    **
    ** \return Retourne rien
    */
    void    slot_anal__bt_save();

    /**
    ** \fn void slot_anal__bt_save_all()
    ** \brief Gere l'enregistrement de toute les analyses
    **
    ** \return Retourne rien
    */
    void    slot_anal__bt_save_all();

    /**
    ** \fn void slot_anal__bt_delete()
    ** \brief Gere la suppression de la partie de l'analyse selectionnees
    **
    ** \return Retourne rien
    */
    void    slot_anal__bt_delete();

    /**
    ** \fn void slot_anal__bt_delete_all()
    ** \brief Gere la suppression de toute les analyses
    **
    ** \return Retourne rien
    */
    void    slot_anal__bt_delete_all();

    /**
    ** \fn void slot_anal__save_analyse_rec(int f, Analyse *analyse, const std::string &title, unsigned long profondeur)
    ** \brief Fonction recursif permettant l'enregistrement d'une analyse et de ses sous-analyses
    **
    ** \param f Fichier ou enregistrer l'analyse
    ** \param analyse Analyse a enregistrer
    ** \param title Titre de l'ananlyse
    ** \param profondeur Profondeur de l'analyse/sous-analyse
    ** \return Retourne rien
    */
    void    slot_anal__save_analyse_rec(int f, Analyse *analyse, const std::string &title, unsigned long profondeur);

protected:
    /**
    ** \fn void fonction_parsing()
    ** \brief Gere l'execution des plugins de parsing
    */
    void     fonction_parsing();

    /**
    ** \fn void fonction_deasm()
    ** \brief Gere l'execution des plugins de deassemblage
    */
    void     fonction_deasm();

    /**
    ** \fn void fonction_clean()
    ** \brief Gere l'execution des plugins de nettoyage
    */
    void     fonction_clean();

    /**
    ** \fn void fonction_decompile()
    ** \brief Gere l'execution des plugins de decompilation
    */
    void     fonction_decompile();

    /**
    ** \fn void fonction_analyse()
    ** \brief Gere l'execution des plugins d'analyse
    */
    void     fonction_analyse();

private:
    /** Interface graphique du decompilateur */
    Ui::MainWindow                        *ui;
    /** Infos du binaire a analyser */
    Info                                  _info;
    /** Liste complete des plugins */
    std::map<std::string, Plugin*>        _list_plugins;

    /** Timer permettant d'actualiser la fenetre de temps en temps */
    QTimer                                _timer;
    /** Thread permettant d'executer les plugins en actualisant la fenetre */
    MyQThread                             _thread;
    /** Etat du decompilateur */
    MainWindow::eStatut                   _statut;
    /** Ancien Etat du decompilateur */
    MainWindow::eStatut                   _last_statut;

    /** Sauvegarde des entrees */
    std::set<unsigned long>               _entry_save;
    /** Sauvegarde des fonctions */
    std::map<unsigned long, Fonction*>    _function_save;

    /** Titre du popup d'erreur */
    QString                               _title_error;
    /** Texte du popup d'erreur */
    QString                               _text_error;
};

#endif
