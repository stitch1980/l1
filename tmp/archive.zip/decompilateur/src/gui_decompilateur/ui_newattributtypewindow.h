/********************************************************************************
** Form generated from reading UI file 'newattributtypewindow.ui'
**
** Created: Thu May 14 13:50:04 2015
**      by: Qt User Interface Compiler version 4.8.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_NEWATTRIBUTTYPEWINDOW_H
#define UI_NEWATTRIBUTTYPEWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QDialogButtonBox>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_DialogNewAttributType
{
public:
    QVBoxLayout *verticalLayout;
    QWidget *widget;
    QHBoxLayout *horizontalLayout;
    QLabel *label;
    QLineEdit *field_type;
    QWidget *widget_2;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_2;
    QLineEdit *field_name;
    QWidget *widget_nbs;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_3;
    QLineEdit *field_nbs;
    QDialogButtonBox *buttonBox;

    void setupUi(QDialog *DialogNewAttributType)
    {
        if (DialogNewAttributType->objectName().isEmpty())
            DialogNewAttributType->setObjectName(QString::fromUtf8("DialogNewAttributType"));
        DialogNewAttributType->resize(400, 214);
        verticalLayout = new QVBoxLayout(DialogNewAttributType);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        widget = new QWidget(DialogNewAttributType);
        widget->setObjectName(QString::fromUtf8("widget"));
        horizontalLayout = new QHBoxLayout(widget);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        label = new QLabel(widget);
        label->setObjectName(QString::fromUtf8("label"));

        horizontalLayout->addWidget(label);

        field_type = new QLineEdit(widget);
        field_type->setObjectName(QString::fromUtf8("field_type"));

        horizontalLayout->addWidget(field_type);


        verticalLayout->addWidget(widget);

        widget_2 = new QWidget(DialogNewAttributType);
        widget_2->setObjectName(QString::fromUtf8("widget_2"));
        horizontalLayout_2 = new QHBoxLayout(widget_2);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        label_2 = new QLabel(widget_2);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        horizontalLayout_2->addWidget(label_2);

        field_name = new QLineEdit(widget_2);
        field_name->setObjectName(QString::fromUtf8("field_name"));

        horizontalLayout_2->addWidget(field_name);


        verticalLayout->addWidget(widget_2);

        widget_nbs = new QWidget(DialogNewAttributType);
        widget_nbs->setObjectName(QString::fromUtf8("widget_nbs"));
        horizontalLayout_3 = new QHBoxLayout(widget_nbs);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        label_3 = new QLabel(widget_nbs);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        horizontalLayout_3->addWidget(label_3);

        field_nbs = new QLineEdit(widget_nbs);
        field_nbs->setObjectName(QString::fromUtf8("field_nbs"));

        horizontalLayout_3->addWidget(field_nbs);


        verticalLayout->addWidget(widget_nbs);

        buttonBox = new QDialogButtonBox(DialogNewAttributType);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);

        verticalLayout->addWidget(buttonBox);


        retranslateUi(DialogNewAttributType);
        QObject::connect(buttonBox, SIGNAL(accepted()), DialogNewAttributType, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), DialogNewAttributType, SLOT(reject()));
        QObject::connect(DialogNewAttributType, SIGNAL(accepted()), DialogNewAttributType, SLOT(slot_validate()));
        QObject::connect(field_nbs, SIGNAL(textEdited(QString)), DialogNewAttributType, SLOT(slot_check_formulaire()));
        QObject::connect(field_name, SIGNAL(textEdited(QString)), DialogNewAttributType, SLOT(slot_check_formulaire()));
        QObject::connect(field_type, SIGNAL(textEdited(QString)), DialogNewAttributType, SLOT(slot_check_formulaire()));

        QMetaObject::connectSlotsByName(DialogNewAttributType);
    } // setupUi

    void retranslateUi(QDialog *DialogNewAttributType)
    {
        DialogNewAttributType->setWindowTitle(QApplication::translate("DialogNewAttributType", "Dialog", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("DialogNewAttributType", "Type :", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("DialogNewAttributType", "Nom :", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("DialogNewAttributType", "Nombre :", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class DialogNewAttributType: public Ui_DialogNewAttributType {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_NEWATTRIBUTTYPEWINDOW_H
