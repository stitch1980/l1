/****************************************************************************
** Meta object code from reading C++ file 'newtypewindow.h'
**
** Created: Thu May 14 13:51:02 2015
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "newtypewindow.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'newtypewindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_NewTypeWindow[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       8,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      15,   14,   14,   14, 0x0a,
      31,   14,   14,   14, 0x0a,
      55,   14,   14,   14, 0x0a,
      79,   14,   14,   14, 0x0a,
      93,   14,   14,   14, 0x0a,
     108,   14,   14,   14, 0x0a,
     125,   14,   14,   14, 0x0a,
     138,   14,   14,   14, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_NewTypeWindow[] = {
    "NewTypeWindow\0\0slot_validate()\0"
    "slot_check_formulaire()\0slot_attribut_clicked()\0"
    "slot_bt_new()\0slot_bt_edit()\0"
    "slot_bt_delete()\0slot_bt_up()\0"
    "slot_bt_down()\0"
};

void NewTypeWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        NewTypeWindow *_t = static_cast<NewTypeWindow *>(_o);
        switch (_id) {
        case 0: _t->slot_validate(); break;
        case 1: _t->slot_check_formulaire(); break;
        case 2: _t->slot_attribut_clicked(); break;
        case 3: _t->slot_bt_new(); break;
        case 4: _t->slot_bt_edit(); break;
        case 5: _t->slot_bt_delete(); break;
        case 6: _t->slot_bt_up(); break;
        case 7: _t->slot_bt_down(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObjectExtraData NewTypeWindow::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject NewTypeWindow::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_NewTypeWindow,
      qt_meta_data_NewTypeWindow, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &NewTypeWindow::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *NewTypeWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *NewTypeWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_NewTypeWindow))
        return static_cast<void*>(const_cast< NewTypeWindow*>(this));
    return QDialog::qt_metacast(_clname);
}

int NewTypeWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 8)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 8;
    }
    return _id;
}
static const uint qt_meta_data_NewAttributTypeWindow[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       2,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      23,   22,   22,   22, 0x0a,
      39,   22,   22,   22, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_NewAttributTypeWindow[] = {
    "NewAttributTypeWindow\0\0slot_validate()\0"
    "slot_check_formulaire()\0"
};

void NewAttributTypeWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        NewAttributTypeWindow *_t = static_cast<NewAttributTypeWindow *>(_o);
        switch (_id) {
        case 0: _t->slot_validate(); break;
        case 1: _t->slot_check_formulaire(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObjectExtraData NewAttributTypeWindow::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject NewAttributTypeWindow::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_NewAttributTypeWindow,
      qt_meta_data_NewAttributTypeWindow, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &NewAttributTypeWindow::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *NewAttributTypeWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *NewAttributTypeWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_NewAttributTypeWindow))
        return static_cast<void*>(const_cast< NewAttributTypeWindow*>(this));
    return QDialog::qt_metacast(_clname);
}

int NewAttributTypeWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 2)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 2;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
