#ifndef    SAVESEGMENTWINDOW_H
#define    SAVESEGMENTWINDOW_H

#include    <stdio.h>
#include    <unistd.h>
#include    <sys/types.h>
#include    <sys/stat.h>
#include    <fcntl.h>

#include    <QMainWindow>
#include    <QApplication>
#include    <QtGui>
#include    <QDialog>

#include    "Section.hpp"

namespace Ui
{
    class Dialog3;
}


class SaveSegmentWindow : public QDialog
{
    Q_OBJECT
public:
    explicit SaveSegmentWindow(unsigned long addr, const unsigned char *data, unsigned long size, QWidget *parent = 0);
    ~SaveSegmentWindow();
    
public slots:
    /**
    ** \fn void slot_validate()
    ** \brief Gere la validation de l'enregistrement
    **
    ** \return Retourne rien
    */
    void    slot_validate();

protected:
    /**
    ** \fn void saveSegmentInBinaire(int f) const
    ** \brief Gere l'enregistrement du segment au format binaire
    **
    ** \param f Fichier ou enregister le segment
    ** \return Retourne rien
    */
    void    saveSegmentInBinaire(int f) const;

    /**
    ** \fn void saveSegmentInHexdump(int f) const
    ** \brief Gere l'enregistrement du segment au format hexdump (adresse+hexa+ASCII)
    **
    ** \param f Fichier ou enregister le segment
    ** \return Retourne rien
    */
    void    saveSegmentInHexdump(int f) const;

    /**
    ** \fn void saveSegmentInShellcode(int f) const
    ** \brief Gere l'enregistrement du segment au shellcode ("\x00\xff\x11")
    **
    ** \param f Fichier ou enregister le segment
    ** \return Retourne rien
    */
    void    saveSegmentInShellcode(int f) const;

protected:
    /** Adresse du segment a sauvegarder */
    unsigned long          _addr;
    /** Contenu du segment a sauvegarder */
    const unsigned char    *_data;
    /** Taille du segment a sauvegarder */
    unsigned long          _size;

    /** Interface graphique du menu */
    Ui::Dialog3            *ui;
};

#endif
