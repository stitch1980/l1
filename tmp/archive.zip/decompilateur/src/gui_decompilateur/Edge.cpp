#include    "Edge.hpp"
#include    "INode.hpp"

#define PI        3.14159265358979
#define TWO_PI    6.28318530717958


/**
** \fn Edge(INode *sourceNode, INode *destNode)
** \brief Constructeur de la classe Edge permettant de tracer un trait entre daux actions
**
** \param sourceNode Node d'ou part le lien entre les deux actions
** \param destNode Node ou arrive le lien entre les deux actions (peut etre NULL)
*/
Edge::Edge(INode *sourceNode, INode *destNode):
    _source(sourceNode), _dest(destNode),
    _sourcePoint(), _destPoint(),
    _arrowSize(10)
{
    if (this->_source != NULL)
        this->_source->add_edge(this);
    if (this->_dest != NULL)
        this->_dest->add_edge(this);

    this->setAcceptedMouseButtons(0);
    this->adjust();
}

/**
** \fn ~Edge()
** \brief Destructeur de la classe Edge
*/
Edge::~Edge()
{
}


/**
** \fn INode *get_source_node() const
** \brief Assesseur permettant d'acceder au Node ayant cree la fleche
**
** \return Retourne un pointeur sur le Node ayant cree la fleche
*/
INode        *Edge::get_source_node() const
{
    return (this->_source);
}

/**
** \fn INode *get_dest_node() const
** \brief Assesseur permettant d'acceder au Node cible
**
** \return Retourne un pointeur sur le Node cible
*/
INode        *Edge::get_dest_node() const
{
    return (this->_dest);
}

/**
** \fn int type() const
** \brief Fonction permettant de connaitre le type de l'objet
**
** \return Retourne le type de l'objet
*/
int         Edge::type() const
{
    return (Type);
}

/**
**
** \fn void adjust()
** \brief Gere l'actualisation des coordonnees de la fleche
**
** \return Retourne rien
*/
void         Edge::adjust()
{
    if (this->_source != NULL)
    {
        QLineF    line;

        line.setP1(this->_source->get_posOutput());
        line.setP2(this->_dest->get_posInput());
        qreal length = line.length();

        prepareGeometryChange();

        if (length > qreal(1.))
        {
            this->_sourcePoint = line.p1();
            this->_destPoint = line.p2();
        }
        else
            this->_sourcePoint = this->_destPoint = line.p1();
    }
}

/**
** \fn boundingRect() const
** \brief Modifie la zone d'affichage de la fleche
**
** \return Retourne les dimensions de la nouvelle zone d'affichage de la fleche
*/
QRectF       Edge::boundingRect() const
{
    if (this->_source == NULL)
        return (QRectF());

    qreal    penWidth = 1;
    qreal    extra = (penWidth + this->_arrowSize) / 2.0;

    return QRectF(this->_sourcePoint,
                  QSizeF(this->_destPoint.x() - this->_sourcePoint.x(),
                        this->_destPoint.y() - this->_sourcePoint.y()))
                  .normalized().adjusted(-extra, -extra, extra, extra);
}

/**
** \fn QPainterPath shape() const
** \brief Modifie la zone de selection de la fleche afin qu'on ne puisse pas la toucher
**
** \return Retourne la zone de selection de la fleche
*/
QPainterPath Edge::shape() const
{
    QPainterPath    path;

    path.addRect(0, 0, 0, 0);
    return (path);
}

/**
** \fn void paint(QPainter *painter, const QStyleOptionGraphicsItem *, QWidget *)
** \brief Gere l'affichage de la fleche
**
** \param painter Objet permettant de dessiner la fleche
** \return Retourne rien
*/
void         Edge::paint(QPainter *painter, const QStyleOptionGraphicsItem *, QWidget *)
{
    QPointF    pt_src;
    QPointF    pt_dst;
    QPointF    pt1;
    QPointF    pt2;
    QLineF     line;/*(this->_sourcePoint, this->_destPoint);
    if (qFuzzyCompare(line.length(), qreal(0.1)))
        return ;*/

    /* Affiche la ligne * /
    pt_src = this->_sourcePoint;
    pt_src.setY(pt_src.y() + 10);
    pt_dst = this->_destPoint;
    pt_dst.setY(pt_dst.y() - 20);
    painter->setPen(QPen(Qt::black, 1, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin));


    / * Affiche le debut de la ligne * /
    line.setPoints(this->_sourcePoint, pt_src);
    painter->drawLine(line);


    / * Affiche le millieu de la ligne si la source est au dessus de la destination * /
    if (pt_src.y() < pt_dst.y())
    {
        qreal    distance_x = fabs(pt_src.x() - pt_dst.x());
        qreal    distance_y = fabs(pt_src.y() - pt_dst.y());
        qreal    pourcentage = tanhf(distance_x / (distance_y*10 + 1));

        / * On descend de la moitie de la distance * /
        pt1 = pt_src;
        pt2 = pt_src;
        pt2.setY(pt_src.y() + pourcentage * distance_y);
        line.setPoints(pt1, pt2);
        painter->drawLine(line);

        / * On fait le mouvement lateral * /
        pt1 = pt_src;
        pt2 = pt_dst;
        pt1.setY(pt_src.y() + pourcentage * distance_y);
        pt2.setY(pt_src.y() + pourcentage * distance_y);
        line.setPoints(pt1, pt2);
        painter->drawLine(line);

        / * On descend jusqu'a la dest * /
        pt1 = pt_dst;
        pt1.setY(pt_src.y() + pourcentage * distance_y);
        pt2 = pt_dst;
        line.setPoints(pt1, pt2);
        painter->drawLine(line);
    }
    else*/
    {
pt_src = this->_sourcePoint;
pt_dst = this->_destPoint;
        line.setPoints(pt_src, pt_dst);
        painter->drawLine(line);
    }


    /* Affiche la fin de la ligne * /
    line.setPoints(pt_dst, this->_destPoint);
    painter->drawLine(line);*/


    /* Affiche la fleche */
    double angle = ::acos(line.dx() / line.length());
    if (line.dy() >= 0)
        angle = TWO_PI - angle;

    QPointF    P1 = this->_destPoint + QPointF(sin(angle - PI / 3) * this->_arrowSize,
                                               cos(angle - PI / 3) * this->_arrowSize);
    QPointF    P2 = this->_destPoint + QPointF(sin(angle - PI + PI / 3) * this->_arrowSize,
                                               cos(angle - PI + PI / 3) * this->_arrowSize);

    painter->setBrush(Qt::black);
    painter->drawPolygon(QPolygonF() << line.p2() << P1 << P2);
}

