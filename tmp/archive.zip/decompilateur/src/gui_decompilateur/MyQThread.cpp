#include    "MyQThread.hpp"
#include    "mainwindow.h"


/**
** \fn MyQThread()
** \brief Constructeur par defaut du Thread
*/
MyQThread::MyQThread(): QThread(NULL),
    _ptr(NULL),
    _func(NULL),
    _mutex()
{
}

/**
** \fn MyQThread(MainWindow *ptr, void (MainWindow::*func)(), QObject *parent=0)
** \brief Constructeur du Thread
**
** \param ptr Objet a utiliser pour executet la fonction
** \param func Fonction a executer
** \param parent Parent du thread
*/
MyQThread::MyQThread(MainWindow *ptr, void (MainWindow::*func)(), QObject *parent): QThread(parent),
    _ptr(ptr),
    _func(func),
    _mutex()
{
    this->_ptr = ptr;
    this->_func = func;
}

/**
** \fn MyQThread(const MyQThread &t)
** \brief Constructeur par copie du Thread
**
** \param t Thread a copier
*/
MyQThread::MyQThread(const MyQThread &t): QThread(NULL),
    _ptr(t._ptr),
    _func(t._func),
    _mutex()
{
}


/**
** \fn MyQThread &operator = (const MyQThread &t)
** \brief Surcharge de l'operateur = pour le thread
**
** \param t Thread a copier
** \return Retourne une reference sur le thread
*/
MyQThread     &MyQThread::operator = (const MyQThread &t)
{
    this->_mutex.lock();

    this->_ptr = t._ptr;
    this->_func = t._func;

    this->_mutex.unlock();
    return (*this);
}


/**
** \fn void set_ptr(MainWindow *ptr)
** \brief Assesseur permettant de modifier l'objet a utiliser pour appeler la fonction
**
** \param ptr Objet a utiliser pour appeler la fonction
** \return Retourne rien
*/
void    MyQThread::set_ptr(MainWindow *ptr)
{
    this->_mutex.lock();
    this->_ptr = ptr;
    this->_mutex.unlock();
}

/**
** \fn void set_func(void (MainWindow::*func)())
** \brief Assesseur permettant de modifier la fonction a appeler durant l'execution du thread
**
** \param func Fonction a appeler durant l'execution du thread
** \return Retourne rien
*/
void    MyQThread::set_func(void (MainWindow::*func)())
{
    this->_mutex.lock();
    this->_func = func;
    this->_mutex.unlock();
}

/**
** \fn void run()
** \brief Permet d'executer la fonction passee en perametre lors de la construction
**
** \return Retourne rien
*/
void    MyQThread::run()
{ printf("deasm aaaaaaaa\n");
    this->_mutex.lock(); printf("deasm bbbbbbbbbbbbbbbb\n");
    if ((this->_func != NULL) && (this->_ptr != NULL))
        ((this->_ptr)->*(this->_func))();
    this->_mutex.unlock();
}

