#include    "Edge.hpp"
#include    "INode.hpp"
#include    "ViewerGraph.hpp"



/**
** \fn INode(ViewerGraph *viewer)
** \brief Constructeur d'une Node basique
**
** \param viewer Pointeur sur la classe gerant l'affichage du graphe
*/
INode::INode(ViewerGraph *viewer): QGraphicsObject(),
    _graph(NULL)
{
    if ((this->_graph = viewer) != NULL)
    {
        this->setFlag(QGraphicsItem::ItemIsFocusable);
        this->setFlag(QGraphicsItem::ItemIsMovable);
        this->setFlag(QGraphicsItem::ItemSendsGeometryChanges);
        this->setCacheMode(DeviceCoordinateCache);
        this->setZValue(-1);
    }
}

/**
** \fn ~INode()
** \brief Destructeur de la Node
*/
INode::~INode()
{
}



/**
** \fn void add_edge(Edge *e)
** \brief Gere l'ajout d'un edge connecte au Node
**
** \brief e Edge a ajouter a la liste des edges connectes au Node
** \return Retourne rien
*/
void    INode::add_edge(Edge *e)
{
    if (e != NULL)
        this->_list_edge.insert(e);
}

/**
** \fn void del_edge(Edge *e)
** \brief Gere la suppression d'un edge connecte au Node
**
** \brief e Edge a supprimer de la liste des edges connectes au Node
** \return Retourne rien
*/
void   INode:: del_edge(Edge *e)
{
    std::set<Edge*>::iterator    it;

    if ((it = this->_list_edge.find(e)) != this->_list_edge.end())
        this->_list_edge.erase(it);
}

/**
** \fn QVariant itemChange(GraphicsItemChange change, const QVariant &value)
** \brief Gere l'actualisation des Edges lorsqu'un Node est deplace
**
** \param change Description du type de changement
** \param value Reference sur la variation
** \return Retourne la variation
*/
QVariant     INode::itemChange(GraphicsItemChange change, const QVariant &value)
{
    switch (change)
    {
        case ItemPositionHasChanged:
            for (std::set<Edge*>::iterator it=this->_list_edge.begin();
                 it!=this->_list_edge.end();
                 it++)
                (*it)->adjust();
            return (this->pos());
        default:
            break;
    };

    return (QGraphicsItem::itemChange(change, value));
}

/**
** \fn void mousePressEvent(QGraphicsSceneMouseEvent *event)
** \brief Gestion des clics de la souris
**
** \param event Pointeur sur la description de l'evenement
** \return Retourne rien
*/
void         INode::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    QGraphicsObject::mousePressEvent(event);
}

/**
** \fn void mouseReleaseEvent(QGraphicsSceneMouseEvent *event)
** \brief Fonction gerant les clics de la souris
**
** \param event Pointeur sur la description de l'evenement
** \return Retourne rien
*/
void         INode::mouseReleaseEvent(QGraphicsSceneMouseEvent *event)
{
    this->update();
    QGraphicsItem::mouseReleaseEvent(event);
}

