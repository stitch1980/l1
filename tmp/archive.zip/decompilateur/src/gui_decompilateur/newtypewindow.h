#ifndef NEWTYPEWINDOW_H
#define NEWTYPEWINDOW_H

#include    <QMainWindow>
#include    <QApplication>
#include    <QtGui>
#include    <QDialog>

#include    "Info.hpp"
#include    "Calcul.hpp"


namespace Ui
{
    class DialogNewType;
}

class NewTypeWindow : public QDialog
{
    Q_OBJECT
public:
    explicit NewTypeWindow(const std::string &name, PrototypeT *proto, QWidget *parent = 0);
    ~NewTypeWindow();
    
public slots:
    /**
    ** \fn void slot_validate()
    ** \brief Gere la validation des changements effectuee par le menu
    **
    ** \return Retourne rien
    */
    void    slot_validate();

    /**
    ** \fn void slot_check_formulaire()
    ** \brief Slot Permettant de verifier que le contenu des champs est valide
    **
    ** \return Retourne rien
    */
    void    slot_check_formulaire();

    /**
    ** \fn void slot_bt_attribut_clicked()
    ** \brief Gere les clics dans la liste des attributs
    **
    ** \return Retourne rien
    */
    void    slot_attribut_clicked();

    /**
    ** \fn void slot_bt_new()
    ** \brief Gere l'ajout d'un attribut
    **
    ** \return Retourne rien
    */
    void    slot_bt_new();

    /**
    ** \fn void slot_bt_edit()
    ** \brief Gere la modification d'un attribut
    **
    ** \return Retourne rien
    */
    void    slot_bt_edit();

    /**
    ** \fn void slot_bt_delete()
    ** \brief Gere la suppression d'un attribut
    **
    ** \return Retourne rien
    */
    void    slot_bt_delete();

    /**
    ** \fn void slot_bt_up()
    ** \brief Gere le deplacement d'un attribut vers le haut
    **
    ** \return Retourne rien
    */
    void    slot_bt_up();

    /**
    ** \fn void slot_bt_down()
    ** \brief Gere le deplacement d'un attribut vers le bas
    **
    ** \return Retourne rien
    */
    void    slot_bt_down();

protected:
    /**
    ** \fn std::string extract_name_from_tablename(const std::string &s)
    ** \brief Gere l'extraction d'un nom de variables de chaines comme "mon_nom[42]"
    **
    ** \param Nom de variable a traiter
    ** \return Retourne le nom de variable epure
    */
    std::string    extract_name_from_tablename(const std::string &s) const;

    /**
    ** \fn unsigned long extract_nbs_from_tablename(const std::string &s)
    ** \brief Gere l'extraction du nombre d'elements de chaines comme "mon_nom[42]"
    **
    ** \param Nom de variable a traiter
    ** \return Retourne le nombre d'elements du tableau si OK, 1 sinon
    */
    unsigned long    extract_nbs_from_tablename(const std::string &s) const;

protected:
    /** Nom du type de variables */
    std::string          _name;
    /** Pointeur sur le gestionnaire de definition de type */
    PrototypeT           *_proto;

    /** Interface graphique du menu */
    Ui::DialogNewType    *ui;

};



namespace Ui
{
    class DialogNewAttributType;
}

class NewAttributTypeWindow : public QDialog
{
    Q_OBJECT
public:
    explicit NewAttributTypeWindow(const std::string &parent_type, std::string &type, std::string &name, unsigned long &nbs, PrototypeT *proto, QWidget *parent = 0);
    ~NewAttributTypeWindow();

public slots:
    /**
    ** \fn void slot_validate()
    ** \brief Gere la validation des changements effectuee par le menu
    **
    ** \return Retourne rien
    */
    void    slot_validate();

    /**
    ** \fn void slot_check_formulaire()
    ** \brief Slot Permettant de verifier que le contenu des champs est valide
    **
    ** \return Retourne rien
    */
    void    slot_check_formulaire();

protected:
    /** Type de la structure devant contenir l'attribut */
    std::string                  _parent_type;
    /** Type de l'attribut */
    std::string                  *_type;
    /** Nom de l'attribut */
    std::string                  *_name;
    /** Nombre d'elements de l'attribut (pour les tableaux) */
    unsigned long                *_nbs;
    /** Pointeur sur le gestionnaire de definition de type */
    PrototypeT                   *_proto;

    /** Interface graphique du menu */
    Ui::DialogNewAttributType    *ui;

};
#endif
