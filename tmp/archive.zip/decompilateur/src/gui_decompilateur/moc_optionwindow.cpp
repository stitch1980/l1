/****************************************************************************
** Meta object code from reading C++ file 'optionwindow.h'
**
** Created: Thu May 14 13:50:53 2015
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "optionwindow.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'optionwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_OptionWindow[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       6,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      14,   13,   13,   13, 0x0a,
      30,   13,   13,   13, 0x0a,
      49,   13,   13,   13, 0x0a,
      71,   13,   13,   13, 0x0a,
     100,   13,   13,   13, 0x0a,
     123,   13,   13,   13, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_OptionWindow[] = {
    "OptionWindow\0\0slot_validate()\0"
    "slot_plugin__new()\0slot_plugin__delete()\0"
    "slot_plugin__option_plugin()\0"
    "slot_plugin__execute()\0slot_plugin__clicked()\0"
};

void OptionWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        OptionWindow *_t = static_cast<OptionWindow *>(_o);
        switch (_id) {
        case 0: _t->slot_validate(); break;
        case 1: _t->slot_plugin__new(); break;
        case 2: _t->slot_plugin__delete(); break;
        case 3: _t->slot_plugin__option_plugin(); break;
        case 4: _t->slot_plugin__execute(); break;
        case 5: _t->slot_plugin__clicked(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObjectExtraData OptionWindow::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject OptionWindow::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_OptionWindow,
      qt_meta_data_OptionWindow, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &OptionWindow::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *OptionWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *OptionWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_OptionWindow))
        return static_cast<void*>(const_cast< OptionWindow*>(this));
    return QDialog::qt_metacast(_clname);
}

int OptionWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 6)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 6;
    }
    return _id;
}
static const uint qt_meta_data_OptionPluginOptionWindow[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       4,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      26,   25,   25,   25, 0x0a,
      42,   25,   25,   25, 0x0a,
      55,   25,   25,   25, 0x0a,
      74,   25,   25,   25, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_OptionPluginOptionWindow[] = {
    "OptionPluginOptionWindow\0\0slot_validate()\0"
    "slot_check()\0slot_option__new()\0"
    "slot_option__delete()\0"
};

void OptionPluginOptionWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        OptionPluginOptionWindow *_t = static_cast<OptionPluginOptionWindow *>(_o);
        switch (_id) {
        case 0: _t->slot_validate(); break;
        case 1: _t->slot_check(); break;
        case 2: _t->slot_option__new(); break;
        case 3: _t->slot_option__delete(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObjectExtraData OptionPluginOptionWindow::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject OptionPluginOptionWindow::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_OptionPluginOptionWindow,
      qt_meta_data_OptionPluginOptionWindow, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &OptionPluginOptionWindow::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *OptionPluginOptionWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *OptionPluginOptionWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_OptionPluginOptionWindow))
        return static_cast<void*>(const_cast< OptionPluginOptionWindow*>(this));
    return QDialog::qt_metacast(_clname);
}

int OptionPluginOptionWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 4)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 4;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
