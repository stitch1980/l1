/********************************************************************************
** Form generated from reading UI file 'GetDescriptionWindow.ui'
**
** Created: Thu May 14 13:50:04 2015
**      by: Qt User Interface Compiler version 4.8.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GETDESCRIPTIONWINDOW_H
#define UI_GETDESCRIPTIONWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QDialogButtonBox>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QTextEdit>
#include <QtGui/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_GetDescriptionDialog
{
public:
    QVBoxLayout *verticalLayout;
    QLabel *label_titre;
    QTextEdit *text_description;
    QDialogButtonBox *buttonBox;

    void setupUi(QDialog *GetDescriptionDialog)
    {
        if (GetDescriptionDialog->objectName().isEmpty())
            GetDescriptionDialog->setObjectName(QString::fromUtf8("GetDescriptionDialog"));
        GetDescriptionDialog->resize(400, 300);
        verticalLayout = new QVBoxLayout(GetDescriptionDialog);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        label_titre = new QLabel(GetDescriptionDialog);
        label_titre->setObjectName(QString::fromUtf8("label_titre"));

        verticalLayout->addWidget(label_titre);

        text_description = new QTextEdit(GetDescriptionDialog);
        text_description->setObjectName(QString::fromUtf8("text_description"));

        verticalLayout->addWidget(text_description);

        buttonBox = new QDialogButtonBox(GetDescriptionDialog);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);

        verticalLayout->addWidget(buttonBox);


        retranslateUi(GetDescriptionDialog);
        QObject::connect(buttonBox, SIGNAL(accepted()), GetDescriptionDialog, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), GetDescriptionDialog, SLOT(reject()));
        QObject::connect(GetDescriptionDialog, SIGNAL(accepted()), GetDescriptionDialog, SLOT(slot_validate()));

        QMetaObject::connectSlotsByName(GetDescriptionDialog);
    } // setupUi

    void retranslateUi(QDialog *GetDescriptionDialog)
    {
        GetDescriptionDialog->setWindowTitle(QApplication::translate("GetDescriptionDialog", "Dialog", 0, QApplication::UnicodeUTF8));
        label_titre->setText(QApplication::translate("GetDescriptionDialog", "Description de la fonction :", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class GetDescriptionDialog: public Ui_GetDescriptionDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GETDESCRIPTIONWINDOW_H
