/********************************************************************************
** Form generated from reading UI file 'newsegmentwindow.ui'
**
** Created: Thu May 14 13:50:04 2015
**      by: Qt User Interface Compiler version 4.8.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_NEWSEGMENTWINDOW_H
#define UI_NEWSEGMENTWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCheckBox>
#include <QtGui/QDialog>
#include <QtGui/QDialogButtonBox>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QSlider>
#include <QtGui/QSpacerItem>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>
#include "HexEditor.hpp"

QT_BEGIN_NAMESPACE

class Ui_Dialog2
{
public:
    QVBoxLayout *verticalLayout;
    QWidget *widget;
    QHBoxLayout *horizontalLayout;
    QWidget *widget_2;
    QVBoxLayout *verticalLayout_2;
    QWidget *widget_4;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label;
    QSpacerItem *horizontalSpacer_3;
    QLineEdit *field_addr;
    QWidget *widget_5;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_2;
    QSpacerItem *horizontalSpacer_2;
    QLineEdit *field_size;
    QWidget *widget_6;
    QHBoxLayout *horizontalLayout_4;
    QLabel *label_3;
    QSpacerItem *horizontalSpacer;
    QCheckBox *field_r;
    QCheckBox *field_w;
    QCheckBox *field_x;
    QCheckBox *field_a;
    QSpacerItem *verticalSpacer;
    QPushButton *bt_use_file;
    QWidget *widget_3;
    QHBoxLayout *horizontalLayout_6;
    QWidget *widget_7;
    QHBoxLayout *horizontalLayout_5;
    HexEditor *field_data;
    QWidget *widget_8;
    QVBoxLayout *verticalLayout_3;
    QPushButton *field_scrollbar_up;
    QSlider *field_scrollbar_data;
    QPushButton *field_scrollbar_down;
    QDialogButtonBox *buttonBox;

    void setupUi(QDialog *Dialog2)
    {
        if (Dialog2->objectName().isEmpty())
            Dialog2->setObjectName(QString::fromUtf8("Dialog2"));
        Dialog2->resize(1007, 572);
        verticalLayout = new QVBoxLayout(Dialog2);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        widget = new QWidget(Dialog2);
        widget->setObjectName(QString::fromUtf8("widget"));
        horizontalLayout = new QHBoxLayout(widget);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        widget_2 = new QWidget(widget);
        widget_2->setObjectName(QString::fromUtf8("widget_2"));
        widget_2->setMaximumSize(QSize(600, 16777215));
        verticalLayout_2 = new QVBoxLayout(widget_2);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        widget_4 = new QWidget(widget_2);
        widget_4->setObjectName(QString::fromUtf8("widget_4"));
        horizontalLayout_2 = new QHBoxLayout(widget_4);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        label = new QLabel(widget_4);
        label->setObjectName(QString::fromUtf8("label"));

        horizontalLayout_2->addWidget(label);

        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_3);

        field_addr = new QLineEdit(widget_4);
        field_addr->setObjectName(QString::fromUtf8("field_addr"));

        horizontalLayout_2->addWidget(field_addr);


        verticalLayout_2->addWidget(widget_4);

        widget_5 = new QWidget(widget_2);
        widget_5->setObjectName(QString::fromUtf8("widget_5"));
        horizontalLayout_3 = new QHBoxLayout(widget_5);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        label_2 = new QLabel(widget_5);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        horizontalLayout_3->addWidget(label_2);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_2);

        field_size = new QLineEdit(widget_5);
        field_size->setObjectName(QString::fromUtf8("field_size"));

        horizontalLayout_3->addWidget(field_size);


        verticalLayout_2->addWidget(widget_5);

        widget_6 = new QWidget(widget_2);
        widget_6->setObjectName(QString::fromUtf8("widget_6"));
        horizontalLayout_4 = new QHBoxLayout(widget_6);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        label_3 = new QLabel(widget_6);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        horizontalLayout_4->addWidget(label_3);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer);

        field_r = new QCheckBox(widget_6);
        field_r->setObjectName(QString::fromUtf8("field_r"));

        horizontalLayout_4->addWidget(field_r);

        field_w = new QCheckBox(widget_6);
        field_w->setObjectName(QString::fromUtf8("field_w"));

        horizontalLayout_4->addWidget(field_w);

        field_x = new QCheckBox(widget_6);
        field_x->setObjectName(QString::fromUtf8("field_x"));

        horizontalLayout_4->addWidget(field_x);

        field_a = new QCheckBox(widget_6);
        field_a->setObjectName(QString::fromUtf8("field_a"));

        horizontalLayout_4->addWidget(field_a);


        verticalLayout_2->addWidget(widget_6);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_2->addItem(verticalSpacer);

        bt_use_file = new QPushButton(widget_2);
        bt_use_file->setObjectName(QString::fromUtf8("bt_use_file"));

        verticalLayout_2->addWidget(bt_use_file);


        horizontalLayout->addWidget(widget_2);

        widget_3 = new QWidget(widget);
        widget_3->setObjectName(QString::fromUtf8("widget_3"));
        horizontalLayout_6 = new QHBoxLayout(widget_3);
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        widget_7 = new QWidget(widget_3);
        widget_7->setObjectName(QString::fromUtf8("widget_7"));
        horizontalLayout_5 = new QHBoxLayout(widget_7);
        horizontalLayout_5->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));

        horizontalLayout_6->addWidget(widget_7);

        field_data = new HexEditor(widget_3);
        field_data->setObjectName(QString::fromUtf8("field_data"));
        field_data->setMinimumSize(QSize(400, 0));
        QFont font;
        font.setFamily(QString::fromUtf8("FreeMono"));
        font.setBold(true);
        font.setWeight(75);
        field_data->setFont(font);

        horizontalLayout_6->addWidget(field_data);

        widget_8 = new QWidget(widget_3);
        widget_8->setObjectName(QString::fromUtf8("widget_8"));
        verticalLayout_3 = new QVBoxLayout(widget_8);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        field_scrollbar_up = new QPushButton(widget_8);
        field_scrollbar_up->setObjectName(QString::fromUtf8("field_scrollbar_up"));
        field_scrollbar_up->setMaximumSize(QSize(20, 16777215));
        field_scrollbar_up->setAutoRepeat(true);

        verticalLayout_3->addWidget(field_scrollbar_up);

        field_scrollbar_data = new QSlider(widget_8);
        field_scrollbar_data->setObjectName(QString::fromUtf8("field_scrollbar_data"));
        field_scrollbar_data->setMaximum(0);
        field_scrollbar_data->setInvertedAppearance(true);

        verticalLayout_3->addWidget(field_scrollbar_data);

        field_scrollbar_down = new QPushButton(widget_8);
        field_scrollbar_down->setObjectName(QString::fromUtf8("field_scrollbar_down"));
        field_scrollbar_down->setMaximumSize(QSize(20, 16777215));
        field_scrollbar_down->setAutoRepeat(true);

        verticalLayout_3->addWidget(field_scrollbar_down);


        horizontalLayout_6->addWidget(widget_8);


        horizontalLayout->addWidget(widget_3);


        verticalLayout->addWidget(widget);

        buttonBox = new QDialogButtonBox(Dialog2);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);

        verticalLayout->addWidget(buttonBox);


        retranslateUi(Dialog2);
        QObject::connect(buttonBox, SIGNAL(accepted()), Dialog2, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), Dialog2, SLOT(reject()));
        QObject::connect(bt_use_file, SIGNAL(clicked()), Dialog2, SLOT(slot_get_filename()));
        QObject::connect(Dialog2, SIGNAL(accepted()), Dialog2, SLOT(slot_validate()));
        QObject::connect(field_addr, SIGNAL(textChanged(QString)), Dialog2, SLOT(slot_check_formulaire()));
        QObject::connect(field_size, SIGNAL(textChanged(QString)), Dialog2, SLOT(slot_check_formulaire()));
        QObject::connect(field_scrollbar_data, SIGNAL(valueChanged(int)), field_data, SLOT(slot_resize()));
        QObject::connect(field_scrollbar_up, SIGNAL(clicked()), field_data, SLOT(slot_show_up()));
        QObject::connect(field_scrollbar_down, SIGNAL(clicked()), field_data, SLOT(slot_show_down()));

        QMetaObject::connectSlotsByName(Dialog2);
    } // setupUi

    void retranslateUi(QDialog *Dialog2)
    {
        Dialog2->setWindowTitle(QApplication::translate("Dialog2", "Dialog2", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("Dialog2", "Adresse du segment en m\303\251moire (hexa) :", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("Dialog2", "Taille du segment en m\303\251moire : ", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("Dialog2", "Permissions : ", 0, QApplication::UnicodeUTF8));
        field_r->setText(QApplication::translate("Dialog2", "R", 0, QApplication::UnicodeUTF8));
        field_w->setText(QApplication::translate("Dialog2", "W", 0, QApplication::UnicodeUTF8));
        field_x->setText(QApplication::translate("Dialog2", "X", 0, QApplication::UnicodeUTF8));
        field_a->setText(QApplication::translate("Dialog2", "A", 0, QApplication::UnicodeUTF8));
        bt_use_file->setText(QApplication::translate("Dialog2", "Utiliser le contenu d'un fichier", 0, QApplication::UnicodeUTF8));
        field_scrollbar_up->setText(QApplication::translate("Dialog2", "\342\206\221", 0, QApplication::UnicodeUTF8));
        field_scrollbar_down->setText(QApplication::translate("Dialog2", "\342\206\223", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class Dialog2: public Ui_Dialog2 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_NEWSEGMENTWINDOW_H
