#include "ViewerFunctionGraph.hpp"
#include    "Edge.hpp"

#include    "mainwindow.h"

#include "/usr/include/graphviz/gvc.h"


ViewerFunctionGraph::ViewerFunctionGraph(QWidget *parent): ViewerGraph(parent)
{
}

ViewerFunctionGraph::~ViewerFunctionGraph()
{
    this->ViewerGraph::clear();
}




/**
** \fn int show(Info *info, unsigned long entry, MainWindow *window,
**              int show_addr, int show_octet, int show_instr)
** \brief Gere l'affichage d'un graphe de fonction
**
** \param info Structure contenant les infos du programme a analyser
** \param addr Adresse du point d'entree de la fonction
** \param window Window contenant le graphe
** \param show_addr Faut-il afficher les adresses des instructions
** \param how_octet Faut-il afficher les octets des instructions
** \param show_instr Faut-il afficher les instructions ASM
** \return Retourne 1 si OK, 0 sinon
*/
int    ViewerFunctionGraph::show(Info *info, unsigned long entry, MainWindow *window,
                                 int show_addr, int show_octet, int show_instr)
{
    QGraphicsScene    *graphe;
    std::string       graphe_name;

    /* Preparation du nom du graphe */
    graphe_name = this->make_scene_name(entry);

    /* Si info est NULL, c'est pour qu'on clear l'affichage sans rien supprimer */
    this->_info = info;
    if (info == NULL)
        this->setScene(NULL);

    /* Si le graphe existe, on l'utilise directement */
    else if ((graphe = this->find_scene(graphe_name)) != NULL)
    {
        QTransform        transform;

        this->setScene(graphe);
        this->scene()->setItemIndexMethod(QGraphicsScene::NoIndex);
        this->setCacheMode(CacheBackground);
        this->setViewportUpdateMode(BoundingRectViewportUpdate);
        this->setRenderHint(QPainter::Antialiasing);
        this->setTransformationAnchor(AnchorUnderMouse);

        transform.scale(qreal(1), qreal(1));
        this->setTransform(transform);
    }

    /* Sinon, on le cree */
    else
    {
        Fonction                                                  *f;
        QGraphicsScene                                            *scene;
        std::set<Fonction::Bloc*>                                 list_bloc;
        std::set<std::pair<Fonction::Bloc*, Fonction::Bloc*> >    link_bloc;
        std::map<Fonction::Bloc*, NodeBloc*>                      nodes;
        unsigned long                                             nbs_ret;

        /* S'il y a trop de graphes dans la liste des graphes sauvegardes, on en supprime */
        while (this->_saved_graph.size() > GRAPHE__NBS_GRAPH_MAX)
            this->del_one_scene();

        if ((scene = new QGraphicsScene(this)) != NULL)
        {
            if (info->function.find(entry) != info->function.end())
            {
                f = info->function.find(entry)->second;

                /* Recuperation des adresses des fonctions a mettre dans le graphe */
                nbs_ret = this->search_nodes_to_do(f, list_bloc, link_bloc);

                /* Creation du contenu du graphe */
                this->make_nodes_function(scene, window,
                                                info, f, list_bloc, nodes,
                                                show_addr, show_octet, show_instr, nbs_ret);

                /* Placement des Nodes */
                this->put_nodes(nodes, link_bloc);

                /* Creation des liens entre fonctions */
                for (std::set<std::pair<Fonction::Bloc*, Fonction::Bloc*> >::const_iterator it_link=link_bloc.begin();
                     it_link!=link_bloc.end();
                     it_link++)
                {
                    std::map<Fonction::Bloc*, NodeBloc*>::const_iterator   it_src = nodes.find(it_link->first);
                    std::map<Fonction::Bloc*, NodeBloc*>::const_iterator   it_dst = nodes.find(it_link->second);

                    if ((it_src != nodes.end()) && (it_dst != nodes.end()))
                    {
                        Edge    *ptr_edge = new Edge(it_src->second, it_dst->second);

                        if (ptr_edge != NULL)
                            scene->addItem(ptr_edge);
                    }
                }
            }

            /* On ajoute le graphe a la liste des graphes sauvegardes et on l'affiche */
            this->add_scene(graphe_name, scene);
            return (this->show(info, entry, window, show_addr, show_octet, show_instr));
        }

        return (0);
    }

    return (1);
}

/**
** \fn int save(const std::string &name, unsigned long addr, Info *info, MainWindow *window,
**              int show_addr, int show_octet, int show_instr)
** \brief Gere l'enregistrement d'un graphe de fonction
**
** \param name Nom de l'image ou enregistrer la scene
** \param addr Adresse du point d'entree de la fonction
** \param info Structure contenant les infos du programme a analyser
** \param window window Window contenant le graphe
** \param show_addr Faut-il afficher les adresses des instructions
** \param how_octet Faut-il afficher les octets des instructions
** \param show_instr Faut-il afficher les instructions ASM
** \return Retourne 1 si OK, 0 sinon
*/
int    ViewerFunctionGraph::save(const std::string &name, unsigned long addr, Info *info, MainWindow *window,
                                 int show_addr, int show_octet, int show_instr)
{
    if (this->scene() != NULL)
    {
        this->show(info, addr, window, show_addr, show_octet, show_instr);

        QImage      img(this->scene()->sceneRect().width(),
                        this->scene()->sceneRect().height(),
                        QImage::Format_ARGB32_Premultiplied);
        QPainter    p(&img);

        this->scene()->render(&p);
        p.end();
        img.save(QString::fromStdString(name));

        return (1);
    }

    return (0);
}

/**
** \fn unsigned long search_nodes_to_do(Fonction *f,
**                                      std::set<Fonction::Bloc*> &list_bloc,
**                                      std::set<std::pair<Fonction::Bloc*, Fonction::Bloc*> > &link_bloc)
** \brief Cherche les adresses des blocs a ajouter au graphe de fonction
**
** \param f Fonction a afficher
** \param list_bloc Liste des blocs de fonction
** \param link_func Set des liens entre les blocs <addr_src, addr_dest>
** \return Retourne 1 si OK, 0 sinon
*/
unsigned long ViewerFunctionGraph::search_nodes_to_do(Fonction *f,
                                               std::set<Fonction::Bloc*> &list_bloc,
                                               std::set<std::pair<Fonction::Bloc*, Fonction::Bloc*> > &link_bloc)
{
    Fonction::Bloc    *ptr_bloc_tmp;
    InstrASM          *instr;
    unsigned long     i;

    /* Insertion du Bloc pour le nom de fonction */
    list_bloc.insert(0);
    if (f->get_list_bloc().size() > 0)
        link_bloc.insert(std::pair<Fonction::Bloc*, Fonction::Bloc*>(0, f->get_bloc_entry()));
    else
    {
        list_bloc.insert(reinterpret_cast<Fonction::Bloc*>(1));
        link_bloc.insert(std::pair<Fonction::Bloc*, Fonction::Bloc*>(0, reinterpret_cast<Fonction::Bloc*>(1)));
    }

    i = 1;
    for (std::list<Fonction::Bloc*>::const_iterator it_bloc=f->get_list_bloc().begin();
         it_bloc!=f->get_list_bloc().end();
         it_bloc++)
    {
        /* Ajoute le bloc a la liste */
        list_bloc.insert(*it_bloc);

        /* Cherche la derniere instruction du bloc */
        if ((instr = (*it_bloc)->get_instr_entry()) == NULL)
        {
            list_bloc.insert(reinterpret_cast<Fonction::Bloc*>(i));
            link_bloc.insert(std::pair<Fonction::Bloc*, Fonction::Bloc*>(*it_bloc, reinterpret_cast<Fonction::Bloc*>(i)));
            i++;
        }
        else
        {
            while (instr->_next_instr != NULL)
                instr = instr->_next_instr;

            if (instr->_addr_next_instr_jump.size() <= 0)
            {
                list_bloc.insert(reinterpret_cast<Fonction::Bloc*>(i));
                link_bloc.insert(std::pair<Fonction::Bloc*, Fonction::Bloc*>(*it_bloc, reinterpret_cast<Fonction::Bloc*>(i)));
                i++;
            }
            else
            {
                for (std::list<unsigned long>::iterator it_addr=instr->_addr_next_instr_jump.begin();
                     it_addr!=instr->_addr_next_instr_jump.end();
                     it_addr++)
                {
                    if ((ptr_bloc_tmp = f->get_bloc(*it_addr)) != NULL)
                        link_bloc.insert(std::pair<Fonction::Bloc*, Fonction::Bloc*>(*it_bloc, ptr_bloc_tmp));
                    else
                    {
                        list_bloc.insert(reinterpret_cast<Fonction::Bloc*>(i));
                        link_bloc.insert(std::pair<Fonction::Bloc*, Fonction::Bloc*>(*it_bloc, reinterpret_cast<Fonction::Bloc*>(i)));
                        i++;
                    }
                }
            }
        }
    }

    return (i);
}

/**
** int make_nodes_bloc(QGraphicsScene *scene, MainWindow *window,
**                     Info *info, Fonction *f,
**                     std::set<Fonction::Bloc*> &list_bloc,
**                     std::map<Fonction::Bloc*, NodeBloc*> &nodes,
**                     int show_addr, int show_octet, int show_instr, unsigned long nbs_ret)
** \brief Gere la creation du callgraphe
**
** \param scene Scene ou mettre les Nodes correspondants aux fonction afin d'en faire un graphe
** \param window Window contenant le graphe
** \param info Structure contenant les infos du programme a analyser
** \param f Fonction a afficher
** \param addr_bloc Adresse des blocs a ajouter au callgraphe
** \param nodes Map devant contenir les Nodes correspondants aux blocs <Bloc*, Node*>
** \param show_addr Faut-il afficher les adresses des instructions
** \param how_octet Faut-il afficher les octets des instructions
** \param show_instr Faut-il afficher les instructions ASM
** \param nbs_ret Nombre de Nodes de fin de fonction
** \return Retourne 1 si OK, 0 sinon
*/
int    ViewerFunctionGraph::make_nodes_function(QGraphicsScene *scene, MainWindow *window,
                                                Info *info, Fonction *f,
                                                std::set<Fonction::Bloc*> &addr_bloc,
                                                std::map<Fonction::Bloc*, NodeBloc*> &nodes,
                                                int show_addr, int show_octet, int show_instr, unsigned long nbs_ret)
{
    NodeBloc    *ptr_node;

    for (std::set<Fonction::Bloc*>::iterator it_addr=addr_bloc.begin();
         it_addr!=addr_bloc.end();
         it_addr++)
    {
         if ((*it_addr) == 0)
            ptr_node = new NodeBloc(info, f, NULL, show_addr, show_octet, show_instr, this, window);
        else if ((reinterpret_cast<unsigned long>(*it_addr) > 0) && (reinterpret_cast<unsigned long>(*it_addr) <= nbs_ret))
            ptr_node = new NodeBloc(info, NULL, NULL, show_addr, show_octet, show_instr, this, window);
        else
            ptr_node = new NodeBloc(info, f, *it_addr, show_addr, show_octet, show_instr, this, window);

        if (ptr_node != NULL)
        {
            nodes[*it_addr] = ptr_node;
            scene->addItem(ptr_node);
        }
    }

    return (1); delete f;
}

/**
** \fn int put_nodes(std::map<Fonction::Bloc*, NodeBloc*> &nodes,
**                   std::set<std::pair<Fonction::Bloc*, Fonction::Bloc*> > &link_func)
** \brief Gere le placement des Nodes du le graphe
**
** \param nodes Tableau contenant les nodes a placer <addr, Node>
** \param link_func Set des liens entre fonctions <addr_src, addr_dest>
** \return Retourne 1 si OK, 0 sinon
*/
int    ViewerFunctionGraph::put_nodes(std::map<Fonction::Bloc*, NodeBloc*> &nodes,
                                      std::set<std::pair<Fonction::Bloc*, Fonction::Bloc*> > &link_func)
{
    /* set up a graphviz context - but only once even for multiple graphs */
    static GVC_t    *gvc;
    Agraph_t        *g;
    Agnode_t        *n;
    std::map<Fonction::Bloc*, Agnode_t*>              map_node_dot;
    std::map<Fonction::Bloc*, Agnode_t*>::iterator    it_node_dot1;
    std::map<Fonction::Bloc*, Agnode_t*>::iterator    it_node_dot2;
    float                                             y_max;

    if (gvc == NULL)
        gvc = gvContext();

    if (gvc != NULL)
    {
        /* Create a simple digraph */
        if ((g = agopen(const_cast<char*>("g"), AGDIGRAPH)) != NULL)
        {
            /* Creation des nodes DOT */
            for (std::map<Fonction::Bloc*, NodeBloc*>::const_iterator it_nodes=nodes.begin();
                 it_nodes!=nodes.end();
                 it_nodes++)
            {
                n = agnode(g, const_cast<char*>(Calcul::lto0x(reinterpret_cast<unsigned long>(it_nodes->first)).c_str()));

                if (n != NULL)
                {
                    agsafeset(n, const_cast<char*>("width"),
                              const_cast<char*>(Calcul::ltos(it_nodes->second->boundingRect().width() / 72).c_str()),
                              const_cast<char*>(""));
                    agsafeset(n, const_cast<char*>("height"),
                              const_cast<char*>(Calcul::ltos(it_nodes->second->boundingRect().height() / 65).c_str()),
                              const_cast<char*>(""));
                    map_node_dot[it_nodes->first] = n;
                }
            }

            /* Creation des edges DOT */
            for (std::set<std::pair<Fonction::Bloc*, Fonction::Bloc*> >::const_iterator it_edge=link_func.begin();
                 it_edge!=link_func.end();
                 it_edge++)
            {
                it_node_dot1 = map_node_dot.find(it_edge->first);
                it_node_dot2 = map_node_dot.find(it_edge->second);
                if ((it_node_dot1 != map_node_dot.end()) && (it_node_dot2 != map_node_dot.end()))
                    agedge(g, it_node_dot1->second, it_node_dot2->second);
            }

            /* Generation du graphe */
            gvLayout(gvc, g, "dot");
            gvRender(gvc, g, "dot", NULL);

            /* Identification de la coordonnee Y max afin d'inverser les coordonnes */
            y_max = 0;
            for (std::map<Fonction::Bloc*, Agnode_t*>::iterator it_nodes=map_node_dot.begin();
                 it_nodes!=map_node_dot.end();
                 it_nodes++)
            {
                if (ND_coord(it_nodes->second).y > y_max)
                    y_max = ND_coord(it_nodes->second).y;
            }

            /* Recuperation des coordonnees des Nodes */
            for (std::map<Fonction::Bloc*, NodeBloc*>::iterator it_nodes=nodes.begin();
                 it_nodes!=nodes.end();
                 it_nodes++)
            {
                if ((it_node_dot1 = map_node_dot.find(it_nodes->first)) != map_node_dot.end())
                {
                    it_nodes->second->setPos(ND_coord(it_node_dot1->second).x, y_max - ND_coord(it_node_dot1->second).y - (it_nodes->second->boundingRect().height()/2));
                }
            }

            gvFreeLayout(gvc, g);
            agclose(g);
        }
    }

    return (1);
}







NodeBloc::NodeBloc(Info *info, Fonction *f, Fonction::Bloc *b,
                   int show_addr, int show_octet, int show_instr,
                   ViewerFunctionGraph *viewer, MainWindow *window): INode(viewer),
    _type(NodeBloc::TYPE_RET),
    _status(NodeBloc::STATUS_CLOSE),
    _addr_fonction(0),
    _addr_bloc(0),
    _description(),
    _content(),
    _rect(),
    _info(info),
    _window(window)
{
    unsigned long    max_size_instr;
    InstrASM         *instr;

    /* Si c'est un bloc */
    if ((b != NULL) && (f != NULL))
    {
        this->_type = NodeBloc::TYPE_BLOC;
        this->_status = NodeBloc::STATUS_OPEN;
        this->_addr_fonction = f->get_addr();
        this->_addr_bloc = b->get_addr();

        if (b->get_description().size() > 0)
            this->_description = QString::fromStdString(b->get_description()) + "\n";
        this->_description += "\n";

        this->_content = "";

        /* Si on doit afficher les octets encodant l'instruction, */
        /* on cherche quel la taille maximum necessaire         */
        max_size_instr = 0;
        if (show_octet != 0)
        {
            instr = b->get_instr_entry();
            while (instr != NULL)
            {
                if (instr->_size > max_size_instr)
                    max_size_instr = instr->_size;
                instr = instr->_next_instr;
            }
        }

        /* Preparation du contenu des instructions */
        instr = b->get_instr_entry();
        while (instr != NULL)
        {
            /* Ajoute l'adresse de l'instruction ASM si besoin est */
            if (show_addr != 0)
            {
                this->_content += " " + QString::fromStdString(Calcul::ltox(instr->_address)) + ":";

                /* On rajoute des espaces si besoin est */
                if ((show_octet != 0) || (show_instr != 0))
                    this->_content += "   ";
            }

            /* Ajoute l'adresse de l'instruction ASM si besoin est */
            if (show_octet != 0)
            {
                this->_content += " ";

                for (unsigned long i=0; i<instr->_size; i++)
                {
                    if (info->sec.get_char(instr->_address + i) < 0x10)
                        this->_content += "0";
                    this->_content += QString::fromStdString(Calcul::ltox(info->sec.get_char(instr->_address + i))) + " ";
                }

                /* On rajoute des espaces si besoin est */
                if (show_instr != 0)
                {
                    for (unsigned long i=instr->_size; i<max_size_instr; i++)
                        this->_content += "   ";
                    this->_content += "   ";
                }
            }

            /* Ajoute l'instruction ASM si besoin est */
            if (show_instr != 0)
            {
                this->_content += " ";
                this->_content += QString::fromStdString(instr->to_asm(info));
            }

            if ((instr->_next_instr != NULL) && ((show_addr != 0) || (show_octet != 0) || (show_instr != 0)))
               this->_content += " \n";
            instr = instr->_next_instr;
        }
    }
    /* Sinon, si c'est une fonction */
    else if (f != NULL)
    {
        this->_type = NodeBloc::TYPE_ENTETE;
        this->_status = NodeBloc::STATUS_OPEN;
        this->_addr_fonction = f->get_addr();

        this->_description = QString::fromStdString("\n" + Calcul::ltox(this->_addr_fonction) + ": " + Fonction::get_name_function(f, info) + "\n");
        if (f->get_description().size() > 0)
            this->_content += QString::fromStdString("\n" + f->get_description() + "\n");
    }
    else
    {
        this->_type = NodeBloc::TYPE_RET;
        this->_description = "    \n    ";
    }

    this->update_rect();
}

NodeBloc::~NodeBloc()
{
}


void    NodeBloc::update_rect()
{    
    /* Calcul des dimensions du Node */
    this->calcul_dimension(NULL);

    this->_rect.setX(this->pos().x() - (this->_rect.width()/2));
    this->_rect.setY(this->pos().y() /*- (this->_rect.height()/2)*/);
}

/**
** \fn QRectF boundingRect() const
** \brief Modifie la zone d'affichage du Node
**
** \return Retourne les dimensions de la nouvelle zone d'affichage du Node
*/
QRectF       NodeBloc::boundingRect() const
{
    return (this->_rect);
}

/**
** \fn QPainterPath shape() const
** \brief Adapte la zone de selection du Node a ses dimensions
**
** \return Retourne la zone de selection du Node
*/
QPainterPath NodeBloc::shape() const
{
    QPainterPath    path;

    path.addRect(this->_rect);
    return (path);
}

/**
** \fn void paint(QPainter *painter, const QStyleOptionGraphicsItem*, QWidget *)
** \brief Fonction gerant l'affichage du Node
**
** \param painter Pointeur sur l'objet permettant de dessiner le Node
** \return Retourne rien
*/
void         NodeBloc::paint(QPainter *painter, const QStyleOptionGraphicsItem*, QWidget*)
{
    if (painter != NULL)
    {
        /* Calcul des dimensions du Node */
        this->calcul_dimension(painter);

        /* Si c'est un Node de fonction */
        if (this->_type == NodeBloc::TYPE_ENTETE)
        {
            /* Contour du node */
            painter->setPen(Qt::NoPen);
            painter->setBrush(Qt::black);
            painter->drawRect(this->_rect);

            /* Texte du node */
            painter->setPen(Qt::white);
            if ((this->_status == NodeBloc::STATUS_CLOSE) || (this->_content.size() <= 0))
                painter->drawText(this->boundingRect(), Qt::AlignCenter, this->_description);
            else if (this->_description.size() > 0)
                painter->drawText(this->boundingRect(), Qt::AlignCenter, this->_description + this->_content);
        }

        /* Si c'est un node de bloc */
        else if (this->_type == NodeBloc::TYPE_BLOC)
        {
            /* Contour du node */
            painter->setPen(Qt::NoPen);
            painter->setBrush(Qt::black);
            painter->drawRect(this->_rect);

            /* Interieur du node */
            painter->setBrush(QBrush(QColor(200, 200, 200)));
            painter->drawRect(this->_rect.left()+1, this->_rect.top()+1, this->_rect.width()-2, this->_rect.height()-2);

            /* Texte du node */
            painter->setPen(Qt::black);
            if ((this->_status == NodeBloc::STATUS_CLOSE) || (this->_content.size() <= 0))
                painter->drawText(this->boundingRect(), Qt::AlignLeft, this->_description);
            else if (this->_description.size() > 0)
                painter->drawText(this->boundingRect(), Qt::AlignLeft, this->_description + this->_content);
        }

        /* Sinon, c'est une fin de fonction */
        else
        {
            painter->setPen(Qt::NoPen);
            painter->setBrush(Qt::black);
            painter->drawEllipse(this->_rect);
        }
    }
}

/**
** \fn QPointF get_posInput() const
** \brief Fonction permettant de connaitre la position relative du point d'entree du Node
**
** \return Retourne la position relative du point d'entree du Node
*/
QPointF      NodeBloc::get_posInput() const
{
    return (QPointF(this->pos().x(), this->pos().y()));
}

/**
** \fn QPointF get_posOutput() const
** \brief Fonction permettant de connaitre la position relative du point de sortie du Node
**
** \return Retourne la position relative du point d'entree du Node
*/
QPointF      NodeBloc::get_posOutput() const
{
    return (QPointF(this->pos().x(), this->pos().y() + this->_rect.height()));
}

/**
** \fn void slot_edit_description()
** \brief Permet d'editer la description de la fonction correspondant a ce Node
**
** \return Retourne rien
*/
void    NodeBloc::slot_edit_description()
{
    qDebug("NodeBloc::slot_edit_description()\n");
    std::map<unsigned long, Fonction*>::iterator    it_func;
    Fonction::Bloc                                  *bloc;
    std::string                                     str;

    /* Edition de la description de la fonction */
    if ((this->_type == NodeBloc::TYPE_ENTETE) && (this->_window != NULL))
    {
        if ((it_func = this->_info->function.find(this->_addr_fonction)) != this->_info->function.end())
        {
            str = it_func->second->get_description();

            GetDescriptionWindow    w("Description de la fonction :", &str, this->_window);
            w.exec();

            it_func->second->set_description(str);
            this->_content = QString::fromStdString(str);
        }
    }

    /* Edition de la description du bloc */
    else if ((this->_type == NodeBloc::TYPE_BLOC) && (this->_window != NULL))
    {
        if ((it_func = this->_info->function.find(this->_addr_fonction)) != this->_info->function.end())
        {
            if ((bloc = it_func->second->get_bloc(this->_addr_bloc)) != NULL)
            {
                str = bloc->get_description();

                GetDescriptionWindow    w("Description du bloc :", &str, this->_window);
                w.exec();

                bloc->set_description(str);
                this->_description = "\n";
                if (str.size() > 0)
                    this->_description = QString::fromStdString(str) + "\n\n";
            }
        }
    }
}

/**
** \fn void slot_edit_prototype()
** \brief Permet d'editer le prototype de la fonction correspondant a ce Node
**
** \return Retourne rien
*/
void    NodeBloc::slot_edit_prototype()
{
    qDebug("NodeBloc::slot_edit_prototype()\n");
    std::map<unsigned long, Fonction*>::iterator    it_func;

    if (this->_type == NodeBloc::TYPE_ENTETE)
    {
        if ((it_func = this->_info->function.find(this->_addr_fonction)) != this->_info->function.end())
        {
            if (this->_window != NULL)
                this->_window->slot_proto_func__edit_name(Fonction::get_name_function(it_func->second, this->_info));
        }
    }
}

/**
** \fn void slot_open_or_close()
** \brief Gere l'affichage ou non de la description du Node
**
** \return Retourne rien
***/
void    NodeBloc::slot_open_or_close()
{
    if (this->_status == NodeBloc::STATUS_OPEN)
        this->_status = NodeBloc::STATUS_CLOSE;
    else
        this->_status = NodeBloc::STATUS_OPEN;
}

/**
** \fn void calcul_dimension(QPainter *painter)
** \brief Gere le calcul des dimensions du Node
**
** \param painter Pointeur sur l'objet permettant de dessiner le Node
** \return Retourne rien
*/
void              NodeBloc::calcul_dimension(QPainter *painter)
{
    QRectF    rect_description;
    QRectF    rect_content;
    QFont     font("Monospace");

    /* Preparation de la police */
    font.setStyleHint(QFont::TypeWriter);
    if (this->_type == NodeBloc::TYPE_ENTETE)
        font.setBold(true);
    font.setPointSize(10);

    /* Calucl des dimensions du titre et de contenu du Node */
    if (painter != NULL)
    {
        painter->setFont(font);

        if (this->_description.size() > 0)
            rect_description = painter->boundingRect(QRectF(), Qt::AlignCenter, this->_description);
        if (this->_status == NodeBloc::STATUS_OPEN)
            rect_content = painter->boundingRect(QRectF(), Qt::AlignLeft, this->_content);
    }
    else
    {
        QFontMetrics    fm(font);

        if (this->_description.size() > 0)
            rect_description = fm.boundingRect(QRect(), Qt::AlignLeft, this->_description);
        if (this->_status == NodeBloc::STATUS_OPEN)
            rect_content = fm.boundingRect(QRect(), Qt::AlignLeft, this->_content);
    }

    /* Choix de la plus grande largeur */
    this->_rect.setHeight(rect_description.height() + rect_content.height());
    if (rect_content.width() > rect_description.width())
        this->_rect.setWidth(rect_content.width());
    else
        this->_rect.setWidth(rect_description.width());

    /* Ajout d'une marge */
    if (painter != NULL)
    {
        if (this->_type == NodeBloc::TYPE_ENTETE)
            this->_rect.setWidth(this->_rect.width() +  painter->boundingRect(QRectF(), Qt::AlignLeft, "    ").width());
        else if (this->_type == NodeBloc::TYPE_BLOC)
            this->_rect.setWidth(this->_rect.width() +  painter->boundingRect(QRectF(), Qt::AlignLeft, " ").width());
    }
    else
    {
        QFontMetrics    fm(font);

        if (this->_type == NodeBloc::TYPE_ENTETE)
            this->_rect.setWidth(this->_rect.width() + fm.boundingRect(QRect(), Qt::AlignLeft, "    ").width());
        else if (this->_type == NodeBloc::TYPE_BLOC)
            this->_rect.setWidth(this->_rect.width() + fm.boundingRect(QRect(), Qt::AlignLeft, " ").width());
    }
}

/**
** \fn void mousePressEvent(QGraphicsSceneMouseEvent *event)
** \brief Gestion des clics de la souris
**
** \param event Pointeur sur la description de l'evenement
** \return Retourne rien
*/
void              NodeBloc::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    qDebug("NodeBloc::mousePressEvent(QMouseEvent *event)\n");
    QMenu      m;
    QAction    *action;
    QCursor    cursor;

    /* Si l'evenement est un clic droit, on affiche un menu */
    if (event->button() == Qt::RightButton)
    {
        if (this->_type == NodeBloc::TYPE_ENTETE)
        {
            if ((action = new QAction(QString::fromUtf8("Modifier la description de la fonction"), &m)) != NULL)
            {
                m.addAction(action);
                connect(action, SIGNAL(triggered()), this, SLOT(slot_edit_description()));
            }

            if ((action = new QAction(QString::fromUtf8("Modifier le prototype de la fonction"), &m)) != NULL)
            {
                m.addAction(action);
                connect(action, SIGNAL(triggered()), this, SLOT(slot_edit_prototype()));
            }

            if ((action = new QAction(QString::fromUtf8("Afficher le callgraph de la fonction"), &m)) != NULL)
            {
                m.addAction(action);
                connect(action, SIGNAL(triggered()), this, SLOT(slot_edit_prototype()));
            }
        }

        else if (this->_type == NodeBloc::TYPE_BLOC)
        {/*
            if ((this->_status == NodeBloc::STATUS_OPEN) &&
                ((action = new QAction(QString::fromUtf8("Fermer le Bloc"), &m)) != NULL))
            {
                m.addAction(action);
                connect(action, SIGNAL(triggered()), this, SLOT(slot_open_or_close()));
            }
            if ((this->_status == NodeBloc::STATUS_CLOSE) &&
                ((action = new QAction(QString::fromUtf8("Afficher le Bloc"), &m)) != NULL))
            {
                m.addAction(action);
                connect(action, SIGNAL(triggered()), this, SLOT(slot_open_or_close()));
            }*/

            if ((action = new QAction(QString::fromUtf8("Modifier la description du bloc"), &m)) != NULL)
            {
                m.addAction(action);
                connect(action, SIGNAL(triggered()), this, SLOT(slot_edit_description()));
            }

            if ((action = new QAction(QString::fromUtf8("Analyse du bloc"), &m)) != NULL)
            {
                m.addAction(action);
                connect(action, SIGNAL(triggered()), this, SLOT(slot_edit_description()));
            }
        }

        m.move(cursor.pos());
        m.exec();
    }
    else
        QGraphicsObject::mousePressEvent(event);
}
