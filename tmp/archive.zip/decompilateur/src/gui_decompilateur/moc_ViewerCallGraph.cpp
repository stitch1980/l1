/****************************************************************************
** Meta object code from reading C++ file 'ViewerCallGraph.hpp'
**
** Created: Tue May 19 13:12:00 2015
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "ViewerCallGraph.hpp"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'ViewerCallGraph.hpp' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_NodeFunction[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       8,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      14,   13,   13,   13, 0x0a,
      38,   13,   13,   13, 0x0a,
      60,   13,   13,   13, 0x0a,
      82,   13,   13,   13, 0x0a,
      98,   13,   13,   13, 0x0a,
     112,   13,   13,   13, 0x0a,
     131,   13,   13,   13, 0x0a,
     147,   13,   13,   13, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_NodeFunction[] = {
    "NodeFunction\0\0slot_edit_description()\0"
    "slot_edit_prototype()\0slot_show_callgraph()\0"
    "slot_show_asm()\0slot_show_c()\0"
    "slot_deassembler()\0slot_nettoyer()\0"
    "slot_decompiler()\0"
};

void NodeFunction::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        NodeFunction *_t = static_cast<NodeFunction *>(_o);
        switch (_id) {
        case 0: _t->slot_edit_description(); break;
        case 1: _t->slot_edit_prototype(); break;
        case 2: _t->slot_show_callgraph(); break;
        case 3: _t->slot_show_asm(); break;
        case 4: _t->slot_show_c(); break;
        case 5: _t->slot_deassembler(); break;
        case 6: _t->slot_nettoyer(); break;
        case 7: _t->slot_decompiler(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObjectExtraData NodeFunction::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject NodeFunction::staticMetaObject = {
    { &INode::staticMetaObject, qt_meta_stringdata_NodeFunction,
      qt_meta_data_NodeFunction, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &NodeFunction::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *NodeFunction::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *NodeFunction::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_NodeFunction))
        return static_cast<void*>(const_cast< NodeFunction*>(this));
    return INode::qt_metacast(_clname);
}

int NodeFunction::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = INode::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 8)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 8;
    }
    return _id;
}
static const uint qt_meta_data_GetDescriptionWindow[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      22,   21,   21,   21, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_GetDescriptionWindow[] = {
    "GetDescriptionWindow\0\0slot_validate()\0"
};

void GetDescriptionWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        GetDescriptionWindow *_t = static_cast<GetDescriptionWindow *>(_o);
        switch (_id) {
        case 0: _t->slot_validate(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObjectExtraData GetDescriptionWindow::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject GetDescriptionWindow::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_GetDescriptionWindow,
      qt_meta_data_GetDescriptionWindow, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &GetDescriptionWindow::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *GetDescriptionWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *GetDescriptionWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_GetDescriptionWindow))
        return static_cast<void*>(const_cast< GetDescriptionWindow*>(this));
    return QDialog::qt_metacast(_clname);
}

int GetDescriptionWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 1)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
