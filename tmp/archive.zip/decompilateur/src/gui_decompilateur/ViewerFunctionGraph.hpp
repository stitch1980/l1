#ifndef VIEWERFUNCTIONGRAPH_H
#define VIEWERFUNCTIONGRAPH_H

#include    "ViewerGraph.hpp"
#include    "ViewerCallGraph.hpp"
#include    "INode.hpp"

class    MainWindow;
class    NodeBloc;


class ViewerFunctionGraph : public ViewerGraph
{
public:
    ViewerFunctionGraph(QWidget *parent);
    ~ViewerFunctionGraph();


    /**
    ** \fn int show(Info *info, unsigned long entry, MainWindow *window,
    **              int show_addr, int show_octet, int show_instr)
    ** \brief Gere l'affichage d'un graphe de fonction
    **
    ** \param info Structure contenant les infos du programme a analyser
    ** \param addr Adresse du point d'entree de la fonction
    ** \param window Window contenant le graphe
    ** \param show_addr Faut-il afficher les adresses des instructions
    ** \param how_octet Faut-il afficher les octets des instructions
    ** \param show_instr Faut-il afficher les instructions ASM
    ** \return Retourne 1 si OK, 0 sinon
    */
    int    show(Info *info, unsigned long entry, MainWindow *window,
                int show_addr, int show_octet, int show_instr);

    /**
    ** \fn int save(const std::string &name, unsigned long addr, Info *info, MainWindow *window,
    **              int show_addr, int show_octet, int show_instr)
    ** \brief Gere l'enregistrement d'un graphe de fonction
    **
    ** \param name Nom de l'image ou enregistrer la scene
    ** \param addr Adresse du point d'entree de la fonction
    ** \param info Structure contenant les infos du programme a analyser
    ** \param window window Window contenant le graphe
    ** \param show_addr Faut-il afficher les adresses des instructions
    ** \param how_octet Faut-il afficher les octets des instructions
    ** \param show_instr Faut-il afficher les instructions ASM
    ** \return Retourne 1 si OK, 0 sinon
    */
    int    save(const std::string &name, unsigned long addr, Info *info, MainWindow *window,
                int show_addr, int show_octet, int show_instr);

protected:
    /**
    ** \fn unsigned long search_nodes_to_do(Fonction *f,
    **                                      std::set<Fonction::Bloc*> &list_bloc,
    **                                      std::set<std::pair<Fonction::Bloc*, Fonction::Bloc*> > &link_bloc)
    ** \brief Cherche les adresses des blocs a ajouter au graphe de fonction
    **
    ** \param f Fonction a afficher
    ** \param list_bloc Liste des blocs de fonction
    ** \param link_func Set des liens entre les blocs <addr_src, addr_dest>
    ** \return Retourne 1 si OK, 0 sinon
    */
    unsigned long    search_nodes_to_do(Fonction *f,
                                        std::set<Fonction::Bloc*> &list_bloc,
                                        std::set<std::pair<Fonction::Bloc*, Fonction::Bloc*> > &link_bloc);

    /**
    ** int make_nodes_bloc(QGraphicsScene *scene, MainWindow *window,
    **                     Info *info, Fonction *f,
    **                     std::set<Fonction::Bloc*> &list_bloc,
    **                     std::map<Fonction::Bloc*, NodeBloc*> &nodes,
    **                     int show_addr, int show_octet, int show_instr, unsigned long nbs_ret)
    ** \brief Gere la creation du callgraphe
    **
    ** \param scene Scene ou mettre les Nodes correspondants aux fonction afin d'en faire un graphe
    ** \param window Window contenant le graphe
    ** \param info Structure contenant les infos du programme a analyser
    ** \param f Fonction a afficher
    ** \param addr_bloc Adresse des blocs a ajouter au callgraphe
    ** \param nodes Map devant contenir les Nodes correspondants aux blocs <Bloc*, Node*>
    ** \param show_addr Faut-il afficher les adresses des instructions
    ** \param how_octet Faut-il afficher les octets des instructions
    ** \param show_instr Faut-il afficher les instructions ASM
    ** \param nbs_ret Nombre de Nodes de fin de fonction
    ** \return Retourne 1 si OK, 0 sinon
    */
    int    make_nodes_function(QGraphicsScene *scene, MainWindow *window,
                               Info *info, Fonction *f,
                               std::set<Fonction::Bloc*> &addr_bloc,
                               std::map<Fonction::Bloc*, NodeBloc*> &nodes,
                               int show_addr, int show_octet, int show_instr, unsigned long nbs_ret);

    /**
    ** \fn int put_nodes(std::map<Fonction::Bloc*, NodeBloc*> &nodes,
    **                   std::set<std::pair<Fonction::Bloc*, Fonction::Bloc*> > &link_func)
    ** \brief Gere le placement des Nodes du le graphe
    **
    ** \param nodes Tableau contenant les nodes a placer <addr, Node>
    ** \param link_func Set des liens entre fonctions <addr_src, addr_dest>
    ** \return Retourne 1 si OK, 0 sinon
    */
    int    put_nodes(std::map<Fonction::Bloc*, NodeBloc*> &nodes,
                     std::set<std::pair<Fonction::Bloc*, Fonction::Bloc*> > &link_func);
};


class    NodeBloc: public INode
{
    Q_OBJECT

public:
    /**
    ** \enum eType
    ** \brief Type de node
    */
    enum eType
    {
        /** Node contenant des inforation sur la fonction */
        TYPE_ENTETE,
        /** Node contenant les instructions d'un Bloc ASM */
        TYPE_BLOC,
        /** Node simbolisant une fin de fonction */
        TYPE_RET
    };

    /**
    ** \enum eStatus
    ** \brief Status de la Node
    */
    enum eStatus
    {
        /** On affiche toutes les infos de la Node */
        STATUS_OPEN,
        /** On affiche seulement l'entete de la Node */
        STATUS_CLOSE
    };

public:
    NodeBloc(Info *info, Fonction *f, Fonction::Bloc *b,
             int show_addr, int show_octet, int show_instr,
             ViewerFunctionGraph *viewer, MainWindow *window);
    ~NodeBloc();

    void    update_rect();

    /**
    ** \fn QRectF boundingRect() const
    ** \brief Modifie la zone d'affichage du Node
    **
    ** \return Retourne les dimensions de la nouvelle zone d'affichage du Node
    */
    QRectF       boundingRect() const;

    /**
    ** \fn QPainterPath shape() const
    ** \brief Adapte la zone de selection du Node a ses dimensions
    **
    ** \return Retourne la zone de selection du Node
    */
    QPainterPath shape() const;

    /**
    ** \fn void paint(QPainter *painter, const QStyleOptionGraphicsItem*, QWidget *)
    ** \brief Fonction gerant l'affichage du Node
    **
    ** \param painter Pointeur sur l'objet permettant de dessiner le Node
    ** \return Retourne rien
    */
    void         paint(QPainter *painter, const QStyleOptionGraphicsItem*, QWidget*);

    /**
    ** \fn QPointF get_posInput() const
    ** \brief Fonction permettant de connaitre la position relative du point d'entree du Node
    **
    ** \return Retourne la position relative du point d'entree du Node
    */
    QPointF      get_posInput() const;

    /**
    ** \fn QPointF get_posOutput() const
    ** \brief Fonction permettant de connaitre la position relative du point de sortie du Node
    **
    ** \return Retourne la position relative du point d'entree du Node
    */
    QPointF      get_posOutput() const;

public slots:
    /**
    ** \fn void slot_edit_description()
    ** \brief Permet d'editer la description de la fonction correspondant a ce Node
    **
    ** \return Retourne rien
    */
    void    slot_edit_description();

    /**
    ** \fn void slot_edit_prototype()
    ** \brief Permet d'editer le prototype de la fonction correspondant a ce Node
    **
    ** \return Retourne rien
    */
    void    slot_edit_prototype();

    /**
    ** \fn void slot_open_or_close()
    ** \brief Gere l'affichage ou non de la description du Node
    **
    ** \return Retourne rien
    ***/
    void    slot_open_or_close();

protected:
    /**
    ** \fn void calcul_dimension(QPainter *painter)
    ** \brief Gere le calcul des dimensions du Node
    **
    ** \param painter Pointeur sur l'objet permettant de dessiner le Node
    ** \return Retourne rien
    */
    void              calcul_dimension(QPainter *painter);

    /**
    ** \fn void mousePressEvent(QGraphicsSceneMouseEvent *event)
    ** \brief Gestion des clics de la souris
    **
    ** \param event Pointeur sur la description de l'evenement
    ** \return Retourne rien
    */
    void              mousePressEvent(QGraphicsSceneMouseEvent *event);

protected:
    /** Type de Node (0: Entree de fonction, 1: Bloc, 2: Fin de fonction) */
    NodeBloc::eType      _type;
    /** Status de la Node (0: ferme, 1: ouvert) */
    NodeBloc::eStatus    _status;

    /** Adresse de la fonction */
    unsigned long        _addr_fonction;
    /** Adresse du bloc (utile uniquement pour les Nodes de type TYPE_BLOC) */
    unsigned long        _addr_bloc;

    /** Description du bloc ou de la fonction */
    QString              _description;
    /** Contenu du bloc */
    QString              _content;

    /** Dimensions de de la Node */
    QRectF               _rect;

    /** Pointeur sur la structure contenant les infos du programme */
    Info                 *_info;
    /** Pointeur sur l'interface graphique */
    MainWindow           *_window;
};

#endif
