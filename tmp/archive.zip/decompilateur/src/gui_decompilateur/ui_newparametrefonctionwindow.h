/********************************************************************************
** Form generated from reading UI file 'newparametrefonctionwindow.ui'
**
** Created: Thu May 14 13:50:04 2015
**      by: Qt User Interface Compiler version 4.8.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_NEWPARAMETREFONCTIONWINDOW_H
#define UI_NEWPARAMETREFONCTIONWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QDialogButtonBox>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_DialogNewParametreFonction
{
public:
    QVBoxLayout *verticalLayout;
    QWidget *widget;
    QHBoxLayout *horizontalLayout;
    QLabel *label;
    QLineEdit *field_type;
    QWidget *widget_2;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_2;
    QLineEdit *field_name;
    QDialogButtonBox *buttonBox;

    void setupUi(QDialog *DialogNewParametreFonction)
    {
        if (DialogNewParametreFonction->objectName().isEmpty())
            DialogNewParametreFonction->setObjectName(QString::fromUtf8("DialogNewParametreFonction"));
        DialogNewParametreFonction->resize(400, 159);
        verticalLayout = new QVBoxLayout(DialogNewParametreFonction);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        widget = new QWidget(DialogNewParametreFonction);
        widget->setObjectName(QString::fromUtf8("widget"));
        horizontalLayout = new QHBoxLayout(widget);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        label = new QLabel(widget);
        label->setObjectName(QString::fromUtf8("label"));

        horizontalLayout->addWidget(label);

        field_type = new QLineEdit(widget);
        field_type->setObjectName(QString::fromUtf8("field_type"));

        horizontalLayout->addWidget(field_type);


        verticalLayout->addWidget(widget);

        widget_2 = new QWidget(DialogNewParametreFonction);
        widget_2->setObjectName(QString::fromUtf8("widget_2"));
        horizontalLayout_2 = new QHBoxLayout(widget_2);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        label_2 = new QLabel(widget_2);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        horizontalLayout_2->addWidget(label_2);

        field_name = new QLineEdit(widget_2);
        field_name->setObjectName(QString::fromUtf8("field_name"));

        horizontalLayout_2->addWidget(field_name);


        verticalLayout->addWidget(widget_2);

        buttonBox = new QDialogButtonBox(DialogNewParametreFonction);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);

        verticalLayout->addWidget(buttonBox);


        retranslateUi(DialogNewParametreFonction);
        QObject::connect(buttonBox, SIGNAL(accepted()), DialogNewParametreFonction, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), DialogNewParametreFonction, SLOT(reject()));
        QObject::connect(DialogNewParametreFonction, SIGNAL(accepted()), DialogNewParametreFonction, SLOT(slot_validate()));
        QObject::connect(field_name, SIGNAL(textEdited(QString)), DialogNewParametreFonction, SLOT(slot_check_formulaire()));
        QObject::connect(field_type, SIGNAL(textEdited(QString)), DialogNewParametreFonction, SLOT(slot_check_formulaire()));

        QMetaObject::connectSlotsByName(DialogNewParametreFonction);
    } // setupUi

    void retranslateUi(QDialog *DialogNewParametreFonction)
    {
        DialogNewParametreFonction->setWindowTitle(QApplication::translate("DialogNewParametreFonction", "Dialog", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("DialogNewParametreFonction", "Type :", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("DialogNewParametreFonction", "Nom :", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class DialogNewParametreFonction: public Ui_DialogNewParametreFonction {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_NEWPARAMETREFONCTIONWINDOW_H
