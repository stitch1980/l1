#include    "mainwindow.h"
#include    "ui_mainwindow.h"

#include    "newprototypewindow.h"


/**
** \fn void slot_proto_func__liste_prototype_func__update()
** \brief Slot gerant l'actualisation de la liste des prototypes
**
** \return Retourne rien
*/
void    MainWindow::slot_proto_func__liste_prototype__update()
{
    qDebug("MainWindow::slot_proto_func__liste_prototype__update()\n");
    int        column;
    int        row;

    this->_info.mutex.lock();
    disconnect(this->ui->proto_func__liste_prototypes, SIGNAL(itemSelectionChanged()), this, SLOT(slot_proto_func__liste_prototype__update()));

    /* Sauvegarde de l'element actuellement selectionne */
    column = this->ui->proto_func__liste_prototypes->currentColumn();
    row = this->ui->proto_func__liste_prototypes->currentRow();

    /* Preparation des protoypes */
    this->ui->proto_func__liste_prototypes->clearContents();
    this->ui->proto_func__liste_prototypes->setRowCount(this->_info.proto_func.get_nbs());
    for (unsigned long i=0; i<this->_info.proto_func.get_nbs(); i++)
    {
        this->ui->proto_func__liste_prototypes->setItem(i, 0, new QTableWidgetItem(QString::fromStdString(this->_info.proto_func.get_ret_nbs(i))));
        this->ui->proto_func__liste_prototypes->setItem(i, 1, new QTableWidgetItem(QString::fromStdString(this->_info.proto_func.get_name_nbs(i))));

        std::string    str;
        for (unsigned long j=0; j<this->_info.proto_func.get_nbs_param_nbs(i); j++)
        {
            if (j > 0)
                str += ", ";
            str += this->_info.proto_func.get_type_param_nbs(i, j);
            str += " ";
            str += this->_info.proto_func.get_name_param_nbs(i, j);
        }
        this->ui->proto_func__liste_prototypes->setItem(i, 2, new QTableWidgetItem(QString::fromStdString(str)));
    }

    /* Re-selection de l'element autrefois selectionne */
    this->ui->proto_func__liste_prototypes->setCurrentCell(row, column);
    this->slot_proto_func__liste_prototype__clicked();

    connect(this->ui->proto_func__liste_prototypes, SIGNAL(itemSelectionChanged()), this, SLOT(slot_proto_func__liste_prototype__update()));
    this->_info.mutex.unlock();
}

/**
** \fn void slot_proto__liste_prototype__clicked()
** \brief Slot gerant le clic sur un prototype
**
** \return Retourne rien
*/
void    MainWindow::slot_proto_func__liste_prototype__clicked()
{
    qDebug("MainWindow::slot_proto_func__liste_prototype__clicked()\n");

    this->ui->proto_func__bt_edit->setEnabled(false);
    this->ui->proto_func__bt_delete->setEnabled(false);
    if (this->ui->proto_func__liste_prototypes->currentItem() != NULL)
    {
        this->ui->proto_func__bt_edit->setEnabled(true);
        this->ui->proto_func__bt_delete->setEnabled(true);
    }
}

/**
** \fn void slot_proto_func__bt_new()
** \brief Slot gerant la creation d'un nouveau prototype
**
** \return Retourne rien
*/
void    MainWindow::slot_proto_func__bt_new()
{
    qDebug("MainWindow::slot_proto_func__bt_new()\n");
    std::string                                         ret;
    std::string                                         name;
    std::vector<std::pair<std::string, std::string> >   param;

    this->_info.mutex.lock();

    ret = "int";
    NewPrototypeWindow    w(NULL, &ret, &name, &param, &(this->_info), this);
    w.exec();

    if (w.is_ok() > 0)
        this->_info.proto_func.add_function(name, ret, param);

    this->_info.mutex.unlock();
    this->slot_proto_func__liste_prototype__update();
}

/**
** \fn void slot_proto_func__bt_edit()
** \brief Slot gerant la modification d'un prototype
**
** \return Retourne rien
*/
void    MainWindow::slot_proto_func__bt_edit()
{
    qDebug("MainWindow::slot_proto_func__bt_edit()\n");
    QTableWidgetItem                                     *item;
    std::string                                          name;

    this->_info.mutex.lock();

    if ((item = this->ui->proto_func__liste_prototypes->item(this->ui->proto_func__liste_prototypes->currentRow(), 1)) != NULL)
    {
        name = item->text().toStdString();
        this->slot_proto_func__edit_name(name);
    }

    this->_info.mutex.unlock();
    this->slot_proto_func__liste_prototype__update();
}

/**
** \fn void slot_proto_func__bt_delete()
** \brief Slot gerant la suppression d'un prototype
**
** \return Retourne rien
*/
void    MainWindow::slot_proto_func__bt_delete()
{
    qDebug("MainWindow::slot_proto_func__bt_delete()\n");
    QTableWidgetItem    *item;
    std::string         name;

    this->_info.mutex.lock();

    if ((item = this->ui->proto_func__liste_prototypes->item(this->ui->proto_func__liste_prototypes->currentRow(), 1)) != NULL)
    {
        /* Recuperation de l'adresse de la section courante */
        name = item->text().toStdString();
        this->_info.proto_func.del_function(name);
    }

    this->_info.mutex.unlock();
    this->slot_proto_func__liste_prototype__update();
}

/**
** \fn void slot_proto_func__edit_name(const std::string &name)
** \brief Gere l'edition du prototype d'une fonction
**
** \param name Nom de la fonction dont le prototype est a editer
** \return Retourne rien
*/
void    MainWindow::slot_proto_func__edit_name(const std::string &n)
{
    qDebug("MainWindow::slot_func__edit_addr(unsigned long addr)\n");
    std::string                                          ret;
    std::string                                          name;
    std::vector<std::pair<std::string, std::string> >    param;

    /* Si le prototype existe, on recupere ses infos */
    ret = "int";
    name = n;
    if (this->_info.proto_func.exist(name) > 0)
    {
        this->_info.proto_func.get_ret(name);

        for (unsigned long i=0; i<this->_info.proto_func.get_nbs_param(name); i++)
        {
            param.push_back(std::pair<std::string, std::string>(this->_info.proto_func.get_type_param(name, i),
                                                                this->_info.proto_func.get_name_param(name, i)));
        }
    }

    NewPrototypeWindow    w(NULL, &ret, &name, &param, &(this->_info), this);
    w.exec();

    if (w.is_ok() > 0)
    {
        this->_info.proto_func.del_function(n);
        this->_info.proto_func.add_function(name, ret, param);
    }
}




/**
** \fn void slot_proto_int__liste_prototype_func__update()
** \brief Slot gerant l'actualisation de la liste des prototypes
**
** \return Retourne rien
*/
void    MainWindow::slot_proto_int__liste_prototype__update()
{
    qDebug("MainWindow::slot_proto_int__liste_prototype__update()\n");
    int        column;
    int        row;

    this->_info.mutex.lock();
    disconnect(this->ui->proto_inter__liste_prototypes, SIGNAL(itemSelectionChanged()), this, SLOT(slot_proto_int__liste_prototype__update()));

    /* Sauvegarde de l'element actuellement selectionne */
    column = this->ui->proto_inter__liste_prototypes->currentColumn();
    row = this->ui->proto_inter__liste_prototypes->currentRow();

    /* Preparation des protoypes */
    this->ui->proto_inter__liste_prototypes->clearContents();
    this->ui->proto_inter__liste_prototypes->setRowCount(this->_info.interrupt.get_nbs());
    for (unsigned long i=0; i<this->_info.interrupt.get_nbs(); i++)
    {
        this->ui->proto_inter__liste_prototypes->setItem(i, 0, new QTableWidgetItem(QString::number(this->_info.interrupt.get_num_nbs(i))));
        this->ui->proto_inter__liste_prototypes->setItem(i, 1, new QTableWidgetItem(QString::fromStdString(this->_info.interrupt.get_ret_nbs(i))));
        this->ui->proto_inter__liste_prototypes->setItem(i, 2, new QTableWidgetItem(QString::fromStdString(this->_info.interrupt.get_name_nbs(i))));

        std::string    str;
        for (unsigned long j=0; j<this->_info.interrupt.get_nbs_param_nbs(i); j++)
        {
            if (j > 0)
                str += ", ";
            str += this->_info.interrupt.get_type_param_nbs(i, j);
            str += " ";
            str += this->_info.interrupt.get_name_param_nbs(i, j);
        }
        this->ui->proto_inter__liste_prototypes->setItem(i, 3, new QTableWidgetItem(QString::fromStdString(str)));
    }

    /* Re-selection de l'element autrefois selectionne */
    this->ui->proto_inter__liste_prototypes->setCurrentCell(row, column);
    this->slot_proto_int__liste_prototype__clicked();

    connect(this->ui->proto_inter__liste_prototypes, SIGNAL(itemSelectionChanged()), this, SLOT(slot_proto_int__liste_prototype__update()));
    this->_info.mutex.unlock();
}

/**
** \fn void slot_proto_int__liste_prototype__clicked()
** \brief Slot gerant le clic sur un prototype
**
** \return Retourne rien
*/
void    MainWindow::slot_proto_int__liste_prototype__clicked()
{
    qDebug("MainWindow::slot_proto_int__liste_prototype__clicked()\n");

    this->ui->proto_inter__bt_edit->setEnabled(false);
    this->ui->proto_inter__bt_delete->setEnabled(false);
    if (this->ui->proto_inter__liste_prototypes->currentItem() != NULL)
    {
        this->ui->proto_inter__bt_edit->setEnabled(true);
        this->ui->proto_inter__bt_delete->setEnabled(true);
    }
}

/**
** \fn void slot_proto_int__bt_new()
** \brief Slot gerant la creation d'un nouveau prototype
**
** \return Retourne rien
*/
void    MainWindow::slot_proto_int__bt_new()
{
    qDebug("MainWindow::slot_proto_int__bt_new()\n");
    unsigned long                                        num;
    std::string                                          ret;
    std::string                                          name;
    std::vector<std::pair<std::string, std::string> >    param;

    this->_info.mutex.lock();

    num = 0;
    ret = "int";
    NewPrototypeWindow    w(&num, &ret, &name, &param, &(this->_info), this);
    w.exec();

    if (w.is_ok() > 0)
        this->_info.interrupt.add_syscall(num, name, ret, param);

    this->_info.mutex.unlock();
    this->slot_proto_int__liste_prototype__update();
}

/**
** \fn void slot_proto_int__bt_edit()
** \brief Slot gerant la modification d'un prototype
**
** \return Retourne rien
*/
void    MainWindow::slot_proto_int__bt_edit()
{
    qDebug("MainWindow::slot_proto_int__bt_edit()\n");
    QTableWidgetItem                                    *item;
    unsigned long                                       num;
    std::string                                         ret;
    std::string                                         name;
    std::vector<std::pair<std::string, std::string> >   param;

    this->_info.mutex.lock();

    if ((item = this->ui->proto_inter__liste_prototypes->item(this->ui->proto_inter__liste_prototypes->currentRow(), 0)) != NULL)
    {
        ret = "int";
        num = item->text().toLong();
        if (this->_info.interrupt.exist(num))
        {
            ret = this->_info.interrupt.get_ret(num);
            name = this->_info.interrupt.get_name(num);

            for (unsigned long i=0; i<this->_info.interrupt.get_nbs_param(num); i++)
            {
                param.push_back(std::pair<std::string, std::string>(this->_info.interrupt.get_type_param(num, i),
                                                                    this->_info.interrupt.get_name_param(num, i)));
            }
        }

        NewPrototypeWindow    w(&num, &ret, &name, &param, &(this->_info), this);
        w.exec();

        if (w.is_ok() > 0)
        {
            this->_info.interrupt.del_syscall(item->text().toLong());
            this->_info.interrupt.add_syscall(num, name, ret, param);
        }
    }

    this->_info.mutex.unlock();
    this->slot_proto_int__liste_prototype__update();
}

/**
** \fn void slot_proto_int__bt_delete()
** \brief Slot gerant la suppression d'un prototype
**
** \return Retourne rien
*/
void    MainWindow::slot_proto_int__bt_delete()
{
    qDebug("MainWindow::slot_proto_int__bt_delete()\n");
    QTableWidgetItem    *item;
    unsigned long       num;

    this->_info.mutex.lock();

    if ((item = this->ui->proto_inter__liste_prototypes->item(this->ui->proto_inter__liste_prototypes->currentRow(), 0)) != NULL)
    {
        /* Recuperation de l'adresse de la section courante */
        num = item->text().toLong();
        this->_info.interrupt.del_syscall(num);
    }

    this->_info.mutex.unlock();
    this->slot_proto_int__liste_prototype__update();
}




/**
** \fn void slot_proto_syscall__liste_prototype_func__update()
** \brief Slot gerant l'actualisation de la liste des prototypes
**
** \return Retourne rien
*/
void    MainWindow::slot_proto_syscall__liste_prototype__update()
{
    qDebug("MainWindow::slot_proto_syscall__liste_prototype__update()\n");
    int        column;
    int        row;

    this->_info.mutex.lock();
    disconnect(this->ui->proto_syscall__liste_prototypes, SIGNAL(itemSelectionChanged()), this, SLOT(slot_proto_syscall__liste_prototype__update()));

    /* Sauvegarde de l'element actuellement selectionne */
    column = this->ui->proto_syscall__liste_prototypes->currentColumn();
    row = this->ui->proto_syscall__liste_prototypes->currentRow();

    /* Preparation des protoypes */
    this->ui->proto_syscall__liste_prototypes->clearContents();
    this->ui->proto_syscall__liste_prototypes->setRowCount(this->_info.syscall.get_nbs());
    for (unsigned long i=0; i<this->_info.syscall.get_nbs(); i++)
    {
        this->ui->proto_syscall__liste_prototypes->setItem(i, 0, new QTableWidgetItem(QString::number(this->_info.syscall.get_num_nbs(i))));
        this->ui->proto_syscall__liste_prototypes->setItem(i, 1, new QTableWidgetItem(QString::fromStdString(this->_info.syscall.get_ret_nbs(i))));
        this->ui->proto_syscall__liste_prototypes->setItem(i, 2, new QTableWidgetItem(QString::fromStdString(this->_info.syscall.get_name_nbs(i))));

        std::string    str;
        for (unsigned long j=0; j<this->_info.syscall.get_nbs_param_nbs(i); j++)
        {
            if (j > 0)
                str += ", ";
            str += this->_info.syscall.get_type_param_nbs(i, j);
            str += " ";
            str += this->_info.syscall.get_name_param_nbs(i, j);
        }
        this->ui->proto_syscall__liste_prototypes->setItem(i, 3, new QTableWidgetItem(QString::fromStdString(str)));
    }

    /* Re-selection de l'element autrefois selectionne */
    this->ui->proto_syscall__liste_prototypes->setCurrentCell(row, column);
    this->slot_proto_syscall__liste_prototype__clicked();

    connect(this->ui->proto_syscall__liste_prototypes, SIGNAL(itemSelectionChanged()), this, SLOT(slot_proto_syscall__liste_prototype__update()));
    this->_info.mutex.unlock();
}

/**
** \fn void slot_proto_syscall__liste_prototype__clicked()
** \brief Slot gerant le clic sur un prototype
**
** \return Retourne rien
*/
void    MainWindow::slot_proto_syscall__liste_prototype__clicked()
{
    qDebug("MainWindow::slot_proto_syscall__liste_prototype__clicked()\n");

    this->ui->proto_syscall__bt_edit->setEnabled(false);
    this->ui->proto_syscall__bt_delete->setEnabled(false);
    if (this->ui->proto_syscall__liste_prototypes->currentItem() != NULL)
    {
        this->ui->proto_syscall__bt_edit->setEnabled(true);
        this->ui->proto_syscall__bt_delete->setEnabled(true);
    }
}

/**
** \fn void slot_proto_syscall__bt_new()
** \brief Slot gerant la creation d'un nouveau prototype
**
** \return Retourne rien
*/
void    MainWindow::slot_proto_syscall__bt_new()
{
    qDebug("MainWindow::slot_proto_syscall__bt_new()\n");
    unsigned long                                        num;
    std::string                                          ret;
    std::string                                          name;
    std::vector<std::pair<std::string, std::string> >    param;

    this->_info.mutex.lock();

    num = 0;
    ret = "int";
    NewPrototypeWindow    w(&num, &ret, &name, &param, &(this->_info), this);
    w.exec();

    if (w.is_ok() > 0)
        this->_info.syscall.add_syscall(num, name, ret, param);

    this->_info.mutex.unlock();
    this->slot_proto_syscall__liste_prototype__update();
}

/**
** \fn void slot_proto_syscall__bt_edit()
** \brief Slot gerant la modification d'un prototype
**
** \return Retourne rien
*/
void    MainWindow::slot_proto_syscall__bt_edit()
{
    qDebug("MainWindow::slot_proto_syscall__bt_edit()\n");
    QTableWidgetItem                                     *item;
    unsigned long                                        num;
    std::string                                          ret;
    std::string                                          name;
    std::vector<std::pair<std::string, std::string> >    param;

    this->_info.mutex.lock();

    if ((item = this->ui->proto_syscall__liste_prototypes->item(this->ui->proto_syscall__liste_prototypes->currentRow(), 0)) != NULL)
    {
        ret = "int";
        num = item->text().toLong();
        if (this->_info.syscall.exist(num))
        {
            ret = this->_info.syscall.get_ret(num);
            name = this->_info.syscall.get_name(num);

            for (unsigned long i=0; i<this->_info.syscall.get_nbs_param(num); i++)
            {
                param.push_back(std::pair<std::string, std::string>(this->_info.syscall.get_type_param(num, i),
                                                                    this->_info.syscall.get_name_param(num, i)));
            }
        }

        NewPrototypeWindow    w(&num, &ret, &name, &param, &(this->_info), this);
        w.exec();

        if (w.is_ok() > 0)
        {
            this->_info.syscall.del_syscall(item->text().toLong());
            this->_info.syscall.add_syscall(num, name, ret, param);
        }
    }

    this->_info.mutex.unlock();
    this->slot_proto_syscall__liste_prototype__update();
}

/**
** \fn void slot_proto_syscall__bt_delete()
** \brief Slot gerant la suppression d'un prototype
**
** \return Retourne rien
*/
void    MainWindow::slot_proto_syscall__bt_delete()
{
    qDebug("MainWindow::slot_proto_syscall__bt_delete()\n");
    QTableWidgetItem    *item;
    unsigned long       num;

    this->_info.mutex.lock();

    if ((item = this->ui->proto_syscall__liste_prototypes->item(this->ui->proto_syscall__liste_prototypes->currentRow(), 0)) != NULL)
    {
        num = item->text().toLong();
        this->_info.syscall.del_syscall(num);
    }

    this->_info.mutex.unlock();
    this->slot_proto_syscall__liste_prototype__update();
}

