#include    "mainwindow.h"
#include    "ui_mainwindow.h"

#include    "newsegmentwindow.h"
#include    "savesegmentwindow.h"


/**
** \fn void slot_seg__list_segment__update()
** \brief Slot gerant l'actualisation de la liste des segments
**
** \return Retourne rien
*/
void    MainWindow::slot_seg__list_segment__update()
{
    qDebug("MainWindow::slot_seg__list_segment__update()\n");
    QString    str;
    int        column;
    int        row;

    this->_info.mutex.lock();

    /* Sauvegarde de l'element actuellement selectionne */
    column = this->ui->seg__liste_segments->currentColumn();
    row = this->ui->seg__liste_segments->currentRow();
    this->ui->seg__liste_segments->setSortingEnabled(false);

    /* Preparation de la liste des segments */
    this->ui->seg__liste_segments->clearContents();
    this->ui->seg__liste_segments->setRowCount(this->_info.sec.get_nbs_section());
    for (unsigned long i=0; i<this->_info.sec.get_nbs_section(); i++)
    {
        this->ui->seg__liste_segments->setItem(i, 0, new QTableWidgetItem(QString::fromStdString(Calcul::lto0x(this->_info.sec.get_addr_section(i)))));
        this->ui->seg__liste_segments->setItem(i, 1, new QTableWidgetItem(QString::fromStdString(Calcul::ltos(this->_info.sec.get_size_section(i)))));

        str = "";
        if ((this->_info.sec.get_flag_section(i) & SECTION_R) & SECTION_R)
            str += "R";
        if ((this->_info.sec.get_flag_section(i) & SECTION_W) & SECTION_W)
            str += "W";
        if ((this->_info.sec.get_flag_section(i) & SECTION_X) & SECTION_X)
            str += "X";
        if ((this->_info.sec.get_flag_section(i) & SECTION_A) & SECTION_A)
            str += "A";
        this->ui->seg__liste_segments->setItem(i, 2, new QTableWidgetItem(str));
    }

    /* Re-selection de l'element autrefois selectionne */
    this->ui->seg__liste_segments->setSortingEnabled(true);
    this->ui->seg__liste_segments->setCurrentCell(row, column);
    this->_info.mutex.unlock();

    this->slot_seg__list_segment__clicked();
}

/**
** \fn void slot_seg__list_segment__clicked()
** \brief Slot gerant l'affichage du contenu d'un segment
**
** \return Retourne rien
*/
void    MainWindow::slot_seg__list_segment__clicked()
{
    qDebug("MainWindow::slot_seg__list_segment__clicked()\n");
    unsigned long          addr;
    unsigned long          size;
    int                    flags;
    const unsigned char    *data;

    /* Si un segment est selectionne, les bouton "Editer" et "Supprimer" sont actifs */
    this->ui->seg__bt_edit->setEnabled(false);
    this->ui->seg__bt_delete->setEnabled(false);
    this->ui->seg__bt_save->setEnabled(false);
    if (this->ui->seg__liste_segments->currentItem() != NULL)
    {
        this->ui->seg__bt_edit->setEnabled(true);
        this->ui->seg__bt_delete->setEnabled(true);
        this->ui->seg__bt_save->setEnabled(true);
        this->ui->seg__liste_segments->selectRow(this->ui->seg__liste_segments->currentRow());
    }

    /* On ne fait qu'un try_look car l'operation est lourde et il y a parfois inter-bloquage */
    if (this->_info.mutex.try_lock() == 0)
        return ;

    if (this->slot_seg__get_infos_selected_segment(this->ui->seg__liste_segments->currentRow(), addr, size, flags) > 0)
    {
        /* Identifie le numero da la section */
        for (unsigned long i=0; i<this->_info.sec.get_nbs_section(); i++)
        {
            if ((this->_info.sec.get_addr_section(i) == addr) &&
                (this->_info.sec.get_size_section(i) == size) &&
                (this->_info.sec.get_flag_section(i) == flags))
            {
                size = this->_info.sec.get_size_section(i);
                data = this->_info.sec.get_buffer_section(i);

                /* Affichage du contenu du segment */
                this->ui->seg__content->set_data_hex(this->ui->seg__scrollbar_content , addr, data, size);

                /* Sort de la boucle de parcourt des sections */
                i = this->_info.sec.get_nbs_section();
            }
        }
    }
    else
        this->ui->seg__content->set_data_hex(this->ui->seg__scrollbar_content , 0, NULL, 0);
    this->_info.mutex.unlock();
}

/**
** \fn void slot_seg__change_selected_segment(unsigned long addr, unsigned long size, int flags)
** \brief Gere la selection d'un segment precis
**
** \param addr Adresse du segment a selectionner
** \param size Taille du segment a selectionner
** \param flags Flags du segment a selectionner
** \return Retourne rien
*/
void    MainWindow::slot_seg__change_selected_segment(unsigned long addr, unsigned long size, int flags)
{
    qDebug("MainWindow::slot_seg__change_selected_segment(unsigned long addr, unsigned long size, int flags)\n");
    unsigned long          addr_tmp;
    unsigned long          size_tmp;
    int                    flags_tmp;

    this->_info.mutex.lock();

    for (int i=0; i<this->ui->seg__liste_segments->rowCount(); i++)
    {
        if (this->slot_seg__get_infos_selected_segment(i, addr_tmp, size_tmp, flags_tmp) > 0)
        {
            /* Si les infos correspondent a ceux de la colonnes a selectionner */
            if ((addr == addr_tmp) && (size = size_tmp) && (flags == flags_tmp))
            {
                this->ui->seg__liste_segments->selectRow(i);
                i = this->ui->seg__liste_segments->rowCount();
            }
        }
    }

    this->_info.mutex.unlock();
    this->slot_seg__list_segment__clicked();
}


/**
** \fn void slot_seg__bt_new()
** \brief Slot gerant la creation d'un nouveau segment
**
** \return Retourne rien
*/
void    MainWindow::slot_seg__bt_new()
{
    qDebug("MainWindow::slot_seg__bt_new()\n");
    unsigned long       addr;
    unsigned long       size;
    int                 flags;

    this->_info.mutex.lock();

    NewSegmentWindow    w(0, 0, 0, &(this->_info.sec), this);
    w.exec();
    addr = w.get_addr_segment();
    size = w.get_size_segment();
    flags = w.get_flags_segment();

    this->_info.mutex.unlock();
    this->slot_seg__list_segment__update();
    this->slot_seg__change_selected_segment(addr, size, flags);
}

/**
** \fn void slot_seg__bt_edit()
** \brief Slot permettant d'editer l'adresse, la taille et les droits d'un segment
**
** \return Retourne rien
*/
void    MainWindow::slot_seg__bt_edit()
{
    qDebug("MainWindow::slot_seg__bt_edit()\n");
    unsigned long       addr;
    unsigned long       size;
    int                 flags;

    this->_info.mutex.lock();

    addr = 0;
    size = 0;
    flags = 0;
    if (this->slot_seg__get_infos_selected_segment(this->ui->seg__liste_segments->currentRow(), addr, size, flags) > 0)
    {
        NewSegmentWindow    w(addr, size, flags, &(this->_info.sec), this);

        w.exec();
        addr = w.get_addr_segment();
        size = w.get_size_segment();
        flags = w.get_flags_segment();
    }

    this->_info.mutex.unlock();
    this->slot_seg__list_segment__update();
    this->slot_seg__change_selected_segment(addr, size, flags);
}

/**
** \fn void slot_seg__bt_delete()
** \brief Slot gerant la suppression du segment selectionne
**
** \return Retourne rien
*/
void    MainWindow::slot_seg__bt_delete()
{
    qDebug("MainWindow::slot_seg__bt_delete()\n");
    unsigned long       addr;
    unsigned long       size;
    int                 flags;

    this->_info.mutex.lock();

    if (this->slot_seg__get_infos_selected_segment(this->ui->seg__liste_segments->currentRow(), addr, size, flags) > 0)
        this->_info.sec.del_section(addr, size, flags);

    this->_info.mutex.unlock();
    this->slot_seg__list_segment__update();
}


/**
** \fn void slot_seg__bt_save()
** \brief Slot gerant l'enregistrement dans un fichier du segment selectionne
**
** \return Retourne rien
*/
void    MainWindow::slot_seg__bt_save()
{
    qDebug("MainWindow::slot_seg__bt_save()\n");
    unsigned long          addr;
    unsigned long          size;
    int                    flags;
    const unsigned char    *data;


    this->_info.mutex.lock();

    if (this->slot_seg__get_infos_selected_segment(this->ui->seg__liste_segments->currentRow(), addr, size, flags) > 0)
    {
        /* Identifie le numero da la section */
        for (unsigned long i=0; i<this->_info.sec.get_nbs_section(); i++)
        {
            if ((this->_info.sec.get_addr_section(i) == addr) &&
                (this->_info.sec.get_size_section(i) == size) &&
                (this->_info.sec.get_flag_section(i) == flags))
            {
                size = this->_info.sec.get_size_section(i);
                data = this->_info.sec.get_buffer_section(i);

                SaveSegmentWindow    w(addr, data, size, this);
                w.exec();

                /* Sort de la boucle de parcourt des sections */
                i = this->_info.sec.get_nbs_section();
            }
        }
    }

    this->_info.mutex.unlock();
}


/**
** \fn int slot_seg__get_infos_selected_segment(int row, unsigned long &addr, unsigned long &size, int &flags)
** \brief Gere la recuperation des infos d'un segment dans la liste des segments
**
** \param row Ligne contenant les infos du segment a recuperer
** \param addr Reference sur un long ou mettre l'adresse du segment selectionne
** \param size Reference sur un long ou mettre la taille du segment selectionne
** \param flags Reference sur un int ou mettre les flags du segment selectionne
** \return Retourne 1 si OK, 0 sinon
*/
int    MainWindow::slot_seg__get_infos_selected_segment(int row, unsigned long &addr, unsigned long &size, int &flags)
{
    qDebug("MainWindow::slot_seg__get_infos_selected_segment(unsigned long &addr, unsigned long &size, int &flags)\n");
    QTableWidgetItem    *item_addr;
    QTableWidgetItem    *item_size;
    QTableWidgetItem    *item_flag;
    std::string         str;
    unsigned long       pos;

    item_addr = this->ui->seg__liste_segments->item(row, 0);
    item_size = this->ui->seg__liste_segments->item(row, 1);
    item_flag = this->ui->seg__liste_segments->item(row, 2);
    if ((item_addr != NULL) && (item_size != NULL) && (item_flag != NULL))
    {
        /* Recuperation de l'adresse de la section courante */
        str = item_addr->text().toStdString();
        if ((pos = str.find("0x")) != std::string::npos)
        {
            addr = Calcul::xtol(&(str.c_str()[pos + 2]));

            /* Recuperation de la taille de la section courante */
            size = item_size->text().toLong();

            /* Recuperation des flags de la section courante */
            flags = 0;
            if (item_flag->text().indexOf("R") != -1)
                flags = flags | SECTION_R;
            if (item_flag->text().indexOf("W") != -1)
                flags = flags | SECTION_W;
            if (item_flag->text().indexOf("X") != -1)
                flags = flags | SECTION_X;
            if (item_flag->text().indexOf("A") != -1)
                flags = flags | SECTION_A;

            return (1);
        }
    }

    return (0);
}
