#ifndef VIEWERCALLGRAPH_HPP
#define VIEWERCALLGRAPH_HPP

#include    "ViewerGraph.hpp"
#include    "INode.hpp"

class    MainWindow;
class    NodeFunction;

class ViewerCallGraph : public ViewerGraph
{
public:
    ViewerCallGraph(QWidget *parent);
    ~ViewerCallGraph();

    /**
    ** \fn int show(Info *info, unsigned long entry, unsigned long profondeur, MainWindow *window)
    ** \brief Gere l'affichage d'un callgraphe
    **
    ** \param info Structure contenant les infos du programme a analyser
    ** \param entry Adresse de la fonction a partir de laquelle tracer le callgraph
    ** \param profondeur Profondeur du callgraphe
    ** \param window Window contenant le graphe
    ** \return Retourne 1 si OK, 0 sinon
    */
    int    show(Info *info, unsigned long entry, unsigned long profondeur, MainWindow *window);

    /**
    ** \fn int save(const std::string &name, unsigned long addr, unsigned long profondeur, Info *info, MainWindow *window)
    ** \brief Gere l'enregistrement d'un callgraph
    **
    ** \param name Nom de l'image ou enregistrer la scene
    ** \param addr Adresse du point d'entree du callgraph
    ** \param profondeur Profondeur du callgraphe
    ** \param info Structure contenant les infos du programme a analyser
    ** \param window window Window contenant le graphe
    ** \return Retourne 1 si OK, 0 sinon
    */
    int    save(const std::string &name, unsigned long addr, unsigned long profondeur, Info *info, MainWindow *window);

protected:
    /**
    ** \fn int search_nodes_to_do(const Info *info, unsigned long entry,
    **                            unsigned long profondeur_max,
    **                            std::set<unsigned long> &addr_func,
    **                            std::set<std::pair<unsigned long, unsigned long> > &link_func)
    ** \brief Cherche les adresses des fonctions a ajouter au callgraphe
    **
    ** \param info Structure contenant les infos du programme a analyser
    ** \param entry Point d'entree d'ou effectuer la recherche des fonctions
    ** \param profondeur_max Profondeur max de l'analyse
    ** \param addr_func Adresse des fonctions a ajouter au callgraphe
    ** \param link_func Set des liens entre fonctions <addr_src, addr_dest>
    ** \return Retourne 1 si OK, 0 sinon
    */
    int    search_nodes_to_do(const Info *info, unsigned long entry,
                              unsigned long profondeur_max,
                              std::set<unsigned long> &addr_func,
                              std::set<std::pair<unsigned long, unsigned long> > &link_func);

    /**
    ** int make_nodes_function(QGraphicsScene *scene, MainWindow *window,
    **                         Info *info, unsigned long entry,
    **                         std::set<unsigned long> &addr_func,
    **                         std::map<unsigned long, NodeFunction*> &nodes)
    ** \brief Gere la creation du callgraphe
    **
    ** \param scene Scene ou mettre les Nodes correspondants aux fonction afin d'en faire un graphe
    ** \param window Window contenant le graphe
    ** \param info Structure contenant les infos du programme a analyser
    ** \param entry Point d'entree d'ou commencer le graphe
    ** \param addr_func Adresse des fonction a ajouter au callgraphe
    ** \param nodes Map devant contenir les Nodes correspondants aux fonctions <addr, Node*>
    ** \return Retourne 1 si OK, 0 sinon
    */
    int    make_nodes_function(QGraphicsScene *scene, MainWindow *window,
                               Info *info, unsigned long entry,
                               std::set<unsigned long> &addr_func,
                               std::map<unsigned long, NodeFunction*> &nodes);

    /**
    ** \fn int put_nodes(std::map<unsigned long, NodeFunction*> &nodes,
    **                   std::set<std::pair<unsigned long, unsigned long> > &link_func)
    ** \brief Gere le placement des Nodes du le graphe
    **
    ** \param nodes Tableau contenant les nodes a placer <addr, Node>
    ** \param link_func Set des liens entre fonctions <addr_src, addr_dest>
    ** \return Retourne 1 si OK, 0 sinon
    */
    int    put_nodes(std::map<unsigned long, NodeFunction*> &nodes,
                     std::set<std::pair<unsigned long, unsigned long> > &link_func);
};


class    NodeFunction: public INode
{
    Q_OBJECT

public:
    NodeFunction(const std::string &name, unsigned long addr, Info *info, int status,
                 ViewerCallGraph *viewer, MainWindow *window);
    ~NodeFunction();

    void    update_rect();

    /**
    ** \fn QRectF boundingRect() const
    ** \brief Modifie la zone d'affichage du Node
    **
    ** \return Retourne les dimensions de la nouvelle zone d'affichage du Node
    */
    QRectF       boundingRect() const;

    /**
    ** \fn QPainterPath shape() const
    ** \brief Adapte la zone de selection du Node a ses dimensions
    **
    ** \return Retourne la zone de selection du Node
    */
    QPainterPath shape() const;

    /**
    ** \fn void paint(QPainter *painter, const QStyleOptionGraphicsItem*, QWidget *)
    ** \brief Fonction gerant l'affichage du Node
    **
    ** \param painter Pointeur sur l'objet permettant de dessiner le Node
    ** \return Retourne rien
    */
    void         paint(QPainter *painter, const QStyleOptionGraphicsItem*, QWidget*);

    /**
    ** \fn QPointF get_posInput() const
    ** \brief Fonction permettant de connaitre la position relative du point d'entree du Node
    **
    ** \return Retourne la position relative du point d'entree du Node
    */
    QPointF      get_posInput() const;

    /**
    ** \fn QPointF get_posOutput() const
    ** \brief Fonction permettant de connaitre la position relative du point de sortie du Node
    **
    ** \return Retourne la position relative du point d'entree du Node
    */
    QPointF      get_posOutput() const;

public slots:
    /**
    ** \fn void slot_edit_description()
    ** \brief Permet d'editer la description de la fonction correspondant a ce Node
    **
    ** \return Retourne rien
    */
    void    slot_edit_description();

    /**
    ** \fn void slot_edit_prototype()
    ** \brief Permet d'editer le prototype de la fonction correspondant a ce Node
    **
    ** \return Retourne rien
    */
    void    slot_edit_prototype();

    /**
    ** \fn void slot_show_callgraph()
    ** \brief Permet d'afficher le callgraph correspondant a ce Node
    **
    ** \return Retourne rien
    */
    void    slot_show_callgraph();

    /**
    ** \fn void slot_show_asm()
    ** \brief Permet d'afficher le graphe ASM correspondant a ce Node
    **
    ** \return Retourne rien
    */
    void    slot_show_asm();

    /**
    ** \fn void slot_show_c()
    ** \brief Permet d'afficher le code C correspondant a ce Node
    **
    ** \return Retourne rien
    */
    void    slot_show_c();

    /**
    ** \fn void slot_deassembler()
    ** \brief Permet de deassembler la fonction correspondant a ce Node
    **
    ** \return Retourne rien
    */
    void    slot_deassembler();

    /**
    ** \fn void slot_nettoyer()
    ** \brief Permet de nettoyer la fonction correspondant a ce Node
    **
    ** \return Retourne rien
    */
    void    slot_nettoyer();

    /**
    ** \fn void slot_decompiler()
    ** \brief Permet de decompiler la fonction correspondant a ce Node
    **
    ** \return Retourne rien
    */
    void    slot_decompiler();

protected:
    /**
    ** \fn void mousePressEvent(QGraphicsSceneMouseEvent *event)
    ** \brief Gestion des clics de la souris
    **
    ** \param event Pointeur sur la description de l'evenement
    ** \return Retourne rien
    */
    void              mousePressEvent(QGraphicsSceneMouseEvent *event);

protected:
    /** Adresse de la fonction */
    unsigned long    _addr;
    /** Nom de la fonction */
    std::string      _name;
    /** Texte a afficher dans la Node */
    QString          _txt;

    /** Dimensions de de la Node */
    QRectF           _rect;
    /** Status de la fonction correspondant a la Node (0: Node racine, 1: deja deassemblee, 2: non-deassemblee) */
    int             _status;

    /** Pointeur sur la structure contenant les infos du programme */
    Info             *_info;
    /** Pointeur sur l'interface graphique */
    MainWindow       *_window;
};



namespace Ui
{
    class GetDescriptionDialog;
}

class GetDescriptionWindow : public QDialog
{
    Q_OBJECT
public:
    explicit GetDescriptionWindow(const std::string &titre, std::string *descr, QWidget *parent = 0);
    ~GetDescriptionWindow();

public slots:
    /**
    ** \fn void slot_validate()
    ** \brief Gere la validation des changements effectuee par le menu
    **
    ** \return Retourne rien
    */
    void    slot_validate();

protected:
    /** Pointeur sur la description a editer */
    std::string                 *_descr;

    /** Interface graphique du menu */
    Ui::GetDescriptionDialog    *ui;

};

#endif
