#include    "newsegmentwindow.h"
#include    "ui_newsegmentwindow.h"


NewSegmentWindow::NewSegmentWindow(unsigned long addr, unsigned long size, int flags, Section *section, QWidget *parent) : QDialog(parent),
    _addr(addr),
    _size(size),
    _flags(flags),
    _section(section),
    ui(new Ui::Dialog2)
{
    ui->setupUi(this);

    this->actualisation();
}

NewSegmentWindow::~NewSegmentWindow()
{
    delete ui;
}


/**
** \fn void actualisation()
** \brief Gere l'actualisation du  contenu du menu
**
** \param info Structure contenant les infos du programme a analyser
** \return Retourne rien
*/
void    NewSegmentWindow::actualisation()
{
    unsigned long          size;
    int                    flags;
    const unsigned char    *data;

    /* Recupere les caracteristiques du segment */
    data = NULL;
    size = 0;
    flags = 0;
    for (unsigned long i=0; i<this->_section->get_nbs_section(); i++)
    {
        if ((this->_section->get_addr_section(i) == this->_addr) &&
            (this->_section->get_size_section(i) == this->_size) &&
            (this->_section->get_flag_section(i) == this->_flags))
        {
            size = this->_section->get_size_section(i);
            flags = this->_section->get_flag_section(i);
            data = this->_section->get_buffer_section(i);
            i = this->_section->get_nbs_section();
        }
    }

    /* Actualisation des differents champs */
    this->ui->field_addr->setText(QString::number(this->_addr, 16));
    this->ui->field_size->setText(QString::number(size));
    this->ui->field_r->setChecked(false);
    this->ui->field_w->setChecked(false);
    this->ui->field_x->setChecked(false);
    this->ui->field_a->setChecked(false);
    if ((flags & SECTION_R) == SECTION_R)
        this->ui->field_r->setChecked(true);
    if ((flags & SECTION_W) == SECTION_W)
        this->ui->field_w->setChecked(true);
    if ((flags & SECTION_X) == SECTION_X)
        this->ui->field_x->setChecked(true);
    if ((flags & SECTION_A) == SECTION_A)
        this->ui->field_a->setChecked(true);

    /* Actualisation du champ data */
    this->ui->field_data->set_data_hex(this->ui->field_scrollbar_data, this->ui->field_addr->text().toLong(NULL, 16), data, size);
}

/**
** \fn unsigned long get_addr(_segment) const
** \brief Assesseur permettant de connaitre la derniere adresse du segment dans le formulaire
**
** \return Retourne la derniere adresse du segment dans le formulaire
*/
unsigned long    NewSegmentWindow::get_addr_segment() const
{
    return (Calcul::xtol(this->ui->field_addr->text().toAscii()));
}

/**
** \fn unsigned long get_size_segment() const
** \brief Assesseur permettant de connaitre la derniere taille du segment dans le formulaire
**
** \return Retourne la derniere taille du segment dans le formulaire
*/
unsigned long    NewSegmentWindow::get_size_segment() const
{
    return (atol(this->ui->field_size->text().toAscii()));
}

/**
** \fn int get_flags_segment() const
** \brief Assesseur permettant de connaitre les derniers flags du segment dans le formulaire
**
** \return Retourne les derniers flags du segment dans le formulaire
*/
int               NewSegmentWindow::get_flags_segment() const
{
    int    flags;

    flags = 0;
    if (this->ui->field_r->isChecked())
        flags = flags | SECTION_R;
    if (this->ui->field_w->isChecked())
        flags = flags | SECTION_W;
    if (this->ui->field_x->isChecked())
        flags = flags | SECTION_X;
    if (this->ui->field_a->isChecked())
        flags = flags | SECTION_A;

    return (flags);
}

/**
** \fn void slot_validate()
** \brief Gere la validation des changements effectuee par le menu
**
** \return Retourne rien
*/
void    NewSegmentWindow::slot_validate()
{
    qDebug("NewSegmentWindow::slot_validate()\n");
    QString                             str;
    unsigned long                       addr;
    unsigned long                       size;
    int                                 flags;
    unsigned char                       *data;
    const std::vector<unsigned char>    *vector_data;

    /* Actualisation des differents champs */
    addr = this->get_addr_segment();
    size = this->get_size_segment();
    flags = this->get_flags_segment();

    /* On ne cree/modifie un segment que si sa taille est superieure a 0 */
    if (size > 0)
    {
        /* Actualisation des donnees */
        str = this->ui->field_data->toPlainText();
        if ((data = new unsigned char[size]) != NULL)
        {
            /* Mise a zero des donnees */
            memset(data, 0, size);

            /* On copie les donnees entrees par l'utilisateur */
            vector_data = &(this->ui->field_data->get_data());
            for (unsigned long i=0; i<size && i<vector_data->size(); i++)
                data[i] = (*vector_data)[i];

            /* Si l'utilisateur n'a pas precise toutes les donnees, on garde celles des autres segments */
            for (unsigned long i=vector_data->size(); i<size; i++)
                data[i] = this->_section->get_char(addr + i);

            /* Creation/modification du segment */
            this->_section->add_section(addr, size, data, flags, this->_addr, this->_size, this->_flags);
        }
    }
}

/**
** \fn void slot_get_filename()
** \brief Slot Permettant de recuperer le nom du fichier a utiliser comme contenu de segment
**
** \return Retourne rien
*/
void    NewSegmentWindow::slot_get_filename()
{
    qDebug("NewSegmentWindow::slot_get_filename()\n");
    unsigned char    *data;
    unsigned long    size;
    unsigned long    size_tmp;
    unsigned long    tmp;
    int              f;

    QString    filename = QFileDialog::getOpenFileName(this);
    if (filename.size() > 0)
    {
        size = 0;
        this->ui->field_data->set_data_hex(this->ui->field_scrollbar_data, this->ui->field_addr->text().toLong(NULL, 16), NULL, 0);

        /* Ouverture du fichier et recuperation de sa taille */
        if ((f = ::open(filename.toAscii(), O_RDONLY)) > 0)
        {
            if ((size_tmp = ::lseek(f, 0, SEEK_END)) != static_cast<unsigned long>(-1))
            {
                if (::lseek(f, 0, SEEK_SET) == 0)
                {
                    if ((data = new unsigned char[size_tmp]) != NULL)
                    {
                        /* Recuperation du contenu du fichier */
                        ::memset(data, 0, size_tmp);
                        while ((tmp = ::read(f, &(data[size]), size_tmp - size)) > 0)
                            size += tmp;

                        this->ui->field_data->set_data_hex(this->ui->field_scrollbar_data, this->ui->field_addr->text().toLong(NULL, 16), data, size);
                        delete data;
                    }
                }
            }

            this->ui->field_size->setText(QString::fromStdString(Calcul::ltos(size)));
            ::close(f);
        }
        else
        {
            QMessageBox    msg(QMessageBox::Warning, "ERROR", "Impossible d'ouvrir le fichier");
            msg.exec();
        }
    }
}

/**
** \fn void slot_check_formulaire()
** \brief Slot Permettant de verifier que le contenu des champs est valide
**
** \return Retourne rien
*/
void    NewSegmentWindow::slot_check_formulaire()
{
    qDebug("NewSegmentWindow::slot_check_formulaire()\n");

    /* Par defaut, on peut valider */
    if (this->ui->buttonBox->button(QDialogButtonBox::Ok) != NULL)
        this->ui->buttonBox->button(QDialogButtonBox::Ok)->setEnabled(true);

    /* Verifie les champs Adresse et Taille */
    this->ui->field_addr->setStyleSheet("");
    if ((this->ui->field_addr->text().size() <= 0) ||
        (BNFcalcul::is_hexa_sans_0x(this->ui->field_addr->text().toStdString(), NULL, NULL, 0, 0) != this->ui->field_addr->text().toStdString().size()))
    {
        this->ui->field_addr->setStyleSheet("background-color: red;");
        if (this->ui->buttonBox->button(QDialogButtonBox::Ok) != NULL)
            this->ui->buttonBox->button(QDialogButtonBox::Ok)->setEnabled(false);
    }
    else
        this->ui->field_data->set_address(this->ui->field_addr->text().toLong(NULL, 16));

    this->ui->field_size->setStyleSheet("");
    if ((this->ui->field_size->text().size() <= 0) ||
        (BNFcalcul::is_udecimal(this->ui->field_size->text().toStdString(), NULL, NULL, 0, 0) != this->ui->field_size->text().toStdString().size()) ||
        (atol(this->ui->field_size->text().toAscii()) <= 0))
    {
        this->ui->field_size->setStyleSheet("background-color: red;");
        if (this->ui->buttonBox->button(QDialogButtonBox::Ok) != NULL)
            this->ui->buttonBox->button(QDialogButtonBox::Ok)->setEnabled(false);
    }
}
