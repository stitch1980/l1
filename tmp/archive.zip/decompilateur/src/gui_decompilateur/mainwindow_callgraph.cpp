#include    "mainwindow.h"
#include    "ui_mainwindow.h"
#include    <time.h>

/**
** \fn void slot_callgraph__list_entry__update()
** \brief Gere l'actualisation de la liste des fonctions dans l'onglet callgraph
**
** \return Retourne rien
*/
void    MainWindow::slot_callgraph__list_entry__update()
{
    qDebug("MainWindow::slot_callgraph__list_entry__update()\n");
    int        column;
    int        row;

    this->_info.mutex.lock();

    /* Sauvegarde de l'element actuellement selectionne */
    column = this->ui->callgraph__list_entry->currentColumn();
    row = this->ui->callgraph__list_entry->currentRow();

    /* Preparation de la liste des fonctions qu'il est possible d'utiliser pour generer un callgraph */
    this->ui->callgraph__list_entry->clearContents();
    this->ui->callgraph__list_entry->setRowCount(this->_info.function.size());
    unsigned long    i = 0;
    for (std::map<unsigned long, Fonction *>::const_iterator it=this->_info.function.begin(); it!=this->_info.function.end(); it++)
    {
        this->ui->callgraph__list_entry->setItem(i, 0, new QTableWidgetItem(QString::fromStdString(Calcul::lto0x(it->first))));
        if (this->_info.sym.get_name(it->first).size() > 0)
            this->ui->callgraph__list_entry->setItem(i, 1, new QTableWidgetItem(QString::fromStdString(this->_info.sym.get_name(it->first))));
        else
            this->ui->callgraph__list_entry->setItem(i, 1, new QTableWidgetItem(""));

        i++;
    }

    /* Re-selection de l'element autrefois selectionne */
    this->ui->callgraph__list_entry->setCurrentCell(row, column);
    this->_info.mutex.unlock();

    /* Actualisation du graphe */
    this->ui->callgraph__view->clear();
    this->slot_callgraph__list_entry__clicked();
}

/**
** \fn void slot_callgraph__list_entry__clicked()
** \brief Gere l'affichage du call-graph d'une fonction
**
** \return Retourne rien
*/
void    MainWindow::slot_callgraph__list_entry__clicked()
{
    qDebug("MainWindow::slot_callgraph__list_entry__clicked()\n");

    this->ui->callgraph__bt_generate->setEnabled(false);
    this->ui->callgraph__bt_save->setEnabled(false);
    if (this->ui->callgraph__list_entry->currentItem() != NULL)
    {
        this->ui->callgraph__bt_generate->setEnabled(true);
        this->ui->callgraph__bt_save->setEnabled(true);
    }

    this->slot_callgraph__bt_generate();
}

/**
** \fn void slot_callgraph__bt_generate()
** \brief Gere l'affichage du call-graph d'une fonction
**
** \return Retourne rien
*/
void    MainWindow::slot_callgraph__bt_generate()
{
    qDebug("MainWindow::slot_callgraph__bt_generate()\n");
    std::map<unsigned long, Fonction*>::iterator    it;
    QTableWidgetItem                                *item;
    std::string                                     str;
    unsigned long                                   addr;
    unsigned long                                   pos;

    /* Juste un try-lock pour eviter les inter-bloquages */
    if (this->_info.mutex.try_lock() == 0)
        return ;

    /* Clear le graphe */
    this->ui->callgraph__view->show(NULL, 0, 0, this);

    if ((item = this->ui->callgraph__list_entry->item(this->ui->callgraph__list_entry->currentRow(), 0)) != NULL)
    {
        /* Recuperation de l'adresse de la fonction courante */
        str = item->text().toStdString();
        if ((pos = str.find("0x")) != std::string::npos)
        {
            addr = Calcul::xtol(&(str.c_str()[pos + 2]));

            /* Identification de la fonction a transformer en graphe */
            if ((it = this->_info.function.find(addr)) != this->_info.function.end())
            {
                this->ui->callgraph__view->show(&(this->_info), addr, this->ui->callgraph__nbs_rec->value(), this);
            }
        }
    }

    this->_info.mutex.unlock();
}

/**
** \fn void slot_callgraph__bt_save()
** \brief Gere la sauvegarde du call-graph d'une fonction deassemblee
**
** \return Retourne rien
*/
void    MainWindow::slot_callgraph__bt_save()
{
    qDebug("MainWindow::slot_callgraph__bt_save()\n");
    std::map<unsigned long, Fonction*>::iterator    it;
    QTableWidgetItem                                *item;
    std::string                                     str;
    unsigned long                                   addr;
    unsigned long                                   pos;

    this->_info.mutex.lock();

    if ((item = this->ui->callgraph__list_entry->item(this->ui->callgraph__list_entry->currentRow(), 0)) != NULL)
    {
        /* Recuperation de l'adresse de la fonction courante */
        str = item->text().toStdString();
        if ((pos = str.find("0x")) != std::string::npos)
        {
            addr = Calcul::xtol(&(str.c_str()[pos + 2]));

            /* Identification de la fonction a transformer en graphe */
            if ((it = this->_info.function.find(addr)) != this->_info.function.end())
            {
                QString    filename = QFileDialog::getSaveFileName(this);
                if (filename.size() > 0)
                    this->ui->callgraph__view->save(filename.toStdString(), addr, this->ui->callgraph__nbs_rec->value(), &(this->_info), this);
            }
        }
    }

    this->_info.mutex.unlock();
}


/**
** \fn void slot_callgraph__select_an_entry(unsigned long addr)
** \brief Gere la selction d'une fonction afin d'afficher son callgraphe
**
** \param addr Adresse de la fonction a selectionner
** \return Retourne rien
*/
void    MainWindow::slot_callgraph__select_an_entry(unsigned long addr)
{
    qDebug("MainWindow::slot_callgraph__select_an_entry(unsigned long addr)\n");
    QTableWidgetItem    *item;
    std::string         str;
    unsigned long       pos;

    for (int i=0; i<this->ui->callgraph__list_entry->rowCount(); i++)
    {
        if ((item = this->ui->callgraph__list_entry->item(i, 0)) != NULL)
        {
            /* Recuperation de l'adresse de la fonction courante */
            str = item->text().toStdString();
            if ((pos = str.find("0x")) != std::string::npos)
            {
                if (Calcul::xtol(&(str.c_str()[pos + 2])) == static_cast<long>(addr))
                {
                    this->ui->tab__main->setCurrentIndex(5);
                    this->ui->callgraph__list_entry->selectRow(i);
                    return ;
                }
            }
        }
    }
}
