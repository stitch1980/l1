#include <QApplication>
#include "mainwindow.h"

int main(int argc, char **argv)
{
    QApplication    a(argc, argv);
    MainWindow      w(argc, const_cast<const char**>(argv));

    w.show();
    return (a.exec());
}
