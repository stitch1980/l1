/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created: Wed May 20 12:53:58 2015
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "mainwindow.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_MainWindow[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
      83,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      12,   11,   11,   11, 0x0a,
      25,   11,   11,   11, 0x0a,
      40,   11,   11,   11, 0x0a,
      57,   11,   11,   11, 0x0a,
      75,   11,   11,   11, 0x0a,
      96,   11,   11,   11, 0x0a,
     117,   11,   11,   11, 0x0a,
     133,   11,   11,   11, 0x0a,
     153,   11,   11,   11, 0x0a,
     171,   11,   11,   11, 0x0a,
     204,   11,   11,   11, 0x0a,
     254,  238,   11,   11, 0x0a,
     305,   11,   11,   11, 0x0a,
     324,   11,   11,   11, 0x0a,
     344,   11,   11,   11, 0x0a,
     366,   11,   11,   11, 0x0a,
     410,  390,  386,   11, 0x0a,
     471,   11,   11,   11, 0x0a,
     512,  506,   11,   11, 0x0a,
     552,   11,   11,   11, 0x0a,
     588,   11,   11,   11, 0x0a,
     607,   11,   11,   11, 0x0a,
     627,   11,   11,   11, 0x0a,
     649,   11,   11,   11, 0x0a,
     705,  680,   11,   11, 0x0a,
     779,  765,   11,   11, 0x2a,
     834,   11,   11,   11, 0x0a,
     866,   11,   11,   11, 0x0a,
     886,   11,   11,   11, 0x0a,
     907,   11,   11,   11, 0x0a,
     930,   11,   11,   11, 0x0a,
     973,   11,   11,   11, 0x0a,
    1017,   11,   11,   11, 0x0a,
    1043,   11,   11,   11, 0x0a,
    1070,   11,   11,   11, 0x0a,
    1101, 1099,   11,   11, 0x0a,
    1141,   11,   11,   11, 0x0a,
    1183,   11,   11,   11, 0x0a,
    1226,   11,   11,   11, 0x0a,
    1251,   11,   11,   11, 0x0a,
    1277,   11,   11,   11, 0x0a,
    1305,   11,   11,   11, 0x0a,
    1351,   11,   11,   11, 0x0a,
    1398,   11,   11,   11, 0x0a,
    1427,   11,   11,   11, 0x0a,
    1457,   11,   11,   11, 0x0a,
    1489,   11,   11,   11, 0x0a,
    1522,   11,   11,   11, 0x0a,
    1553,   11,   11,   11, 0x0a,
    1587,   11,   11,   11, 0x0a,
    1607,   11,   11,   11, 0x0a,
    1630,   11,   11,   11, 0x0a,
    1668,   11,   11,   11, 0x0a,
    1704,   11,   11,   11, 0x0a,
    1743,   11,   11,   11, 0x0a,
    1769,   11,   11,   11, 0x0a,
    1798,   11,   11,   11, 0x0a,
    1829,   11,   11,   11, 0x0a,
    1868,   11,   11,   11, 0x0a,
    1899,   11,   11,   11, 0x0a,
    1925,   11,   11,   11, 0x0a,
    1955, 1950,   11,   11, 0x0a,
    1993, 1950,   11,   11, 0x0a,
    2031, 1950,   11,   11, 0x0a,
    2064,   11,   11,   11, 0x0a,
    2092,   11,   11,   11, 0x0a,
    2120,   11,   11,   11, 0x0a,
    2143, 1950,   11,   11, 0x0a,
    2179, 1950,   11,   11, 0x0a,
    2216,   11,   11,   11, 0x0a,
    2253,   11,   11,   11, 0x0a,
    2291,   11,   11,   11, 0x0a,
    2321,   11,   11,   11, 0x0a,
    2347, 1950,   11,   11, 0x0a,
    2386,   11,   11,   11, 0x0a,
    2430, 2406,   11,   11, 0x0a,
    2506, 2493,   11,   11, 0x2a,
    2564,   11,   11,   11, 0x0a,
    2598,   11,   11,   11, 0x0a,
    2619,   11,   11,   11, 0x0a,
    2644,   11,   11,   11, 0x0a,
    2667,   11,   11,   11, 0x0a,
    2721, 2694,   11,   11, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_MainWindow[] = {
    "MainWindow\0\0slot_timer()\0slot_bt_open()\0"
    "slot_bt_option()\0slot_bt_parsing()\0"
    "slot_bt_definition()\0slot_bt_deassemble()\0"
    "slot_bt_clean()\0slot_bt_decompile()\0"
    "slot_bt_analyse()\0slot_seg__list_segment__update()\0"
    "slot_seg__list_segment__clicked()\0"
    "addr,size,flags\0"
    "slot_seg__change_selected_segment(ulong,ulong,int)\0"
    "slot_seg__bt_new()\0slot_seg__bt_edit()\0"
    "slot_seg__bt_delete()\0slot_seg__bt_save()\0"
    "int\0row,addr,size,flags\0"
    "slot_seg__get_infos_selected_segment(int,ulong&,ulong&,int&)\0"
    "slot_sym__liste_symboles__update()\0"
    "value\0slot_sym__change_selected_symbol(ulong)\0"
    "slot_sym__liste_symboles__clicked()\0"
    "slot_sym__bt_new()\0slot_sym__bt_edit()\0"
    "slot_sym__bt_delete()\0"
    "slot_type__list_type__update()\0"
    "item,type_var,profondeur\0"
    "slot_type__list_type_son(QTreeWidgetItem*,std::string,uint)\0"
    "item,type_var\0"
    "slot_type__list_type_son(QTreeWidgetItem*,std::string)\0"
    "slot_type__liste_type_clicked()\0"
    "slot_type__bt_new()\0slot_type__bt_edit()\0"
    "slot_type__bt_delete()\0"
    "slot_proto_func__liste_prototype__update()\0"
    "slot_proto_func__liste_prototype__clicked()\0"
    "slot_proto_func__bt_new()\0"
    "slot_proto_func__bt_edit()\0"
    "slot_proto_func__bt_delete()\0n\0"
    "slot_proto_func__edit_name(std::string)\0"
    "slot_proto_int__liste_prototype__update()\0"
    "slot_proto_int__liste_prototype__clicked()\0"
    "slot_proto_int__bt_new()\0"
    "slot_proto_int__bt_edit()\0"
    "slot_proto_int__bt_delete()\0"
    "slot_proto_syscall__liste_prototype__update()\0"
    "slot_proto_syscall__liste_prototype__clicked()\0"
    "slot_proto_syscall__bt_new()\0"
    "slot_proto_syscall__bt_edit()\0"
    "slot_proto_syscall__bt_delete()\0"
    "slot_func__liste_entry__update()\0"
    "slot_func__liste_entry__edit()\0"
    "slot_func__liste_entry__clicked()\0"
    "slot_func__bt_new()\0slot_func__bt_delete()\0"
    "slot_func_value__list_value__update()\0"
    "slot_func_value__list_value__edit()\0"
    "slot_func_value__list_value__clicked()\0"
    "slot_func_value__bt_new()\0"
    "slot_func_value__bt_delete()\0"
    "slot_func_asm__arbre__update()\0"
    "slot_func_asm__arbre__option_changed()\0"
    "slot_func_asm__bt_deassemble()\0"
    "slot_func_asm__bt_clean()\0"
    "slot_func_asm__bt_save()\0addr\0"
    "slot_func__select_an_entry_asm(ulong)\0"
    "slot_func__deassemble_an_entry(ulong)\0"
    "slot_func__clean_an_entry(ulong)\0"
    "slot_func_c__text__update()\0"
    "slot_func_c__bt_decompile()\0"
    "slot_func_c__bt_save()\0"
    "slot_func__select_an_entry_c(ulong)\0"
    "slot_func__decompile_an_entry(ulong)\0"
    "slot_callgraph__list_entry__update()\0"
    "slot_callgraph__list_entry__clicked()\0"
    "slot_callgraph__bt_generate()\0"
    "slot_callgraph__bt_save()\0"
    "slot_callgraph__select_an_entry(ulong)\0"
    "slot_anal__update()\0item,analyse,profondeur\0"
    "slot_anal__list_type_son(QTreeWidgetItem*,const Analyse*,uint)\0"
    "item,analyse\0"
    "slot_anal__list_type_son(QTreeWidgetItem*,const Analyse*)\0"
    "slot_anal__tree_analyse_clicked()\0"
    "slot_anal__bt_save()\0slot_anal__bt_save_all()\0"
    "slot_anal__bt_delete()\0"
    "slot_anal__bt_delete_all()\0"
    "f,analyse,title,profondeur\0"
    "slot_anal__save_analyse_rec(int,Analyse*,std::string,ulong)\0"
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        MainWindow *_t = static_cast<MainWindow *>(_o);
        switch (_id) {
        case 0: _t->slot_timer(); break;
        case 1: _t->slot_bt_open(); break;
        case 2: _t->slot_bt_option(); break;
        case 3: _t->slot_bt_parsing(); break;
        case 4: _t->slot_bt_definition(); break;
        case 5: _t->slot_bt_deassemble(); break;
        case 6: _t->slot_bt_clean(); break;
        case 7: _t->slot_bt_decompile(); break;
        case 8: _t->slot_bt_analyse(); break;
        case 9: _t->slot_seg__list_segment__update(); break;
        case 10: _t->slot_seg__list_segment__clicked(); break;
        case 11: _t->slot_seg__change_selected_segment((*reinterpret_cast< ulong(*)>(_a[1])),(*reinterpret_cast< ulong(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3]))); break;
        case 12: _t->slot_seg__bt_new(); break;
        case 13: _t->slot_seg__bt_edit(); break;
        case 14: _t->slot_seg__bt_delete(); break;
        case 15: _t->slot_seg__bt_save(); break;
        case 16: { int _r = _t->slot_seg__get_infos_selected_segment((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< ulong(*)>(_a[2])),(*reinterpret_cast< ulong(*)>(_a[3])),(*reinterpret_cast< int(*)>(_a[4])));
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 17: _t->slot_sym__liste_symboles__update(); break;
        case 18: _t->slot_sym__change_selected_symbol((*reinterpret_cast< ulong(*)>(_a[1]))); break;
        case 19: _t->slot_sym__liste_symboles__clicked(); break;
        case 20: _t->slot_sym__bt_new(); break;
        case 21: _t->slot_sym__bt_edit(); break;
        case 22: _t->slot_sym__bt_delete(); break;
        case 23: _t->slot_type__list_type__update(); break;
        case 24: _t->slot_type__list_type_son((*reinterpret_cast< QTreeWidgetItem*(*)>(_a[1])),(*reinterpret_cast< const std::string(*)>(_a[2])),(*reinterpret_cast< uint(*)>(_a[3]))); break;
        case 25: _t->slot_type__list_type_son((*reinterpret_cast< QTreeWidgetItem*(*)>(_a[1])),(*reinterpret_cast< const std::string(*)>(_a[2]))); break;
        case 26: _t->slot_type__liste_type_clicked(); break;
        case 27: _t->slot_type__bt_new(); break;
        case 28: _t->slot_type__bt_edit(); break;
        case 29: _t->slot_type__bt_delete(); break;
        case 30: _t->slot_proto_func__liste_prototype__update(); break;
        case 31: _t->slot_proto_func__liste_prototype__clicked(); break;
        case 32: _t->slot_proto_func__bt_new(); break;
        case 33: _t->slot_proto_func__bt_edit(); break;
        case 34: _t->slot_proto_func__bt_delete(); break;
        case 35: _t->slot_proto_func__edit_name((*reinterpret_cast< const std::string(*)>(_a[1]))); break;
        case 36: _t->slot_proto_int__liste_prototype__update(); break;
        case 37: _t->slot_proto_int__liste_prototype__clicked(); break;
        case 38: _t->slot_proto_int__bt_new(); break;
        case 39: _t->slot_proto_int__bt_edit(); break;
        case 40: _t->slot_proto_int__bt_delete(); break;
        case 41: _t->slot_proto_syscall__liste_prototype__update(); break;
        case 42: _t->slot_proto_syscall__liste_prototype__clicked(); break;
        case 43: _t->slot_proto_syscall__bt_new(); break;
        case 44: _t->slot_proto_syscall__bt_edit(); break;
        case 45: _t->slot_proto_syscall__bt_delete(); break;
        case 46: _t->slot_func__liste_entry__update(); break;
        case 47: _t->slot_func__liste_entry__edit(); break;
        case 48: _t->slot_func__liste_entry__clicked(); break;
        case 49: _t->slot_func__bt_new(); break;
        case 50: _t->slot_func__bt_delete(); break;
        case 51: _t->slot_func_value__list_value__update(); break;
        case 52: _t->slot_func_value__list_value__edit(); break;
        case 53: _t->slot_func_value__list_value__clicked(); break;
        case 54: _t->slot_func_value__bt_new(); break;
        case 55: _t->slot_func_value__bt_delete(); break;
        case 56: _t->slot_func_asm__arbre__update(); break;
        case 57: _t->slot_func_asm__arbre__option_changed(); break;
        case 58: _t->slot_func_asm__bt_deassemble(); break;
        case 59: _t->slot_func_asm__bt_clean(); break;
        case 60: _t->slot_func_asm__bt_save(); break;
        case 61: _t->slot_func__select_an_entry_asm((*reinterpret_cast< ulong(*)>(_a[1]))); break;
        case 62: _t->slot_func__deassemble_an_entry((*reinterpret_cast< ulong(*)>(_a[1]))); break;
        case 63: _t->slot_func__clean_an_entry((*reinterpret_cast< ulong(*)>(_a[1]))); break;
        case 64: _t->slot_func_c__text__update(); break;
        case 65: _t->slot_func_c__bt_decompile(); break;
        case 66: _t->slot_func_c__bt_save(); break;
        case 67: _t->slot_func__select_an_entry_c((*reinterpret_cast< ulong(*)>(_a[1]))); break;
        case 68: _t->slot_func__decompile_an_entry((*reinterpret_cast< ulong(*)>(_a[1]))); break;
        case 69: _t->slot_callgraph__list_entry__update(); break;
        case 70: _t->slot_callgraph__list_entry__clicked(); break;
        case 71: _t->slot_callgraph__bt_generate(); break;
        case 72: _t->slot_callgraph__bt_save(); break;
        case 73: _t->slot_callgraph__select_an_entry((*reinterpret_cast< ulong(*)>(_a[1]))); break;
        case 74: _t->slot_anal__update(); break;
        case 75: _t->slot_anal__list_type_son((*reinterpret_cast< QTreeWidgetItem*(*)>(_a[1])),(*reinterpret_cast< const Analyse*(*)>(_a[2])),(*reinterpret_cast< uint(*)>(_a[3]))); break;
        case 76: _t->slot_anal__list_type_son((*reinterpret_cast< QTreeWidgetItem*(*)>(_a[1])),(*reinterpret_cast< const Analyse*(*)>(_a[2]))); break;
        case 77: _t->slot_anal__tree_analyse_clicked(); break;
        case 78: _t->slot_anal__bt_save(); break;
        case 79: _t->slot_anal__bt_save_all(); break;
        case 80: _t->slot_anal__bt_delete(); break;
        case 81: _t->slot_anal__bt_delete_all(); break;
        case 82: _t->slot_anal__save_analyse_rec((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< Analyse*(*)>(_a[2])),(*reinterpret_cast< const std::string(*)>(_a[3])),(*reinterpret_cast< ulong(*)>(_a[4]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData MainWindow::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow,
      qt_meta_data_MainWindow, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &MainWindow::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow))
        return static_cast<void*>(const_cast< MainWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 83)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 83;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
