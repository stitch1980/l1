/**
** Plugin permettant de definir les nom des fonctions grace aux symbole et a une liste de noms en dur
** Le fichier doit avoir ete ouvert et parsee
** Retourne 1 si OK, -1 sinon
*/
#include    <stdio.h>
#include    <stdlib.h>
#include    <string.h>

#include    "Info.hpp"
#include    "Calcul.hpp"

#define DEBUG_PLUGIN	      32
#define PLUGIN_NAME           PLUGIN_TYPE__PARSING ".3000.plugin_type_simple.0"
#define PLUGIN_DESCRIPTION    "Plugin permettant de definir les types de variables basique (int, long, ...)\n"

extern "C"
{
    const char    *PLUGIN_FUNC_GET_PLUGIN_NAME();
    int           PLUGIN_FUNC_EXECUTE(Info *info);
    const char    *PLUGIN_FUNC_APROPOS();
}
 

/**
** \fn const char *get_plugin_name()
** \brief Fonction permettant de connaitre le nom du plugin
**
** \return Retourne un pointeur vers le nom du plugin
*/
const char    *PLUGIN_FUNC_GET_PLUGIN_NAME()
{
    return (PLUGIN_NAME);
}

/**
** \fn int execute(Info *info)
** \brief Fonction permettant d'executer le plugin pour modifier les points d'entrees a analyser
**
** \param info Classe contenant les infos du programme a analyser
** \return Retourne 1 si OK, 0 si le plugin n'a pas ete execute et -1 en cas d'erreur
*/
int    PLUGIN_FUNC_EXECUTE(Info *info)
{
    if (info == NULL)
        return (-1);

    /* Types de base */
    info->proto_var.add_definition("char", sizeof (char));
    info->proto_var.add_definition("short", sizeof (short));
    info->proto_var.add_definition("int", sizeof (int));
    if (info->archi == Info::ARCHI_I64)
        info->proto_var.add_definition("long", sizeof (long));
    else
        info->proto_var.add_definition("long", sizeof (int));
    info->proto_var.add_definition("float", sizeof (float));
    info->proto_var.add_definition("double", sizeof (double));
    if (info->archi == Info::ARCHI_I64)
        info->proto_var.add_definition("*", sizeof (long));
    else
        info->proto_var.add_definition("*", sizeof (int));

    /* Types moins de base */
    if (info->archi == Info::ARCHI_I64)
        info->proto_var.add_definition("size_t", sizeof (long));
    else
        info->proto_var.add_definition("size_t", sizeof (int));
 
    return (1);    
}

/**
** \fn const char *get_plugin_name()
** \brief Fonction permettant de d'acceder a la description du plugin
**
** \return Retourne un pointeur vers la description du plugin
*/
const char    *PLUGIN_FUNC_APROPOS()
{
    return (PLUGIN_DESCRIPTION);
}

