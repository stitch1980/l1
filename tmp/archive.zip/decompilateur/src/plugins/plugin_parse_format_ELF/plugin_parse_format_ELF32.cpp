
#define DEBUG_PLUGIN	      32
#define PLUGIN_NAME           PLUGIN_TYPE__PARSING ".2000.plugin_parse_format_elf32.0"
#define PLUGIN_DESCRIPTION    "Plugin parsant les fichiers ELF32\n"

#define	Elf_Ehdr	Elf32_Ehdr
#define	Elf_Shdr	Elf32_Shdr
#define Elf_Phdr        Elf32_Phdr

#define Elf_Rela        Elf32_Rela
#define ELF_R_SYM       ELF32_R_SYM
#define ELF_R_TYPE      ELF32_R_TYPE
#define ELF_R_INFO      ELF32_R_INFO

#define Elf_Dyn         Elf32_Dyn

#define Elf_Sym         Elf32_Sym

#define Elf_Rel         Elf32_Rel
#define ELFCLASS	ELFCLASS32
#define FORMAT		Info::FORMAT_ELF32 

#include	"plugin_format_ELF.hpp"

