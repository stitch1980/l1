
#define DEBUG_PLUGIN	      64
#define PLUGIN_NAME           PLUGIN_TYPE__PARSING ".2000.plugin_parse_format_elf64.0"
#define PLUGIN_DESCRIPTION    "Plugin parsant les fichiers ELF64\n"

#define	Elf_Ehdr	Elf64_Ehdr
#define	Elf_Shdr	Elf64_Shdr
#define Elf_Phdr        Elf64_Phdr

#define Elf_Rela        Elf64_Rela
#define ELF_R_SYM       ELF64_R_SYM
#define ELF_R_TYPE      ELF64_R_TYPE
#define ELF_R_INFO      ELF64_R_INFO

#define Elf_Dyn         Elf64_Dyn

#define Elf_Sym         Elf64_Sym

#define Elf_Rel         Elf64_Rel
#define ELFCLASS	ELFCLASS64
#define FORMAT		Info::FORMAT_ELF64

#include	"plugin_format_ELF.hpp"


