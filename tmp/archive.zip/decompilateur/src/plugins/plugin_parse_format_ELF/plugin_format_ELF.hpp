#include    <stdio.h>
#include    <stdlib.h>
#include    <string.h>
#include    <elf.h>

#include    "Info.hpp"

extern "C"
{
    const char    *PLUGIN_FUNC_GET_PLUGIN_NAME();
    int           PLUGIN_FUNC_EXECUTE(Info *info);
    const char    *PLUGIN_FUNC_APROPOS();
}

/**
** \fn get_data(void *dst, unsigned long dst_size, const unsigned char *src, unsigned long src_size, unsigned long offset)
** \brief Gere la recuperation d'une structure dans le buffer passee en parametre
**
** \param dst Buffer de destination
** \param dst_size Taille de la structure a recuperer
** \param src Buffer ou chercher le contenu de la structure a recuperer
** \param src_size Taille du buffer ou chercher le contenu de la structure a recuperer
** \param offset Offset de la structure a recuperer dans le buffer source
** \return Retourne 1 si OK, 0 si incomplet, -1 en cas d'erreur (met le reste de la structure a 0 si incomplet)
*/
int    get_data(void *dst, unsigned long dst_size, const unsigned char *src, unsigned long src_size, unsigned long offset)
{
    int    ret;

    if ((src == NULL) || (dst == NULL))
        return (-1);

    memset(dst, 0, dst_size);
    if (offset > src_size)
        return (-1);
    ret = 1;

    if ((src_size - offset) < dst_size)
    {
        dst_size = src_size - offset;
        ret = 0;
    }

    memmove(dst, &(src[offset]), dst_size);
    return (ret);
}

/**
** \fn std::string get_nieme_str(unsigned long n, const unsigned char *src, unsigned long src_size, unsigned long offset)
** \brief Gere la recuperation de la N-ieme chaine d'une section contenant des noms de symboles
**
** \param n Numero de la chaine a recuperer
** \param src Buffer ou chercher la chaine
** \param src_size Taille du buffer source
** \param offset Offet apres lequel commencer a chercher la chaine
** \return Retourne la chaine si on la trouve, "" sinon
*/
std::string	get_nieme_str(unsigned long n, const unsigned char *src, unsigned long src_size, unsigned long offset)
{
    std::string      s;
    unsigned long    i;
    unsigned char    c;

    /* Cherche le debut de la n-ieme chaine de caracteres */
    for (i=0; i<n; )
    {
        if (get_data(&c, 1, src, src_size, offset) < 0)
            return ("");
        if (c == '\0')
            i++;
        offset++;
    }

    /* Recupere la chaine caracteres apres caracteres */
    while (get_data(&c, 1, src, src_size, offset) > 0)
    {
        if (c == '\0')
            return (s);
        s.insert(s.end(), static_cast<char >(c));
        offset++;
    }

    return (s);
}

/**
** \fn void verif_header_elf(Info *info, const Elf_Ehdr *hdr)
** \brief Gere la verification et le parsing d'un entete de fichier ELF
**
** \param info Classe contenant les infos du programme a analyser
** \param hdr Entete ELF du fichier a analyser
** \return Retourne 1 si OK, 0 sinon
*/
int    verif_header_elf(Info *info, const Elf_Ehdr *hdr)
{
    /* Verifie qu'il s'agit bien d'un fichier ELF */
    if ((hdr->e_ident[EI_MAG0] != ELFMAG0) ||
        (hdr->e_ident[EI_MAG1] != ELFMAG1) ||
        (hdr->e_ident[EI_MAG2] != ELFMAG2) ||
        (hdr->e_ident[EI_MAG3] != ELFMAG3) ||
        (hdr->e_ident[EI_CLASS] != ELFCLASS))
        return (0);

    /* Identification du systeme prevu pour l'executable */
    switch (hdr->e_ident[EI_OSABI])
    {
        case ELFOSABI_SYSV:        info->os = Info::OS_SYSV;          break;
        case ELFOSABI_HPUX:        info->os = Info::OS_HPUX;          break;
        case ELFOSABI_NETBSD:      info->os = Info::OS_NETBSD;        break;
        case ELFOSABI_LINUX:       info->os = Info::OS_LINUX;         break;
        case ELFOSABI_SOLARIS:     info->os = Info::OS_SOLARIS;       break;
        case ELFOSABI_AIX:         info->os = Info::OS_AIX;           break;
        case ELFOSABI_IRIX:        info->os = Info::OS_IRIX;          break;
        case ELFOSABI_FREEBSD:     info->os = Info::OS_FREEBSD;       break;
        case ELFOSABI_TRU64:       info->os = Info::OS_TRU64;         break;
        case ELFOSABI_MODESTO:     info->os = Info::OS_MODESTO;       break;
        case ELFOSABI_OPENBSD:     info->os = Info::OS_OPENBSD;       break;
        case ELFOSABI_ARM_AEABI:   info->os = Info::OS_ARM_AEABI;     break;
        case ELFOSABI_ARM:         info->os = Info::OS_ARM;           break;
        case ELFOSABI_STANDALONE:  info->os = Info::OS_STANDALONE;    break;
        default:                   info->os = Info::OS_NONE;          break;
    }

    /* Identification de l'architecture prevu pour l'executable */
    switch (hdr->e_machine)
    {
        case EM_NONE:          info->archi = Info::ARCHI_NONE;           break;
        case EM_M32:           info->archi = Info::ARCHI_M32;            break;
        case EM_SPARC:         info->archi = Info::ARCHI_SPARC;          break;
        case EM_386:           info->archi = Info::ARCHI_I32;            break;
        case EM_68K:           info->archi = Info::ARCHI_68K;            break;
        case EM_88K:           info->archi = Info::ARCHI_88K;            break;
        case EM_860:           info->archi = Info::ARCHI_860;            break;
        case EM_MIPS:          info->archi = Info::ARCHI_MIPS;           break;
        case EM_S370:          info->archi = Info::ARCHI_S370;           break;
        case EM_MIPS_RS3_LE:   info->archi = Info::ARCHI_MIPS_RS3_LE;    break;
        case EM_PARISC:        info->archi = Info::ARCHI_PARISC;         break;
        case EM_VPP500:        info->archi = Info::ARCHI_VPP500;         break;
        case EM_SPARC32PLUS:   info->archi = Info::ARCHI_SPARC32PLUS;    break;
        case EM_960:           info->archi = Info::ARCHI_960;            break;
        case EM_PPC:           info->archi = Info::ARCHI_PPC;            break;
        case EM_PPC64:         info->archi = Info::ARCHI_PPC64;          break;
        case EM_S390:          info->archi = Info::ARCHI_S390;           break;
        case EM_V800:          info->archi = Info::ARCHI_V800;           break;
        case EM_FR20:          info->archi = Info::ARCHI_FR20;           break;
        case EM_RH32:          info->archi = Info::ARCHI_RH32;           break;
        case EM_RCE:           info->archi = Info::ARCHI_RCE;            break;
        case EM_ARM:           info->archi = Info::ARCHI_ARM;            break;
        case EM_FAKE_ALPHA:    info->archi = Info::ARCHI_FAKE_ALPHA;     break;
        case EM_SH:            info->archi = Info::ARCHI_SH;             break;
        case EM_SPARCV9:       info->archi = Info::ARCHI_SPARCV9;        break;
        case EM_TRICORE:       info->archi = Info::ARCHI_TRICORE;        break;
        case EM_ARC:           info->archi = Info::ARCHI_ARC;            break;
        case EM_H8_300:        info->archi = Info::ARCHI_H8_300;         break;
        case EM_H8_300H:       info->archi = Info::ARCHI_H8_300H;        break;
        case EM_H8S:           info->archi = Info::ARCHI_H8S;            break;
        case EM_H8_500:        info->archi = Info::ARCHI_H8_500;         break;
        case EM_IA_64:         info->archi = Info::ARCHI_IA_64;          break;
        case EM_MIPS_X:        info->archi = Info::ARCHI_MIPS_X;         break;
        case EM_COLDFIRE:      info->archi = Info::ARCHI_COLDFIRE;       break;
        case EM_68HC12:        info->archi = Info::ARCHI_68HC12;         break;
        case EM_MMA:           info->archi = Info::ARCHI_MMA;            break;
        case EM_PCP:           info->archi = Info::ARCHI_PCP;            break;
        case EM_NCPU:          info->archi = Info::ARCHI_NCPU;           break;
        case EM_NDR1:          info->archi = Info::ARCHI_NDR1;           break;
        case EM_STARCORE:      info->archi = Info::ARCHI_STARCORE;       break;
        case EM_ME16:          info->archi = Info::ARCHI_ME16;           break;
        case EM_ST100:         info->archi = Info::ARCHI_ST100;          break;
        case EM_TINYJ:         info->archi = Info::ARCHI_TINYJ;          break;
        case EM_X86_64:        info->archi = Info::ARCHI_I64;            break;
        case EM_PDSP:          info->archi = Info::ARCHI_PDSP;           break;
        case EM_FX66:          info->archi = Info::ARCHI_FX66;           break;
        case EM_ST9PLUS:       info->archi = Info::ARCHI_ST9PLUS;        break;
        case EM_ST7:           info->archi = Info::ARCHI_ST7;            break;
        case EM_68HC16:        info->archi = Info::ARCHI_68HC16;         break;
        case EM_68HC11:        info->archi = Info::ARCHI_68HC11;         break;
        case EM_68HC08:        info->archi = Info::ARCHI_68HC08;         break;
        case EM_68HC05:        info->archi = Info::ARCHI_68HC05;         break;
        case EM_SVX:           info->archi = Info::ARCHI_SVX;            break;
        case EM_ST19:          info->archi = Info::ARCHI_ST19;           break;
        case EM_VAX:           info->archi = Info::ARCHI_VAX;            break;
        case EM_CRIS:          info->archi = Info::ARCHI_CRIS;           break;
        case EM_JAVELIN:       info->archi = Info::ARCHI_JAVELIN;        break;
        case EM_FIREPATH:      info->archi = Info::ARCHI_FIREPATH;       break;
        case EM_ZSP:           info->archi = Info::ARCHI_ZSP;            break;
        case EM_MMIX:          info->archi = Info::ARCHI_MMIX;           break;
        case EM_HUANY:         info->archi = Info::ARCHI_HUANY;          break;
        case EM_PRISM:         info->archi = Info::ARCHI_PRISM;          break;
        case EM_AVR:           info->archi = Info::ARCHI_AVR;            break;
        case EM_FR30:          info->archi = Info::ARCHI_FR30;           break;
        case EM_D10V:          info->archi = Info::ARCHI_D10V;           break;
        case EM_D30V:          info->archi = Info::ARCHI_D30V;           break;
        case EM_V850:          info->archi = Info::ARCHI_V850;           break;
        case EM_M32R:          info->archi = Info::ARCHI_M32R;           break;
        case EM_MN10300:       info->archi = Info::ARCHI_MN10300;        break;
        case EM_MN10200:       info->archi = Info::ARCHI_MN10200;        break;
        case EM_PJ:            info->archi = Info::ARCHI_PJ;             break;
        case EM_OPENRISC:      info->archi = Info::ARCHI_OPENRISC;       break;
        case EM_ARC_A5:        info->archi = Info::ARCHI_ARC_A5;         break;
        case EM_XTENSA:        info->archi = Info::ARCHI_XTENSA;         break;
        default:               info->archi = Info::ARCHI_NONE;           break;
    }

    /* Identification du format de fichier */
    info->format = FORMAT;

    /* Identification du type d'endian de l'executable */
    switch (hdr->e_ident[EI_DATA])
    {
        case ELFDATANONE:    info->endian = Info::ENDIAN_NONE;    break;
        case ELFDATA2LSB:    info->endian = Info::ENDIAN_LITTLE;  break;
        case ELFDATA2MSB:    info->endian = Info::ENDIAN_BIG;     break;
        default:             info->endian = Info::ENDIAN_NONE;    break;
    }

    /* Si c'est un fichier executable, on recupere son point d'entree */
    if (hdr->e_type == ET_EXEC)
    {
        info->entry.insert(hdr->e_entry);
        info->sym.add_symbole(hdr->e_entry, "_start", Symbole::NONE);
    }

#ifdef    DEBUG_PLUGIN
    printf("Entete ELF%d :\n", DEBUG_PLUGIN);

    switch (hdr->e_ident[EI_OSABI])
    {
        case ELFOSABI_SYSV:          printf(" - OS: SYSV\n");       break;
        case ELFOSABI_HPUX:          printf(" - OS: HPUX\n");       break;
        case ELFOSABI_NETBSD:        printf(" - OS: NETBSD\n");     break;
        case ELFOSABI_LINUX:         printf(" - OS: LINUX\n");      break;
        case ELFOSABI_SOLARIS:       printf(" - OS: SOLARIS\n");    break;
        case ELFOSABI_AIX:           printf(" - OS: AIX\n");        break;
        case ELFOSABI_IRIX:          printf(" - OS: IRIX\n");       break;
        case ELFOSABI_FREEBSD:       printf(" - OS: FREEBSD\n");    break;
        case ELFOSABI_TRU64:         printf(" - OS: TRU64\n");      break;
        case ELFOSABI_MODESTO:       printf(" - OS: MODESTO\n");    break;
        case ELFOSABI_OPENBSD:       printf(" - OS: OPENBSD\n");    break;
        case ELFOSABI_ARM_AEABI:     printf(" - OS: ARM_AEABI\n");  break;
        case ELFOSABI_ARM:           printf(" - OS: ARM\n");        break;
        case ELFOSABI_STANDALONE:    printf(" - OS: STANDALONE\n"); break;
        default:                     printf(" - OS: NONE\n");       break;
    }

    switch (hdr->e_machine)
    {
        case EM_NONE:        printf(" - ARCHI: NONE\n");        break;
        case EM_M32:         printf(" - ARCHI: M32\n");         break;
        case EM_SPARC:       printf(" - ARCHI: SPARC\n");       break;
        case EM_386:         printf(" - ARCHI: 386\n");         break;
        case EM_68K:         printf(" - ARCHI: 68K\n");         break;
        case EM_88K:         printf(" - ARCHI: 88K\n");         break;
        case EM_860:         printf(" - ARCHI: 860\n");         break;
        case EM_MIPS:        printf(" - ARCHI: MIPS\n");        break;
        case EM_S370:        printf(" - ARCHI: S370\n");        break;
        case EM_MIPS_RS3_LE: printf(" - ARCHI: MIPS_RS3_LE\n"); break;
        case EM_PARISC:      printf(" - ARCHI: PARISC\n");      break;
        case EM_VPP500:      printf(" - ARCHI: VPP500\n");      break;
        case EM_SPARC32PLUS: printf(" - ARCHI: SPARC32PLUS\n"); break;
        case EM_960:         printf(" - ARCHI: 960\n");         break;
        case EM_PPC:         printf(" - ARCHI: PPC\n");         break;
        case EM_PPC64:       printf(" - ARCHI: PPC64\n");       break;
        case EM_S390:        printf(" - ARCHI: S390\n");        break;
        case EM_V800:        printf(" - ARCHI: V800\n");        break;
        case EM_FR20:        printf(" - ARCHI: FR20\n");        break;
        case EM_RH32:        printf(" - ARCHI: RH32\n");        break;
        case EM_RCE:         printf(" - ARCHI: RCE\n");         break;
        case EM_ARM:         printf(" - ARCHI: ARM\n");         break;
        case EM_FAKE_ALPHA:  printf(" - ARCHI: FAKE_ALPHA\n");  break;
        case EM_SH:          printf(" - ARCHI: SH\n");          break;
        case EM_SPARCV9:     printf(" - ARCHI: SPARCV9\n");     break;
        case EM_TRICORE:     printf(" - ARCHI: TRICORE\n");     break;
        case EM_ARC:         printf(" - ARCHI: ARC\n");         break;
        case EM_H8_300:      printf(" - ARCHI: H8_300\n");      break;
        case EM_H8_300H:     printf(" - ARCHI: H8_300H\n");     break;
        case EM_H8S:         printf(" - ARCHI: H8S\n");         break;
        case EM_H8_500:      printf(" - ARCHI: H8_500\n");      break;
        case EM_IA_64:       printf(" - ARCHI: IA_64\n");       break;
        case EM_MIPS_X:      printf(" - ARCHI: MIPS_X\n");      break;
        case EM_COLDFIRE:    printf(" - ARCHI: COLDFIRE\n");    break;
        case EM_68HC12:      printf(" - ARCHI: 68HC12\n");      break;
        case EM_MMA:         printf(" - ARCHI: MMA\n");         break;
        case EM_PCP:         printf(" - ARCHI: PCP\n");         break;
        case EM_NCPU:        printf(" - ARCHI: NCPU\n");        break;
        case EM_NDR1:        printf(" - ARCHI: NDR1\n");        break;
        case EM_STARCORE:    printf(" - ARCHI: STARCORE\n");    break;
        case EM_ME16:        printf(" - ARCHI: ME16\n");        break;
        case EM_ST100:       printf(" - ARCHI: ST100\n");       break;
        case EM_TINYJ:       printf(" - ARCHI: TINYJ\n");       break;
        case EM_X86_64:      printf(" - ARCHI: X86_64\n");      break;
        case EM_PDSP:        printf(" - ARCHI: PDSP\n");        break;
        case EM_FX66:        printf(" - ARCHI: FX66\n");        break;
        case EM_ST9PLUS:     printf(" - ARCHI: ST9PLUS\n");     break;
        case EM_ST7:         printf(" - ARCHI: ST7\n");         break;
        case EM_68HC16:      printf(" - ARCHI: 68HC16\n");      break;
        case EM_68HC11:      printf(" - ARCHI: 68HC11\n");      break;
        case EM_68HC08:      printf(" - ARCHI: 68HC08\n");      break;
        case EM_68HC05:      printf(" - ARCHI: 68HC05\n");      break;
        case EM_SVX:         printf(" - ARCHI: SVX\n");         break;
        case EM_ST19:        printf(" - ARCHI: ST19\n");        break;
        case EM_VAX:         printf(" - ARCHI: VAX\n");         break;
        case EM_CRIS:        printf(" - ARCHI: CRIS\n");        break;
        case EM_JAVELIN:     printf(" - ARCHI: JAVELIN\n");     break;
        case EM_FIREPATH:    printf(" - ARCHI: FIREPATH\n");    break;
        case EM_ZSP:         printf(" - ARCHI: ZSP\n");         break;
        case EM_MMIX:        printf(" - ARCHI: MMIX\n");        break;
        case EM_HUANY:       printf(" - ARCHI: HUANY\n");       break;
        case EM_PRISM:       printf(" - ARCHI: PRISM\n");       break;
        case EM_AVR:         printf(" - ARCHI: AVR\n");         break;
        case EM_FR30:        printf(" - ARCHI: FR30\n");        break;
        case EM_D10V:        printf(" - ARCHI: D10V\n");        break;
        case EM_D30V:        printf(" - ARCHI: D30V\n");        break;
        case EM_V850:        printf(" - ARCHI: V850\n");        break;
        case EM_M32R:        printf(" - ARCHI: M32R\n");        break;
        case EM_MN10300:     printf(" - ARCHI: MN10300\n");     break;
        case EM_MN10200:     printf(" - ARCHI: MN10200\n");     break;
        case EM_PJ:          printf(" - ARCHI: PJ\n");          break;
        case EM_OPENRISC:    printf(" - ARCHI: OPENRISC\n");    break;
        case EM_ARC_A5:      printf(" - ARCHI: ARC_A5\n");      break;
        case EM_XTENSA:      printf(" - ARCHI: XTENSA\n");      break;
        default:             printf(" - ARCHI: NONE\n");        break;
    }

    info->format = FORMAT;

    switch (hdr->e_ident[EI_DATA])
    {
        case ELFDATANONE:    printf(" - ENDIAN: NONE\n");    break;
        case ELFDATA2LSB:    printf(" - ENDIAN: LITTLE\n");  break;
        case ELFDATA2MSB:    printf(" - ENDIAN: BIG\n");     break;
        default:             printf(" - ENDIAN: NONE\n");    break;
    }

    printf(" - Entry : 0x%lx\n", static_cast<unsigned long>(hdr->e_entry));
#endif
    return (1);
}

/**
** \fn int get_segment_elf(Info *info, const Elf_Ehdr *hdr)
** \brief Fonction gerant la recuperation des segments d'un fichier ELF
**
** \param info Structure contenant les infos du fichier a analyser
** \param hdr Entete de fichier ELF
** \return Retourne toujours 1
*/
int    get_segment_elf(Info *info, const Elf_Ehdr *hdr)
{
    Elf_Phdr         phdr;
    unsigned char    *buffer;
    unsigned long    nbs_seg;
    unsigned long    size_tmp;
    int              flag;
    unsigned long    align;

    /* Recuperation du nombre de segments */
    nbs_seg = hdr->e_phnum;

    for (unsigned long i=0; i<nbs_seg; i++)
    {
        get_data(&phdr, sizeof (Elf_Phdr), info->data, info->size, hdr->e_phoff + i * sizeof (Elf_Phdr));

        /* Si la taille du segment en memoire est superieure a 0, on le recupere */
        if (phdr.p_memsz > 0)
        {
            align = 0;
            /* On rajoute de la marge s'il y a un alignement en memoire * /
            align = phdr.p_align;
            if (align > 0)
            {
                if ((phdr.p_memsz % phdr.p_align) != 0)
                    align = align - (phdr.p_memsz % phdr.p_align);
            }*/
            
            if ((buffer = new unsigned char[phdr.p_memsz + align]) != NULL)
            {
                /* Blanchi le segment */
                memset(buffer, 0, phdr.p_memsz + align);

                /* Recupere le bon nombre d'octets pour les mettre dans le segment */
                size_tmp = phdr.p_filesz;
                if (phdr.p_memsz < phdr.p_filesz)
                    size_tmp = phdr.p_memsz;
                get_data(buffer, size_tmp, info->data, info->size, phdr.p_offset);

                /* Prepare les droits du segment */
                flag = 0;
                if ((phdr.p_flags & PF_R) == PF_R)
                    flag = flag | SECTION_R;
                if ((phdr.p_flags & PF_W) == PF_W)
                    flag = flag | SECTION_W;
                if ((phdr.p_flags & PF_X) == PF_X)
                    flag = flag | SECTION_X;

                /* Ajoute le segment dans les infos du programme */
                info->sec.add_section(phdr.p_vaddr, phdr.p_memsz + align, buffer, flag);
            }
        }

#ifdef    DEBUG_PLUGIN
        printf("Segment %ld :\n", i);
        printf("  type   : 0x%lx\t", static_cast<unsigned long>(phdr.p_type));
        switch (phdr.p_type)
        {
            case PT_NULL:            printf("(NULL)");         break;
            case PT_LOAD:            printf("(LOAD)");         break;
            case PT_DYNAMIC:         printf("(DYNAMIC)");      break;
            case PT_INTERP:          printf("(INTERP)");       break;
            case PT_NOTE:            printf("(NOTE)");         break;
            case PT_SHLIB:           printf("(SHLIB)");        break;
            case PT_PHDR:            printf("(PHDR)");         break;
            case PT_TLS:             printf("(TLS)");          break;
            case PT_NUM:             printf("(NUM)");          break;
            case PT_LOOS:            printf("(LOOS)");         break;
            case PT_GNU_EH_FRAME:    printf("(GNU_EH_FRAME)"); break;
            case PT_GNU_STACK:       printf("(GNU_STACK)");    break;
            case PT_GNU_RELRO:       printf("(GNU_RELRO)");    break;
            case PT_LOSUNW:          printf("(LOSUNW)");       break;
            case PT_SUNWSTACK:       printf("(SUNWSTACK)");    break;
            case PT_HISUNW:          printf("(HISUNW)");       break;
            case PT_LOPROC:          printf("(LOPROC)");       break;
            case PT_HIPROC:          printf("(HIPROC)");       break;
            default:                                           break;
        }
        printf("\n");

        printf("  offset : %lu\n", static_cast<unsigned long>(phdr.p_offset));
        printf("  vaddr  : 0x%lx\n", static_cast<unsigned long>(phdr.p_vaddr));
        printf("  paddr  : 0x%lx\n", static_cast<unsigned long>(phdr.p_paddr));
        printf("  filesz : %lu\n", static_cast<unsigned long>(phdr.p_filesz));
        printf("  memsz  : %lu\n", static_cast<unsigned long>(phdr.p_memsz));
        printf("  flags  : 0x%lx\t( ", static_cast<unsigned long>(phdr.p_flags));
        if ((phdr.p_flags & PF_R) == PF_R)
            printf("R ");
        if ((phdr.p_flags & PF_W) == PF_W)
            printf("W ");
        if ((phdr.p_flags & PF_X) == PF_X)
            printf("X ");
        printf(")\n");

        printf("  align  : %lu\n", static_cast<unsigned long>(phdr.p_align));
#endif
    }
    return (1);
}

/**
** \fn void parse_entry_section_dynsym(Info *info, const Elf_Shdr *hdr, const Elf_Shdr *hdr_str,
**                                     unsigned long num, unsigned long addr)
** \brief Gere le parsing une entree de section DYNSYM
**
** \param info Structure contenant les infos du programme a analyser
** \param hdr Header de la section a parser
** \param hdr_str Header de la section contenant les noms de symboles
** \param num Numero de l'entree dynamique a parser
** \param addr Adresse de l'entree en memoire
** \return rien
*/
void    parse_entry_section_dynsym(Info *info, const Elf_Shdr *hdr, const Elf_Shdr *hdr_str, unsigned long num, unsigned long addr)
{
    Elf_Sym             sym;
    char                buffer[256];

    get_data(&sym, sizeof (Elf_Sym), info->data, info->size, hdr->sh_offset + num * sizeof (Elf_Sym));
    get_data(buffer, 256, info->data, info->size, hdr_str->sh_offset + sym.st_name);

    /* Ajout du symbole dans la liste */
    info->sym.add_symbole(addr, buffer, Symbole::NONE);

#ifdef    DEBUG_PLUGIN
    printf("        - name  : %lu\t \"%s\"\n", static_cast<unsigned long>(sym.st_name), buffer);
    printf("        - info  : 0x%02x\n", sym.st_info);
    printf("        - other : 0x%02x\n", sym.st_other);
    printf("        - shndx : %lu\n", static_cast<unsigned long>(sym.st_shndx));
    printf("        - value : 0x%lx\n", static_cast<unsigned long>(sym.st_value));
    printf("        - size  : %lu\n", static_cast<unsigned long>(sym.st_size));
#endif
}

/**
** \fn void parse_section_symtab(Info *info, const Elf_Shdr *hdr, const Elf_Shdr *hdr_str)
** \brief Gere le parsing des sections SYMTAB
**
** \param info Structure contenant les infos du programme a analyser
** \param hdr Header de la section a parser
** \param hdr_str Header de la section contenant les noms de symboles
** \return rien
*/
void    parse_section_symtab(Info *info, const Elf_Shdr *hdr, const Elf_Shdr *hdr_str)
{
    Elf_Sym             sym;
    char                buffer[1024];
    unsigned long       i;

    /* Tant que l'on est pas a la fin de la section, on continu a la parser */
    for (i=0; (i * sizeof (Elf_Sym))<hdr->sh_size; i++)
    {
        get_data(&sym, sizeof (Elf_Sym), info->data, info->size, hdr->sh_offset + i * sizeof (Elf_Sym));
        get_data(buffer, 1023, info->data, info->size, hdr_str->sh_offset + sym.st_name);
        buffer[1023] = '\0';

// Faut-il decommenter cette ligne pour avoir moins de points d'entree ? */
//        if (strlen(buffer) > 0)
        {
            /* Ajout du symbole dans la liste */
            info->sym.add_symbole(sym.st_value, buffer, Symbole::NONE);

            /* Ajout d'un point d'entree si le symbole est dans un segment executable */
            if ((info->sec.get_flag(sym.st_value) & SECTION_X) == SECTION_X)
                info->entry.insert(sym.st_value);
        }

#ifdef    DEBUG_PLUGIN
        printf("      - Sym %lu :\n", i);
        printf("        - name  : %lu\t \"%s\"\n", static_cast<unsigned long>(sym.st_name), buffer);
        printf("        - info  : 0x%02x\n", sym.st_info);
        printf("        - other : 0x%02x\n", sym.st_other);
        printf("        - shndx : %lu\n", static_cast<unsigned long>(sym.st_shndx));
        printf("        - value : 0x%lx\n", static_cast<unsigned long>(sym.st_value));
        printf("        - size  : %lu\n", static_cast<unsigned long>(sym.st_size));
#endif

    }
}

/**
** \fn void parse_section_rela(Info *info, const Elf_Ehdr *hdr, const Elf_Shdr *shdr)
** \brief Gere le parsing des sections RELA
**
** \param info Structure contenant les infos du programme a analyser
** \param hdr Header du fichier ELF
** \param shdr Header de la section a parser
** \return rien
*/
void    parse_section_rela(Info *info, const Elf_Ehdr *hdr, const Elf_Shdr *shdr)
{
    Elf_Shdr            hdrsym;
    Elf_Shdr            hdrstr;
    Elf_Rela            rela;
    unsigned long       i;

    get_data(&hdrsym, sizeof (Elf_Shdr), info->data, info->size,
             hdr->e_shoff + sizeof (Elf_Shdr) * (shdr->sh_link));

    if ((hdrsym.sh_type == SHT_DYNSYM))
    {
        get_data(&hdrstr, sizeof (Elf_Shdr), info->data, info->size,
                 hdr->e_shoff + sizeof (Elf_Shdr) * (hdrsym.sh_link));

        /* Tant que l'on est pas a la fin de la section, on continu a la parser */
        for (i=0; (i * sizeof (Elf_Rela))<shdr->sh_size; i++)
        {
            get_data(&rela, sizeof (Elf_Rela), info->data, info->size, shdr->sh_offset + i * sizeof (Elf_Rela));

#ifdef    DEBUG_PLUGIN
            printf("      Rela %lu\t : adresse: 0x%lx    sym: 0x%lx type: 0x%lx    addend: 0x%lu    \n",
                   i,
                   static_cast<unsigned long>(rela.r_offset),
                   static_cast<unsigned long>(ELF_R_SYM(rela.r_info)),
                   static_cast<unsigned long>(ELF_R_TYPE(rela.r_info)),
                   static_cast<unsigned long>(rela.r_addend));
#endif
            parse_entry_section_dynsym(info, &hdrsym, &hdrstr, static_cast<unsigned long>(ELF_R_SYM(rela.r_info)), rela.r_offset);
        }
    }
}

/**
** \fn void parse_section_rel(Info *info, const Elf_Ehdr *hdr, const Elf_Shdr *shdr)
** \brief Gere le parsing des sections REL
**
** \param info Structure contenant les infos du programme a analyser
** \param hdr Header du fichier ELF
** \param hdr Header de la section a parser
** \return rien
*/
void    parse_section_rel(Info *info, const Elf_Ehdr *hdr, const Elf_Shdr *shdr)
{
    Elf_Shdr            hdrsym;
    Elf_Shdr            hdrstr;
    Elf_Rel             rel;
    unsigned long       i;

    get_data(&hdrsym, sizeof (Elf_Shdr), info->data, info->size,
             hdr->e_shoff + sizeof (Elf_Shdr) * (shdr->sh_link));

    if ((hdrsym.sh_type == SHT_DYNSYM))
    {
        get_data(&hdrstr, sizeof (Elf_Shdr), info->data, info->size,
                 hdr->e_shoff + sizeof (Elf_Shdr) * (hdrsym.sh_link));

        /* Tant que l'on est pas a la fin de la section, on continu a la parser */
        for (i=0; (i * sizeof (Elf_Rel))<shdr->sh_size; i++)
        {
            get_data(&rel, sizeof (Elf_Rel), info->data, info->size, shdr->sh_offset + i * sizeof (Elf_Rel));

#ifdef    DEBUG_PLUGIN
            printf("      Rel %lu\t : adresse: 0x%lx    sym: 0x%lx type: 0x%lx\n",
                   i,
                   static_cast<unsigned long>(rel.r_offset),
                   static_cast<unsigned long>(ELF_R_SYM(rel.r_info)),
                   static_cast<unsigned long>(ELF_R_TYPE(rel.r_info)));
#endif
            parse_entry_section_dynsym(info, &hdrsym, &hdrstr, static_cast<unsigned long>(ELF_R_SYM(rel.r_info)), rel.r_offset);
        }
    }
}

/**
** \fn void parse_section_dynamic(Info *info, const Elf_Shdr *hdr, const Elf_Shdr *)
** \brief Gere le parsing des sections SYMTAB
**
** \param info Structure contenant les infos du programme a analyser
** \param hdr Header de la section a parser
** \return rien
*/
void    parse_section_dynamic(Info *info, const Elf_Shdr *hdr, const Elf_Shdr */*hdr_str*/)
{
    Elf_Dyn             dyn;
    unsigned long       i;

    /* Tant que l'on est pas a la fin de la section, on continu a la parser */
    for (i=0; (i * sizeof (Elf_Dyn))<hdr->sh_size; i++)
    {
        get_data(&dyn, sizeof (Elf_Dyn), info->data, info->size, hdr->sh_offset + i * sizeof (Elf_Dyn));

#ifdef    DEBUG_PLUGIN
        printf("      - Dyn %lu\t : tag: 0x%lx   val: 0x%lx\t ", i,
               static_cast<unsigned long>(dyn.d_tag),
               static_cast<unsigned long>(dyn.d_un.d_val));
        switch (dyn.d_tag)
        {
            case DT_NULL:             printf("(NULL)");             break;
            case DT_NEEDED:           printf("(NEEDED)");           break;
            case DT_PLTRELSZ:         printf("(PLTRELSZ)");         break;
            case DT_PLTGOT:           printf("(PLTGOT)");           break;
            case DT_HASH:             printf("(HASH)");             break;
            case DT_STRTAB:           printf("(STRTAB)");           break;
            case DT_SYMTAB:           printf("(SYMTAB)");           break;
            case DT_RELA:             printf("(RELA)");             break;
            case DT_RELASZ:           printf("(RELASZ)");           break;
            case DT_RELAENT:          printf("(RELAENT)");          break;
            case DT_STRSZ:            printf("(STRSZ)");            break;
            case DT_SYMENT:           printf("(SYMENT)");           break;
            case DT_INIT:             printf("(INIT)");             break;
            case DT_FINI:             printf("(FINI)");             break;
            case DT_SONAME:           printf("(SONAME)");           break;
            case DT_RPATH:            printf("(RPATH)");            break;
            case DT_SYMBOLIC:         printf("(SYMBOLIC)");         break;
            case DT_REL:              printf("(REL)");              break;
            case DT_RELSZ:            printf("(RELSZ)");            break;
            case DT_RELENT:           printf("(RELENT)");           break;
            case DT_PLTREL:           printf("(PLTREL)");           break;
            case DT_DEBUG:            printf("(DEBUG)");            break;
            case DT_TEXTREL:          printf("(TEXTREL)");          break;
            case DT_JMPREL:           printf("(JMPREL)");           break;
            case DT_BIND_NOW:         printf("(BIND_NOW)");         break;
            case DT_INIT_ARRAY:       printf("(INIT_ARRAY)");       break;
            case DT_FINI_ARRAY:       printf("(FINI_ARRAY)");       break;
            case DT_INIT_ARRAYSZ:     printf("(INIT_ARRAYSZ)");     break;
            case DT_FINI_ARRAYSZ:     printf("(FINI_ARRAYSZ)");     break;
            case DT_RUNPATH:          printf("(RUNPATH)");          break;
            case DT_FLAGS:            printf("(FLAGS)");            break;
            case DT_PREINIT_ARRAY:    printf("(PREINIT_ARRAY)");    break;
            case DT_PREINIT_ARRAYSZ:  printf("(PREINIT_ARRAYSZ)");  break;
            case DT_NUM:              printf("(NUM)");              break;
            case DT_LOOS:             printf("(LOOS)");             break;
            case DT_HIOS:             printf("(HIOS)");             break;
            case DT_LOPROC:           printf("(LOPROC)");           break;
            case DT_HIPROC:           printf("(HIPROC)");           break;
            case DT_VALRNGLO:         printf("(VALRNGLO)");         break;
            case DT_GNU_PRELINKED:    printf("(GNU_PRELINKED)");    break;
            case DT_GNU_CONFLICTSZ:   printf("(GNU_CONFLICTSZ)");   break;
            case DT_GNU_LIBLISTSZ:    printf("(GNU_LIBLISTSZ)");    break;
            case DT_CHECKSUM:         printf("(CHECKSUM)");         break;
            case DT_PLTPADSZ:         printf("(PLTPADSZ)");         break;
            case DT_MOVEENT:          printf("(MOVEENT)");          break;
            case DT_MOVESZ:           printf("(MOVESZ)");           break;
            case DT_FEATURE_1:        printf("(FEATURE_1)");        break;
            case DT_POSFLAG_1:        printf("(POSFLAG_1)");        break;
            case DT_SYMINSZ:          printf("(SYMINSZ)");          break;
            case DT_SYMINENT:         printf("(SYMINENT)");         break;
            case DT_ADDRRNGLO:        printf("(ADDRRNGLO)");        break;
            case DT_GNU_HASH:         printf("(GNU_HASH)");         break;
            case DT_TLSDESC_PLT:      printf("(TLSDESC_PLT)");      break;
            case DT_TLSDESC_GOT:      printf("(TLSDESC_GOT)");      break;
            case DT_GNU_CONFLICT:     printf("(GNU_CONFLICT)");     break;
            case DT_GNU_LIBLIST:      printf("(GNU_LIBLIST)");      break;
            case DT_CONFIG:           printf("(CONFIG)");           break;
            case DT_DEPAUDIT:         printf("(DEPAUDIT)");         break;
            case DT_AUDIT:            printf("(AUDIT)");            break;
            case DT_PLTPAD:           printf("(PLTPAD)");           break;
            case DT_MOVETAB:          printf("(MOVETAB)");          break;
            case DT_SYMINFO:          printf("(SYMINFO)");          break;
            case DT_VERSYM:           printf("(VERSYM)");           break;
            case DT_RELACOUNT:        printf("(RELACOUNT)");        break;
            case DT_RELCOUNT:         printf("(RELCOUNT)");         break;
            case DT_FLAGS_1:          printf("(FLAGS_1)");          break;
            case DT_VERDEF:           printf("(VERDEF)");           break;
            case DT_VERDEFNUM:        printf("(VERDEFNUM)");        break;
            case DT_VERNEED:          printf("(VERNEED)");          break;
            case DT_VERNEEDNUM:       printf("(VERNEEDNUM)");       break;
            case DT_AUXILIARY:        printf("(AUXILIARY)");        break;
            default: break;
        }
        printf("\n");
#endif
    }
}

/**
** \fn int get_symbol_elf(Info *info, const Elf_Ehdr *hdr)
** \brief Fonction gerant la recuperation des symboles et point d'entree d'un fichier ELF
**
** \param info Structure contenant les infos du fichier a analyser
** \param hdr Entete de fichier ELF
** \return Retourne toujours 1
*/
int    get_symbol_elf(Info *info, const Elf_Ehdr *hdr)
{
    Elf_Shdr    shdr;        /* Entete de la section a analyser */
    Elf_Shdr    shdrstr_sym; /* Entete de la section contenant les strings de la section a analyser */
    Elf_Shdr    shdrstr;     /* Entete de la section contenant les noms de sections */

    /* Recuperation de l'entete de la section contenant les noms de sections */
    get_data(&shdrstr, sizeof (Elf_Shdr), info->data, info->size, hdr->e_shoff + sizeof (Elf_Shdr) * hdr->e_shstrndx);

    /* Parcours les sections a la recherche des sections de symboles */
    for (unsigned long i=0; i<hdr->e_shnum; i++)
    {
        if (get_data(&shdr, sizeof (Elf_Shdr), info->data, info->size, hdr->e_shoff + sizeof (Elf_Shdr) * i) >= 0)
        {
#ifdef    DEBUG_PLUGIN
            char        buffer[256];

            if (i == 0)
                printf("\nSection :\n");
            printf(" - Section %lu/%u :\n", i, hdr->e_shnum);

            get_data(buffer, 256, info->data, info->size, shdrstr.sh_offset + shdr.sh_name);
            printf("    - sh_name      : %lu  \t\"%s\"\n", static_cast<unsigned long>(shdr.sh_name), buffer);
            printf("    - sh_type      : %lu  ", static_cast<unsigned long>(shdr.sh_type));
            switch (shdr.sh_type)
            {
                case SHT_NULL:           printf("(NULL)\n");           break;
                case SHT_PROGBITS:       printf("(PROGBITS)\n");       break;
                case SHT_SYMTAB:         printf("(SYMTAB)\n");         break;
                case SHT_STRTAB:         printf("(STRTAB)\n");         break;
                case SHT_RELA:           printf("(RELA)\n");           break;
                case SHT_HASH:           printf("(HASH)\n");           break;
                case SHT_DYNAMIC:        printf("(DYNAMIC)\n");        break;
                case SHT_NOTE:           printf("(NOTE)\n");           break;
                case SHT_NOBITS:         printf("(NOBITS)\n");         break;
                case SHT_REL:            printf("(REL)\n");            break;
                case SHT_SHLIB:          printf("(SHLIB)\n");          break;
                case SHT_DYNSYM:         printf("(DYNSYM)\n");         break;
                case SHT_INIT_ARRAY:     printf("(INIT_ARRAY)\n");     break;
                case SHT_FINI_ARRAY:     printf("(FINI_ARRAY)\n");     break;
                case SHT_PREINIT_ARRAY:  printf("(PREINIT_ARRAY)\n");  break;
                case SHT_GROUP:          printf("(GROUP)\n");          break;
                case SHT_SYMTAB_SHNDX:   printf("(SYMTAB_SHNDX)\n");   break;
                case SHT_NUM:            printf("(NUM)\n");            break;
                case SHT_LOOS:           printf("(LOOS)\n");           break;
                case SHT_GNU_ATTRIBUTES: printf("(GNU_ATTRIBUTES)\n"); break;
                case SHT_GNU_HASH:       printf("(GNU_HASH)\n");       break;
                case SHT_GNU_LIBLIST:    printf("(GNU_LIBLIST)\n");    break;
                case SHT_CHECKSUM:       printf("(CHECKSUM)\n");       break;
                case SHT_LOSUNW:         printf("(LOSUNW)\n");         break;
                case SHT_SUNW_COMDAT:    printf("(SUNW_COMDAT)\n");    break;
                case SHT_SUNW_syminfo:   printf("(SUNW_syminfo)\n");   break;
                case SHT_GNU_verdef:     printf("(GNU_verdef)\n");     break;
                case SHT_GNU_verneed:    printf("(GNU_verneed)\n");    break;
                case SHT_GNU_versym:     printf("(GNU_versym)\n");     break;
                case SHT_LOPROC:         printf("(LOPROC)\n");         break;
                case SHT_HIPROC:         printf("(HIPROC)\n");         break;
                case SHT_LOUSER:         printf("(LOUSER)\n");         break;
                case SHT_HIUSER:         printf("(HIUSER)\n");         break;
                default:                 printf("\n");                 break;
            }
            printf("    - sh_flags     : %lx  \n", static_cast<unsigned long>(shdr.sh_flags));
            printf("    - sh_addr      : 0x%lx\n", static_cast<unsigned long>(shdr.sh_addr));
            printf("    - sh_offset    : %lu  \n", static_cast<unsigned long>(shdr.sh_offset));
            printf("    - sh_size      : %lu  \n", static_cast<unsigned long>(shdr.sh_size));
            printf("    - sh_link      : %lu  \n", static_cast<unsigned long>(shdr.sh_link));
            printf("    - sh_info      : %lu  \n", static_cast<unsigned long>(shdr.sh_info));
            printf("    - sh_addralign : %lu  \n", static_cast<unsigned long>(shdr.sh_addralign));
            printf("    - sh_entsize   : %lu  \n", static_cast<unsigned long>(shdr.sh_entsize));
#endif
            /* On parse le contenu de la section differement suivant son type */
            switch (shdr.sh_type)
            {
                case SHT_RELA:
                    parse_section_rela(info, hdr, &shdr);
                    break;
                case SHT_REL:
                    parse_section_rel(info, hdr, &shdr);
                    break;
                case SHT_DYNAMIC:
                    get_data(&shdrstr_sym, sizeof (Elf_Shdr), info->data, info->size,
                             hdr->e_shoff + sizeof (Elf_Shdr) * (shdr.sh_link));
                    parse_section_dynamic(info, &shdr, &shdrstr_sym);
                    break;
                case SHT_SYMTAB:
                    get_data(&shdrstr_sym, sizeof (Elf_Shdr), info->data, info->size,
                             hdr->e_shoff + sizeof (Elf_Shdr) * (shdr.sh_link));
                    parse_section_symtab(info, &shdr, &shdrstr_sym);
                    break;
            	default:
#ifdef    DEBUG_PLUGIN
/*
                    char        buffer[256];
                    for (unsigned long j=0; j<shdr.sh_size; j++)
                    {
                        get_data(buffer, 1, info->data, info->size, shdr.sh_offset + j);
                        printf("%c", buffer[0]);
                    }//*/
                    printf("\n");
#endif
            	    break;
            }
        }
    }
    return (1);
}

/**
** \fn int resolve_symbole_plt(Info *info, const Elf_Ehdr *hdr)
** \brief Fonction gerant l'identification des symboles des la PLT (pas generique)
**
** \param info Structure contenant les infos du programme a analyser
** \param hdr entete ELF
** \return Retourne toujours 1
*/
int    resolve_symbole_plt(Info *info, const Elf_Ehdr *hdr)
{
    Elf_Shdr             shdr;        /* Entete de la section a analyser */
    Elf_Shdr             shdrstr;     /* Entete de la section contenant les noms de sections */
    unsigned char        buffer[256];
    int                  ok;

    /* Recuperation de l'entete de la section contenant les noms de sections */
    get_data(&shdrstr, sizeof (Elf_Shdr), info->data, info->size, hdr->e_shoff + sizeof (Elf_Shdr) * hdr->e_shstrndx);

    /* Parcours les sections a la recherche des sections de symboles */
    ok = 0;
    for (unsigned long i=0; i<hdr->e_shnum && ok!=1; i++)
    {
        if (get_data(&shdr, sizeof (Elf_Shdr), info->data, info->size, hdr->e_shoff + sizeof (Elf_Shdr) * i) >= 0)
        {
            /* Recuperation du nom de la section pour trouver la PLT */
            get_data(buffer, 256, info->data, info->size, shdrstr.sh_offset + shdr.sh_name);
            
            if (strncmp(reinterpret_cast<char *>(buffer), ".plt", 255) == 0)
                ok = 1;
        }
    }
    if (ok == 0)
        return (0);

    /* On parcours la PLT a la recherche des sequences correspondants aux redirections */
/* TODO: Absolument pas generique et a modifier pour chaque nouvelle architecture... */
    for (unsigned long i=0; i<shdr.sh_size; i++)
    {
        /* Recupere quelques octets de la PLT */
        get_data(buffer, 20, info->data, info->size, shdr.sh_offset + i);
        
        /* Identification des redirections pour architecture Intel i386 */
        if ((info->archi == Info::ARCHI_I32) && (buffer[0] == 0xff) && (buffer[1] == 0x25) &&
            (info->sym.get_name(*reinterpret_cast<unsigned int*>(&(buffer[2]))) != ""))
        {
            info->sym.add_symbole(shdr.sh_addr + i,
                                  info->sym.get_name(*reinterpret_cast<unsigned int*>(&(buffer[2]))),
                                  Symbole::FUNC);
        }

        /* Identification des redirections pour architecture Intel i386 */
        else if ((info->archi == Info::ARCHI_I64) && (buffer[0] == 0xff) && (buffer[1] == 0x25))
        {
            unsigned long    addr = shdr.sh_addr + i + 6 + *reinterpret_cast<int*>(&(buffer[2]));
            if (info->sym.get_name(addr) != "")
            {
                info->sym.add_symbole(shdr.sh_addr + i, info->sym.get_name(addr), Symbole::FUNC);
            }
        }
    }

    return (1);
}



/**
** \fn const char *get_plugin_name()
** \brief Fonction permettant de connaitre le nom du plugin
**
** \return Retourne un pointeur vers le nom du plugin
*/
const char    *PLUGIN_FUNC_GET_PLUGIN_NAME()
{
    return (PLUGIN_NAME);
}

/**
** \fn int execute(Info *info)
** \brief Fonction permettant d'executer le plugin pour extraire les infos des fichiers ELF
**
** \param info Classe contenant les infos du programme a analyser
** \return Retourne 1 si OK, 0 si le plugin n'a pas ete execute et -1 en cas d'erreur
*/
int    PLUGIN_FUNC_EXECUTE(Info *info)
{
    Elf_Ehdr    hdr;

    if ((info == NULL) || (info->data == NULL))
        return (-1);

    /* Recuperation et verification de l'entete l'entete ELF */
    if (get_data(&hdr, sizeof (Elf_Ehdr), info->data, info->size, 0) <= 0)
        return (0);
    if (verif_header_elf(info, &hdr) <= 0)
        return (0);

    /* Recuperation du contenu des segments qui seront charges en memoire */
    if (get_segment_elf(info, &hdr) <= 0)
        return (0);

    /* Recuperation des symboles */
    if (get_symbol_elf(info, &hdr) <= 0)
        return (0);

    /* Ajout des symboles present dans un segment executable a la liste des elements a analyser */

    /* Resolution des symboles de la PLT */
    resolve_symbole_plt(info, &hdr);

#ifdef    DEBUG_PLUGIN
    printf("Liste des symboles :\n");
    for (unsigned long i=0; i<info->sym.get_nbs_symbole(); i++)
        printf("  %lx\t: \"%s\"\n", info->sym.get_addr_nieme_symbole(i),
               info->sym.get_name_nieme_symbole(i).c_str());

    printf("Liste des points d'entrees :\n");
    for (std::set<unsigned long>::iterator it=info->entry.begin(); it!=info->entry.end(); it++)
        printf("  %lx\n", (*it));

    printf("Liste des segments :\n");
    for (unsigned long i=0; i<info->sec.get_nbs_section(); i++)
        printf("  %lx\t: %lu\t%x\n", info->sec.get_addr_section(i),
               info->sec.get_size_section(i), info->sec.get_flag_section(i));
#endif
    return (1);
}

/**
** \fn const char *get_plugin_name()
** \brief Fonction permettant de d'acceder a la description du plugin
**
** \return Retourne un pointeur vers la description du plugin
*/
const char    *PLUGIN_FUNC_APROPOS()
{
    return (PLUGIN_DESCRIPTION);
}

