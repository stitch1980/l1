/**
** 
*/
#include    "header_plugin_deassembleaur.hpp"

#define    PLUGIN_NAME    PLUGIN_TYPE__DEASM ".10000.deassembleur.0"

#define    NBS_THREAD_DEASM    4 /* Nombre de thread a utiliser pour deassembler les fonctions */

#define    OPTION_RECURSIF     "recursif"

extern "C"
{
    const char    *get_plugin_name();
    int           execute(Info *info);
    const char    *apropos();
}


/**
** \class Param_thread
** \brief Classe a passer en parametre a la fonction de deassemblage
*/
class    Param_thread
{
public:
    Param_thread():                                    _info(NULL),    _entry(NULL),     _mutex() {}
    Param_thread(Info *i, std::set<unsigned long> *e): _info(i),       _entry(e),        _mutex() {}
    Param_thread(const Param_thread &p):               _info(p._info), _entry(p._entry), _mutex() {}
    ~Param_thread() {}
    
    Param_thread    &operator = (const Param_thread &) { return (*this); }

public:
    /** Pointeur sur la classe contenant les infos du programme a analyser */
    Info                       *_info;
    /** Pointeur sur la liste des points d'entree a deassembler */
    std::set<unsigned long>    *_entry;

    /** Mutex permettant de rendre la classe thread-safe */
    Mutex                      _mutex;
};


/**
** \fn void *fonction_thread_deassemble(void *p)
** \brief Fonction utilisee par les threads pour deassembler le binaire a analyser
**
** \param p Pointeur sur la structure contenant les infos du binaire a deassembler
** \return Retourne toujours NULL
*/
void   *fonction_thread_deassemble(void *p)
{
    Param_thread     *param;
    Fonction         *f_tmp;
    unsigned long    entry_tmp;
    
    if ((param = static_cast<Param_thread*>(p)) != NULL)
    {
        param->_mutex.lock();
        param->_info->mutex.lock(); 

        /* Cherche un point d'entree pas encore traite */
        while (param->_entry->begin() != param->_entry->end())
        {
            /* On enleve le point d'entree de la liste des entrees a traiter */
            /* et on unlock les mutex pour laisser les autres threads jouer */
            entry_tmp = (*param->_entry->begin());
            param->_entry->erase(param->_entry->begin());
            param->_info->mutex.unlock();
            param->_mutex.unlock();
    
            /* On deassemble la fonction */
            if ((f_tmp = deassemble_fonction(param->_info, entry_tmp)) != NULL)
            {
                param->_info->mutex.lock();
                  
#ifdef    DEBUG_PLUGIN
            printf("Deassemblage de la fonction : %lx (nbs func = %lu)\n", entry_tmp, param->_info->function.size());
#endif
  
                if (param->_info->function[entry_tmp] != NULL)
                    delete param->_info->function[entry_tmp];
                param->_info->function[entry_tmp] = f_tmp;
                 
                param->_info->mutex.unlock(); 
            }
                   
            /* On relock les mutex avant de commencer un nouveau rdeassemblage */ 
            param->_mutex.lock();
            param->_info->mutex.lock();
        }

        param->_info->mutex.unlock();
        param->_mutex.unlock();
    }

    return (NULL);
}

void    add_entry_recursively(std::set<unsigned long> &entry, Info *info)
{
    info->mutex.lock();

    /* Pour toutes les fonctions deja deassemblees */
    for (std::map<unsigned long, Fonction*>::const_iterator it_func=info->function.begin();
         it_func!=info->function.end();
         it_func++)
    {
        /* Pour tout les CALL realises par ces fonctions */
        for (std::set<unsigned long>::const_iterator it_call=it_func->second->get_addr_call().begin();
             it_call!=it_func->second->get_addr_call().end();
             it_call++)
        {
            /* Si la fonction CALLer n'est pas deja deassemblee, on l'ajoute au points d'entree */
            if (info->function.find(*it_call) == info->function.end())
            {
                entry.insert(*it_call);
                info->entry.insert(*it_call);
            }
        }
    }
    
    info->mutex.unlock();
}

/**
** \fn const char *get_plugin_name()
** \brief Fonction permettant de connaitre le nom du plugin
**
** \return Retourne un pointeur vers le nom du plugin
*/
const char    *get_plugin_name()
{
    return (PLUGIN_NAME);
}

/**
** \fn int execute(Info *info)
** \brief Fonction permettant de deassembler les fonctions dont le point d'entree est indiquee
**
** \param info Classe contenant les infos du programme a analyser
** \return Retourne 1 si OK, -1 sinon
*/
int        execute(Info *info)
{
    std::map<std::string, std::map<std::string, std::string> >::const_iterator    it_options;
    unsigned long                                                                 option_recursif;
    std::set<unsigned long>    entry;
    Param_thread               param_thread(info, &entry);
    Thread                     tab_thread[NBS_THREAD_DEASM];
    std::list<Thread*>         list_thread;

    if (info == NULL)
        return (-1);
    if (info->ptr_func.deasm == NULL)
    {
        printf("ERROR: No disassembler for this architecture\n");
        return (-1);
    }
  
    /* Copie des points d'entree a deassembler et traitement des options */
    info->mutex.lock();
    entry = info->entry;
    
    option_recursif = 0;
    if ((it_options = info->option_plugin.find(PLUGIN_NAME)) != info->option_plugin.end())
    {
        /* Si l'option OPTION_RECURSIF existe et est differente de 0 */
        if ((it_options->second.find(OPTION_RECURSIF) != it_options->second.end()) &&
            (atol(it_options->second.find(OPTION_RECURSIF)->second.c_str()) > 0))
            option_recursif = atol(it_options->second.find(OPTION_RECURSIF)->second.c_str());
    }
    
    info->mutex.unlock();
    

    while (entry.size() > 0)
    {
        /* Lance les threads de deassemblages */
        for (unsigned long i=0; i<NBS_THREAD_DEASM; i++)
            tab_thread[i].launch(&fonction_thread_deassemble, &param_thread);

        /* Attend la fin du deassemblage de toutes les fonctions */
        for (unsigned long i=0; i<NBS_THREAD_DEASM; i++)
            tab_thread[i].stop();
      
        /* En cas de decompilation recursive, gere la recuperation des points d'entrees suivant */
        if (option_recursif == 0)
            entry.clear();
        else
        {
            add_entry_recursively(entry, info);
            option_recursif--;
        }
    }

    return (1);
}

/**
** \fn const char *get_plugin_name()
** \brief Fonction permettant de d'acceder a la description du plugin
**
** \return Retourne un pointeur vers la description du plugin
*/
const char    *apropos()
{
    return ("Plugin gerant le deassemblage des fonctions dont le point d'entree est indiquee\n");
}

