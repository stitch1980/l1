#include    "header_plugin_deassembleaur.hpp"


/**
** \fn Fonction *deassemble_fonction(Info *info, unsigned long entry)
** \brief Gere le deassemblage d'une fonction a partir de son point d'entree
**
** \param info Classe contenant les infos du programme a analyser
** \param entry Point d'entree de la fonction a deassembler
** \return Retourne un pointeur sur la fonction si OK, NULL sinon
*/
Fonction    *deassemble_fonction(Info *info, unsigned long entry)
{
    std::map<std::string, ContentContexte>    values_register;
    Fonction                                  *f_tmp;
    Contexte                                  ctx;

    /* Si le point d'entree de la fonction n'est pas dans le programme, on ne deassemble pas */
    if ((info->sec.is_in_section(entry) == 0) ||
        ((info->sec.get_flag(entry) & SECTION_X) != SECTION_X))
        return (NULL);

    /* Creation de la fonction */
    if ((f_tmp = new Fonction) == NULL)
        return (NULL);

    /* Creation du contexte d'execution de la fonction */
    info->ptr_func.deasm->init_registre(values_register, entry, info);
    for (std::map<std::string, ContentContexte>::const_iterator it=values_register.begin();
         it!=values_register.end();
         it++)
        ctx.set_content(it->first, it->second.get_size(), it->second.get_type(),
                        it->second.get_values(), it->second.get_filters(), info);

    /* Deassemblage d'un bloc */
    deassemble_bloc(entry, info, f_tmp, &ctx);

    return (f_tmp);
}

/**
** \fn int deassemble_bloc(unsigned long addr, Info *info, Fonction *f, Contexte *last_ctx)
** \brief Gere le deassemblage d'un bloc d'instructions a partir de son point d'entree
**
** \param addr Adresse du debut du bloc a deassembler
** \param info Classe contenant les infos du programme a analyser
** \param f Conction auquel appartient le bloc a deassembler
** \param last_ctx Contexte d'execution du bloc precedent afin de realiser l'analyse symbolique
** \return Retourne un pointeur sur la fonction si OK, NULL sinon
*/
int    deassemble_bloc(unsigned long addr, Info *info, Fonction *f, Contexte *last_ctx)
{
    Contexte                    *ctx;
    Fonction::Bloc              *bloc;
    Fonction::Bloc              *bloc_tmp;
    InstrASM                    *instr;
    InstrASM                    *prev_instr;
    std::list<unsigned long>    list_addr_next;

    /* Si l'adresse n'est pas dans le programme, on ne deassemble pas */
    if ((info->sec.is_in_section(addr) == 0) ||
        ((info->sec.get_flag(addr) & SECTION_X) != SECTION_X))
        return (1);

    /* Si l'instruction a deja ete deassemblee, on split le bloc */
    if ((bloc_tmp = f->get_bloc(addr)) != NULL)
    {
        if (bloc_tmp->get_addr() != addr)
        {
            if ((bloc = bloc_tmp->split(addr)) != NULL)
                f->add_bloc(bloc);
        }
        return (1);
    }

    /* Creation du bloc d'instruction */
    if ((bloc = new Fonction::Bloc) != NULL)
    {//fprintf(stderr, "iiiiii 4\n"); 
        f->add_bloc(bloc);

        /* Si c'est le premier bloc, on le connecte a la fonction */
        if (f->get_bloc_entry() == NULL)
            f->set_bloc_entry(bloc);

        /* On deassemble les instructions de ce bloc tant qu'on les trouve */
        instr = NULL;
        while ((info->sec.is_in_section(addr) != 0) &&
               ((info->sec.get_flag(addr) & SECTION_X) == SECTION_X))
        {
     
/* Si l'instruction a deja ete deassemblee, on split le bloc */
if ((bloc_tmp = f->get_bloc(addr)) != NULL)
{
    instr->_addr_next_instr_jump.push_back(addr);

    if (bloc_tmp->get_addr() != addr)
    {
        if ((bloc = bloc_tmp->split(addr)) != NULL)
            f->add_bloc(bloc);
    }
    return (1);
}

            /* Deassemblage de l'instruction */
            prev_instr = instr;
            if ((instr = info->ptr_func.deasm->deasm_instr(addr, info)) == NULL)
                return (1);

            /* Ajout de l'instruction fraichement deassemblee au bloc */
            bloc->add_instr(instr);
            if (bloc->get_instr_entry() == NULL)
                bloc->set_instr_entry(instr);

            /* Connexion de l'instruction fraichement deassemblee a la precedente */
            if (prev_instr != NULL)
            {
                instr->_prev_instr = prev_instr;
                prev_instr->_next_instr = instr;
                prev_instr->_addr_next_instr_jump.clear();
            }

#ifdef    DEBUG_PLUGIN
            /* Affichage de l'adresse, des octets et de l'instruction pour le debug */
            printf("%lx:\t", addr);
            for (unsigned long i=0; i<instr->_size; i++)
                printf("%02x ", info->sec.get_char(addr + i));
            for (unsigned long i=instr->_size; i<10; i++)
                printf("   ");
            printf("\t%s\n", instr->to_asm(info).c_str());
#endif

            /* Creation d'un contexte d'execution pour l'instruction */
            if ((ctx = new Contexte) == NULL)
                return (1);
            else
            {
                /* Preparation du contexte d'execution en vu de l'execution symbolique */
                ctx->add_parent(last_ctx);
                ctx->set_value(Calcul::lto0x(addr), NAME_PC, info);
                instr->_contexte = ctx;
                last_ctx = ctx;
                set_value_contexte(info, addr, (*ctx));

                /* Si l'instruction est de type type CALL, on ajoute l'adresse du call a la liste */
                if (((instr->_type & INSTR_CALL) == INSTR_CALL) && (instr->__operande.size() > 0))
                    f->add_addr_call(Calcul::calcul(instr->__operande[0]._name, info, instr->_contexte));
    
                /* Si l'instruction a une fonction de prevu pour gerer son execution, on l'utilise */
                if (instr->__func_exec != NULL)
                {
                    /* Si la fonction retourne 0, on se debrouille pour arreter l'execution du bloc */
                    if (instr->__func_exec(info, f, instr) < 0)
                        return (1);
                    else
                        addr = instr->_address + instr->_size;
                }
                else
                {
                    /* Pseudo execution de l'instruction */
                    /* (et recuperation de l'adresse de l'instruction suivante si on ne jump pas) */
                    addr = exec_instr(instr, info, list_addr_next);

                    /* Si on a effectue un saut, on execute les instructions suivantes en recursif */
                    if (list_addr_next.size() > 0)
                    {
                        for (std::list<unsigned long>::const_iterator it=list_addr_next.begin();
                             it!=list_addr_next.end();
                             it++)
                            deassemble_bloc(*it, info, f, ctx);
                        return (1);
                    }
                }
            }
   
            /* Si l'instruction est de type RETURN, la fonction est fini */
            if ((instr->_type & INSTR_RETURN) == INSTR_RETURN)
                return (1);
        }
    }
    return (1);
}

/**
** \fn unsigned long exec_instr(InstrASM *instr, Info *info, std::list<unsigned long> &list_addr_next)
** \brief Gere l'execution symbolique de l'instruction afin de determiner les suivantes
**
** \param instr Instruction ASM a traiter
** \param info Structure contenant les infos du programme a analyser
** \param list_addr_next Liste des adresses des instructions suivantes possibles en cas de sauts
** \return Retourne l'adresse de l'instruction suivante si on effectue pas de sauts
*/
int    exec_instr(InstrASM *instr, Info *info, std::list<unsigned long> &list_addr_next)
{
    std::map<std::string, std::string>    m;
    std::string                           effect;
    std::set<std::string>                 result;

    list_addr_next.clear();

    /* Traitement des effets de bord les uns apres les autres */
    for (std::list<std::string>::const_iterator it=instr->_effect.begin();
         it!=instr->_effect.end(); it++)
    {
#ifdef    DEBUG_PLUGIN
        printf("\n  Traitement de: \"%s\"\n", it->c_str());
#endif

        /* Ici, on epure les chaines a chaque fois: c'est lourd et pas forcement utile */
        effect = (*it);
        Calcul::suppr_space_expr(effect);
        Calcul::suppr_endl_expr(effect);

        /* Si l'effet de bord est une association, on la traite */
        if (BNFcalcul::is_association(effect, &m, info->ptr_func.deasm, 0, 1) > 0)
        {
//            printf("dest = \"%s\"\n", m["dest"].c_str());
//            printf("expr = \"%s\"\n", m["expression"].c_str());

Calcul::evaluate(result, m["expression"], info, instr->_contexte);
printf("resultat \"%s\" = \n", m["expression"].c_str());
for (std::set<std::string>::iterator it_result=result.begin(); it_result!=result.end(); it_result++)
    printf("%s\n", (*it_result).c_str());
    
            /* Evaluation de l'expression */
            Calcul::evaluate(result, m["expression"], info, instr->_contexte);

            /* Modification du contexte d'execution en consequence */
            if (m["dest"] != NAME_PC)
                instr->_contexte->set_values(result, m["dest"], info);

            /* En cas de saut, on ajoute les adresses d'arrivee aux adresses de blocs a deassembler */
            if (m["dest"] == NAME_PC)
            {
                if ((instr->_type & INSTR_JUMP) == INSTR_JUMP)
                {
                    /* En cas de saut conditionnel */
                    if (((instr->_type & INSTR_CONDITION) == INSTR_CONDITION) &&
                        (m.find("ternaire_test") != m.end()))
                    {
                        printf("JUMP NO rencontre (%lx) !!!\n", Calcul::calcul(m["ternaire_choix2"], info, instr->_contexte));
                        set_destination_jump(instr, list_addr_next, info, m, "ternaire_choix2");
                        
                        printf("JUMP YES rencontre (%lx) !!!\n", Calcul::calcul(m["ternaire_choix1"], info, instr->_contexte));
                        set_destination_jump(instr, list_addr_next, info, m, "ternaire_choix1");
                    }
                    
                    /* En cas de saut normal */
                    else
                    {
                        printf("JUMP rencontre (%lx) !!!\n", Calcul::calcul(m["expression"], info, instr->_contexte));
                        set_destination_jump(instr, list_addr_next, info, m, "expression");
                    }
                }
            }
        }
else
{
printf("***********************************************************************\n");
printf("*\n");
printf("*\n");
printf("*\n");
printf("*\n");
printf("*\n");
printf("*\n");
printf("*\n");
printf("*\n");
printf("* INSTRUCTION FAIL = \"%s\" (%s)\n", effect.c_str(), instr->_opcode.c_str());
printf("*\n");
printf("*\n");
printf("*\n");
printf("*\n");
printf("*\n");
printf("*\n");
printf("*\n");
printf("*\n");
printf("*\n");
printf("***********************************************************************\n");
exit(0);
}
    }

    return (instr->_address + instr->_size);
}

/**
** \fn int set_value_contexte(Info *info, unsigned long addr, Contexte &ctx)
** \brief Gere l'initialisation d'elements du contexte d'execution en fonction d'une adresse
**
** \param info Contient les infos du prog. (pour trouver d'eventuelles valeurs)
** \param addr Adresse de l'instruction correspondant a ce contexte
** \param ctx Contexte a initialiser avec des valeurs precises si elles sont precisees
** \return Retourne 1 si le contexte d'execution a ete modifie, 0 sinon
*/
int    set_value_contexte(Info *info, unsigned long addr, Contexte &ctx)
{
    std::map<unsigned long, std::map<std::string, ContentContexte> >::const_iterator    it;

    if (info == NULL)
        return (0);

    it = info->value_of_register_at_begining_of_function.find(addr);
    if (it != info->value_of_register_at_begining_of_function.end())
    {
        /* Si la valeur ou le type de l'element de contexte est precise, on le modifie */
        for (std::map<std::string, ContentContexte>::const_iterator it2=it->second.begin();
             it2!=it->second.end();
             it2++)
        {
            ctx.set_content(it2->first, it2->second.get_size(), it2->second.get_type(), it2->second.get_values(), it2->second.get_filters(), info);
        }   
        return (1);
    }
    
    return (0);
}

/**
** \fn void set_destination_jump(InstrASM *instr, std::list<unsigned long> &list_addr_next,
**                               const Info *info, const std::map<std::string, std::string> &m,
**                               const std::string &name_expr)
** \brief Gere l'identifiaction des adresses sur lequel, il est possible de jumper
**
** \param instr Instruction en cours d'analyse
** \param list_addr_next Liste des adresses ou il est possible de jumper
** \param info Structure contenant les info du programme a analyser
** \param m Map contenant les elements de l'expression decrivant le jump
** \param name_expr Nom de l'element a analyser pour connaitre les adresses de jump
** \return Retourne rien
*/
void    set_destination_jump(InstrASM *instr, std::list<unsigned long> &list_addr_next,
                             const Info *info, const std::map<std::string, std::string> &m,
                             const std::string &name_expr)
{
    std::map<std::string, std::string>::const_iterator    it;
    std::set<std::string>                                 result;
    unsigned long                                         addr_tmp;

    if ((it = m.find(name_expr)) != m.end())
    {
        Calcul::evaluate(result, it->second, info, instr->_contexte);

        /* S'il n'y a pas de resultats connu, on jump sur une adresse invalide pour arreter l'analyse */                  
        if (result.size() == 0)
        {
            for (unsigned long i=0; i<0xfffffffe; i++)
            {
                if (info->sec.is_in_section(i) == 0)
                {
                    list_addr_next.push_back(i);
                    i = 0xfffffffe;
                }
            }
        }

        /* Sinon, on ajoute toutes les adresses de jump aux adresses a analyser */
        else
        {
            for (std::set<std::string>::iterator it_result=result.begin();
                 it_result!=result.end();
                 it_result++)
            {
                addr_tmp = Calcul::Oxtol((*it_result).c_str());
                list_addr_next.push_back(addr_tmp);
                instr->_addr_next_instr_jump.push_back(addr_tmp);
            }
        }
    }
}

