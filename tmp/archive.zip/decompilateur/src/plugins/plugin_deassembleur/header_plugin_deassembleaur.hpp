#ifndef    HEADER_PLUGIN_DEASSEMBLEUR_HPP_
#define    HEADER_PLUGIN_DEASSEMBLEUR_HPP_

#include    <stdio.h>
#include    <string.h>
#include    <unistd.h>
#include    <sys/types.h>
#include    <sys/stat.h>
#include    <fcntl.h>

#include    "Info.hpp"
#include    "Fonction.hpp"
#include    "Calcul.hpp"
#include    "Thread.hpp"

#define    DEBUG_PLUGIN

/**
** \fn Fonction *deassemble_fonction(Info *info, unsigned long entry)
** \brief Gere le deassemblage d'une fonction a partir de son point d'entree
**
** \param info Classe contenant les infos du programme a analyser
** \param entry Point d'entree de la fonction a deassembler
** \return Retourne un pointeur sur la fonction si OK, NULL sinon
*/
Fonction    *deassemble_fonction(Info *info, unsigned long entry);

/**
** \fn int deassemble_bloc(unsigned long addr, Info *info, Fonction *f, Contexte *last_ctx)
** \brief Gere le deassemblage d'un bloc d'instructions a partir de son point d'entree
**
** \param addr Adresse du debut du bloc a deassembler
** \param info Classe contenant les infos du programme a analyser
** \param f Conction auquel appartient le bloc a deassembler
** \param last_ctx Contexte d'execution du bloc precedent afin de realiser l'analyse symbolique
** \return Retourne un pointeur sur la fonction si OK, NULL sinon
*/
int    deassemble_bloc(unsigned long addr, Info *info, Fonction *f, Contexte *last_ctx);

/**
** \fn unsigned long exec_instr(InstrASM *instr, Info *info, std::list<unsigned long> &list_addr_next)
** \brief Gere l'execution symbolique de l'instruction afin de determiner les suivantes
**
** \param instr Instruction ASM a traiter
** \param info Structure contenant les infos du programme a analyser
** \param list_addr_next Liste des adresses des instructions suivantes possibles en cas de sauts
** \return Retourne l'adresse de l'instruction suivante si on effectue pas de sauts
*/
int    exec_instr(InstrASM *instr, Info *info, std::list<unsigned long> &list_addr_next);

/**
** \fn int set_value_contexte(Info *info, unsigned long addr, Contexte &ctx)
** \brief Gere l'initialisation d'elements du contexte d'execution en fonction d'une adresse
**
** \param info Contient les infos du prog. (pour trouver d'eventuelles valeurs)
** \param addr Adresse de l'instruction correspondant a ce contexte
** \param ctx Contexte a initialiser avec des valeurs precises si elles sont precisees
** \return Retourne 1 si le contexte d'execution a ete modifie, 0 sinon
*/
int    set_value_contexte(Info *info, unsigned long addr, Contexte &ctx);

/**
** \fn void set_destination_jump(InstrASM *instr, std::list<unsigned long> &list_addr_next,
**                               const Info *info, const std::map<std::string, std::string> &m,
**                               const std::string &name_expr)
** \brief Gere l'identifiaction des adresses sur lequel, il est possible de jumper
**
** \param instr Instruction en cours d'analyse
** \param list_addr_next Liste des adresses ou il est possible de jumper
** \param info Structure contenant les info du programme a analyser
** \param m Map contenant les elements de l'expression decrivant le jump
** \param name_expr Nom de l'element a analyser pour connaitre les adresses de jump
** \return Retourne rien
*/
void    set_destination_jump(InstrASM *instr, std::list<unsigned long> &list_addr_next,
                             const Info *info, const std::map<std::string, std::string> &m,
                             const std::string &name_expr);

#endif


