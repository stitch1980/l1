#include    "ASM_i16.hpp"
#include    "Info.hpp"
#include    "Contexte.hpp"
#include    "Calcul.hpp"


ASM_i16::ASM_i16(): ASM_i32()
{
    /* Initialisation du deassembleur en mode 16 bits, syntaxe intel */
    ud_init(&(this->_ud_obj));
    ud_set_mode(&(this->_ud_obj), 16);
    ud_set_syntax(&(this->_ud_obj), UD_SYN_INTEL);
}

ASM_i16::~ASM_i16()
{
}

ASM_i16::ASM_i16(const ASM_i16&): ASM_i32()
{
}

ASM_i16&    ASM_i16::operator = (const ASM_i16&)
{
    return (*this);
}


/**
** \fn InstrASM *deasm_instr(unsigned long addr, Info *info)
** \brief Gere le deassemblage de l'instruction ASM a l'adresse indiquee
**
** \param addr Adresse de l'instruction a deassembler
** \param info Structure contenant les infos du programme a analyser
** \return Retourne un pointeur sur l'instruction cree si OK, NULL sinon
*/
InstrASM    *ASM_i16::deasm_instr(unsigned long addr, Info *info)
{
    return (ASM_i32::deasm_instr(addr, info));
}

