/* -----------------------------------------------------------------------------
 * udis86.h
 *
 * Copyright (c) 2002, 2003, 2004 Vivek Mohan <vivek@sig9.com>
 * All rights reserved. See (LICENSE)
 * -----------------------------------------------------------------------------
 */

#ifndef UDIS86_H
#define UDIS86_H

#include "libudis86/types.h"
#include "libudis86/extern.h"
#include "libudis86/itab.h"

#include "libudis86/decode.h"
#include "libudis86/syn.h"

#endif
