/**
** Plugin gerant le chargement du deassembleur a utiliser pour l'architecture intel 64bits
** Le champ "archi" de la structure "Info" doit valoir Info::ARCHI_I64
** Retourne 1 si OK, -1 sinon
*/
#include    "Info.hpp"
#include    "ASM_i64.hpp"


#define    PLUGIN_NAME    PLUGIN_TYPE__DEASM ".5000.deasm_intel64.0"

extern "C"
{
    const char    *get_plugin_name();
    int           execute(Info *info);
    const char    *apropos();
}


/**
** \fn const char *func_emplacement_param_int(unsigned long num)
** \brief Fonction permettant de connaitre l'emplacement des parametres d'interruptions
**
** \param num Numero du parametre a localiser
** \return Retourne l'emplacement du parametre si OK, NAME_PC sinon
*/
const char    *func_emplacement_param_int(unsigned long num)
{
    if (num == 0)
        return ("ebx");
    else if (num == 1)
        return ("ecx");
    else if (num == 2)
        return ("edx");
    else if (num == 3)
        return ("esi");
    else if (num == 4)
        return ("edi");
    else if (num == 5)
        return ("ebp");
    return (NAME_PC);
}

/**
** \fn const char *func_emplacement_return_int()
** \brief Fonction permettant de connaitre l'emplacement de la valeur de retour des interruptions
**
** \return Retourne l'emplacement de la valeur de retour
*/
const char    *func_emplacement_return_int()
{
    return ("eax");
}

/**
** \fn const char *func_emplacement_numero_int()
** \brief Fonction permettant de connaitre le numero d'une interruption
**
** \return Retourne l'emplacement du numero d'interruption
*/
const char    *func_emplacement_numero_int()
{
    return ("eax");
}

/**
** \fn const char *func_emplacement_param_syscall(unsigned long num)
** \brief Fonction permettant de connaitre l'emplacement des parametres de syscall
**
** \param num Numero du parametre a localiser
** \return Retourne l'emplacement du parametre si OK, NAME_PC sinon
*/
const char    *func_emplacement_param_syscall(unsigned long num)
{
    if (num == 0)
        return ("rdi");
    else if (num == 1)
        return ("rsi");
    else if (num == 2)
        return ("rdx");
    else if (num == 3)
        return ("rcx");
    else if (num == 4)
        return ("r8");
    else if (num == 5)
        return ("r9");
    return (NAME_PC);
}

/**
** \fn const char *func_emplacement_return_syscall()
** \brief Fonction permettant de connaitre l'emplacement de la valeur de retour des syscall
**
** \return Retourne l'emplacement de la valeur de retour
*/
const char    *func_emplacement_return_syscall()
{
    return ("rax");
}

/**
** \fn const char *func_emplacement_numero_syscall()
** \brief Fonction permettant de connaitre le numero d'une interruption
**
** \return Retourne l'emplacement du numero des sycall
*/
const char    *func_emplacement_numero_syscall()
{
    return ("rax");
}

/**
** \fn const char *func_emplacement_param_func(unsigned long num)
** \brief Fonction permettant de connaitre l'emplacement des parametres de fonctions
**
** \param num Numero du parametre a localiser
** \return Retourne l'emplacement du parametre si OK, NAME_PC sinon
*/
const char    *func_emplacement_param_func(unsigned long num)
{
    if (num == 0)
        return ("rdi");
    else if (num == 1)
        return ("rsi");
    else if (num == 2)
        return ("rdx");
    else if (num == 3)
        return ("rcx");
    else if (num == 4)
        return ("r8");
    else if (num == 5)
        return ("r9");
    return (NAME_PC);
}

/**
** \fn const char *func_emplacement_return_func()
** \brief Fonction permettant de connaitre l'emplacement de la valeur de retour des fonctions
**
** \return Retourne l'emplacement de la valeur de retour
*/
const char    *func_emplacement_return_func()
{
    return ("reax");
}




/**
** \fn const char *get_plugin_name()
** \brief Fonction permettant de connaitre le nom du plugin
**
** \return Retourne un pointeur vers le nom du plugin
*/
const char    *get_plugin_name()
{
    return (PLUGIN_NAME);
}

/**
** \fn int execute(Info *info)
** \brief Fonction permettant d'executer le plugin pour recuperer le contenu du fichier
**
** \param info Classe contenant les infos du programme a analyser
** \return Retourne 1 si OK, -1 sinon
*/
int        execute(Info *info)
{
    if (info == NULL)
        return (0);

    /* Si l'executable a analyser est un binaire i64, on prepare son deassembleur */
    if (info->archi == Info::ARCHI_I64)
    {
        info->endian = Info::ENDIAN_LITTLE;
        
        /* Initialisation des pointeurs des fonctions permettant d'acceder aux emplacements des parametres */
        info->ptr_func.f_param_func = &func_emplacement_param_func;
        info->ptr_func.f_ret_func = &func_emplacement_return_func;
        
        info->ptr_func.f_num_int = &func_emplacement_numero_int;
        info->ptr_func.f_param_int = &func_emplacement_param_int;
        info->ptr_func.f_ret_int = &func_emplacement_return_int;
        
        info->ptr_func.f_num_syscall = &func_emplacement_numero_syscall;
        info->ptr_func.f_param_syscall = &func_emplacement_param_syscall;
        info->ptr_func.f_ret_syscall = &func_emplacement_return_syscall;
        
        /* Creation de l'objet gerant le deassemblage des instructions ASM */
        if (info->ptr_func.deasm != NULL)
            delete info->ptr_func.deasm;
        info->ptr_func.deasm = NULL;
        
        if ((info->ptr_func.deasm = new ASM_i64) == NULL)
            return (-1);
        return (1);
    }
    return (0);
}

/**
** \fn const char *get_plugin_name()
** \brief Fonction permettant de d'acceder a la description du plugin
**
** \return Retourne un pointeur vers la description du plugin
*/
const char    *apropos()
{
    return ("Plugin permettant de deassembler les instructions ASM i64\n");
}

