#ifndef    ASM_I64_HPP_
#define    ASM_I64_HPP_

#include    "ASM_i32.hpp"


class    ASM_i64: public ASM_i32
{
public:
    ASM_i64();
    virtual ~ASM_i64();
protected:
    ASM_i64(const ASM_i64&);
    ASM_i64&    operator = (const ASM_i64&);

public:
    /**
    ** \fn InstrASM *deasm_instr(unsigned long addr, Info *info)
    ** \brief Gere le deassemblage de l'instruction ASM a l'adresse indiquee
    **
    ** \param addr Adresse de l'instruction a deassembler
    ** \param info Structure contenant les infos du programme a analyser
    ** \return Retourne un pointeur sur l'instruction cree si OK, NULL sinon
    */
    virtual InstrASM     *deasm_instr(unsigned long addr, Info *info);

protected:
};

#endif

