#ifndef    ASM_I32_HPP_
#define    ASM_I32_HPP_

#include    <stdio.h>
#include    <string.h>
#include    "IASM.hpp"

/** Librairie gerant le deassemblage des ocpodes */
#include    "udis86.h"


/**
** \struct s_effect_instr
** \brief Structure contenant la description des effets d'une instruction ASM
*/
typedef struct s_effect_instr
{
    /** Mnemonic permettant d'identifier l'instruction */
    enum ud_mnemonic_code    mnemonic;
    /** Type d'instruction (INSTR_INVALIDE, INSTR_OPER, INSTR_ASSOC, ...) */
    unsigned long           type;
    /** Description des effets de bord sous forme de calcul */
    const char              *effect[20];
    /** Effets de l'action sur les flags */
    const char              *effect_flag;
    /** Pointeur sur une fonction pouvant etre appelee pour traiter l'instruction */
    int                     (*func_exec)(Info*, Fonction*, InstrASM*);
} t_effect_instr;



class    ASM_i32: public IASM
{
public:
    ASM_i32();
    virtual ~ASM_i32();
protected:
    ASM_i32(const ASM_i32&);
    ASM_i32&    operator = (const ASM_i32&);

public:
    /**
    ** \fn const char **get_registre() const;
    ** \brief Assesseurs permettant d'acceder a la liste des registres existants
    **
    ** \return Retourne Retourne un tableau contenant les nom des registres
    */
    virtual const char   **get_registre() const;

    /**
    ** \fn void init_registre(std::map<std::string, ContentContexte> &reg,
    **                        unsigned long addr=0, Info *info=NULL) const = 0;
    ** \brief Permet d'initialiser les registres du contexte d'execution
    **
    ** \param reg Map contenant les registre a initialiser
    ** \param addr Adresse de la fonction pour lequel les registre sont prevu
    ** \param info Contient les infos du prog. (pour trouver d'eventuelles valeurs de reg.)
    ** \return Retourne rien
    */
    virtual void    init_registre(std::map<std::string, ContentContexte> &reg,
                               unsigned long addr=0, const Info *info=NULL) const;


    /**
    ** \fn void get_name_and_mask_getter(const std::string &name, std::string &begin_mask,
    **                                   std::string &name_parent, std::string &end_mask)
    ** \brief Fonction permettant au contexte de savoir comment acceder aux sous-registres
    **
    ** \param name Nom du registre auquel acceder
    ** \param begin_mask String ou mettre le debut du masque a utiliser pour extraire la valeur du sous-registre de son parent
    ** \param name_parent String ou mettre le nom du registre parent (vaudra name s'il ny a pas de parent)
    ** \param end_mask String ou mettre la fin du masque a utiliser pour extraire la valeur du sous-registre de son parent
    ** \return Retourne rien
    */
    virtual void    get_name_and_mask_getter(const std::string &name, std::string &begin_mask,
                                             std::string &name_parent, std::string &end_mask);

    /**
    ** \fn void get_name_and_mask_setter(const std::string &name, std::string &begin_mask,
    **                                   std::string &name_parent, std::string &end_mask)
    ** \brief Fonction permettant au contexte de savoir comment modifier les sous-registres
    **
    ** \param name Nom du registre auquel acceder
    ** \param begin_mask String ou mettre le debut du masque a utiliser pour extraire la valeur du sous-registre de son parent
    ** \param name_parent String ou mettre le nom du registre parent (vaudra name s'il ny a pas de parent)
    ** \param end_mask String ou mettre la fin du masque a utiliser pour extraire la valeur du sous-registre de son parent
    ** \return Retourne rien
    */
    virtual void    get_name_and_mask_setter(const std::string &name, std::string &begin_mask,
                                             std::string &name_parent, std::string &end_mask);

    /**
    ** \fn std::string get_size_registre(const std::string &name,
    **                                   const std::map<std::string, ContentContexte> &reg)
    ** \brief Fonction permettant d'acceder a la taille d'un registre
    **
    ** \param name Nom du registre
    ** \param reg Map contenant les registres
    ** \return Retourne la taille du registre si on le trouve, 0 sinon
    */
    virtual unsigned long    get_size_registre(const std::string &name,
                                               const std::map<std::string, ContentContexte*> &reg);

    /**
    ** \fn std::string &get_type_registre(std::string &dest, const std::string &name,
    **                                   const std::map<std::string, ContentContexte> &reg)
    ** \brief Fonction permettant d'acceder au type de contenu d'un registre
    **
    ** \param dest String ou mettre les valeurs
    ** \param name Nom du registre
    ** \param reg Map contenant les registres
    ** \return Retourne le type de contenu du registre si on le trouve, "" sinon
    */
    virtual std::string      &get_type_registre(std::string &dest, const std::string &name,
                                                const std::map<std::string, ContentContexte*> &reg);


    /**
    ** \fn InstrASM *deasm_instr(unsigned long addr, Info *info)
    ** \brief Gere le deassemblage de l'instruction ASM a l'adresse indiquee
    **
    ** \param addr Adresse de l'instruction a deassembler
    ** \param info Structure contenant les infos du programme a analyser
    ** \return Retourne un pointeur sur l'instruction cree si OK, NULL sinon
    */
    virtual InstrASM     *deasm_instr(unsigned long addr, Info *info);

protected:
    /**
    ** \fn void remplace_op1_op2(std::list<std::string> &effect);
    ** \brief Gere le rempacement des mots-clefs "op1", "op2"... par leur valeur
    **
    ** \param effect Liste des effets de bord a traiter
    ** \return Retourne rien
    */
    void    remplace_op1_op2(std::list<std::string> &effect);

    /**
    ** \fn void get_value_operande(std::string &value, unsigned int num)
    ** \brief Gere la recuperation du nom d'un operande
    **
    ** \param value String ou mettre le nom de l'operande (sera videe en cas d'erreur)
    ** \param num Numero de l'operande (commence a 0)
    ** \return Retourne rien
    */
    void    get_operande(std::string &value, unsigned int num);
    
    /**
    ** \fn void gestion_effect_flags(InstrASM *instr, const char *effect) const
    ** \brief Gere la preparation des effets d'une instruction ASM sur les flags
    **
    ** \param instr Instruction a preparer
    ** \param effect Effet de l'instruction sur les flags (ex= ":zf:zf=0:zf=1:"
    ** \return Retourne rien
    */
    void    gestion_effect_flags(InstrASM *instr, const char *effect) const;
                                  
protected:
    /* Objet sevant au deassemblage des instructions ASM */
    ud_t    _ud_obj;
};

#endif

