#ifndef    ASM_I16_HPP_
#define    ASM_I16_HPP_

#include    "ASM_i32.hpp"


class    ASM_i16: public ASM_i32
{
public:
    ASM_i16();
    virtual ~ASM_i16();
protected:
    ASM_i16(const ASM_i16&);
    ASM_i16&    operator = (const ASM_i16&);

public:
    /**
    ** \fn InstrASM *deasm_instr(unsigned long addr, Info *info)
    ** \brief Gere le deassemblage de l'instruction ASM a l'adresse indiquee
    **
    ** \param addr Adresse de l'instruction a deassembler
    ** \param info Structure contenant les infos du programme a analyser
    ** \return Retourne un pointeur sur l'instruction cree si OK, NULL sinon
    */
    virtual InstrASM     *deasm_instr(unsigned long addr, Info *info);

protected:
};

#endif

