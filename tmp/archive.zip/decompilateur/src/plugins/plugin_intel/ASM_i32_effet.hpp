#ifndef    ASM_I32_EFFET_HPP_
#define    ASM_I32_EFFET_HPP_

#include    "ASM_i32.hpp"




/**
** \fn int func_exec_call(Info *info, Fonction *func, InstrASM *instr)
** \brief Fonction permettant de gerer les CALL
**
** \param info Structure contenant les infos du programme a analyser
** \param func Fonction en cours d'analyse
** \param instr Instruction en cours d'analyse
** \return Retourne 1 si l'analyse peut continuer -1 sinon (si l'appel arrete la fonction)
*/
int    func_exec_call(Info *info, Fonction *, InstrASM *instr)
{
    std::string      name;
    unsigned long    addr;
    
    /* Identification de l'adresse du CALL */
    if (instr->__operande.size() < 1)
        return (1);
    addr = Calcul::calcul(instr->__operande[0]._name, info, instr->_contexte);
    
    /* On regarde si un symbole correspond a cette adresse */
    if ((name = info->sym.get_name(addr)).size() > 0)
    {
        /* On regarde si ce nom correspond a une fonction */
        if (info->proto_func.exist(name) != 0)
        {
            /* Si cette fonction ne retourne rien, on retourne -1 */
            if (info->proto_func.get_ret(name).size() == 0)
                return (-1);
        }
    }
    
    return (1);
}


/**
** \fn int func_exec_int(Info *info, Fonction *func, InstrASM *instr)
** \brief Fonction permettant de gerer les INT
**
** \param info Structure contenant les infos du programme a analyser
** \param func Fonction en cours d'analyse
** \param instr Instruction en cours d'analyse
** \return Retourne 1 si l'analyse peut continuer -1 sinon (si l'appel arrete la fonction)
*/
int    func_exec_int(Info *info, Fonction *, InstrASM *instr)
{
    std::string      emplacement_num_int;
    unsigned long    num_int;
    
    /* Recuperation du numero de l'interruption */
    emplacement_num_int = info->ptr_func.f_num_int();
    num_int = Calcul::calcul(emplacement_num_int, info, instr->_contexte);

    /* Recuperation du type de retour de l'interruption */
    if (info->interrupt.exist(num_int) != 0)
    {
        /* Si cette interruption ne retourne rien, on retourne -1 */
        if (info->interrupt.get_ret(num_int).size() == 0)
            return (-1);
    }
    
    return (1);
}


#define    ASM_I32_EFFET__NBS_INSTR    33

t_effect_instr    ASM_i32_descr_effect[ASM_I32_EFFET__NBS_INSTR] =
{
    /* NOP */
    {
        UD_Inop,
        INSTR_NOP,
        {
            NULL, NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL, 
            NULL, NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL
        },
        NULL,
        NULL
    },

    /* ADD */
    {
        UD_Iadd,
        INSTR_OPER,
        {
            "dst = op1 + op2",
            NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL, 
            NULL, NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL
        },
        ":of:sf:zf:af:cf:pf:",
        NULL
    },
    
    /* AND */
    {
        UD_Iand,
        INSTR_OPER,
        {
            "dst = op1 & op2",
            NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL, 
            NULL, NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL
        },
        ":of=0:cf=0:sf:zf:pf:",
        NULL
    },
    
    /* CALL */
    {
        UD_Icall,
        INSTR_CALL,
        {
            NULL, NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL, 
            NULL, NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL
        },
        NULL,
        &func_exec_call
    },

    /* DEC */
    {
        UD_Idec,
        INSTR_OPER,
        {
            "dst = op1 - 1",
            NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL, 
            NULL, NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL
        },
        ":of:sf:zf:af:pf:",
        NULL
    },

    /* INC */
    {
        UD_Iinc,
        INSTR_OPER,
        {
            "dst = op1 + 1",
            NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL, 
            NULL, NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL
        },
        ":of:sf:zf:af:pf:",
        NULL
    },
    
    /* INT */
    {
        UD_Iint,
        INSTR_INT,
        {
            NULL, NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL, 
            NULL, NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL
        },
        NULL,
        &func_exec_int
    },
    
    /* JMP */
    {
        UD_Ijmp,
        INSTR_JUMP,
        {
            "pc = op1",
            NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL, 
            NULL, NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL
        },
        NULL,
        NULL
    },
    
    /* JO */
    {
        UD_Ijo,
        INSTR_JUMP | INSTR_CONDITION,
        {
            "pc = (of == 1) ? op1 : (pc+instr_size)",
            NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL, 
            NULL, NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL
        },
        NULL,
        NULL
    },
    
    /* JNO */
    {
        UD_Ijno,
        INSTR_JUMP | INSTR_CONDITION,
        {
            "pc = (of == 0) ? op1 : (pc+instr_size)",
            NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL, 
            NULL, NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL
        },
        NULL,
        NULL
    },
    
    /* JB */
    {
        UD_Ijb,
        INSTR_JUMP | INSTR_CONDITION,
        {
            "pc = (cf == 1) ? op1 : (pc+instr_size)",
            NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL, 
            NULL, NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL
        },
        NULL,
        NULL
    },
    
    /* JAE */
    {
        UD_Ijae,
        INSTR_JUMP | INSTR_CONDITION,
        {
            "pc = (cf == 0) ? op1 : (pc+instr_size)",
            NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL, 
            NULL, NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL
        },
        NULL,
        NULL
    },
    
    /* JZ */
    {
        UD_Ijz,
        INSTR_JUMP | INSTR_CONDITION,
        {
            "pc = (zf == 1) ? op1 : (pc+instr_size)",
            NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL, 
            NULL, NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL
        },
        NULL,
        NULL
    },
    
    /* JNZ */
    {
        UD_Ijnz,
        INSTR_JUMP | INSTR_CONDITION,
        {
            "pc = (zf == 0) ? op1 : (pc+instr_size)",
            NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL, 
            NULL, NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL
        },
        NULL,
        NULL
    },
    
    /* JBE */
    {
        UD_Ijbe,
        INSTR_JUMP | INSTR_CONDITION,
        {
            "pc = (cf == 1 || zf == 1) ? op1 : (pc+instr_size)",
            NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL, 
            NULL, NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL
        },
        NULL,
        NULL
    },
    
    /* JA */
    {
        UD_Ija,
        INSTR_JUMP | INSTR_CONDITION,
        {
            "pc = (cf == 0 && zf == 0) ? op1 : (pc+instr_size)",
            NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL, 
            NULL, NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL
        },
        NULL,
        NULL
    },
    
    /* JS */
    {
        UD_Ijs,
        INSTR_JUMP | INSTR_CONDITION,
        {
            "pc = (sf == 1) ? op1 : (pc+instr_size)",
            NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL, 
            NULL, NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL
        },
        NULL,
        NULL
    },
    
    /* JNS */
    {
        UD_Ijns,
        INSTR_JUMP | INSTR_CONDITION,
        {
            "pc = (sf == 0) ? op1 : (pc+instr_size)",
            NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL, 
            NULL, NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL
        },
        NULL,
        NULL
    },
    
    /* JP */
    {
        UD_Ijp,
        INSTR_JUMP | INSTR_CONDITION,
        {
            "pc = (pf == 1) ? op1 : (pc+instr_size)",
            NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL, 
            NULL, NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL
        },
        NULL,
        NULL
    },
    
    /* JNP */
    {
        UD_Ijnp,
        INSTR_JUMP | INSTR_CONDITION,
        {
            "pc = (pf == 0) ? op1 : (pc+instr_size)",
            NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL, 
            NULL, NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL
        },
        NULL,
        NULL
    },
    
    /* JL */
    {
        UD_Ijl,
        INSTR_JUMP | INSTR_CONDITION,
        {
            "pc = (sf != of) ? op1 : (pc+instr_size)",
            NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL, 
            NULL, NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL
        },
        NULL,
        NULL
    },
    
    /* JGE */
    {
        UD_Ijge,
        INSTR_JUMP | INSTR_CONDITION,
        {
            "pc = (sf == of) ? op1 : (pc+instr_size)",
            NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL, 
            NULL, NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL
        },
        NULL,
        NULL
    },
    
    /* JLE */
    {
        UD_Ijle,
        INSTR_JUMP | INSTR_CONDITION,
        {
            "pc = (zf==1 || sf!=of) ? op1 : (pc+instr_size)",
            NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL, 
            NULL, NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL
        },
        NULL,
        NULL
    },
    
    /* JG */
    {
        UD_Ijg,
        INSTR_JUMP | INSTR_CONDITION,
        {
            "pc = (zf==0 && sf==of) ? op1 : (pc+instr_size)",
            NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL, 
            NULL, NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL
        },
        NULL,
        NULL
    },
    
    /* JCXZ */
    {
        UD_Ijcxz,
        INSTR_JUMP | INSTR_CONDITION,
        {
            "pc = (cx==0) ? op1 : (pc+instr_size)",
            NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL, 
            NULL, NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL
        },
        NULL,
        NULL
    },
    
    /* JECXZ */
    {
        UD_Ijecxz,
        INSTR_JUMP | INSTR_CONDITION,
        {
            "pc = (ecx==0) ? op1 : (pc+instr_size)",
            NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL, 
            NULL, NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL
        },
        NULL,
        NULL
    },
    
    /* JRCXZ */
    {
        UD_Ijrcxz,
        INSTR_JUMP | INSTR_CONDITION,
        {
            "pc = (rcx==0) ? op1 : (pc+instr_size)",
            NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL, 
            NULL, NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL
        },
        NULL,
        NULL
    },

    /* MOV */
    {
        UD_Imov,
        INSTR_ASSOC,
        {
            "op1 = op2",
            NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL, 
            NULL, NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL
        },
        NULL,
        NULL
    },

    /* OR */
    {
        UD_Ior,
        INSTR_OPER,
        {
            "dst = op1 | op2",
            NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL, 
            NULL, NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL
        },
        ":of=0:cf=0:sf:zf:pf:",
        NULL
    },

    /* SHL */
    {
        UD_Ishl,
        INSTR_OPER,
        {
            "dst = op1 << op2",
            NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL, 
            NULL, NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL
        },
        NULL,
        NULL
    },

    /* SUB */
    {
        UD_Isub,
        INSTR_OPER,
        {
            "dst = op1 - op2",
            NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL, 
            NULL, NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL
        },
        ":of:sf:zf:af:cf:pf:",
        NULL
    },

    /* RET */
    {
        UD_Iret,
        INSTR_RETURN,
        {
            NULL, NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL, 
            NULL, NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL
        },
        NULL,
        NULL
    },

    /* XOR */
    {
        UD_Ixor,
        INSTR_OPER,
        {
            "dst = op1 ^ op2",
            NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL, 
            NULL, NULL, NULL, NULL, NULL,     NULL, NULL, NULL, NULL, NULL
        },
        NULL,
        NULL
    }
};

#endif

