#include    "ASM_i32.hpp"
#include    "Info.hpp"
#include    "Contexte.hpp"
#include    "Calcul.hpp"

#include    "ASM_i32_effet.hpp"


ASM_i32::ASM_i32(): IASM(),
    _ud_obj()
{
    /* Initialisation du deassembleur en mode 32 bits, syntaxe intel */
    ud_init(&(this->_ud_obj));
    ud_set_mode(&(this->_ud_obj), 32);
    ud_set_syntax(&(this->_ud_obj), UD_SYN_INTEL);
}

ASM_i32::~ASM_i32()
{
}

ASM_i32::ASM_i32(const ASM_i32&): IASM(),
    _ud_obj()
{
}

ASM_i32&    ASM_i32::operator = (const ASM_i32&)
{
    return (*this);
}


/**
** \fn const char **get_registre() const
** \brief Assesseurs permettant d'acceder a la liste des registres existants
**
** \return Retourne Retourne un tableau contenant les nom des registres
*/
const char   **ASM_i32::get_registre() const
{
    static const char *registre[] =
    {
//NULL,
        /* Registres */
        "rax", "eax", "ax", "ah",  "al",
        "rbx", "ebx", "bx", "bh",  "bl",
        "rcx", "ecx", "cx", "ch",  "cl",
        "rdx", "edx", "dx", "dh",  "dl",
        "rsp", "esp", "sp", "sph", "spl",
        "rbp", "ebp", "bp", "bph", "bpl",
        "rdi", "edi", "di", "dih", "dil",
        "rsi", "esi", "si", "sih", "sil",
        "cs", "ds", "es", "fs", "gs", "ss",
        "rip", "eip", "ip",
        NAME_PC,
        
        "r8", "r8d", "r8w", "r8b", 
        "r9", "r9d", "r9w", "r9b", 
        "r10", "r10d", "r10w", "r10b",
        "r11", "r11d", "r11w", "r11b",
        "r12", "r12d", "r12w", "r12b",
        "r13", "r13d", "r13w", "r13b",
        "r14", "r14d", "r14w", "r14b",
        "r15", "r15d", "r15w", "r15b",

        /* Flags
        **
        ** Bit   Label    Description
        ** ---------------------------
        ** 0      CF      Carry flag
        ** 2      PF      Parity flag
        ** 4      AF      Auxiliary carry flag
        ** 6      ZF      Zero flag
        ** 7      SF      Sign flag
        ** 8      TF      Trap flag
        ** 9      IF      Interrupt enable flag
        ** 10     DF      Direction flag
        ** 11     OF      Overflow flag
        ** 12-13  IOPL    I/O Priviledge level
        ** 14     NT      Nested task flag
        ** 16     RF      Resume flag
        ** 17     VM      Virtual 8086 mode flag
        ** 18     AC      Alignment check flag (486+)
        ** 19     VIF     Virutal interrupt flag
        ** 20     VIP     Virtual interrupt pending flag
        ** 21     ID      ID flag
        */
//        "eflags",
        "cf", "pf",   "af",  "zf",
        "sf", "tf",   "if",  "df",
        "of", "iopl", "nt",  "rf",
        "vm", "ac",   "vif", "vip",
        "id",







        /* Control registers are CR0 to CR4 */
        "cr0", "cr1", "cr2", "cr3", "cr4",

        /* Debug registers are DR0 to DR7 */
        "dr0", "dr1", "dr2", "dr3", "dr4", "dr5", "dr6", "dr7",

        /* Test registers are TR3 to TR7 */
        "tr3", "tr4", "tr5", "tr6", "tr7",

        /*
        ** Protected mode segmentation registers are :
        ** GDTR (Global Descriptor Table Register)
        ** IDTR (Interrupt Descriptor Table Register)
        ** LDTR (Local DTR), and TR
        */
        "gdtr", "idtr", "ldtr", "tr",

        /* Valeurs temporaires */
        "dest_tmp", "op1_tmp", "op2_tmp", "op3_tmp",
        "tmp0",     "tmp1",    "tmp2",    "tmp3",    "tmp4",
        "tmp5",     "tmp6",    "tmp7",    "tmp8",    "tmp9",
        NULL
    };

    return (registre);
}

/**
** \fn void init_registre(std::map<std::string, ContentContexte> &reg,
**                        unsigned long addr=0, Info *info=NULL) const = 0;
** \brief Permet d'initialiser les registres du contexte d'execution
**
** \param reg Map contenant les registre a initialiser
** \param addr Adresse de la fonction pour lequel les registre sont prevu
** \param info Contient les infos du prog. (pour trouver d'eventuelles valeurs de reg.)
** \return Retourne rien
*/
void    ASM_i32::init_registre(std::map<std::string, ContentContexte> &reg,
                               unsigned long addr, const Info */*info*/) const
{
    const char    **name;

    name = this->get_registre();
    for (unsigned long i=0; name[i]!=NULL; i++)
    {
        /* On ne traite pas les sous-registres */
        if ((strcmp(name[i], "ax") != 0) && (strcmp(name[i], "ah") != 0) && (strcmp(name[i], "al") != 0) &&
            (strcmp(name[i], "bx") != 0) && (strcmp(name[i], "bh") != 0) && (strcmp(name[i], "bl") != 0) &&
            (strcmp(name[i], "cx") != 0) && (strcmp(name[i], "ch") != 0) && (strcmp(name[i], "cl") != 0) &&
            (strcmp(name[i], "dx") != 0) && (strcmp(name[i], "dh") != 0) && (strcmp(name[i], "dl") != 0) &&
            (strcmp(name[i], "sp") != 0) &&
            (strcmp(name[i], "bp") != 0) &&
            (strcmp(name[i], "si") != 0) &&
            (strcmp(name[i], "di") != 0) &&
            (strcmp(name[i], "eip") != 0) && (strcmp(name[i], "ip") != 0) &&
            (strcmp(name[i], "eflags") != 0))
        {
            if (0)
            {
            }
            /* Initialisation par defaut du registre a 0 (devrait etre a inconnu) */
            else
            {
                reg[name[i]].set_value("");
                reg[name[i]].set_size(4);
                reg[name[i]].set_type("int");
            }
        }
    }

    /* Precise le PC de la fonction */
    reg[NAME_PC].set_value(Calcul::lto0x(addr));
    reg[NAME_PC].set_size(4);
    reg[NAME_PC].set_type("void*");
}


/**
** \fn void get_name_and_mask_getter(const std::string &name, std::string &begin_mask,
**                                   std::string &name_parent, std::string &end_mask)
** \brief Fonction permettant au contexte de savoir comment acceder aux sous-registres
**
** \param name Nom du registre auquel acceder
** \param begin_mask String ou mettre le debut du masque a utiliser pour extraire la valeur du sous-registre de son parent
** \param name_parent String ou mettre le nom du registre parent (vaudra name s'il ny a pas de parent)
** \param end_mask String ou mettre la fin du masque a utiliser pour extraire la valeur du sous-registre de son parent
** \return Retourne rien
*/
void    ASM_i32::get_name_and_mask_getter(const std::string &name, std::string &begin_mask,
                                          std::string &name_parent, std::string &end_mask)
{
    begin_mask.clear();
    name_parent = name;
    end_mask.clear();
    
    if (name == NAME_PC)
        name_parent = "rip";
    
    else if (name == "eax")
        { name_parent = "rax";    begin_mask = "(";    end_mask = "&0xffffffff)"; }
    else if (name == "ebx")
        { name_parent = "rbx";    begin_mask = "(";    end_mask = "&0xffffffff)"; }
    else if (name == "ecx")
        { name_parent = "rcx";    begin_mask = "(";    end_mask = "&0xffffffff)"; }
    else if (name == "edx")
        { name_parent = "rdx";    begin_mask = "(";    end_mask = "&0xffffffff)"; }
    else if (name == "esp")
        { name_parent = "rsp";    begin_mask = "(";    end_mask = "&0xffffffff)"; }
    else if (name == "ebp")
        { name_parent = "rbp";    begin_mask = "(";    end_mask = "&0xffffffff)"; }
    else if (name == "edi")
        { name_parent = "rdi";    begin_mask = "(";    end_mask = "&0xffffffff)"; }
    else if (name == "esi")
        { name_parent = "rsi";    begin_mask = "(";    end_mask = "&0xffffffff)"; }
    else if (name == "eip")
        { name_parent = "rip";    begin_mask = "(";    end_mask = "&0xffffffff)"; }
    else if (name == "r8d")
        { name_parent = "r8";    begin_mask = "(";    end_mask = "&0xffffffff)"; }
    else if (name == "r9d")
        { name_parent = "r9";    begin_mask = "(";    end_mask = "&0xffffffff)"; }
    else if (name == "r10d")
        { name_parent = "r10";    begin_mask = "(";    end_mask = "&0xffffffff)"; }
    else if (name == "r11d")
        { name_parent = "r11";    begin_mask = "(";    end_mask = "&0xffffffff)"; }
    else if (name == "r12d")
        { name_parent = "r12";    begin_mask = "(";    end_mask = "&0xffffffff)"; }
    else if (name == "r13d")
        { name_parent = "r13";    begin_mask = "(";    end_mask = "&0xffffffff)"; }
    else if (name == "r14d")
        { name_parent = "r14";    begin_mask = "(";    end_mask = "&0xffffffff)"; }
    else if (name == "r15d")
        { name_parent = "r15";    begin_mask = "(";    end_mask = "&0xffffffff)"; }
        
    else if (name == "ax")
        { name_parent = "rax";    begin_mask = "(";    end_mask = "&0xffff)"; }
    else if (name == "bx")
        { name_parent = "rbx";    begin_mask = "(";    end_mask = "&0xffff)"; }
    else if (name == "cx")
        { name_parent = "rcx";    begin_mask = "(";    end_mask = "&0xffff)"; }
    else if (name == "dx")
        { name_parent = "rdx";    begin_mask = "(";    end_mask = "&0xffff)"; }  
    else if (name == "sp")
        { name_parent = "rsp";    begin_mask = "(";    end_mask = "&0xffff)"; }
    else if (name == "bp")
        { name_parent = "rbp";    begin_mask = "(";    end_mask = "&0xffff)"; }
    else if (name == "di")
        { name_parent = "rdi";    begin_mask = "(";    end_mask = "&0xffff)"; }
    else if (name == "si")
        { name_parent = "rsi";    begin_mask = "(";    end_mask = "&0xffff)"; }
    else if (name == "ip")
        { name_parent = "rip";    begin_mask = "(";    end_mask = "&0xffff)"; }
    else if (name == "r8w")
        { name_parent = "r8";     begin_mask = "(";    end_mask = "&0xffff)"; }
    else if (name == "r9w")
        { name_parent = "r9";     begin_mask = "(";    end_mask = "&0xffff)"; }
    else if (name == "r10w")
        { name_parent = "r10";    begin_mask = "(";    end_mask = "&0xffff)"; }
    else if (name == "r11w")
        { name_parent = "r11";    begin_mask = "(";    end_mask = "&0xffff)"; }
    else if (name == "r12w")
        { name_parent = "r12";    begin_mask = "(";    end_mask = "&0xffff)"; }
    else if (name == "r13w")
        { name_parent = "r13";    begin_mask = "(";    end_mask = "&0xffff)"; }
    else if (name == "r14w")
        { name_parent = "r14";    begin_mask = "(";    end_mask = "&0xffff)"; }
    else if (name == "r15w")
        { name_parent = "r15";    begin_mask = "(";    end_mask = "&0xffff)"; }
        
    else if (name == "al")
        { name_parent = "rax";    begin_mask = "(";    end_mask = "&0xff)"; }
    else if (name == "bl")
        { name_parent = "rbx";    begin_mask = "(";    end_mask = "&0xff)"; }
    else if (name == "cl")
        { name_parent = "rcx";    begin_mask = "(";    end_mask = "&0xff)"; }
    else if (name == "dl")
        { name_parent = "rdx";    begin_mask = "(";    end_mask = "&0xff)"; }     
    else if (name == "spl")
        { name_parent = "rsp";    begin_mask = "(";    end_mask = "&0xff)"; }
    else if (name == "bpl")
        { name_parent = "rbp";    begin_mask = "(";    end_mask = "&0xff)"; }
    else if (name == "dil")
        { name_parent = "rdi";    begin_mask = "(";    end_mask = "&0xff)"; }
    else if (name == "sil")
        { name_parent = "rsi";    begin_mask = "(";    end_mask = "&0xff)"; }
    else if (name == "r8b")
        { name_parent = "r8";     begin_mask = "(";    end_mask = "&0xff)"; }
    else if (name == "r9b")
        { name_parent = "r9";     begin_mask = "(";    end_mask = "&0xff)"; }
    else if (name == "r10b")
        { name_parent = "r10";    begin_mask = "(";    end_mask = "&0xff)"; }
    else if (name == "r11b")
        { name_parent = "r11";    begin_mask = "(";    end_mask = "&0xff)"; }
    else if (name == "r12b")
        { name_parent = "r12";    begin_mask = "(";    end_mask = "&0xff)"; }
    else if (name == "r13b")
        { name_parent = "r13";    begin_mask = "(";    end_mask = "&0xff)"; }
    else if (name == "r14b")
        { name_parent = "r14";    begin_mask = "(";    end_mask = "&0xff)"; }
    else if (name == "r15b")
        { name_parent = "r15";    begin_mask = "(";    end_mask = "&0xff)"; }
        
    else if (name == "ah")
        { name_parent = "rax";    begin_mask = "((";    end_mask = "&0xff00)>>8)"; }
    else if (name == "bh")
        { name_parent = "rbx";    begin_mask = "((";    end_mask = "&0xff00)>>8)"; }
    else if (name == "ch")
        { name_parent = "rcx";    begin_mask = "((";    end_mask = "&0xff00)>>8)"; }
    else if (name == "dh")
        { name_parent = "rdx";    begin_mask = "((";    end_mask = "&0xff00)>>8)"; }     
    else if (name == "sph")
        { name_parent = "rsp";    begin_mask = "((";    end_mask = "&0xff00)>>8)"; }
    else if (name == "bph")
        { name_parent = "rbp";    begin_mask = "((";    end_mask = "&0xff00)>>8)"; }
    else if (name == "dih")
        { name_parent = "rdi";    begin_mask = "((";    end_mask = "&0xff00)>>8)"; }
    else if (name == "sih")
        { name_parent = "rsi";    begin_mask = "((";    end_mask = "&0xff00)>>8)"; }
}

/**
** \fn void get_name_and_mask_setter(const std::string &name, std::string &begin_mask,
**                                   std::string &name_parent, std::string &end_mask)
** \brief Fonction permettant au contexte de savoir comment modifier les sous-registres
**
** \param name Nom du registre auquel acceder
** \param begin_mask String ou mettre le debut du masque a utiliser pour extraire la valeur du sous-registre de son parent
** \param name_parent String ou mettre le nom du registre parent (vaudra name s'il ny a pas de parent)
** \param end_mask String ou mettre la fin du masque a utiliser pour extraire la valeur du sous-registre de son parent
** \return Retourne rien
*/
void    ASM_i32::get_name_and_mask_setter(const std::string &name, std::string &begin_mask,
                                             std::string &name_parent, std::string &end_mask)
{
    begin_mask.clear();
    name_parent = name;
    end_mask.clear();
    
    if (name == NAME_PC)
        name_parent = "rip";
    
    else if (name == "eax")
        { name_parent = "rax";    begin_mask = "((rax&0xffffffff00000000)&(";    end_mask = "&0xffffffff))"; }
    else if (name == "ebx")
        { name_parent = "rbx";    begin_mask = "((rbx&0xffffffff00000000)&(";    end_mask = "&0xffffffff))"; }
    else if (name == "ecx")
        { name_parent = "rcx";    begin_mask = "((rcx&0xffffffff00000000)&(";    end_mask = "&0xffffffff))"; }
    else if (name == "edx")
        { name_parent = "rdx";    begin_mask = "((rdx&0xffffffff00000000)&(";    end_mask = "&0xffffffff))"; }
    else if (name == "esp")
        { name_parent = "rsp";    begin_mask = "((rsp&0xffffffff00000000)&(";    end_mask = "&0xffffffff))"; }
    else if (name == "ebp")
        { name_parent = "rbp";    begin_mask = "((rbp&0xffffffff00000000)&(";    end_mask = "&0xffffffff))"; }
    else if (name == "edi")
        { name_parent = "rdi";    begin_mask = "((rdi&0xffffffff00000000)&(";    end_mask = "&0xffffffff))"; }
    else if (name == "esi")
        { name_parent = "rsi";    begin_mask = "((rdi&0xffffffff00000000)&(";    end_mask = "&0xffffffff))"; }
    else if (name == "eip")
        { name_parent = "rip";    begin_mask = "((rip&0xffffffff00000000)&(";    end_mask = "&0xffffffff))"; }
    else if (name == "r8d")
        { name_parent = "r8";     begin_mask = "((r8&0xffffffff00000000)&(";    end_mask = "&0xffffffff))"; }
    else if (name == "r9d")
        { name_parent = "r9";     begin_mask = "((r9&0xffffffff00000000)&(";    end_mask = "&0xffffffff))"; }
    else if (name == "r10d")
        { name_parent = "r10";    begin_mask = "((r10&0xffffffff00000000)&(";    end_mask = "&0xffffffff))"; }
    else if (name == "r11d")
        { name_parent = "r11";    begin_mask = "((r11&0xffffffff00000000)&(";    end_mask = "&0xffffffff))"; }
    else if (name == "r12d")
        { name_parent = "r12";    begin_mask = "((r12&0xffffffff00000000)&(";    end_mask = "&0xffffffff))"; }
    else if (name == "r13d")
        { name_parent = "r13";    begin_mask = "((r13&0xffffffff00000000)&(";    end_mask = "&0xffffffff))"; }
    else if (name == "r14d")
        { name_parent = "r14";    begin_mask = "((r14&0xffffffff00000000)&(";    end_mask = "&0xffffffff))"; }
    else if (name == "r15d")
        { name_parent = "r15";    begin_mask = "((r15&0xffffffff00000000)&(";    end_mask = "&0xffffffff))"; }
        
    else if (name == "ax")
        { name_parent = "rax";    begin_mask = "((rax&0xffffffffffff0000)&(";    end_mask = "&0xffff))"; }
    else if (name == "bx")
        { name_parent = "rbx";    begin_mask = "((rbx&0xffffffffffff0000)&(";    end_mask = "&0xffff))"; }
    else if (name == "cx")
        { name_parent = "rcx";    begin_mask = "((rcx&0xffffffffffff0000)&(";    end_mask = "&0xffff))"; }
    else if (name == "dx")
        { name_parent = "rdx";    begin_mask = "((rdx&0xffffffffffff0000)&(";    end_mask = "&0xffff))"; }  
    else if (name == "sp")
        { name_parent = "rsp";    begin_mask = "((rsp&0xffffffffffff0000)&(";    end_mask = "&0xffff))"; }
    else if (name == "bp")
        { name_parent = "rbp";    begin_mask = "((rbp&0xffffffffffff0000)&(";    end_mask = "&0xffff))"; }
    else if (name == "di")
        { name_parent = "rdi";    begin_mask = "((rdi&0xffffffffffff0000)&(";    end_mask = "&0xffff))"; }
    else if (name == "si")
        { name_parent = "rsi";    begin_mask = "((rsi&0xffffffffffff0000)&(";    end_mask = "&0xffff))"; }
    else if (name == "ip")
        { name_parent = "rip";    begin_mask = "((rip&0xffffffffffff0000)&(";    end_mask = "&0xffff))"; }
    else if (name == "r8w")
        { name_parent = "r8";     begin_mask = "((r8&0xffffffffffff0000)&(";    end_mask = "&0xffff))"; }
    else if (name == "r9w")
        { name_parent = "r9";     begin_mask = "((r9&0xffffffffffff0000)&(";    end_mask = "&0xffff))"; }
    else if (name == "r10w")
        { name_parent = "r10";    begin_mask = "((r10&0xffffffffffff0000)&(";    end_mask = "&0xffff))"; }
    else if (name == "r11w")
        { name_parent = "r11";    begin_mask = "((r11&0xffffffffffff0000)&(";    end_mask = "&0xffff))"; }
    else if (name == "r12w")
        { name_parent = "r12";    begin_mask = "((r12&0xffffffffffff0000)&(";    end_mask = "&0xffff))"; }
    else if (name == "r13w")
        { name_parent = "r13";    begin_mask = "((r13&0xffffffffffff0000)&(";    end_mask = "&0xffff))"; }
    else if (name == "r14w")
        { name_parent = "r14";    begin_mask = "((r14&0xffffffffffff0000)&(";    end_mask = "&0xffff))"; }
    else if (name == "r15w")
        { name_parent = "r15";    begin_mask = "((r15&0xffffffffffff0000)&(";    end_mask = "&0xffff))"; }
        
    else if (name == "al")
        { name_parent = "rax";    begin_mask = "(rax&0xffffffffffffff00)&(";    end_mask = "&0xff))"; }
    else if (name == "bl")
        { name_parent = "rbx";    begin_mask = "(rbx&0xffffffffffffff00)&(";    end_mask = "&0xff))"; }
    else if (name == "cl")
        { name_parent = "rcx";    begin_mask = "(rcx&0xffffffffffffff00)&(";    end_mask = "&0xff))"; }
    else if (name == "dl")
        { name_parent = "rdx";    begin_mask = "(rdx&0xffffffffffffff00)&(";    end_mask = "&0xff))"; }     
    else if (name == "spl")
        { name_parent = "rsp";    begin_mask = "(rsp&0xffffffffffffff00)&(";    end_mask = "&0xff))"; }
    else if (name == "bpl")
        { name_parent = "rbp";    begin_mask = "(rbp&0xffffffffffffff00)&(";    end_mask = "&0xff))"; }
    else if (name == "dil")
        { name_parent = "rdi";    begin_mask = "(rdi&0xffffffffffffff00)&(";    end_mask = "&0xff))"; }
    else if (name == "sil")
        { name_parent = "rsi";    begin_mask = "(rsi&0xffffffffffffff00)&(";    end_mask = "&0xff))"; }
    else if (name == "r8b")
        { name_parent = "r8";     begin_mask = "(r8&0xffffffffffffff00)&(";    end_mask = "&0xff))"; }
    else if (name == "r9b")
        { name_parent = "r9";     begin_mask = "(r9&0xffffffffffffff00)&(";    end_mask = "&0xff))"; }
    else if (name == "r10b")
        { name_parent = "r10";    begin_mask = "(r10&0xffffffffffffff00)&(";    end_mask = "&0xff))"; }
    else if (name == "r11b")
        { name_parent = "r11";    begin_mask = "(r11&0xffffffffffffff00)&(";    end_mask = "&0xff))"; }
    else if (name == "r12b")
        { name_parent = "r12";    begin_mask = "(r12&0xffffffffffffff00)&(";    end_mask = "&0xff))"; }
    else if (name == "r13b")
        { name_parent = "r13";    begin_mask = "(r13&0xffffffffffffff00)&(";    end_mask = "&0xff))"; }
    else if (name == "r14b")
        { name_parent = "r14";    begin_mask = "(r14&0xffffffffffffff00)&(";    end_mask = "&0xff))"; }
    else if (name == "r15b")
        { name_parent = "r15";    begin_mask = "(r15&0xffffffffffffff00)&(";    end_mask = "&0xff))"; }
        
    else if (name == "ah")
        { name_parent = "rax";    begin_mask = "((rax&0xffffffffffff00ff)&((";    end_mask = "&0xff)<<8))"; }
    else if (name == "bh")
        { name_parent = "rbx";    begin_mask = "((rbx&0xffffffffffff00ff)&((";    end_mask = "&0xff)<<8))"; }
    else if (name == "ch")
        { name_parent = "rcx";    begin_mask = "((rcx&0xffffffffffff00ff)&((";    end_mask = "&0xff)<<8))"; }
    else if (name == "dh")
        { name_parent = "rdx";    begin_mask = "((rdx&0xffffffffffff00ff)&((";    end_mask = "&0xff)<<8))"; }     
    else if (name == "sph")
        { name_parent = "rsp";    begin_mask = "((rsp&0xffffffffffff00ff)&((";    end_mask = "&0xff)<<8))"; }
    else if (name == "bph")
        { name_parent = "rbp";    begin_mask = "((rbp&0xffffffffffff00ff)&((";    end_mask = "&0xff)<<8))"; }
    else if (name == "dih")
        { name_parent = "rdi";    begin_mask = "((rdi&0xffffffffffff00ff)&((";    end_mask = "&0xff)<<8))"; }
    else if (name == "sih")
        { name_parent = "rsi";    begin_mask = "((rsi&0xffffffffffff00ff)&((";    end_mask = "&0xff)<<8))"; }
}

/**
** \fn std::string get_size_registre(const std::string &name,
**                                   const std::map<std::string, ContentContexte> &reg)
** \brief Fonction permettant d'acceder a la taille d'un registre
**
** \param name Nom du registre
** \param reg Map contenant les registres
** \return Retourne la taille du registre si on le trouve, 0 sinon
*/
unsigned long    ASM_i32::get_size_registre(const std::string &name,
                                            const std::map<std::string, ContentContexte*> &/*reg*/)
{
    unsigned long    ret;
    
    this->_mutex.lock();
    
    ret = 0;
    if ((name == "rax") || (name == "rbx") || (name == "rcx") || (name == "rdx") ||
        (name == "rsp") || (name == "rbp") || (name == "rdi") || (name == "rsi") ||
        (name == "rip") || (name == NAME_PC) || 
        (name == "r8") || (name == "r9") || (name == "r10") || (name == "r11") || 
        (name == "r12") || (name == "r13") || (name == "r14") || (name == "r15"))
        ret = 8;
    else if ((name == "eax") || (name == "ebx") || (name == "ecx") || (name == "edx") ||
             (name == "esp") || (name == "ebp") || (name == "edi") || (name == "esi") ||
             (name == "eip") || 
             (name == "r8d") || (name == "r9d") || (name == "r10d") || (name == "r11d") || 
             (name == "r12d") || (name == "r13d") || (name == "r14d") || (name == "r15d"))
        ret = 4;
    else if ((name == "ax") || (name == "bx") || (name == "cx") || (name == "dx") ||
             (name == "sp") || (name == "bp") || (name == "di") || (name == "si") ||
             (name == "ip") ||
             (name == "cs") || (name == "ds") || (name == "es") || (name == "fs") ||
             (name == "gs") || (name == "ss") ||
             (name == "r8w") || (name == "r9w") || (name == "r10w") || (name == "r11w") || 
             (name == "r12w") || (name == "r13w") || (name == "r14w") || (name == "r15w"))
        ret = 2;
    else if ((name == "ah") || (name == "bh") || (name == "ch") || (name == "dh") ||
             (name == "sph") || (name == "bph") || (name == "dih") || (name == "sih") ||
             (name == "al") || (name == "bl") || (name == "cl") || (name == "dl") ||
             (name == "bpl") || (name == "bpl") || (name == "dil") || (name == "sil") ||
             (name == "r8b") || (name == "r9b") || (name == "r10b") || (name == "r11b") || 
             (name == "r12b") || (name == "r13b") || (name == "r14b") || (name == "r15b") ||
              
             (name == "cf") || (name == "pf") || (name == "af") || (name == "zf") || 
             (name == "sf") || (name == "tf") || (name == "if") || (name == "df") || 
             (name == "of") || (name == "iopl") || (name == "nt") || (name == "rf") || 
             (name == "vm") || (name == "ac") || (name == "vif") || (name == "vip") || 
             (name == "id"))
        ret = 1;
    else
        ret = 0;
        
    this->_mutex.unlock();
    return (ret);
}

/**
** \fn std::string &get_type_registre(std::string &dest, const std::string &name,
**                                   const std::map<std::string, ContentContexte> &reg)
** \brief Fonction permettant d'acceder au type de contenu d'un registre
**
** \param dest String ou mettre les valeurs
** \param name Nom du registre
** \param reg Map contenant les registres
** \return Retourne le type de contenu du registre si on le trouve, "" sinon
*/
std::string      &ASM_i32::get_type_registre(std::string &dest, const std::string &name,
                                             const std::map<std::string, ContentContexte*> &reg)
{
    this->_mutex.lock();
    
    dest = "";
    if (reg.find(name) != reg.end())
        dest = reg.find(name)->second->get_type();
        
    this->_mutex.unlock();
    return (dest);
}



/**
** \fn InstrASM *deasm_instr(unsigned long addr, Info *info)
** \brief Gere le deassemblage de l'instruction ASM a l'adresse indiquee
**
** \param addr Adresse de l'instruction a deassembler
** \param info Structure contenant les infos du programme a analyser
** \return Retourne un pointeur sur l'instruction cree si OK, NULL sinon
*/
InstrASM    *ASM_i32::deasm_instr(unsigned long addr, Info *info)
{
    InstrASM         *instr;
    std::string      str_tmp;
    unsigned char    buffer[20];
    unsigned long    size;
    
    if (info->sec.is_in_section(addr) == 0)
        return (NULL);
    this->_mutex.lock();

    /* On recupere des octets a deassembler dans un buffer temporaire */
    for (unsigned int i=0; i<20; i++)
        buffer[i] = info->sec.get_char(addr + i);
    
    /* Actualise le buffer, le PC et deassemble l'instruction */
    instr = NULL;
    ud_set_input_buffer(&(this->_ud_obj), buffer, 20);
    ud_set_pc(&(this->_ud_obj), addr);
    if ((size = ud_disassemble(&(this->_ud_obj))) > 0)
    {
        /* Cree et initialise l'instruction ASM */
        if ((instr = new InstrASM) != NULL)
        {
            instr->_opcode = ud_insn_asm(&(this->_ud_obj));

            instr->__name = ud_lookup_mnemonic(this->_ud_obj.mnemonic);
            instr->_address = addr;
            instr->_size = size;
        
            instr->_type = INSTR_INVALIDE;
        
            /* Recherche des infos personelles de l'instruction */
            for (unsigned long i=0; i<ASM_I32_EFFET__NBS_INSTR; i++)
            {
                if (ASM_i32_descr_effect[i].mnemonic == this->_ud_obj.mnemonic)
                {
                    instr->_type = ASM_i32_descr_effect[i].type;
                    instr->__func_exec = ASM_i32_descr_effect[i].func_exec;
                
                    for (unsigned long j=0; (j<20) && (ASM_i32_descr_effect[i].effect[j]!=NULL); j++)
                        instr->_effect.push_back(ASM_i32_descr_effect[i].effect[j]);
         
         
                    /* Preparation des operandes de l'instruction */
                    for (unsigned long j=0; j<3; j++)
                    {
                        if (this->_ud_obj.operand[j].type != UD_NONE)
                        {
                            this->get_operande(str_tmp, j);
                            instr->__operande.push_back(InstrASM::Operande(this->_ud_obj.operand[j].size/8, str_tmp));
                        }
                    }
            
            
                    /* Preparation des effets de bords sur les flags */
                    if (ASM_i32_descr_effect[i].effect_flag != NULL)
                        this->gestion_effect_flags(instr, ASM_i32_descr_effect[i].effect_flag);

                    /* Actualisation des effets de bords en fonction des parametres */
                    this->remplace_op1_op2(instr->_effect);
                
                    i = ASM_I32_EFFET__NBS_INSTR; 
                }
            }
            
        }
    }

    this->_mutex.unlock();
    return (instr);
}

/**
** \fn void remplace_op1_op2(std::list<std::string> &effect);
** \brief Gere le rempacement des mots-clefs "op1", "op2"... par leur valeur
**
** \param effect Liste des effets de bord a traiter
** \return Retourne rien
*/
void         ASM_i32::remplace_op1_op2(std::list<std::string> &effect)
{
    std::list<std::string>::iterator    it;
    unsigned long                       pos;
    std::string                         value;
    
    /* Remplacement des destinations et premier operandes */
    this->get_operande(value, 0);
    if (value.size() == 0)
        value = "0";
    for (it=effect.begin(); it!=effect.end(); it++)
    {
        while ((pos = it->find("dst")) != std::string::npos)
            it->replace(pos, 3, value);
    }
    for (it=effect.begin(); it!=effect.end(); it++)
    {
        while ((pos = it->find("op1")) != std::string::npos)
            it->replace(pos, 3, value);
    }
    
    /* Remplacement des seconds operandes */
    this->get_operande(value, 1);
    if (value.size() == 0)
        value = "0";
    for (it=effect.begin(); it!=effect.end(); it++)
    {
        while ((pos = it->find("op2")) != std::string::npos)
            it->replace(pos, 3, value);
    }
    
    /* Remplacement des 3eme operandes */
    this->get_operande(value, 2);
    if (value.size() == 0)
        value = "0";
    for (it=effect.begin(); it!=effect.end(); it++)
    {
        while ((pos = it->find("op3")) != std::string::npos)
            it->replace(pos, 3, value);
    }
    
    /* Remplacement de la taille de l'instruction */
    value = Calcul::lto0x(ud_insn_len(&(this->_ud_obj)));
    for (it=effect.begin(); it!=effect.end(); it++)
    {
        while ((pos = it->find("instr_size")) != std::string::npos)
            it->replace(pos, 10, value);
    }
}





#include <stdio.h>
#include <stdarg.h>

void my_mkasm(char *buffer, const char* fmt, ...)
{
  va_list ap;
  va_start(ap, fmt);
  vsprintf(&(buffer[strlen(buffer)]), fmt, ap);
  va_end(ap);
}

void 
my_opr_cast(char */*buffer*/, struct ud_operand* /*op*/)
{/*
  switch(op->size) {
	case  8: my_mkasm(buffer, "byte " ); break;
	case 16: my_mkasm(buffer, "word " ); break;
	case 32: my_mkasm(buffer, "dword "); break;
	case 64: my_mkasm(buffer, "qword "); break;
	case 80: my_mkasm(buffer, "tword "); break;
	default: break;
  }*/
}

std::string my_gen_operand(struct ud* u, struct ud_operand* op, int syn_cast)
{
    char buffer[100];
    
    buffer[0] = '\0';

  switch(op->type) {
	case UD_OP_REG:
		my_mkasm(buffer, ud_reg_tab[op->base - UD_R_AL]);
		break;

	case UD_OP_MEM: {

		int op_f = 0;

		if (syn_cast) 
			my_opr_cast(buffer, op);

		my_mkasm(buffer, "[");

		if (u->pfx_seg)
			my_mkasm(buffer, "%s+", ud_reg_tab[u->pfx_seg - UD_R_AL]);

		if (op->base) {
			my_mkasm(buffer, "%s", ud_reg_tab[op->base - UD_R_AL]);
			op_f = 1;
		}

		if (op->index) {
			if (op_f)
				my_mkasm(buffer, "+");
			my_mkasm(buffer, "%s", ud_reg_tab[op->index - UD_R_AL]);
			op_f = 1;
		}

		if (op->scale)
			my_mkasm(buffer, "*%d", op->scale);

		if (op->offset == 8) {
			if (op->lval.sbyte < 0)
				my_mkasm(buffer, "-0x%x", -op->lval.sbyte);
			else	my_mkasm(buffer, "%s0x%x", (op_f) ? "+" : "", op->lval.sbyte);
		}
		else if (op->offset == 16)
			my_mkasm(buffer, "%s0x%x", (op_f) ? "+" : "", op->lval.uword);
		else if (op->offset == 32) {
			if (u->adr_mode == 64) {
				if (op->lval.sdword < 0)
					my_mkasm(buffer, "-0x%x", -op->lval.sdword);
				else	my_mkasm(buffer, "%s0x%x", (op_f) ? "+" : "", op->lval.sdword);
			} 
			else	my_mkasm(buffer, "%s0x%lx", (op_f) ? "+" : "", op->lval.udword);
		}
		else if (op->offset == 64) 
			my_mkasm(buffer, "%s0x" FMT64 "x", (op_f) ? "+" : "", op->lval.uqword);

		my_mkasm(buffer, "]");
		break;
	}
			
	case UD_OP_IMM:
		if (syn_cast) my_opr_cast(buffer, op);
		switch (op->size) {
			case  8: my_mkasm(buffer, "0x%x", op->lval.ubyte);    break;
			case 16: my_mkasm(buffer, "0x%x", op->lval.uword);    break;
			case 32: my_mkasm(buffer, "0x%lx", op->lval.udword);  break;
			case 64: my_mkasm(buffer, "0x" FMT64 "x", op->lval.uqword); break;
			default: break;
		}
		break;

	case UD_OP_JIMM:
		if (syn_cast) my_opr_cast(buffer, op);
		switch (op->size) {
			case  8:
				my_mkasm(buffer, "0x" FMT64 "x", u->pc + op->lval.sbyte); 
				break;
			case 16:
				my_mkasm(buffer, "0x" FMT64 "x", u->pc + op->lval.sword);
				break;
			case 32:
				my_mkasm(buffer, "0x" FMT64 "x", u->pc + op->lval.sdword);
				break;
			default:break;
		}
		break;

	case UD_OP_PTR:
		switch (op->size) {
			case 32:
				my_mkasm(buffer, "0x%x+0x%x", op->lval.ptr.seg, 
					op->lval.ptr.off & 0xFFFF);
				break;
			case 48:
				my_mkasm(buffer, "0x%x+0x%lx", op->lval.ptr.seg, 
					op->lval.ptr.off);
				break;
		}
		break;

	case UD_OP_CONST:
		if (syn_cast) my_opr_cast(buffer, op);
		my_mkasm(buffer, "%d", op->lval.udword);
		break;

	default: return "";
  }
  
  return (buffer);
}





/**
** \fn void get_value_operande(std::string &value, unsigned int num)
** \brief Gere la recuperation du nom d'un operande
**
** \param value String ou mettre le nom de l'operande (sera videe en cas d'erreur)
** \param num Numero de l'operande (commence a 0)
** \return Retourne rien
*/
void    ASM_i32::get_operande(std::string &value, unsigned int num)
{
    ud_operand_t    *oper;
    
    value.clear();
    if (num > 2)
        return ;
    oper = &(this->_ud_obj.operand[num]);
        
    if (num == 0)
        value = my_gen_operand(&(this->_ud_obj), oper, this->_ud_obj.c1);
    else if (num == 1)
        value = my_gen_operand(&(this->_ud_obj), oper, this->_ud_obj.c1);
    else if (num == 2)
        value = my_gen_operand(&(this->_ud_obj), oper, this->_ud_obj.c1);
}

/**
** \fn void gestion_effect_flags(InstrASM *instr, const char *effect) const
** \brief Gere la preparation des effets d'une instruction ASM sur les flags
**
** \param instr Instruction a preparer
** \param effect Effet de l'instruction sur les flags (ex= ":zf:zf=0:zf=1:"
** \return Retourne rien
*/
void    ASM_i32::gestion_effect_flags(InstrASM *instr, const char *effect) const
{
    //"eflags",
    
    if (strstr(effect, ":cf=0:") != NULL)
        instr->_effect.push_back("cf=0");
    if (strstr(effect, ":cf=1:") != NULL)
        instr->_effect.push_back("cf=1");
    if (strstr(effect, ":cf:") != NULL)
        instr->_effect.push_back("cf=42");
        
    if (strstr(effect, ":pf=0:") != NULL)
        instr->_effect.push_back("pf=0");
    if (strstr(effect, ":pf=1:") != NULL)
        instr->_effect.push_back("pf=1");
    if (strstr(effect, ":pf:") != NULL)
        instr->_effect.push_back("pf=42");
    
    if (strstr(effect, ":af=0:") != NULL)
        instr->_effect.push_back("af=0");
    if (strstr(effect, ":af=1:") != NULL)
        instr->_effect.push_back("af=1");
    if (strstr(effect, ":af:") != NULL)
        instr->_effect.push_back("af=42");
    
    if (strstr(effect, ":zf=0:") != NULL)
        instr->_effect.push_back("zf=0");
    if (strstr(effect, ":zf=1:") != NULL)
        instr->_effect.push_back("zf=1");
    if (strstr(effect, ":zf:") != NULL)
        instr->_effect.push_back("zf=42");
    

    if (strstr(effect, ":sf=0:") != NULL)
        instr->_effect.push_back("sf=0");
    if (strstr(effect, ":sf=1:") != NULL)
        instr->_effect.push_back("sf=1");
    if (strstr(effect, ":sf:") != NULL)
        instr->_effect.push_back("sf=42");
    
    if (strstr(effect, ":tf=0:") != NULL)
        instr->_effect.push_back("tf=0");
    if (strstr(effect, ":tf=1:") != NULL)
        instr->_effect.push_back("tf=1");
    if (strstr(effect, ":tf:") != NULL)
        instr->_effect.push_back("tf=42");
    
    if (strstr(effect, ":if=0:") != NULL)
        instr->_effect.push_back("if=0");
    if (strstr(effect, ":if=1:") != NULL)
        instr->_effect.push_back("if=1");
    if (strstr(effect, ":if:") != NULL)
        instr->_effect.push_back("if=42");
    
    if (strstr(effect, ":df=0:") != NULL)
        instr->_effect.push_back("df=0");
    if (strstr(effect, ":df=1:") != NULL)
        instr->_effect.push_back("df=1");
    if (strstr(effect, ":df:") != NULL)
        instr->_effect.push_back("df=42");
    

    if (strstr(effect, ":of=0:") != NULL)
        instr->_effect.push_back("of=0");
    if (strstr(effect, ":of=1:") != NULL)
        instr->_effect.push_back("of=1");
    if (strstr(effect, ":of:") != NULL)
        instr->_effect.push_back("of=42");
    
    if (strstr(effect, ":iopl=0:") != NULL)
        instr->_effect.push_back("iopl=0");
    if (strstr(effect, ":iopl=1:") != NULL)
        instr->_effect.push_back("iopl=1");
    if (strstr(effect, ":iopl:") != NULL)
        instr->_effect.push_back("iopl=42");
    
    if (strstr(effect, ":nt=0:") != NULL)
        instr->_effect.push_back("nt=0");
    if (strstr(effect, ":nt=1:") != NULL)
        instr->_effect.push_back("nt=1");
    if (strstr(effect, ":nt:") != NULL)
        instr->_effect.push_back("nt=42");
    
    if (strstr(effect, ":rf=0:") != NULL)
        instr->_effect.push_back("rf=0");
    if (strstr(effect, ":rf=1:") != NULL)
        instr->_effect.push_back("rf=1");
    if (strstr(effect, ":rf:") != NULL)
        instr->_effect.push_back("rf=42");
    

    if (strstr(effect, ":vm=0:") != NULL)
        instr->_effect.push_back("vm=0");
    if (strstr(effect, ":vm=1:") != NULL)
        instr->_effect.push_back("vm=1");
    if (strstr(effect, ":vm:") != NULL)
        instr->_effect.push_back("vm=42");
    
    if (strstr(effect, ":ac=0:") != NULL)
        instr->_effect.push_back("ac=0");
    if (strstr(effect, ":ac=1:") != NULL)
        instr->_effect.push_back("ac=1");
    if (strstr(effect, ":ac:") != NULL)
        instr->_effect.push_back("ac=42");
    
    if (strstr(effect, ":vif=0:") != NULL)
        instr->_effect.push_back("vif=0");
    if (strstr(effect, ":vif=1:") != NULL)
        instr->_effect.push_back("vif=1");
    if (strstr(effect, ":vif:") != NULL)
        instr->_effect.push_back("vif=42");
    
    if (strstr(effect, ":vip=0:") != NULL)
        instr->_effect.push_back("vip=0");
    if (strstr(effect, ":vip=1:") != NULL)
        instr->_effect.push_back("vip=1");
    if (strstr(effect, ":vip:") != NULL)
        instr->_effect.push_back("vip=42");
    

    if (strstr(effect, ":id=0:") != NULL)
        instr->_effect.push_back("id=0");
    if (strstr(effect, ":id=1:") != NULL)
        instr->_effect.push_back("id=1");
    if (strstr(effect, ":id:") != NULL)
        instr->_effect.push_back("id=42");
}


