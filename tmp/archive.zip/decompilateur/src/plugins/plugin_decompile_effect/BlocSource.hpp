#ifndef    BLOC_SOURCE_HPP_
#define    BLOC_SOURCE_HPP_

#include    <list>
#include    <string>

#include    "IBlocSource.hpp"

class    BlocSource: public IBlocSource
{
public:
    /**
    ** \fn BlocSource()
    ** \brief Constructeur d'un bloc de code source
    */
    BlocSource();

    /**
    ** \fn ~BlocSource()
    ** \brief Destructeur d'un bloc de code source
    */
    ~BlocSource();

protected:
    BlocSource(const BlocSource&): IBlocSource(), _addr(0), _instr(), _next(NULL) {}
    BlocSource    &operator = (const BlocSource&) {return (*this); }

public:
    /**
    ** \fn void clear()
    ** \brief Supprime le contenu du bloc de source
    **
    ** \return Retourne rien
    */
    virtual void           clear();

    /**
    ** \fn std::string to_string(std::string &dest) const
    ** \brief Gere la conversion de tout les blocs de source en un code-source complet
    **
    ** \param dest String ou mettre le code-source (le code est concatene a la chaine)
    ** \return Retourne une string contenant le code source complet
    */
    virtual std::string    to_string(std::string &dest) const;
    
    
    /**
    ** \fn unsigned long get_addr() const
    ** \brief Assesseur permettant d'acceder a l'adresse du Bloc ASM correspondant a ce bloc C
    **
    ** \return Retourne l'adresse du Bloc ASM correspondant a ce bloc C
    */
    unsigned long             get_addr() const;

    /**
    ** \fn void set_addr(unsigned long addr)
    ** \brief Assesseur permettant de modifier l'adresse du Bloc ASM correspondant a ce bloc C
    **
    ** \param addr Adresse du Bloc ASM correspondant a ce bloc C
    ** \return Retourne rien
    */
    void                      set_addr(unsigned long addr);

    /**
    ** \fn std::list<std::string> &get_instr()
    ** \brief Assesseur permettant d'acceder a la liste des instructions C
    **
    ** \return Retourne une reference sur la liste des instructions C
    */
    std::list<std::string>    &get_instr();

    /**
    ** \fn BlocSource *get_next() const
    ** \brief Assesseur permettant d'acceder au bloc suivant
    **
    ** \return Retourne un pointeur sur le bloc suivant
    */
    BlocSource                *get_next() const;
    
    /**
    ** \fn void set_next(BlocSource *next)
    ** \brief Assesseur permettant de modifier le bloc suivant
    **
    ** \param next Pointeur sur le bloc suivant
    ** \return Retourne rien
    */
    void                      set_next(BlocSource *next);

protected:
    /** Address correspondant a un bloc d'instructions ASM */
    unsigned long             _addr;

    /** Liste des instruction du bloc */
    std::list<std::string>    _instr;
    /** Pointeur sur le bloc suivant */
    BlocSource                *_next;
};

#endif

