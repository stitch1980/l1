#include    "BlocSource.hpp"


/**
** \fn BlocSource()
** \brief Constructeur d'un bloc de code source
*/
BlocSource::BlocSource(): IBlocSource(), _addr(0), _instr(), _next(NULL)
{
}

/**
** \fn ~BlocSource()
** \brief Destructeur d'un bloc de code source
*/
BlocSource::~BlocSource()
{
    this->clear();
}



/**
** \fn void clear()
** \brief Supprime le contenu du bloc de source
**
** \return Retourne rien
*/
void           BlocSource::clear()
{
    this->_addr = 0;
    this->_instr.clear();
    
    if (this->_next != NULL)
        delete this->_next;
}

/**
** \fn std::string to_string(std::string &dest) const
** \brief Gere la conversion de tout les blocs de source en un code-source complet
**
** \param dest String ou mettre le code-source (le code est concatene a la chaine)
** \return Retourne une string contenant le code source complet
*/
std::string    BlocSource::to_string(std::string &dest) const
{
    const BlocSource    *bloc;

    /* On utilise un boucle a la place du recursif pour ne pas eclater la pile */
    bloc = this;
    while (bloc != NULL)
    {
        /* Ajout des instructions du bloc */
        for (std::list<std::string>::const_iterator it=bloc->_instr.begin();
             it!=bloc->_instr.end();
             it++)
            dest += (*it);
        
        bloc = bloc->_next;
    }

    return (dest);
}
    
    
/**
** \fn unsigned long get_addr() const
** \brief Assesseur permettant d'acceder a l'adresse du Bloc ASM correspondant a ce bloc C
**
** \return Retourne l'adresse du Bloc ASM correspondant a ce bloc C
*/
unsigned long             BlocSource::get_addr() const
{
    return (this->_addr);
}

/**
** \fn void set_addr(unsigned long addr)
** \brief Assesseur permettant de modifier l'adresse du Bloc ASM correspondant a ce bloc C
**
** \param addr Adresse du Bloc ASM correspondant a ce bloc C
** \return Retourne rien
*/
void                      BlocSource::set_addr(unsigned long addr)
{
    this->_addr = addr;
}

/**
** \fn std::list<std::string> &get_instr()
** \brief Assesseur permettant d'acceder a la liste des instructions C
**
** \return Retourne une reference sur la liste des instructions C
*/
std::list<std::string>    &BlocSource::get_instr()
{
    return (this->_instr);
}

/**
** \fn BlocSource *get_next() const
** \brief Assesseur permettant d'acceder au bloc suivant
**
** \return Retourne un pointeur sur le bloc suivant
*/
BlocSource                *BlocSource::get_next() const
{
    return (this->_next);
}
    
/**
** \fn void set_next(BlocSource *next)
** \brief Assesseur permettant de modifier le bloc suivant
**
** \param next Pointeur sur le bloc suivant
** \return Retourne rien
*/
void                      BlocSource::set_next(BlocSource *next)
{
    if ((this->_next != NULL) && (this->_next != next))
        delete this->_next;
    this->_next = next;
}

