#include    <stdio.h>
#include    <stdlib.h>
#include    <string.h>

#include    "Info.hpp"
#include    "Calcul.hpp"

#include    "BlocSource.hpp"

#define DEBUG_PLUGIN	      32
#define PLUGIN_NAME           PLUGIN_TYPE__DECOMPILE ".30001.plugin_decompile_effect.0"
#define PLUGIN_DESCRIPTION    "Plugin permettant de transformer une fonction deassemblee en code C\n"

extern "C"
{
    const char    *PLUGIN_FUNC_GET_PLUGIN_NAME();
    int           PLUGIN_FUNC_EXECUTE(Info *info);
    const char    *PLUGIN_FUNC_APROPOS();
}

/**
** \fn int make_entete_fonction(BlocSource *entete, Info *info, Fonction *f)
** \brief Gere la creation du prototype de la fonction a decompiler
**
** \param entete BlocSource ou mettre le prototype de la fonction
** \param info Structure contenant les infos du programme a analyser
** \param f Fonction a decompiler
** \return Retourne toujours 1
*/
int    make_entete_fonction(BlocSource *entete, Info *info, Fonction *f)
{
    std::string                 ret;
    std::string                 name;
    std::vector<std::string>    param;
    std::string                 prototype;
    
    /* Recuperation du nom de la fonction */
    name = Fonction::get_name_function(f, info);
        
    /* Recuperation de l'adresse et des parametres grace aux prototypes */
    ret = "int";
    if (info->proto_func.exist(name) != 0)
    {
        ret = info->proto_func.get_ret(name);
        for (unsigned long i=0; i<info->proto_func.get_nbs_param(name); i++)
            param.push_back(info->proto_func.get_type_param(name, i) +
                            " " +
                            info->proto_func.get_name_param(name, i));
    }

    /* Preparation du prototype */
    if (ret.size() <= 0)
        ret = "void";
    prototype = ret + "\t" + name + "(";

    for (unsigned long i=0; i<param.size(); i++)
    {
        if (i > 0)
            prototype += ", ";
        prototype += param[i] + " param" + Calcul::ltos(i);
    }
    prototype += ")";

    /* Ajout de l'entete Doxygen au code-source */
    entete->get_instr().push_back("/**\n");
    entete->get_instr().push_back("** \\fn " + prototype + "\n");
    entete->get_instr().push_back("** \\brief\n");
    entete->get_instr().push_back("**\n");
    for (unsigned long i=0; i<param.size(); i++)
        entete->get_instr().push_back("** \\param " + param[i] + "\n");
    entete->get_instr().push_back("** \\return\n");
    entete->get_instr().push_back("*/\n");
    
    /* Ajout du prototype au code-source */
    entete->get_instr().push_back(prototype + "\n");

    return (1);
}

unsigned long    get_nbs_bloc_suivant(const Fonction::Bloc *b)
{
    InstrASM    *instr;

    if (b == NULL)
        return (0);
    
    if ((instr = b->get_instr_entry()) == NULL)
        return (0);
    while (instr->_next_instr != NULL)
        instr = instr->_next_instr;
    
    return (instr->_addr_next_instr_jump.size());
}

unsigned long    get_adresse_bloc_suivant(const Fonction::Bloc *b)
{
    InstrASM    *instr;

    if (b == NULL)
        return (0);
    
    if ((instr = b->get_instr_entry()) == NULL)
        return (0);

    while (instr->_next_instr != NULL)
        instr = instr->_next_instr;

    if (instr->_addr_next_instr_jump.size() <= 0)
        return (0);

    return (*(instr->_addr_next_instr_jump.begin()));
}

unsigned long    get_nbs_origine_bloc(const Fonction *f, unsigned long addr)
{
    InstrASM         *instr;
    unsigned long    nbs;
    
    nbs = 0;
    for (std::list<Fonction::Bloc*>::const_iterator it_bloc=f->get_list_bloc().begin();
         it_bloc!=f->get_list_bloc().end();
         it_bloc++)
    {
        if ((instr = (*it_bloc)->get_instr_entry()) != NULL)
        {
            while (instr->_next_instr != NULL)
                instr = instr->_next_instr;
            
            for (std::list<unsigned long>::const_iterator it_addr=instr->_addr_next_instr_jump.begin();
                 it_addr!=instr->_addr_next_instr_jump.end();
                 it_addr++)
            {
                if ((*it_addr) == addr)
                    nbs++;
            }
        }        
    }
    
    return (nbs);
}

Fonction::Bloc    *get_bloc_at_address(const Fonction *f, unsigned long addr)
{
    for (std::list<Fonction::Bloc*>::const_iterator it=f->get_list_bloc().begin();
         it!=f->get_list_bloc().end();
         it++)
    {
        if ((*it)->get_addr() == addr)
            return (*it);
    }

    return (NULL);
}

int    can_i_access_to_this_bloc(const Fonction *f, unsigned long addr_dest, unsigned long current_addr, std::set<unsigned long> *forbidden_blocs)
{
    std::set<unsigned long>    set_forbidden_blocs;
    Fonction::Bloc             *current_bloc;
    InstrASM                   *instr;

    if (addr_dest == current_addr)
        return (1);
    if ((f == NULL) || ((current_bloc = get_bloc_at_address(f, current_addr)) == NULL))
        return (0);
    
    if ((instr = current_bloc->get_instr_entry()) == NULL)
        return (0);
    while (instr->_next_instr != NULL)
        instr = instr->_next_instr;

    /* Si une des destinations correspond a l'adresse, on peut atteindre cette adresse */
    for (std::list<unsigned long>::const_iterator it_addr=instr->_addr_next_instr_jump.begin();
         it_addr!=instr->_addr_next_instr_jump.end();
         it_addr++)
    {
        if ((*it_addr) == addr_dest)
            return (1);
    }
    
    /* Ca c'est super degeu */
    if (forbidden_blocs != NULL)
        set_forbidden_blocs = (*forbidden_blocs);
    set_forbidden_blocs.insert(current_bloc->get_addr());
    
    /* Si on a pas encore atteint la destination, on parcourt tout les bloc encore non parcouru */
    for (std::list<unsigned long>::const_iterator it_addr=instr->_addr_next_instr_jump.begin();
         it_addr!=instr->_addr_next_instr_jump.end();
         it_addr++)
    {
        /* Cherche dans les blos suivant en recursif */
        if (set_forbidden_blocs.find(*it_addr) == set_forbidden_blocs.end())
        {
            if (can_i_access_to_this_bloc(f, addr_dest, *it_addr, &set_forbidden_blocs) > 0)
                return (1);
        }
    }
    
    return (0);
}

unsigned long    get_adresse_bloc_no(const Fonction::Bloc *b)
{
    InstrASM    *instr;

    if (b == NULL)
        return (0);
    
    if ((instr = b->get_instr_entry()) == NULL)
        return (0);
    while (instr->_next_instr != NULL)
        instr = instr->_next_instr;
        
    if (instr->_addr_next_instr_jump.size() <= 0)
        return (0);
    return (*(instr->_addr_next_instr_jump.begin()));
}

unsigned long    get_adresse_bloc_yes(const Fonction::Bloc *b)
{
    std::list<unsigned long>::const_iterator    it_addr;   
    InstrASM                                    *instr;

    if (b == NULL)
        return (0);
    
    if ((instr = b->get_instr_entry()) == NULL)
        return (0);
    while (instr->_next_instr != NULL)
        instr = instr->_next_instr;
        
    if (instr->_addr_next_instr_jump.size() <= 1)
        return (0);
    
    it_addr = instr->_addr_next_instr_jump.begin();
    it_addr++;
    return ((*it_addr));
}

/**
** \fn BlocSource *decompile_bloc(Info *info, Fonction *f, Fonction::Bloc *b, unsigned long profondeur)
** \brief Gere la decompilation d'un bloc de fonction
**
** \param info Structure contenant les infos du programme a analyser
** \param f Fonction a decompiler
** \param b Bloc a decompiler
** \param profondeur Profondeur de l'identation du bloc
** \return Retourne un pointeur sue la source du bloc decompile si OK, NULL sinon
*/
BlocSource    *decompile_bloc(Info *info, Fonction *f, Fonction::Bloc *b, BlocSource *bloc_src_prev, unsigned long profondeur)
{
    BlocSource     *bloc_src;
    InstrASM       *instr_prev;
    std::string    str_indent;

    if ((info == NULL) || (f == NULL) || (b == NULL) || (bloc_src_prev == NULL))
        return (bloc_src_prev);

    /* Preparation de l'identation du bloc */
    for (unsigned long i=0; i<profondeur; i++);
        str_indent += "\t";

    /* On cree un bloc de source */
    bloc_src = NULL;
    while ((b != NULL) && ((bloc_src = new BlocSource) != NULL))
    {
        bloc_src->set_addr(b->get_addr());
        bloc_src_prev->set_next(bloc_src);
        
        /* Traitement de toutes les instructions ASM du bloc */
        instr_prev = NULL;
        for (InstrASM *instr=b->get_instr_entry();
             (instr!=NULL) && (b!=NULL);
             instr=instr->_next_instr)
        {
            bloc_src->get_instr().push_back(str_indent + "asm(\"" + instr->to_asm(info) + "\");    //" + Calcul::ltox(instr->_address) + "\n");
            
            instr_prev = instr;
        }
        
        if ((instr_prev != NULL) &&
            (instr_prev->_addr_next_instr_jump.size() == 1) &&
            (get_nbs_origine_bloc(f, *(instr_prev->_addr_next_instr_jump.begin())) == 1) )
        {
            b = get_bloc_at_address(f, *(instr_prev->_addr_next_instr_jump.begin()));
             bloc_src_prev = bloc_src;
        }
        
        else if ((instr_prev != NULL) &&
                 (instr_prev->_addr_next_instr_jump.size() == 1) &&
                 (get_nbs_origine_bloc(f, *(instr_prev->_addr_next_instr_jump.begin())) > 1) )
        {
            /* Si on peut acceder au bloc courant a partir du bloc suivant, c'est une boucle donc un "do{"*/
            if (can_i_access_to_this_bloc(f, b->get_addr(), get_adresse_bloc_suivant(b), NULL) > 0)
            {
                bloc_src->get_instr().push_back(str_indent + "do    //" + Calcul::ltox(instr_prev->_address) + "\n");
                bloc_src->get_instr().push_back(str_indent + "{\n");                        
            }
            /* Sinon c'est un "}" */
            else
            {
                for (unsigned long i=1; i<profondeur; i++);
                    str_indent += "\t";
                bloc_src->get_instr().push_back(str_indent + "}    //" + Calcul::ltox(instr_prev->_address) + + "   " + Calcul::ltox(get_nbs_origine_bloc(f, *(instr_prev->_addr_next_instr_jump.begin()))) + "\n\n");
                return (bloc_src); 
            }
        }
        else
            b = NULL;
    }
    
    return (bloc_src);
    
    
    
    bloc_src = NULL;
    while ((b != NULL) && ((bloc_src = new BlocSource) != NULL))
    {
        bloc_src->set_addr(b->get_addr());
        bloc_src_prev->set_next(bloc_src);
        
        /* Traitement de toutes les instructions ASM du bloc */
        for (InstrASM *instr=b->get_instr_entry();
             (instr!=NULL) && (b!=NULL);
             instr=instr->_next_instr)
        {
        printf(".\n");
        

            bloc_src->get_instr().push_back(str_indent + "asm(\"" + instr->to_asm(info) + "\");//" + Calcul::ltox(instr->_address) + "\n");

            /* Gestion des sauts */
            if (instr->_addr_next_instr_jump.size() > 0 && 0)//((instr->_type & INSTR_JUMP) == INSTR_JUMP)
            {printf("000000000000000000000000\n");
               
                /* Si c'est un saut conditionnel */
                if (((instr->_type & INSTR_JUMP) == INSTR_JUMP) && ((instr->_type & INSTR_CONDITION) == INSTR_CONDITION))
                {printf("2222222222\n");
                    /* Si on peut rejoindre le bloc courant a partir du bloc suivant, c'est une boucle donc un "while {"*/
                    if (can_i_access_to_this_bloc(f, b->get_addr(), get_adresse_bloc_suivant(b), NULL) > 0)
                        bloc_src->get_instr().push_back(str_indent + "while ()//" + Calcul::ltox(instr->_address) + "\n");
                    /* Sinon c'est un if */
                    else
                        bloc_src->get_instr().push_back(str_indent + "if ()//" + Calcul::ltox(instr->_address) + "\n");
                    bloc_src->get_instr().push_back(str_indent + "{\n");
                    
                    /* On traite le NO en recursif */
                    bloc_src_prev = decompile_bloc(info, f, get_bloc_at_address(f, get_adresse_bloc_no(b)), bloc_src, profondeur + 1);
                    
                    /* On traite le bloc YES en iteratif */
                    b = get_bloc_at_address(f, get_adresse_bloc_yes(b));                    
                }
                
                /* Si le saut est non-conditionnel, avec un seul bloc suivant et que ce bloc n'a qu'une origine : */
                /* -> On le colle au bloc courant */
                else if (((instr->_type == INSTR_JUMP) || (instr->_addr_next_instr_jump.size() > 0)) &&
                    (get_nbs_bloc_suivant(b) == 1) &&
                    (get_nbs_origine_bloc(f, get_adresse_bloc_suivant(b)) <= 1)){printf("0000000\n");
                    b = get_bloc_at_address(f, get_adresse_bloc_suivant(b));}
                    
                /* Si le saut est non-conditionnel, avec un seul bloc suivant et que ce bloc a plusieurs origines : */
                /* -> C'est un "do{" ou un "}" */
                else if (((instr->_type == INSTR_JUMP) || (instr->_addr_next_instr_jump.size() > 0)) &&
                         (get_nbs_bloc_suivant(b) == 1) &
                         (get_nbs_origine_bloc(f, get_adresse_bloc_suivant(b)) > 1))
                {printf("1111111111\n");
                    /* Si on peut acceder au bloc courant a partir du bloc suivant, c'est une boucle donc un "do{"*/
                    if (can_i_access_to_this_bloc(f, b->get_addr(), get_adresse_bloc_suivant(b), NULL) > 0)
                    {
                        bloc_src->get_instr().push_back(str_indent + "do//" + Calcul::ltox(instr->_address) + "\n");
                        bloc_src->get_instr().push_back(str_indent + "{\n");                        
                    }
                    /* Sinon c'est un "}" */
                    else
                    {
                        for (unsigned long i=1; i<profondeur; i++);
                            str_indent += "\t";
                        bloc_src->get_instr().push_back(str_indent + "}//" + Calcul::ltox(instr->_address) + "\n\n");
                        return (bloc_src); 
                    }
                }

                else
                    b = NULL;
            }
        }
    }
    
    return (bloc_src);
}

/**
** \fn int decompile_fonction(Info *info, Fonction *f)
** \brief Gere la decompilation d'une fonction blocs par blocs
**
** \param info Structure contenant les infos du programme a analyser
** \param f Fonction a decompiler
** \return Retourne toujours 1
*/
int    decompile_fonction(Info *info, Fonction *f)
{
    BlocSource        *bloc_src_prev;
    BlocSource        *bloc_src;
    Fonction::Bloc    *bloc_asm;

    if ((bloc_src_prev = new BlocSource) != NULL)
    {
        /* Creation de l'entete */
        f->set_source_code(bloc_src_prev);
        make_entete_fonction(bloc_src_prev, info, f);
        bloc_src_prev->get_instr().push_back("{\n");

        /* Le deassemblage commence par le bloc d'entree */
        bloc_asm = f->get_bloc_entry();
        if (bloc_asm != NULL)
            decompile_bloc(info, f, bloc_asm, bloc_src_prev, 1);

        /* Ajout de l'accolade de fin */
        while (bloc_src_prev->get_next() != NULL)
            bloc_src_prev = bloc_src_prev->get_next();
        if ((bloc_src = new BlocSource) != NULL)
        {
            bloc_src_prev->set_next(bloc_src);
            bloc_src->get_instr().push_back("}\n");
        }
    }

    return (1);
}


/**
** \fn const char *get_plugin_name()
** \brief Fonction permettant de connaitre le nom du plugin
**
** \return Retourne un pointeur vers le nom du plugin
*/
const char    *PLUGIN_FUNC_GET_PLUGIN_NAME()
{
    return (PLUGIN_NAME);
}

/**
** \fn int execute(Info *info)
** \brief Fonction permettant d'executer le plugin pour decompiler les fonctions deja deassemblees
**
** \param info Classe contenant les infos du programme a analyser
** \return Retourne 1 si OK, 0 si le plugin n'a pas ete execute et -1 en cas d'erreur
*/
int    PLUGIN_FUNC_EXECUTE(Info *info)
{
    if (info == NULL)
        return (-1);

    /* Traite les fonctions les unes apres les autres */
    for (std::map<unsigned long, Fonction *>::const_iterator it=info->function.begin();
         it!=info->function.end();
         it++)
        decompile_fonction(info, it->second);
    return (1);
}

/**
** \fn const char *get_plugin_name()
** \brief Fonction permettant de d'acceder a la description du plugin
**
** \return Retourne un pointeur vers la description du plugin
*/
const char    *PLUGIN_FUNC_APROPOS()
{
    return (PLUGIN_DESCRIPTION);
}

