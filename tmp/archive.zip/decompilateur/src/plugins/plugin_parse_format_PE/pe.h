#ifndef    FORMAT_PE_H_
#define    FORMAT_PE_H_

#define    BYTE    unsigned char
#define    WORD    unsigned short
#define    DWORD   unsigned int
#define    LONG    unsigned long


#define    DOS_BLOC_SIZE        512
#define    DOS_PARGRAPH_SIZE    16

struct _DOS_RELOC
{
    WORD    offset;
    WORD    segment;
};

/**
** \struct _IMAGE_DOS_HEADER
** \brief DOS .EXE header
*/
struct _IMAGE_DOS_HEADER
{      
    /** Magic number */
    BYTE    e_magic[2];
    /** The number of bytes in the last block of the program that are actually used. */
    /** If this value is zero, that means the entire last block is used (i.e. the effective value is 512). */                
    WORD    e_cblp;
    /** Number of blocks in the file that are part of the EXE file. If [02-03] is non-zero, only that much of the last block is used. */                
    WORD    e_cp;
    /** Number of relocation entries stored after the header. May be zero. */
    WORD    e_crlc;

    /** Number of paragraphs in the header. */
    /** The program's data begins just after the header, and this field can be used to calculate the appropriate file offset. */
    /** The header includes the relocation entries. Note that some OSs and/or programs may fail if the header is not a multiple of 512 bytes. */
    WORD    e_cparhdr;
    /** Number of paragraphs of additional memory that the program will need. */
    /** This is the equivalent of the BSS size in a Unix program. */
    /** The program can't be loaded if there isn't at least this much memory available to it. */
    WORD    e_minalloc;
    /** Maximum number of paragraphs of additional memory. */
    /** Normally, the OS reserves all the remaining conventional memory for your program, but you can limit it with this field. */
    WORD    e_maxalloc; 
    
    /** Relative value of the stack segment. */
    /** This value is added to the segment the program was loaded at, and the result is used to initialize the SS register. */
    WORD    e_ss;
    /** Initial value of the SP register. */
    WORD    e_sp; 
    /** Word checksum. If set properly, the 16-bit sum of all words in the file should be zero. Usually, this isn't filled in. */
    WORD    e_csum;
    /** Initial value of the IP register. */
    WORD    e_ip;
    /** Initial value of the CS register, relative to the segment the program was loaded at. */
    WORD    e_cs;
    
    /** Offset of the first relocation item in the file. */
    WORD    e_lfarlc;
    /** Overlay number. Normally zero, meaning that it's the main program. */
    WORD    e_ovno;                      /* Overlay number */
    
    WORD    e_res[4];                    /* Reserved words */
    WORD    e_oemid;                     /* OEM identifier (for e_oeminfo) */
    WORD    e_oeminfo;                   /* OEM information; e_oemid specific */
    WORD    e_res2[10];                  /* Reserved words */
    DWORD   e_lfanew;                    /* File address of new exe header */
};




struct _IMAGE_FILE_HEADER
{
    WORD     Machine;
    WORD     NumberOfSections;
    DWORD    TimeDateStamp;
    DWORD    PointerToSymbolTable;
    DWORD    NumberOfSymbols;
    WORD     SizeOfOptionalHeader;
    WORD     Characteristics;
};

struct _IMAGE_OPTIONAL_HEADER
{
    WORD     Magic;
    BYTE     MajorLinkerVersion;
    BYTE     MinorLinkerVersion;
    DWORD    SizeOfCode;
    DWORD    SizeOfInitializedData;
    DWORD    SizeOfUninitializedData;
    DWORD    AddressOfEntryPoint;
    DWORD    BaseOfCode;
    DWORD    BaseOfData;
    DWORD    ImageBase;
    DWORD    SectionAlignment;
    DWORD    FileAlignment;
    WORD     MajorOperatingSystemVersion;
    WORD     MinorOperatingSystemVersion;
    WORD     MajorImageVersion;
    WORD     MinorImageVersion;
    WORD     MajorSubsystemVersion;
    WORD     MinorSubsystemVersion;
    DWORD    Win32VersionValue;
    DWORD    SizeOfImage;
    DWORD    SizeOfHeaders;
    DWORD    CheckSum;
    WORD     Subsystem;
    WORD     DllCharacteristics;
    DWORD    SizeOfStackReserve;
    DWORD    SizeOfStackCommit;
    DWORD    SizeOfHeapReserve;
    DWORD    SizeOfHeapCommit;
    DWORD    LoaderFlags;
    DWORD    NumberOfRvaAndSizes;
//    _IMAGE_DATA_DIRECTORY    DataDirectory[16];
};

struct _IMAGE_NT_HEADERS
{
    BYTE                      Signature[4];
    _IMAGE_FILE_HEADER        FileHeader;
    _IMAGE_OPTIONAL_HEADER    OptionalHeader;
};




#define    IMAGE_SIZEOF_SHORT_NAME    8

struct _IMAGE_SECTION_HEADER
{
    BYTE    Name[IMAGE_SIZEOF_SHORT_NAME];
    union
    {
        DWORD    PhysicalAddress;
        DWORD    VirtualSize;
    } Misc;
    DWORD    VirtualAddress;
    DWORD    SizeOfRawData;
    DWORD    PointerToRawData;
    DWORD    PointerToRelocations;
    DWORD    PointerToLinenumbers;
    WORD     NumberOfRelocations;
    WORD     NumberOfLinenumbers;
    DWORD    Characteristics;
};

#endif

