#include    <stdio.h>
#include    <stdlib.h>
#include    <string.h>

#include    "pe.h"
#include    "Info.hpp"


#define PLUGIN_DESCR_TYPE        PLUGIN_TYPE__PARSING
#define PLUGIN_DESCR_PRIORITE    "2500"      
#define PLUGIN_DESCR_NAME        "plugin_parse_format_DOS"
#define PLUGIN_DESCR_VERSION     "0"  
#define PLUGIN_NAME              PLUGIN_DESCR_TYPE "." PLUGIN_DESCR_PRIORITE "." PLUGIN_DESCR_NAME "." PLUGIN_DESCR_VERSION

#define OFFSET_CODE         0x7c00    /* Offset a partir duquel placer le code */

extern "C"
{
    const char    *PLUGIN_FUNC_GET_PLUGIN_NAME();
    int           PLUGIN_FUNC_EXECUTE(Info *info);
    const char    *PLUGIN_FUNC_APROPOS();
}


/**
** \fn get_data(void *dst, unsigned long dst_size, const unsigned char *src, unsigned long src_size, unsigned long offset)
** \brief Gere la recuperation d'une structure dans le buffer passee en parametre
**
** \param dst Buffer de destination
** \param dst_size Taille de la structure a recuperer
** \param src Buffer ou chercher le contenu de la structure a recuperer
** \param src_size Taille du buffer ou chercher le contenu de la structure a recuperer
** \param offset Offset de la structure a recuperer dans le buffer source
** \return Retourne 1 si OK, 0 si incomplet, -1 en cas d'erreur (met le reste de la structure a 0 si incomplet)
*/
int    get_data(void *dst, unsigned long dst_size, const unsigned char *src, unsigned long src_size, unsigned long offset)
{
    int    ret;

    if ((src == NULL) || (dst == NULL))
        return (-1);

    memset(dst, 0, dst_size);
    if (offset > src_size)
        return (-1);
    ret = 1;

    if ((src_size - offset) < dst_size)
    {
        dst_size = src_size - offset;
        ret = 0;
    }

    memmove(dst, &(src[offset]), dst_size);
    return (ret);
}


/**
** \fn const char *get_plugin_name()
** \brief Fonction permettant de connaitre le nom du plugin
**
** \return Retourne un pointeur vers le nom du plugin
*/
const char    *PLUGIN_FUNC_GET_PLUGIN_NAME()
{
    return (PLUGIN_NAME);
}
   
/**
** \fn int execute(Info *info)
** \brief Fonction permettant d'executer le plugin pour parser les executables DOS
**
** \param info Classe contenant les infos du programme a analyser
** \return Retourne 1 si OK, 0 si le plugin n'a pas ete execute et -1 en cas d'erreur
*/
int    PLUGIN_FUNC_EXECUTE(Info *info)
{
    struct _IMAGE_DOS_HEADER    header_dos;
    struct _IMAGE_NT_HEADERS    header_pe;
    unsigned long               offset_data;
    unsigned long               size_data;
    unsigned char               *buffer;

    if ((info == NULL) || (info->data == NULL))
        return (-1);
    
    /* Recuperation de l'header DOS */
    if ((get_data(&header_dos, sizeof(_IMAGE_OPTIONAL_HEADER), info->data, info->size, 0) < 0) ||
        (header_dos.e_magic[0] != 'M') || (header_dos.e_magic[1] != 'Z'))
        return (0);
printf("Fichier DOS %u %u %u %u     %u\n", header_dos.e_lfanew, header_dos.e_cp, header_dos.e_crlc, header_dos.e_lfarlc, header_dos.e_cparhdr);

    /* Si c'est un fichier PE et qu'on a pas precise qu'on s'interessait a la partie DOS, on arrete */
    if ((get_data(&header_pe, sizeof(_IMAGE_NT_HEADERS), info->data, info->size, header_dos.e_lfanew) > 0) &&
        (header_pe.Signature[0] == 'P') && (header_pe.Signature[1] == 'E') &&
        (header_pe.Signature[2] == '\0') && (header_pe.Signature[3] == '\1')/* && <------------------------ \1
        (info->format != Info::FORMAT_DOS)*/)
        return (0);
    
    /* Suppression des fonctions, symboles, sections... */
    info->clear_segment();
    info->clear_function();
    info->clear_proto();
    info->clear_analyse();
    
    info->format = Info::FORMAT_DOS;
    info->archi = Info::ARCHI_I16;
    info->endian = Info::ENDIAN_LITTLE;

/* TODO: Gestion de la relocation (http://www.delorie.com/djgpp/doc/exe/) 
for (unsigned long i=0; i<header_dos.e_crlc; i++)
{
    if (get_data(&header_relloc, sizeof(_DOS_RELOC), info->data, info->size, header_dos.e_lfarlc) >= 0)
    {
        printf("Relloc %lu:  off: %u    seg: %u\n", i, header_relloc.offset , header_relloc.segment);
    }
}*/

    /** Creation d'un segment */
    if ((offset_data = header_dos.e_cparhdr * DOS_PARGRAPH_SIZE) < info->size)
    {
        size_data = info->size + (header_dos.e_minalloc * DOS_PARGRAPH_SIZE);
        if (header_dos.e_cp == 0)
        {
            if ((buffer = new unsigned char[size_data]) != NULL)
            {
                memset(buffer, 0, size_data);
                if (info->size > offset_data)
                    memcpy(buffer, &(info->data[offset_data]), info->size - offset_data);
            
                info->sec.add_section(OFFSET_CODE, size_data, buffer, SECTION_R | SECTION_W | SECTION_X);
            }
        }
        else
        {
            if ((buffer = new unsigned char[size_data]) != NULL)
            {
                memset(buffer, 0, size_data);
                if (info->size > offset_data)
                    memcpy(buffer, &(info->data[offset_data]), info->size - offset_data);
            
                info->sec.add_section(OFFSET_CODE, size_data, buffer, SECTION_R | SECTION_W);
            }
        
            /* Creation du segment executable */
            size_data = header_dos.e_cp * DOS_BLOC_SIZE;
            if (info->size < (offset_data + size_data))
                size_data = info->size - offset_data;
                
            if ((buffer = new unsigned char[size_data]) != NULL)
            {
                memcpy(buffer, &(info->data[offset_data]), size_data);            
                info->sec.add_section(OFFSET_CODE, size_data, buffer, SECTION_R | SECTION_W | SECTION_X);
            }
        }
    }
        
    /* Ajout d'un point d'entree */
    info->entry.insert(OFFSET_CODE + header_dos.e_ip);
    info->sym.add_symbole(OFFSET_CODE + header_dos.e_ip, "_start", Symbole::FUNC);
        
    /** Valeurs initiales a donner aux registres */
    printf("ip=%x, ss=%x sp=%x cs=%x\n", header_dos.e_ip, header_dos.e_ss, header_dos.e_sp, header_dos.e_cs); 
  
    return (1);
}

/**
** \fn const char *get_plugin_name()
** \brief Fonction permettant de d'acceder a la description du plugin
**
** \return Retourne un pointeur vers la description du plugin
*/
const char    *PLUGIN_FUNC_APROPOS()
{
    return ("");
}

