#include    <stdio.h>
#include    <stdlib.h>
#include    <string.h>

#include    "Info.hpp"


#define PLUGIN_NAME           PLUGIN_TYPE__PARSING ".3000.plugin_parse_init_interrupt_brainfuck.0"
#define PLUGIN_DESCRIPTION    "Plugin permettant d'initialiser la liste des interruptions Brainfuck\n"


extern "C"
{
    const char    *PLUGIN_FUNC_GET_PLUGIN_NAME();
    int           PLUGIN_FUNC_EXECUTE(Info *info);
    const char    *PLUGIN_FUNC_APROPOS();
}


/**
** \fn int init_interrupt_linux_i386(Info *info)
** \brief Gere l'initialisation des interruptions pour linux
**
** \param info Structure contenant les infos du programme a analyser
** \return Retourne toujours 1
*/
int    init_interrupt_brainfuck(Info *info)
{
    /* Initialisation des interruptions */
    info->interrupt.add_syscall('.', "putchar", "void", "char");
    info->interrupt.add_syscall(',', "getchar", "char");

    return (1);
}

/**
** \fn const char *get_plugin_name()
** \brief Fonction permettant de connaitre le nom du plugin
**
** \return Retourne un pointeur vers le nom du plugin
*/
const char    *PLUGIN_FUNC_GET_PLUGIN_NAME()
{
    return (PLUGIN_NAME);
}

/**
** \fn int execute(Info *info)
** \brief Fonction permettant d'initialiser la liste des interruptions pour architecture Intel sous linux
**
** \param info Classe contenant les infos du programme a analyser
** \return Retourne 1 si OK, 0 si le plugin n'a pas ete execute et -1 en cas d'erreur
*/
int    PLUGIN_FUNC_EXECUTE(Info *info)
{
    if (info == NULL)
        return (-1);

    if (info->archi == Info::ARCHI_BRAINFUCK)
    {
        init_interrupt_brainfuck(info);
        return (1);
    }
    return (0);
}

/**
** \fn const char *get_plugin_name()
** \brief Fonction permettant de d'acceder a la description du plugin
**
** \return Retourne un pointeur vers la description du plugin
*/
const char    *PLUGIN_FUNC_APROPOS()
{
    return (PLUGIN_DESCRIPTION);
}

