#include    "Info.hpp"
#include    "ASM_brainfuck.hpp"
#include    "Contexte.hpp"


#define    ASM_BRAINFUCK_EFFET__NBS_INSTR    8

const t_effect_instr    ASM_brainfuck_descr_effect[ASM_BRAINFUCK_EFFET__NBS_INSTR] =
{
    /* '>' */
    {
        '>',
        INSTR_OPER,
        {
            "index = index + 1", NULL
        },
        "inc\tindex",
    },
    
    /* '<' */
    {
        '<',
        INSTR_OPER,
        {
            "index = index - 1", NULL
        },
        "dec\tindex",
    },
    
    /* '+' */
    {
        '+',
        INSTR_OPER,
        {
            "[ptr+index*4] = [ptr+index*4] + 1", NULL
        },
        "inc\t[ptr+index*4]",
    },
    
    /* '-' */
    {
        '-',
        INSTR_OPER,
        {
            "[ptr+index*4] = [ptr+index*4] - 1", NULL
        },
        "dec\t[ptr+index*4]",
    },
    
    /* '.' */
    {
        '.',
        INSTR_INT,
        {
            NULL, NULL
        },
        "write",
    },
    
    /* ',' */
    {
        ',',
        INSTR_INT,
        {
            NULL, NULL
        },
        "read",
    },
    
    /* '[' */
    {
        '[',
        INSTR_JUMP | INSTR_CONDITION,
        {
            NAME_PC " = ([ptr+index*4] == 0) ? (next_jump) : ("NAME_PC"+1)",
            NULL
        },
        "je next_jump",
    },
    
    /* ']' */
    {
        ']',
        INSTR_JUMP,
        {
            NAME_PC " = (previous_jump)",
            NULL
        },
        "jmp previous_jump",
    },
};

        

/**
** \fn ASM_brainfuck()
** \brief Constructeur par defaut de la classe gerant l'assembleur Brainfuck
*/
ASM_brainfuck::ASM_brainfuck(): IASM()
{
}

/**
** \fn ~ASM_brainfuck()
** \brief Destructeur de la classe gerant l'assembleur Brainfuck
*/
ASM_brainfuck::~ASM_brainfuck()
{
}

/**
** \fn ASM_brainfuck(const ASM_brainfuck&)
** \brief Constructeur par copie de la classe gerant l'assembleur Brainfuck (inutile)
*/
ASM_brainfuck::ASM_brainfuck(const ASM_brainfuck&): IASM()
{
}

/**
** \fn ASM_brainfuck& ASM_brainfuck::operator = (const ASM_brainfuck&)
** \brief Surcharge de l'operateur = pour la classe gerant l'assembleur Brainfuck
**
** \return Retourne une reference sur l'assembleur
*/
ASM_brainfuck&    ASM_brainfuck::operator = (const ASM_brainfuck&)
{
    return (*this);
}



/**
** \fn const char **get_registre() const
** \brief Assesseurs permettant d'acceder a la liste des registres existants
**
** \return Retourne Retourne un tableau contenant les nom des registres
*/
const char   **ASM_brainfuck::get_registre() const
{
    static const char *registre[] =
    {
        "ptr", "index", NAME_PC,
        NULL
    };

    return (registre);
}

/**
** \fn void init_registre(std::map<std::string, ContentContexte> &reg,
**                        unsigned long addr=0, const Info *info=NULL) const = 0;
** \brief Permet d'initialiser les registres du contexte d'execution
**
** \param reg Map contenant les registre a initialiser
** \param addr Adresse de la fonction pour lequel les registre sont prevu
** \param info Contient les infos du prog. (pour trouver d'eventuelles valeurs de reg.)
** \return Retourne rien
*/
void    ASM_brainfuck::init_registre(std::map<std::string, ContentContexte> &reg,
                                   unsigned long addr, const Info *info) const
{
    /* Valeur par defaut du pointeur de data */
    reg["ptr"].set_value("");
    reg["ptr"].set_size(4);
    reg["ptr"].set_type("int*");
    
    reg["index"].set_value("0x0");
    reg["index"].set_size(4);
    reg["index"].set_type("int");
    
    /* On cherche une section avec acces en lectuere/ecriture pour le pointeur de data */
    for (unsigned long i=0; i<info->sec.get_nbs_section(); i++)
    {
    	if (((info->sec.get_flag_section(i) & SECTION_R) == SECTION_R) && 
    	    ((info->sec.get_flag_section(i) & SECTION_W) == SECTION_W))
            reg["ptr"].set_value( Calcul::lto0x(info->sec.get_addr_section(i)) );
    }

    /* Precise le PC de la fonction */
    reg[NAME_PC].set_value(Calcul::lto0x(addr));
    reg[NAME_PC].set_size(4);
    reg[NAME_PC].set_type("void*");
}


/**
** \fn std::set<std::string> get_value_registre(std::set<std::string> &dest, const std::string &name,
**                                    const std::map<std::string, ContentContexte> &reg)
** \brief Fonction permettant d'acceder a la valeur d'un registre
**
** \param dest Set ou mettre les valeurs
** \param name Nom du registre
** \param reg Map contenant les registres
** \return Retourne les valeurs du registre si on le trouve, un set vide sinon
*/
std::set<std::string>    &ASM_brainfuck::get_value_registre(std::set<std::string> &dest,
                                                            const std::string &name,
                                                            const std::map<std::string, ContentContexte*> &reg)
{
    this->_mutex.lock();
    
    dest.clear();
    if (reg.find(name) != reg.end())
        dest = reg.find(name)->second->get_values();
        
    this->_mutex.unlock();
    return (dest);
}

/**
** \fn std::string get_size_registre(const std::string &name,
**                                   const std::map<std::string, ContentContexte> &reg)
** \brief Fonction permettant d'acceder a la taille d'un registre
**
** \param name Nom du registre
** \param reg Map contenant les registres
** \return Retourne la taille du registre si on le trouve, 0 sinon
*/
unsigned long    ASM_brainfuck::get_size_registre(const std::string &name,
                                                const std::map<std::string, ContentContexte*> &reg)
{
    unsigned long    ret;
    
    this->_mutex.lock();
    
    ret = 0;
    if (reg.find(name) != reg.end())
        ret = reg.find(name)->second->get_size();
        
    this->_mutex.unlock();
    return (ret);
}

/**
** \fn std::string &get_type_registre(std::string &dest, const std::string &name,
**                                   const std::map<std::string, ContentContexte> &reg)
** \brief Fonction permettant d'acceder au type de contenu d'un registre
**
** \param dest String ou mettre les valeurs
** \param name Nom du registre
** \param reg Map contenant les registres
** \return Retourne le type de contenu du registre si on le trouve, "" sinon
*/
std::string      &ASM_brainfuck::get_type_registre(std::string &dest, const std::string &name,
                                                   const std::map<std::string, ContentContexte*> &reg)
{
    this->_mutex.lock();
    
    dest = "";
    if (reg.find(name) != reg.end())
        dest = reg.find(name)->second->get_type();
        
    this->_mutex.unlock();
    return (dest);
}

/**
** \fn void set_value_registre(const std::string &name,
**                             std::map<std::string, ContentContexte> &reg, 
**                             const std::set<std::string> &values,
**                             const std::string &type)
** \brief Fonction permettant d'acceder a la valeur d'un registre
**
** \param name Nom du registre
** \param reg Map contenant les registres
** \param values Nouvelles valeurs du registre
** \param type Nouveau type du registre
** \return Retourne la valeur du registre si on le trouve, "" sinon
*/
void             ASM_brainfuck::set_value_registre(const std::string &name,
                                                std::map<std::string, ContentContexte*> &reg, 
                                                const std::set<std::string> &values,
                                                const std::string &type)
{
    std::map<std::string, ContentContexte*>::iterator    it;

    this->_mutex.lock();
    
    if ((it = reg.find(name)) != reg.end())
    {
        it->second->set_values(values);
        it->second->set_type(type);
    }
    
    this->_mutex.unlock();
}


/**
** \fn InstrASM *deasm_instr(unsigned long addr, Info *info)
** \brief Gere le deassemblage de l'instruction ASM a l'adresse indiquee
**
** \param addr Adresse de l'instruction a deassembler
** \param info Structure contenant les infos du programme a analyser
** \return Retourne un pointeur sur l'instruction cree si OK, NULL sinon
*/
InstrASM      *ASM_brainfuck::deasm_instr(unsigned long addr, Info *info)
{
    InstrASM         *instr;
    std::string      str_tmp;
    unsigned char    octet;
    
    if (info->sec.is_in_section(addr) == 0)
        return (NULL);
    this->_mutex.lock();

    /* On recupere l'octet a deassembler */
    octet = info->sec.get_char(addr);
    
    /* Actualise le buffer, le PC et deassemble l'instruction */
    instr = NULL;
    /* Cree et initialise l'instruction ASM */
    if ((instr = new InstrASM) != NULL)
    {
        instr->_opcode = NAME_INVALIDE;

        instr->__name = NAME_INVALIDE;
        instr->_address = addr;
        instr->_size = 1;
        instr->_type = INSTR_INVALIDE;
        
        /* Recherche des infos personelles de l'instruction */
        for (unsigned long i=0; i<ASM_BRAINFUCK_EFFET__NBS_INSTR; i++)
        {
            if (ASM_brainfuck_descr_effect[i].mnemonic == octet)
            {
                instr->_opcode = ASM_brainfuck_descr_effect[i].opcode;
                instr->__name.clear();
                instr->__name += octet;
                instr->_type = ASM_brainfuck_descr_effect[i].type;
                
                for (unsigned long j=0; (j<2) && (ASM_brainfuck_descr_effect[i].effect[j]!=NULL); j++)
                    instr->_effect.push_back(ASM_brainfuck_descr_effect[i].effect[j]);
                
                i = ASM_BRAINFUCK_EFFET__NBS_INSTR; 
            }
        }
         
        /* Preparation des operandes de l'instruction * /
        for (unsigned long i=0; i<3; i++)
        {
            if (this->_ud_obj.operand[i].type != UD_NONE)
            {
                this->get_operande(str_tmp, i);
                instr->__operande.push_back(InstrASM::Operande(this->_ud_obj.operand[i].size, str_tmp));
            }
        }*/

        /* Actualisation des effets de bords et de l'opcode de l'instrcution en fonction des offsets */
        this->remplace_offset(instr->_opcode, instr->_effect, &(info->sec), addr);
    }

    this->_mutex.unlock();
    return (instr);
}

void    ASM_brainfuck::remplace_offset(std::string &str_instr, std::list<std::string> &str_effect, const Section *sec, unsigned long addr)
{
    std::list<std::string>::iterator    it;
    unsigned long                       pos;
    unsigned long                       profondeur;
    unsigned long                       offset;
    std::string                         str_offset;

    if (str_instr.find("next_jump") != std::string::npos)
    {
        /* Cherche la fin de la boucle */
        profondeur = 1;
        offset = 1;
        while (((sec->get_flag(addr+offset) & SECTION_X) == SECTION_X) &&
               (profondeur != 0))
        {
            if (sec->get_char(addr+offset) == '[')
                profondeur++;
            else if (sec->get_char(addr+offset) == ']')
                profondeur--;
            offset++;
        }
        
        /* Prepare l'offset */
        str_offset = Calcul::lto0x(addr+offset);
        
        /* Remplace la chaine de demande d'offset par sa valeur */
        while ((pos = str_instr.find("next_jump")) != std::string::npos)
            str_instr.replace(pos, 9, str_offset);
        for (it=str_effect.begin(); it!=str_effect.end(); it++)
            while ((pos = it->find("next_jump")) != std::string::npos)
                it->replace(pos, 9, str_offset);
    }
    
    if (str_instr.find("previous_jump") != std::string::npos)
    {
        /* Cherche la fin de la boucle */
        profondeur = 1;
        offset = 1;
        while (((sec->get_flag(addr+offset) & SECTION_X) == SECTION_X) &&
               (profondeur != 0))
        {
            if (sec->get_char(addr-offset) == '[')
                profondeur--;
            else if (sec->get_char(addr-offset) == ']')
                profondeur++;
            offset++;
        }
        if ((sec->get_flag(addr+(offset-1)) & SECTION_X) == SECTION_X)
            offset--;
        
        /* Prepare l'offset */
        str_offset = Calcul::lto0x(addr-offset);
        
        /* Remplace la chaine de demande d'offset par sa valeur */
        while ((pos = str_instr.find("previous_jump")) != std::string::npos)
            str_instr.replace(pos, 13, str_offset);
        for (it=str_effect.begin(); it!=str_effect.end(); it++)
            while ((pos = it->find("previous_jump")) != std::string::npos)
                it->replace(pos, 13, str_offset);
    }
}




/**
** \fn InstrASM *make_simple_instr(unsigned long addr, unsigned long size, const std::string &name,
**                                 const std::vector<std::string> *effect,
**                                 unsigned long type, const InstrASM::Operande *dst,
**                                 const InstrASM::Operande *op1, const InstrASM::Operande *op2,
**                                 const InstrASM::Operande *op3, const InstrASM::Operande *op4)
** \brief Gere la preparation d'une instruction simple
**
** \param addr Adresse de l'instruction
** \param size Taille de l'instruction
** \param name Nom de l'instruction
** \param effect Tableau contenant la description des effets de bord
** \param type Type d'instruction
** \param dst Pointeur sur l'operande destination s'il existe (NULL sinon)
** \param op1 Pointeur sur le premier operande s'il existe (NULL sinon)
** \param op2 Pointeur sur le deuxieme operande s'il existe (NULL sinon)
** \param op3 Pointeur sur le troisieme operande s'il existe (NULL sinon)
** \param op4 Pointeur sur le quatrieme operande s'il existe (NULL sinon)
** \return Retourne un pointeur sur l'instruction cree si OK, NULL sinon
*/
InstrASM    *ASM_brainfuck::make_simple_instr(unsigned long addr, unsigned long size,
                                 const std::string &name, const std::vector<std::string> *effect,
                                 unsigned long type, const InstrASM::Operande *dst,
                                 const InstrASM::Operande *op1, const InstrASM::Operande *op2,
                                 const InstrASM::Operande *op3, const InstrASM::Operande *op4)
{
    InstrASM         *instr;

    if ((instr = new InstrASM) != NULL)
    {
        instr->__name = name;
        instr->__address = addr;
        instr->__size = size;
        instr->_type = type;

        if (effect != NULL)
            instr->__effect = (*effect);

        if (dst != NULL)
            instr->__dst = (*dst);
        if (op1 != NULL)
            instr->__operande.push_back(*op1);
        if (op2 != NULL)
            instr->__operande.push_back(*op2);
        if (op3 != NULL)
            instr->__operande.push_back(*op3);
        if (op4 != NULL)
            instr->__operande.push_back(*op4);
    }

    return (instr);
}

/**
** \fn void remplace_op1_op2(std::vector<std::string> &effect, const InstrASM::Operande *dst=NULL,
**                           const InstrASM::Operande *op1=NULL, const InstrASM::Operande *op2=NULL,
**                           const InstrASM::Operande *op3=NULL, const InstrASM::Operande *op4=NULL);
** \brief Gere le rempacement des mots-clefs "op1", "op2"... par leur valeur
**
** \param effect Liste des effets de bord a traiter
** \param dst Valeur de la destination
** \param op1 Valeur du premier operande
** \param op2 Valeur du premier operande
** \param op3 Valeur du premier operande
** \param op4 Valeur du premier operande
** \return Retourne rien
*/
void         ASM_brainfuck::remplace_op1_op2(std::vector<std::string> &effect, const InstrASM::Operande *dst,
                              const InstrASM::Operande *op1, const InstrASM::Operande *op2,
                              const InstrASM::Operande *op3, const InstrASM::Operande *op4)
{
    unsigned long    pos;

    for (unsigned long i=0; i<effect.size(); i++)
    {
        if (dst != NULL)
            while ((pos = effect[i].find("dst")) != std::string::npos)
                effect[i].replace(pos, 3, dst->_name);

        if (op1 != NULL)
            while ((pos = effect[i].find("op1")) != std::string::npos)
                effect[i].replace(pos, 3, op1->_name);
        if (op2 != NULL)
            while ((pos = effect[i].find("op2")) != std::string::npos)
                effect[i].replace(pos, 3, op2->_name);
        if (op3 != NULL)
            while ((pos = effect[i].find("op3")) != std::string::npos)
                effect[i].replace(pos, 3, op3->_name);
        if (op4 != NULL)
            while ((pos = effect[i].find("op4")) != std::string::npos)
                effect[i].replace(pos, 3, op4->_name);
    }
}

