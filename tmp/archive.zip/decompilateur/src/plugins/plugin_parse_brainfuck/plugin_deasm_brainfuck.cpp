/**
** Plugin gerant le chargement du deassembleur a utiliser pour l'architecture Brainfuck
** Le champ "archi" de la structure "Info" doit valoir Info::ARCHI_COREWAR
** Le champ "endian" de la structure "Info" doit valoir Info::ENDIAN_BIG
** Retourne 1 si OK, -1 sinon
*/
#include    "Info.hpp"
#include    "ASM_brainfuck.hpp"


#define    PLUGIN_NAME    PLUGIN_TYPE__DEASM ".5000.deasm_brainfuck.0"

extern "C"
{
    const char    *PLUGIN_FUNC_GET_PLUGIN_NAME();
    int           PLUGIN_FUNC_EXECUTE(Info *info);
    const char    *PLUGIN_FUNC_APROPOS();
}


/**
** \fn const char *func_emplacement_param(unsigned long num)
** \brief Fonction permettant de connaitre l'emplacement des parametres d'interruptions
**
** \param num Numero du parametre a localiser
** \return Retourne l'emplacement du parametre si OK, NAME_PC sinon
*/
const char    *func_emplacement_param(unsigned long)
{
    return ("[ptr+index*4]");
}

/**
** \fn const char *func_emplacement_return()
** \brief Fonction permettant de connaitre l'emplacement de la valeur de retour des interruptions
**
** \return Retourne l'emplacement de la valeur de retour
*/
const char    *func_emplacement_return()
{
    return ("[ptr+index*4]");
}

/**
** \fn const char *func_emplacement_numero()
** \brief Fonction permettant de connaitre le numero d'une interruption
**
** \return Retourne l'emplacement du numero d'interruption
*/
const char    *func_emplacement_numero()
{
    return ("[" NAME_PC "]");
}




/**
** \fn const char *get_plugin_name()
** \brief Fonction permettant de connaitre le nom du plugin
**
** \return Retourne un pointeur vers le nom du plugin
*/
const char    *PLUGIN_FUNC_GET_PLUGIN_NAME()
{
    return (PLUGIN_NAME);
}

/**
** \fn int execute(Info *info)
** \brief Fonction permettant d'executer le plugin pour recuperer le contenu du fichier
**
** \param info Classe contenant les infos du programme a analyser
** \return Retourne 1 si OK, -1 sinon
*/
int        PLUGIN_FUNC_EXECUTE(Info *info)
{
    if (info == NULL)
        return (0);

    /* Si l'executable a analyser est un binaire i64, on prepare son deassembleur */
    if (info->archi == Info::ARCHI_BRAINFUCK)
    {
        info->endian = Info::ENDIAN_LITTLE;
        
        /* Initialisation des pointeurs des fonctions permettant d'acceder aux emplacements des parametres */
        info->ptr_func.f_param_func = &func_emplacement_param;
        info->ptr_func.f_ret_func = &func_emplacement_return;
        
        info->ptr_func.f_num_int = &func_emplacement_numero;
        info->ptr_func.f_param_int = &func_emplacement_param;
        info->ptr_func.f_ret_int = &func_emplacement_return;
        
        info->ptr_func.f_num_syscall = &func_emplacement_numero;
        info->ptr_func.f_param_syscall = &func_emplacement_param;
        info->ptr_func.f_ret_syscall = &func_emplacement_return;

        if (info->ptr_func.deasm != NULL)
            delete info->ptr_func.deasm;
        info->ptr_func.deasm = NULL;

        if ((info->ptr_func.deasm = new ASM_brainfuck) == NULL)
            return (-1);
        return (1);
    }
    return (0);
}

/**
** \fn const char *get_plugin_name()
** \brief Fonction permettant de d'acceder a la description du plugin
**
** \return Retourne un pointeur vers la description du plugin
*/
const char    *PLUGIN_FUNC_APROPOS()
{
    return ("Plugin permettant de deassembler les instructions Brainfuck\n");
}

