#include	"ParsingPreprocesseur.hpp"


/**
** \fn int open(const std::string &filename, std::vector<std::string> &lines)
** \brief Gere l'ouverture d'un fichier source et la mise en forme de ses lignes
**
** \param filename Nom du fichier a parser
** \param lines Tableau ou mettre les ligne du fichier
** \return Retourne 1 si OK, 0 sinon
*/
int	ParsingPreprocesseur::open(const std::string &filename, std::vector<std::string> &lines)
{
    std::ifstream    file(filename.c_str(), std::ios::in);
    std::string      str;

    lines.clear();
 
    if (file)
    {
        while (getline(file, str))
            lines.push_back(str);
 
        file.close();
        return (1);
    }
 
    return 0;
}

/**
** \fn int open_and_parse(const std::string &filename, std::vector<std::string> &lines,
**                        std::map<std::string, std::string> &def, int rec=0)
** \brief Gere l'ouverture d'un fichier source et son parsing preprocesseur
**
** \param filename Nom du fichier a parser
** \param lines Tableau ou mettre les ligne du fichier
** \param def Tableau contenant les valeur des defines indexes par leur nom
** \param rec Profondeur de l'analyse a faire dans les "include", "import"...
** \return Retourne 1 si OK, 0 sinon
*/
int	ParsingPreprocesseur::open_and_parse(const std::string &filename, std::vector<std::string> &lines,
	                       std::map<std::string, std::string> &def, int rec)
{
	if (ParsingPreprocesseur::open(filename, lines) <= 0)
		return (0);
	return (ParsingPreprocesseur::parse(filename, lines, def, rec));
}

/**
** \fn int parse(const std::string &filename, std::vector<std::string> &lines,
**              std::map<std::string, std::string> &def, int rec=0)
** \brief Gere le parsing preprocesseur des lignes d'un fichier
**
** \param filename Nom du fichier (pour gerer les includes)
** \param lines Tableau ou mettre les ligne du fichier
** \param def Tableau contenant les valeur des defines indexes par leur nom
** \param rec Profondeur de l'analyse a faire dans les "include", "import"...
** \return Retourne 1 si OK, 0 sinon
*/
int	ParsingPreprocesseur::parse(const std::string &filename, std::vector<std::string> &lines,
	              std::map<std::string, std::string> &def, int rec)
{
	unsigned long    i;

	/* Epuration des lignes */
	if (ParsingPreprocesseur::remove_comment(lines) <= 0)
		return (0);
	if (ParsingPreprocesseur::epure_line(lines) <= 0)
		return (0);

	i = 0;
	ParsingPreprocesseur::parse_rec(filename, lines, def, i, rec);
	
	/* Si o a pas traiter le contenu jusqu'a la fin, on enleve le reste */
	if (i < lines.size())
		lines.erase(lines.begin() + i, lines.end());
	return (1);
}

/**
** \fn int parse_rec(const std::string &filename, std::vector<std::string> &lines,
**              std::map<std::string, std::string> &def, unsigned long &num_line, int rec=0)
** \brief Gere le parsing preprocesseur des lignes d'un fichier jusqu'a renconter un "#endif"
**
** \param filename Nom du fichier (pour gerer les includes)
** \param lines Tableau ou mettre les ligne du fichier
** \param def Tableau contenant les valeur des defines indexes par leur nom
** \param num_line Numero de la line actuelle
** \param rec Profondeur de l'analyse a faire dans les "include", "import"...
** \return Retourne 1 si OK, 0 sinon
*/
int	ParsingPreprocesseur::parse_rec(const std::string &filename, std::vector<std::string> &lines,
	              std::map<std::string, std::string> &def, unsigned long &num_line, int rec)
{
	unsigned long    pos;

	while (num_line < lines.size())
	{
		/* Remplacement des defines par leur valeur */
		ParsingPreprocesseur::gestion_replace_define(lines[num_line], def);
printf("o .%s.\n", lines[num_line].c_str());		
		if (lines[num_line].size() <= 0)
			lines.erase(lines.begin() + num_line);

		/* Passe les espaces du debut */
		else if ((pos = lines[num_line].find_first_not_of(" \t\f\v\n\r")) != std::string::npos)
		{
			/* Si c'est une directive de preprocesseur */
			if (lines[num_line][pos] == '#')
			{
				if ((pos = lines[num_line].find_first_not_of(" \t\f\v\n\r", pos + 1)) != std::string::npos)
				{
					/* Gestion de la directive "define" */
					if (lines[num_line].find("define", pos) == pos)
						ParsingPreprocesseur::gestion_directive_define(lines, def, num_line);
						
					/* Gestion de la directive "undef" */
					else if (lines[num_line].find("undef", pos) == pos)
						ParsingPreprocesseur::gestion_directive_undef(lines, def, num_line);
					
					/* Gestion de la directive "include" */
					else if ((lines[num_line].find("include", pos) == pos) && (rec > 0))
						ParsingPreprocesseur::gestion_directive_include(filename, "include", lines, def, num_line, rec);
					   
					/* Gestion de la directive "include_next" */
					else if ((lines[num_line].find("include_next", pos) == pos) && (rec > 0))
						ParsingPreprocesseur::gestion_directive_include(filename, "include_next", lines, def, num_line, rec);
					
					/* Gestion de la directive "import" */
					else if ((lines[num_line].find("import", pos) == pos) && (rec > 0))
						ParsingPreprocesseur::gestion_directive_include(filename, "import", lines, def, num_line, rec);

					/* Gestion de la directive "ifndef" */
					else if (lines[num_line].find("ifndef", pos) == pos)
						ParsingPreprocesseur::gestion_directive_ifndef(filename, lines, def, num_line, rec);

					/* Gestion de la directive "ifdef" */
					else if (lines[num_line].find("ifdef", pos) == pos)
						ParsingPreprocesseur::gestion_directive_ifdef(filename, lines, def, num_line, rec);

					/* Gestion de la directive "if" */
					else if (lines[num_line].find("if", pos) == pos)
						ParsingPreprocesseur::gestion_directive_if(filename, "if", lines, def, num_line, rec);

					/* Gestion de la directive "elif" */
					else if (lines[num_line].find("elif", pos) == pos)
						ParsingPreprocesseur::gestion_directive_if(filename, "elif", lines, def, num_line, rec);

					/* Gestion de la directive "#else" */
					else if (lines[num_line].find("else", pos) == pos)
						return (1);

					/* Gestion de la directive "#elif" */
					else if (lines[num_line].find("elif", pos) == pos)
						return (1);

					/* Gestion de la directive "endif" */
					else if ((lines[num_line].find("endif", pos) == pos) &&
					         (isalnum(lines[num_line][pos + strlen("endif")]) == 0) &&
					         (lines[num_line][pos + strlen("endif")] != '_'))
					{
						printf("mmmmmmmmmmmmmmmmmok\n");
						return (1);
					}
					else { printf(",,%s--\n", lines[num_line].c_str());
						/**num_line++;/*/lines.erase(lines.begin() + num_line);/**/ }
				}
				else
					lines.erase(lines.begin() + num_line);
			}
			else
				num_line++;
		}
		else
			lines.erase(lines.begin() + num_line);
	}

	return (1);
}

/**
** \fn int skip_rec(const std::string &filename, std::vector<std::string> &lines,
**              std::map<std::string, std::string> &def, unsigned long &num_line, int rec=0)
** \brief Gere l'effacement des lignes d'un fichier jusqu'a renconter un "#endif"
**
** \param lines Tableau ou mettre les ligne du fichier
** \param num_line Numero de la line actuelle
** \return Retourne 1 si OK, 0 sinon
*/
int	ParsingPreprocesseur::skip_rec(std::vector<std::string> &lines, unsigned long &num_line)
{
	unsigned long    pos;
	unsigned long    profondeur;

	profondeur = 1;
	while (num_line < lines.size())
	{
		/* Passe les espaces du debut */
		if ((pos = lines[num_line].find_first_not_of(" \t\f\v\n\r")) != std::string::npos)
		{
			/* Si c'est une directive de preprocesseur */
			if (lines[num_line][pos] == '#')
			{
				if ((pos = lines[num_line].find_first_not_of(" \t\f\v\n\r", pos + 1)) != std::string::npos)
				{

					if ((lines[num_line].find("ifdef", pos) == pos) ||
					    (lines[num_line].find("ifndef", pos) == pos) ||
					    (lines[num_line].find("if", pos) == pos))
						profondeur++;

					/* Gestion de la directive "#else" */
					else if ((profondeur <= 1) &&
					         ((lines[num_line].find("else", pos) == pos) ||
					          (lines[num_line].find("elif", pos) == pos)))
						return (1);

					/* Gestion de la directive "endif" */
					if ((lines[num_line].find("endif", pos) == pos) &&
					         (isalnum(lines[num_line][pos + strlen("endif")]) == 0) &&
					         (lines[num_line][pos + strlen("endif")] != '_'))
					{
						profondeur--;
						
						if (profondeur <= 0)
							return (1);
					}
				}
			}
		}
		lines.erase(lines.begin() + num_line);
	}

	return (1);
}

/**
** \fn int remove_comment(std::vector<std::string> &lines)
** \brief Gere la suppression des commentaires des lignes du fichier a analyser
**
** \param lines Lignes du fichier a analyser
** \return Retourne 1 si OK, 0 sinon
*/
int	ParsingPreprocesseur::remove_comment(std::vector<std::string> &lines)
{
	int	         is_comment;
	int	         is_text;
	int	         is_backslash;
	unsigned long    begin_comment;
	unsigned long    end_comment;

	is_comment = 0;
	is_text = 0;
	is_backslash = 0;
	begin_comment = 0;
	end_comment = 0;
	for (unsigned long i=0; i<lines.size(); i++)
	{
		for (unsigned long j=0; j<lines[i].size(); j++)
		{
			/* Gestion des backslashs */
			if ((lines[i][j] == '\\') && (is_comment == 0))
	        		is_backslash++;
	        	else
	        	{
	        		/* Gestion du texte */
	        		if ((lines[i][j] == '\"') && ((is_backslash % 2) == 0) && (is_comment == 0))
	        			is_text = (is_text + 1) % 2;

				/* Gestion des commentaires "//" */
	        		else if ((is_backslash == 0) && (is_text == 0) && (is_comment == 0) &&
	        		         (lines[i][j] == '/') && (lines[i][j+1] == '/'))
	        		         lines[i].erase(j);

	        		/* Gestion du debut des commentaires "/ *" */
	        		else if ((is_backslash == 0) && (is_text == 0) &&
	        		         (lines[i][j] == '/') && (lines[i][j+1] == '*'))
	        		{
	        		         is_comment = 1;
	        		         begin_comment = j;
	        		}
	        		
	        		/* Gestion de la fin des commentaires "* /" */
	        		else if ((is_backslash == 0) && (is_text == 0) &&
	        		         (lines[i][j] == '*') && (lines[i][j+1] == '/'))
	        		{
	        		         is_comment = 0;
	        		         end_comment = j + 2;
	        		         lines[i].erase(begin_comment, end_comment - begin_comment);
	        		}
	        		
	        		is_backslash = 0;
	        	}
	        }

		/* Si la ligne est en commentaire, on l'enleve */
		if (is_comment == 1)
		{
			lines[i].erase(begin_comment);
		}
		begin_comment = 0;
		end_comment = 0;
	        is_backslash = 0;
	}
	
	/* Suppression des lignes vides */
	for (unsigned long i=0; i<lines.size(); i++)
	{
		if (lines[i].size() <= 0)
			lines.erase(lines.begin() + i);
	}

	return (1);
}

/**
** \fn int gestion_directive_define(std::vector<std::string> &lines,
**                                  std::map<std::string, std::string> &def,
**                                  unsigned long &current_line)
** \brief Gere la directive "define"
**
** \param lines Tableau ou mettre les ligne du fichier
** \param def Tableau contenant les valeur des defines indexes par leur nom
** \param current_line Numero de la ligne actuelle
** \return Retourne 1 si OK, 0 sinon
*/
int	ParsingPreprocesseur::gestion_directive_define(std::vector<std::string> &lines,
                                 std::map<std::string, std::string> &def,
                                 unsigned long &current_line)
{
	std::string      line;
	unsigned long    pos;
	unsigned long    begin_define;
	unsigned long    end_define;
	unsigned long    begin_value;

	if (current_line >= lines.size())
		{printf("merde1 .%s.\n", ""); /*exit(0);*/ return (0);}
	line = lines[current_line];
	lines.erase(lines.begin() + current_line);

	/* Passe le "#define" */
	if ((pos = ParsingPreprocesseur::skip_name(line, "define")) == 0)
		{printf("merde2 .%s.\n", line.c_str()); /*exit(0);*/ return (0);}

	/* Recupere la position du define */
	begin_define = pos;
	if ((end_define = line.find_first_not_of("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_", begin_define)) == begin_define)
		{printf("merde3 .%s.\n", line.c_str());  return (0);}

	if (end_define == std::string::npos)
		end_define = line.size();

	/* Recupere la valeur et ajoute le define dans le tableau */
	begin_value = line.find_first_not_of(" \t\f\v\n\r", end_define);
	if ((begin_value != end_define) && (begin_value != std::string::npos))
		def[line.substr(begin_define, end_define-begin_define)] = line.substr(begin_value);
	else
		def[line.substr(begin_define, end_define-begin_define)] = "";

	return (1);
}

/**
** \fn int gestion_directive_undef(std::vector<std::string> &lines,
**                                  std::map<std::string, std::string> &def,
**                                  unsigned long &current_line)
** \brief Gere la directive "undef"
**
** \param lines Tableau ou mettre les ligne du fichier
** \param def Tableau contenant les valeur des defines indexes par leur nom
** \param current_line Numero de la ligne actuelle
** \return Retourne 1 si OK, 0 sinon
*/
int	ParsingPreprocesseur::gestion_directive_undef(std::vector<std::string> &lines,
	                                 std::map<std::string, std::string> &def,
	                                 unsigned long &current_line)
{
	std::string      line;
	unsigned long    pos;
	unsigned long    begin_define;
	unsigned long    end_define;

	if (current_line >= lines.size())
		return (0);
	line = lines[current_line];
	lines.erase(lines.begin() + current_line);

	/* Passe le "#undef" */
	if ((pos = ParsingPreprocesseur::skip_name(line, "undef")) == 0)
		return (0);

	/* Recupere la position du define */
	begin_define = pos;
	if ((end_define = line.find_first_not_of("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_", begin_define)) == begin_define)
		return (0);

	if (end_define == std::string::npos)
		end_define = line.size();

	line = line.substr(begin_define, end_define-begin_define);
	if (def.find(line) != def.end())
		def.erase(def.find(line));
		
	return (1);
}

/**
** \fn int gestion_directive_include(const std::string &filename,
**                               const std::string &directive,
**                               std::vector<std::string> &lines,
**                               std::map<std::string, std::string> &def,
**                               unsigned long &current_line,
**                               int rec)
** \brief Gere les directives "include", "import", "include_next"...
**
** \param filename Nom du fichier actuel (pour gerer l'include)
** \param directive Directive de preprocesseur ("include", "import", ...)
** \param lines Tableau ou mettre les ligne du fichier
** \param def Tableau contenant les valeur des defines indexes par leur nom
** \param current_line Numero de la ligne actuelle
** \param rec Supperieura a 0 s'il faut traiter le header recursivement
** \return Retourne 1 si OK, 0 sinon
*/
int	ParsingPreprocesseur::gestion_directive_include(const std::string &filename,
                                         const std::string &directive,
	                                 std::vector<std::string> &lines,
	                                 std::map<std::string, std::string> &def,
	                                 unsigned long &current_line,
	                                 int rec)
{
	std::vector<std::string>    lines_tmp;
	std::string                 line;
	std::string                 path;
	std::string                 file;
	unsigned long               pos;
	unsigned long               pos_end;
	unsigned long               new_current_line;
	int                         is_header_standard;
	
	if (current_line >= lines.size())
		return (0);
	line = lines[current_line];
	lines.erase(lines.begin() + current_line);

	/* Passe le "#include" */
	if ((pos = ParsingPreprocesseur::skip_name(line, directive)) == 0)
		return (0);
		
	/* Recuperation du nom de fichier */
	is_header_standard = 0;
	if (line[pos] == '<')
	{
		is_header_standard = 1;
		pos++;
		pos_end = pos;
		while ((line[pos_end] != '>') && (line[pos_end] != '\0'))
			pos_end++;
		file = line.substr(pos, pos_end - pos);
	}
	else
	{
		pos++;
		pos_end = pos;
		pos_end = pos;
		while ((line[pos_end] != '\"') && (line[pos_end] != '\0'))
			pos_end++;
		file = line.substr(pos, pos_end - pos);
	}
	
	/* Recuperation du nom de dossier */
	if (is_header_standard == 1)
	{
		path = PARSING_PREPROCESSEUR_HEADER_DIRECTORY;
	}
	else
	{
		char    buffer_tmp[filename.size() + 1];
		char    *ptr_tmp;
		strcpy(buffer_tmp, filename.c_str());
		if ((ptr_tmp = dirname(buffer_tmp)) != NULL)
			path = std::string(ptr_tmp) + "/";
		else
			path = "./";
	}
	
	/* Parsing du fichier a inclure */
	ParsingPreprocesseur::open_and_parse(path + file, lines_tmp, def, rec-1);

	new_current_line = current_line + lines_tmp.size();
	while (lines_tmp.size() > 0)
	{
	printf("::%s.\n", lines_tmp.back().c_str());
		lines.insert(lines.begin() + current_line, lines_tmp.back());
		lines_tmp.pop_back();
	}
	current_line = new_current_line;
	return (1);
}

/**
** \fn int gestion_directive_ifndef(const std::string &filename,
**                               std::vector<std::string> &lines,
**                               std::map<std::string, std::string> &def,
**                               unsigned long &current_line,
**                               int rec)
** \brief Gere la directive "ifndef"
**
** \param filename Nom du fichier actuel (pour gerer l'include)
** \param lines Tableau ou mettre les ligne du fichier
** \param def Tableau contenant les valeur des defines indexes par leur nom
** \param current_line Numero de la ligne actuelle
** \param rec Superieure a 0 s'il faut traiter le header recursivement
** \return Retourne 1 si OK, 0 sinon
*/
int	ParsingPreprocesseur::gestion_directive_ifndef(const std::string &filename,
	                                 std::vector<std::string> &lines,
	                                 std::map<std::string, std::string> &def,
	                                 unsigned long &current_line,
	                                 int rec)
{
	std::string      line;
	unsigned long    pos;
	unsigned long    begin_define;
	unsigned long    end_define;

	if (current_line >= lines.size())
		return (0);
	line = lines[current_line];
	lines.erase(lines.begin() + current_line);

	/* Passe le "#undef" */
	if ((pos = ParsingPreprocesseur::skip_name(line, "ifndef")) == 0)
		return (0);

	/* Recupere la position du define */
	begin_define = pos;
	if ((end_define = line.find_first_not_of("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_", begin_define)) == begin_define)
		return (0);

	if (end_define == std::string::npos)
		end_define = line.size();

	line = line.substr(begin_define, end_define-begin_define);
	if (def.find(line) == def.end())
	{
		printf("pass\n");
		ParsingPreprocesseur::parse_rec(filename, lines, def, current_line, rec);
		
		while ((current_line < lines.size()) &&
		       ((ParsingPreprocesseur::skip_name(lines[current_line], "else") > 0) ||
		        (ParsingPreprocesseur::skip_name(lines[current_line], "elif") > 0)))
		{
		printf("BINNNNGO\n");
			lines.erase(lines.begin() + current_line);
			ParsingPreprocesseur::skip_rec(lines, current_line);
		}
	}
	else
	{
		printf("ignore\n");
		ParsingPreprocesseur::skip_rec(lines, current_line);

		if ((current_line < lines.size()) &&
		    (ParsingPreprocesseur::skip_name(lines[current_line], "else") > 0))
		{
		printf("BINNNNGO\n");
			lines.erase(lines.begin() + current_line);
			ParsingPreprocesseur::parse_rec(filename, lines, def, current_line, rec);
		}
	}
		
	if ((current_line < lines.size()) &&
	    (ParsingPreprocesseur::skip_name(lines[current_line], "endif") > 0))
		lines.erase(lines.begin() + current_line);
	return (1);
}

/**
** \fn int gestion_directive_ifdef(const std::string &filename,
**                               std::vector<std::string> &lines,
**                               std::map<std::string, std::string> &def,
**                               unsigned long &current_line,
**                               int rec)
** \brief Gere la directive "ifdef"
**
** \param filename Nom du fichier actuel (pour gerer l'include)
** \param lines Tableau ou mettre les ligne du fichier
** \param def Tableau contenant les valeur des defines indexes par leur nom
** \param current_line Numero de la ligne actuelle
** \param rec Superieure a 0 s'il faut traiter le header recursivement
** \return Retourne 1 si OK, 0 sinon
*/
int	ParsingPreprocesseur::gestion_directive_ifdef(const std::string &filename,
	                                 std::vector<std::string> &lines,
	                                 std::map<std::string, std::string> &def,
	                                 unsigned long &current_line,
	                                 int rec)
{
	std::string      line;
	unsigned long    pos;
	unsigned long    begin_define;
	unsigned long    end_define;

	if (current_line >= lines.size())
		return (0);
	line = lines[current_line];
	lines.erase(lines.begin() + current_line);

	/* Passe le "#ifdef" */
	if ((pos = ParsingPreprocesseur::skip_name(line, "ifdef")) == 0)
		return (0);

	/* Recupere la position du define */
	begin_define = pos;
	if ((end_define = line.find_first_not_of("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_", begin_define)) == begin_define)
		return (0);

	if (end_define == std::string::npos)
		end_define = line.size();

	line = line.substr(begin_define, end_define-begin_define);
	if (def.find(line) != def.end())
	{
		printf("pass\n");
		ParsingPreprocesseur::parse_rec(filename, lines, def, current_line, rec);
		
		while ((current_line < lines.size()) &&
		       ((ParsingPreprocesseur::skip_name(lines[current_line], "else") > 0) ||
		        (ParsingPreprocesseur::skip_name(lines[current_line], "elif") > 0)))
		{
		printf("BINNNNGO\n");
			lines.erase(lines.begin() + current_line);
			ParsingPreprocesseur::skip_rec(lines, current_line);
		}
	}
	else
	{
		printf("ignore\n");
		ParsingPreprocesseur::skip_rec(lines, current_line);

		if ((current_line < lines.size()) &&
		    (ParsingPreprocesseur::skip_name(lines[current_line], "else") > 0))
		{
		printf("BINNNNGO\n");
			lines.erase(lines.begin() + current_line);
			ParsingPreprocesseur::parse_rec(filename, lines, def, current_line, rec);
		}
	}
		
	if ((current_line < lines.size()) &&
	    (ParsingPreprocesseur::skip_name(lines[current_line], "endif") > 0))
		lines.erase(lines.begin() + current_line);
	return (1);
}	                                 

/**
** \fn int gestion_directive_if(const std::string &filename,
**                               const std::string &directive,
**                               std::vector<std::string> &lines,
**                               std::map<std::string, std::string> &def,
**                               unsigned long &current_line,
**                               int rec)
** \brief Gere la directive "if" et "elif"
**
** \param filename Nom du fichier actuel (pour gerer l'include)
** \param directive Directive de preprocesseur ("if", "elif")
** \param lines Tableau ou mettre les ligne du fichier
** \param def Tableau contenant les valeur des defines indexes par leur nom
** \param current_line Numero de la ligne actuelle
** \param rec Superieure a 0 s'il faut traiter le header recursivement
** \return Retourne 1 si OK, 0 sinon
*/
int	ParsingPreprocesseur::gestion_directive_if(const std::string &filename,
	                                 const std::string &directive,
	                                 std::vector<std::string> &lines,
	                                 std::map<std::string, std::string> &def,
	                                 unsigned long &current_line,
	                                 int rec)
{
	std::string      line;
	unsigned long    pos;
	unsigned long    begin_define;
	unsigned long    end_define;

	if (current_line >= lines.size())
		return (0);
	line = lines[current_line];
	lines.erase(lines.begin() + current_line);

	/* Passe le "if" */
	if ((pos = ParsingPreprocesseur::skip_name(line, directive)) == 0)
		return (0);

	/* Recupere la position du define */
	begin_define = pos;
	if ((end_define = line.find_first_not_of("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_", begin_define)) == begin_define)
		return (0);

	if (end_define == std::string::npos)
		end_define = line.size();

	line = line.substr(begin_define, end_define-begin_define);
printf(".%s.\n", line.c_str()); 
        Info    info;
	if (Calcul::calcul_str(line, &info, NULL) != "0x0")
	{
		printf("pass\n");
		ParsingPreprocesseur::parse_rec(filename, lines, def, current_line, rec);
		
		while ((current_line < lines.size()) &&
		       ((ParsingPreprocesseur::skip_name(lines[current_line], "else") > 0) ||
		        (ParsingPreprocesseur::skip_name(lines[current_line], "elif") > 0)))
		{
		printf("BINNNNGO\n");
			lines.erase(lines.begin() + current_line);
			ParsingPreprocesseur::skip_rec(lines, current_line);
		}
	}
	else
	{
		printf("ignore\n");
		ParsingPreprocesseur::skip_rec(lines, current_line);

		if ((current_line < lines.size()) &&
		    (ParsingPreprocesseur::skip_name(lines[current_line], "else") > 0))
		{
		printf("BINNNNGO\n");
			lines.erase(lines.begin() + current_line);
			ParsingPreprocesseur::parse_rec(filename, lines, def, current_line, rec);
		}
	}
		
	if ((current_line < lines.size()) &&
	    (ParsingPreprocesseur::skip_name(lines[current_line], "endif") > 0))
		lines.erase(lines.begin() + current_line);
	return (1);
}

/**
** \fn int epure_line(std::vector<std::string> &lines)
** \brief Gere la suppression des espaces en fin de ligne et la concatenation des lignes finissant par un "\"
**
** \param lines Lignes du fichier a analyser
** \return Retourne 1 si OK, 0 sinon
*/
int	ParsingPreprocesseur::epure_line(std::vector<std::string> &lines)
{
	unsigned long    pos;

	for (unsigned long i=0; i<lines.size(); )
	{
		/* Suppression des espaces en fin de ligne */
		if ((pos = lines[i].find_last_not_of(" \t\f\v\n\r")) != std::string::npos)
			lines[i].erase(pos + 1);
		else
			lines[i].clear();
		
		/* Concatenation de lignes si la premiere fini par un "\" */
		if (lines[i].size() > 0)
		{
			if (lines[i][lines[i].size()-1] == '\\')
			{
				lines[i].erase(lines[i].size() - 1);
				if (i < lines.size())
				{
					lines[i] += lines[i + 1];
					lines[i + 1].clear();
				}
				else
					i++;
			}
			else
				i++;
		}
		else
			i++;
	}

	
	/* Suppression des lignes vides */
	for (unsigned long i=0; i<lines.size(); i++)
	{
		if (lines[i].size() <= 0)
			lines.erase(lines.begin() + i);
	}

	return (1);	
}

/**
** \fn unsigned long skip_name(const std::string &line, const std::string &name)
** \brief Permet de passer une directive de prerocesseur pour acceder a ses attributs
**
** \param line Line contenant la directive de preprocesseur
** \param name Nom de la directive
** \return Retourne la taille de la directive si OK, 0 sinon
*/
unsigned long	ParsingPreprocesseur::skip_name(const std::string &line, const std::string &name)
{
	unsigned long    pos;
	unsigned long    tmp;

	/* Passe le "#define" */
	if ((pos = line.find_first_not_of(" \t\f\v\n\r")) == std::string::npos)
		return (0);
	if (line[pos] != '#')
		return (0);
	if ((pos = line.find_first_not_of(" \t\f\v\n\r", pos + 1)) == std::string::npos)
		return (0);

	if (line.find(name, pos) != pos)
		return (0);
	tmp = pos + name.size();
	
	/* Si la ligne est fini: OK */
	if (tmp == line.size())
		return (line.size());
		

	if ((pos = line.find_first_of(" \t\f\v\n\r", tmp)) != tmp)
		return (0);
	if ((pos = line.find_first_not_of(" \t\f\v\n\r", pos)) == std::string::npos)
		pos = line.size();
	
	return (pos);
}

/**
** \fn int gestion_replace_define(std::string &line, const std::map<std::string, std::string> &def)
** \brief Gere le remplacement des defines par leur valeur
**
** \param line Ligne a traiter
** \param def Tableau contenant les defines indexes par leur nom
** \return Retourne 1 si OK, 0 sinon
*/
int	ParsingPreprocesseur::gestion_replace_define(std::string &line, const std::map<std::string, std::string> &def)
{
	std::map<std::string, std::string>::const_iterator    it;
	unsigned long                                         pos;
	unsigned long                                         tmp;

	/* On ne remplace pas les defines pour les directive "ifdef", "ifndef"... */
	if (ParsingPreprocesseur::skip_name(line, "ifdef") > 0)
		return (1);
	if (ParsingPreprocesseur::skip_name(line, "ifndef") > 0)
		return (1);
	if (ParsingPreprocesseur::skip_name(line, "undef") > 0)
		return (1);

	for (it=def.begin(); it!=def.end(); it++)
	{
		/* Tant que l'on trouve le define dans la ligne, on le remplace */
		pos = 0;
		while ((pos = line.find(it->first, pos)) != std::string::npos)
		{
			if (((tmp = ParsingPreprocesseur::skip_name(line, "define")) == 0) ||
	    		    (pos != tmp))
		        {
				/* Remplace le define par sa valeur tant qu'on le trouve */
				if (((pos == 0) ||
				     ((isalnum(line[pos-1]) == 0) &&
				      (line[pos-1] != '_'))) &&
				    (((pos + it->first.size()) >= line.size()) ||
				     ((isalnum(line[pos + it->first.size()]) == 0) &&
				      (line[pos + it->first.size()] != '_'))))
				{
					line.replace(pos, it->first.size(), it->second);
					pos = pos + it->second.size();
				}
				else
				    pos++;
			}
			else
			    pos++;
		}
	}
	
	return (1);
}

