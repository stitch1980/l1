#ifndef    BNF_C_HPP_
#define    BNF_C_HPP_

#include    <string.h>
#include    <ctype.h>
#include    <string>


/**
** \namespace BNFc
** \brief Fonctions de la BNF du langage C
*/
namespace    BNFc
{    
    /**
    ** \fn unsigned long is_type_name(const std::string &s)
    ** \brief Gere l'identification des noms de types
    **
    ** \param str Chaine a analyser
    ** \return Retourne la taille du token si on le trouve
    */
    unsigned long    is_type_name(const std::string &s);
    
    /**
    ** \fn unsigned long is_var_name(const std::string &s)
    ** \brief Gere l'identification des noms de variables
    **
    ** \param str Chaine a analyser
    ** \return Retourne la taille du token si on le trouve
    */
    unsigned long    is_var_name(const std::string &s);
    
    /**
    ** \fn unsigned long is_keyword(const std::string &s)
    ** \brief Gere l'identification des mots-clef du langage
    **
    ** \param str Chaine a analyser
    ** \return Retourne la taille du token si on le trouve
    */
    unsigned long    is_keyword(const std::string &s);
    
}

#endif
