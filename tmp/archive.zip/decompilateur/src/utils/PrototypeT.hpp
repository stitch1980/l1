#ifndef    PROTOTYPE_T_HPP_
#define    PROTOTYPE_T_HPP_

#include    <string>
#include    <vector>
#include    <list>
#include    <map>
#include    <set>
#include    <utility>

#include    "BNFc.hpp"
#include    "Mutex.h"

#include <stdio.h>

/**
** \class PrototypeT
** \brief Classe servant de gestionnaire de definition de type
*/
class    PrototypeT
{
public:
    /**
    ** \fn class ProtoType
    ** \brief Classe definissant un type de variable
    */
    class    ProtoType
    {
    public:
        /**
        ** \class AttributType
        ** \brief Classe contenant les infos decrivant un attribut de structure
        */
        class    AttributType
        {
        public:
            AttributType();
            AttributType(const std::string &t, const std::string &n, unsigned long nbs);
            AttributType(const AttributType &a);

        public:
            /** Type de l'attribut */
            std::string      _type;
            /** Nom de l'attribut */
            std::string      _name;
            /** Nombre d'element de l'attribut (utile pour les tableauw) */
            unsigned long    _nbs;
        };

    public:
        /**
        ** \fn ProtoType()
        ** \brief Constructeur par defaut d'un descripteur de type
        */
        ProtoType();

        /**
        ** \fn ProtoType(unsigned long size)
        ** \brief Constructeur d'un descripteur de type simple (int, long, ...)
        **
        ** \param size Taille du type
        */
        ProtoType(unsigned long size);
        
        /**
        ** \fn ProtoType(const std::vector<PrototypeT::ProtoType::AttributType> &attribut)
        ** \brief Constructeur d'un descripteur de type complexe (structure)
        **
        ** \param attribut Tableau contenant le type des attributs et leur nom
        */
        ProtoType(const std::vector<PrototypeT::ProtoType::AttributType> &attribut);
        
        
        /**
        ** \fn int is_valid(const std::map<std::string, PrototypeT::ProtoType*> &proto) const
        ** \brief Fonction permettant de savoir si un type est valide (taille correct, attribut definis...)
        **
        ** \param proto Map contenant les definition de variables (pour les variables complexe)
        ** \return Retourne 1 si la definition de type est valide, 0 sinon
        */
        int    is_valid(const std::map<std::string, PrototypeT::ProtoType*> &proto) const;


        /**
        ** \fn unsigned long get_size(const std::map<std::string, PrototypeT::ProtoType*> &proto) const
        ** \brief Fonction permettant de connaitre la taille de la variable en octets
        **
        ** \param proto Map contenant les definition de variables (pour les variables complexe)
        ** \return Retourne la taille de la variable
        */
        unsigned long    get_size(const std::map<std::string, PrototypeT::ProtoType*> &proto) const;
        
        /**
        ** \fn unsigned long get_nbs_attribut() const
        ** \brief Permet de connaitre le nombre d'attribut d'une definition de variables complexe
        **
        ** \return Retourne le nombre d'attributs de la declaration si elle en a, 0 sinon
        */
        unsigned long    get_nbs_attribut() const;
        
        /**
        ** \fn std::string get_type_attribut(unsigned long offset) const
        ** \brief Permet de connaitre le type d'un attribut (long, int)
        **
        ** \param num Numero de l'attribut
        ** \return Retourne le type de l'attribut s'il existe, "" sinon 
        */
        std::string      get_type_attribut(unsigned long num) const;
        
        /**
        ** \fn std::string get_type_attribut(const std::string &name) const
        ** \brief Permet de connaitre le type d'un attribut (long, int)
        **
        ** \param nom de l'attribut a identifier (x, poney)
        ** \return Retourne le type de l'attribut s'il existe, "" sinon 
        */
        std::string      get_type_attribut(const std::string &name) const;
                                           
        /**
        ** \fn std::string get_name_attribut(unsigned long offset) const
        ** \brief Permet de connaitre le nom d'un attribut (x, poney)
        **
        ** \param num Numero de l'attribut
        ** \return Retourne le type de l'attribut s'il existe, "" sinon 
        */
        std::string      get_name_attribut(unsigned long num) const;
                                           
        /**
        ** \fn unsigned long get_nbs_element_attribut(unsigned long offset) const
        ** \brief Permet de connaitre le nombre d'element de l'attribut (utile pour les tableaux)
        **
        ** \param num Numero de l'attribut
        ** \return Retourne le nombre d'element de l'attribut
        */
        unsigned long     get_nbs_element_attribut(unsigned long num) const;

    protected:
        /** Type, nom et nombre des attributs de la variable dans le cas d'une structure ou d'une union */
        std::vector<PrototypeT::ProtoType::AttributType>     _attribut;
        /** Taille de la variable si elle n'est pas compose de sous-variables */
        unsigned long                                        _size;
    };


public:
    /**
    ** \fn static std::string get_token_name(std::string &name, unsigned long offset=0)
    ** \brief Gere la recuperation d'un token de nom (retourne "s", "->" puis "x" pour "s->x")
    **
    ** \param name Nom complet d'une variable ou dun attribut (long, Elf32_Ehdr.e_flags)
    ** \param offset Offset a partir duquel effectuer la recherche
    ** \return Retourne un token de nom, "." ou "->" si OK, "" sinon
    */
    static std::string    get_token_name(const std::string &name, unsigned long offset=0);

    /**
    ** \fn static PrototypeT::ProtoType*    find(const std::string &name,
    **                                    const std::map<std::string, PrototypeT::ProtoType*> &list_proto,
    **                                    PrototypeT::ProtoType *last) const
    ** \brief Gere l'identification d'une definition grace a son nom 
    **
    ** \param name Nom complet d'une variable ou dun attribut (long, Elf32_Ehdr.e_flags)
    ** \param list_proto Liste des prototypes
    ** \param last Prototype a retourner si on ne trouve rien
    ** \return Retourne Un pointeur sur la definition si on la trouve, NULL sinon
    */
    static PrototypeT::ProtoType*    find(const std::string &name,
                                   const std::map<std::string, PrototypeT::ProtoType*> &list_proto,
                                   PrototypeT::ProtoType *last);

public:
    /**
    ** \fn PrototypeT()
    ** \brief Constructeur par defeut du gestionnaire de definition de variables
    */
    PrototypeT();

    /**
    ** \fn ~PrototypeT()
    ** \brief Destructeur du gestionnaire de definition de variables
    */
    ~PrototypeT();


    /**
    ** \fn void clear()
    ** \brief Gere la suppression de toutes les definitions
    **
    ** \return Retourne rien
    */
    void     clear();

    /**
    ** \fn int exist(const std::string &name) const
    ** \brief Permet de savoir si un type existe
    **
    ** \param name Type de la variable
    ** \return Retourne 1 si le type existe, 0 sinon
    */
    int      exist(const std::string &name) const;

    /**
    ** \fn int is_valid(const std::string &name) const
    ** \brief Permet de savoir si un type est valide (taille correct, attribut definis...)
    **
    ** \param name Type de la variable
    ** \return Retourne 1 si le type existe, 0 sinon
    */
    int      is_valid(const std::string &name) const;
    
    /**
    ** \fn int can_be_an_attribute_of_struct(const std::string &type_base,
    **                                       const std::string &typa_attr,
    **                                       std::set<std::string> *liste_type=NULL) const
    ** \brief Permet de verifier si un attribut peut faire partie d'une structure de donnees
    **
    ** \param type_base Type de la structure de donnees
    ** \param type_attr Type de l'attribut a verifier
    ** \param liste_type Liste des type pour savoir quel types sont interdit car deja utilise
    ** \return Retourne 1 si OK, 0 sinon
    */
    int    can_be_an_attribute_of_struct(const std::string &type_base,
                                         const std::string &typa_attr,
                                         std::set<std::string> *liste_type=NULL) const;
                                         

    /**
    ** \fn void add_definition(const std::string &name, unsigned long size)
    ** \brief Gere l'ajout d'un definition de variable simple
    **
    ** \param name Type de la variable (int, long, ...)
    ** \param size Taille de la variable en octet
    ** \return Retourne rien 
    */
    void                 add_definition(const std::string &name, unsigned long size);
    
    /**
    ** \fn void add_definition(const std::string &name,
    **                                  const std::string &type0="", const std::string &name0="",
    **                                  const std::string &type1="", const std::string &name1="",
    **                                  const std::string &type2="", const std::string &name2="",
    **                                  const std::string &type3="", const std::string &name3="",
    **                                  const std::string &type4="", const std::string &name4="",
    **                                  const std::string &type5="", const std::string &name5="",
    **                                  const std::string &type6="", const std::string &name6="")
    ** \brief Gere l'ajout d'une definition de variable complexe (structure)
    **
    ** \param name Type de la variable (int, long, ...)
    ** \param type0 Type du 1er attribut de la variable (int, Elf32_Ehdr, ...)
    ** \param name0 Nome du 1er attribut de la variable (x, poney, ...)
    ** \param type1 Type du 2eme attribut de la variable (int, Elf32_Ehdr, ...)
    ** \param name1 Nome du 2eme attribut de la variable (x, poney, ...)
    ** \param type2 Type du 3eme attribut de la variable (int, Elf32_Ehdr,  ...)
    ** \param name2 Nome du 3eme attribut de la variable (x, poney, ...)
    ** \param type3 Type du 4eme attribut de la variable (int, Elf32_Ehdr, ...)
    ** \param name3 Nome du 4eme attribut de la variable (x, poney, ...)
    ** \param type4 Type du 5eme attribut de la variable (int, Elf32_Ehdr, ...)
    ** \param name4 Nome du 5eme attribut de la variable (x, poney, ...)
    ** \param type5 Type du 6eme attribut de la variable (int, Elf32_Ehdr, ...)
    ** \param name5 Nome du 6eme attribut de la variable (x, poney, ...)
    ** \param type6 Type du 7eme attribut de la variable (int, Elf32_Ehdr, ...)
    ** \param name6 Nome du 7eme attribut de la variable (x, poney, ...)
    ** \return Retourne rien
    */
    void                 add_definition(const std::string &name,
                                        const std::string &type0="", const std::string &name0="",
                                        const std::string &type1="", const std::string &name1="",
                                        const std::string &type2="", const std::string &name2="",
                                        const std::string &type3="", const std::string &name3="",
                                        const std::string &type4="", const std::string &name4="",
                                        const std::string &type5="", const std::string &name5="",
                                        const std::string &type6="", const std::string &name6="");
    /**
    ** \fn void add_definition(const std::string &name,
    **                                  const std::string &type0="", const std::string &name0="", unsigned long nbs_elem0=1,
    **                                  const std::string &type1="", const std::string &name1="", unsigned long nbs_elem1=1,
    **                                  const std::string &type2="", const std::string &name2="", unsigned long nbs_elem2=1,
    **                                  const std::string &type3="", const std::string &name3="", unsigned long nbs_elem3=1,
    **                                  const std::string &type4="", const std::string &name4="", unsigned long nbs_elem4=1,
    **                                  const std::string &type5="", const std::string &name5="", unsigned long nbs_elem5=1,
    **                                  const std::string &type6="", const std::string &name6="", unsigned long nbs_elem6=1)
    ** \brief Gere l'ajout d'une definition de variable complexe (structure)
    **
    ** \param name Type de la variable (int, long, ...)
    ** \param type0 Type du 1er attribut de la variable (int, Elf32_Ehdr, ...)
    ** \param name0 Nome du 1er attribut de la variable (x, poney, ...)
    ** \param nbs_elem0 Nombre d'element du 1er attribut
    ** \param type1 Type du 2eme attribut de la variable (int, Elf32_Ehdr, ...)
    ** \param name1 Nome du 2eme attribut de la variable (x, poney, ...)
    ** \param nbs_elem1 Nombre d'element du 2eme attribut
    ** \param type2 Type du 3eme attribut de la variable (int, Elf32_Ehdr,  ...)
    ** \param name2 Nome du 3eme attribut de la variable (x, poney, ...)
    ** \param nbs_elem2 Nombre d'element du 3eme attribut
    ** \param type3 Type du 4eme attribut de la variable (int, Elf32_Ehdr, ...)
    ** \param name3 Nome du 4eme attribut de la variable (x, poney, ...)
    ** \param nbs_elem3 Nombre d'element du 4eme attribut
    ** \param type4 Type du 5eme attribut de la variable (int, Elf32_Ehdr, ...)
    ** \param name4 Nome du 5eme attribut de la variable (x, poney, ...)
    ** \param nbs_elem4 Nombre d'element du 5eme attribut
    ** \param type5 Type du 6eme attribut de la variable (int, Elf32_Ehdr, ...)
    ** \param name5 Nome du 6eme attribut de la variable (x, poney, ...)
    ** \param nbs_elem5 Nombre d'element du 6eme attribut
    ** \param type6 Type du 7eme attribut de la variable (int, Elf32_Ehdr, ...)
    ** \param name6 Nome du 7eme attribut de la variable (x, poney, ...)
    ** \param nbs_elem6 Nombre d'element du 7eme attribut
    ** \return Retourne rien
    */
    void                 add_definition(const std::string &name,
                                        const std::string &type0="", const std::string &name0="", unsigned long nbs_elem0=1,
                                        const std::string &type1="", const std::string &name1="", unsigned long nbs_elem1=1,
                                        const std::string &type2="", const std::string &name2="", unsigned long nbs_elem2=1,
                                        const std::string &type3="", const std::string &name3="", unsigned long nbs_elem3=1,
                                        const std::string &type4="", const std::string &name4="", unsigned long nbs_elem4=1,
                                        const std::string &type5="", const std::string &name5="", unsigned long nbs_elem5=1,
                                        const std::string &type6="", const std::string &name6="", unsigned long nbs_elem6=1);
                                        
    /**
    ** \fn void add_definition(const std::string &name,
    **                         const std::vector<std::string> &type_attr,
    **                         const std::vector<std::string> &name_attr)
    ** \brief Gere l'ajout d'une definition de variable complexe (structure)
    **
    ** \param name Type de la variable (int, long, ...)
    ** \param type0 Tableau contenant le type des attributs de la variable (int, Elf32_Ehdr, ...)
    ** \param name0 Tableau contenant le nom attributs de la variable (x, poney, ...)
    ** \return Retourne rien
    */
    void                 add_definition(const std::string &name,
                                        const std::vector<std::string> &type_attr,
                                        const std::vector<std::string> &name_attr);
                                        
    /**
    ** \fn void add_definition(const std::string &name,
    **                         const std::vector<std::string> &type_attr,
    **                         const std::vector<std::string> &name_attr,
    **                         const std::vector<unsigned long> &nbs_elem_attr)
    ** \brief Gere l'ajout d'une definition de variable complexe (structure)
    **
    ** \param name Type de la variable (int, long, ...)
    ** \param type0 Tableau contenant le type des attributs de la variable (int, Elf32_Ehdr, ...)
    ** \param name0 Tableau contenant le nom attributs de la variable (x, poney, ...)
    ** \pram nbs_elem_attr Tableau contenant le nombre d'elements des attributs de la variable (x, poney, ...)
    ** \return Retourne rien
    */
    void                 add_definition(const std::string &name,
                                        const std::vector<std::string> &type_attr,
                                        const std::vector<std::string> &name_attr,
                                        const std::vector<unsigned long> &nbs_elem_attr);

    /**
    ** \fn void del_definition(const std::string &name)
    ** \brief Gere la suppression de la definition d'une variable
    **
    ** \param name Nom de la variable a supprimer (long, Elf32_Ehdr, Elf32_Ehdr)
    ** \return Retourne rien
    */
    void                 del_definition(const std::string &name);



    /**
    ** \fn unsigned long get_size(const std::string &name)
    ** \brief Gere la recuperation de la taille d'une varaible
    **
    ** \param name Nom de la variable (long, Elf32_Ehdr, Elf32_Ehdr.e_flags)
    ** \return Retourne la taille de la variable ou le l'attribut si OK, 0 sinon
    */
    unsigned long        get_size(const std::string &name) const;

    /**
    ** \fn unsigned long get_nbs_attribut(const std::string &name)
    ** \brief Gere la recuperation du nombre d'attributs d'une structure
    **
    ** \param name Nom de la variable (long, Elf32_Ehdr, Elf32_Ehdr.e_flags)
    ** \return Retourne le nombre d'attribut de la structure si OK, 0 sinon
    */
    unsigned long        get_nbs_attribut(const std::string &name) const;

    /**
    ** \fn std::string get_type_attribut_num(const std::string &name, unsigned long num)
    ** \brief Gere la recuperation du type d'un attribut d'une structure
    **
    ** \param name Nom de la variable (long, Elf32_Ehdr, Elf32_Ehdr.e_flags)
    ** \param num Numero de l'attribut dont le type nous interesse
    ** \return Retourne le type de l'attribut si OK, "" sinon
    */
    std::string         get_type_attribut_num(const std::string &name, unsigned long num) const;

    /**
    ** \fn std::string get_name_attribut_num(const std::string &name, unsigned long num)
    ** \brief Gere la recuperation du nom d'un attribut d'une structure
    **
    ** \param name Nom de la variable (long, Elf32_Ehdr, Elf32_Ehdr.e_flags)
    ** \param num Numero de l'attribut dont le type nous interesse
    ** \return Retourne le type de l'attribut si OK, "" sinon
    */
    std::string         get_name_attribut_num(const std::string &name, unsigned long num) const;
    
    /**
    ** \fn unsigned long get_nbs_element_attribut_num(const std::string &name, unsigned long num)
    ** \brief Gere la recuperation du nombre d'elements d'un attribut d'une structure (utile pour les tableaux)
    **
    ** \param name Nom de la variable (long, Elf32_Ehdr, Elf32_Ehdr.e_flags)
    ** \param num Numero de l'attribut dont le type nous interesse
    ** \return Retourne le nombre d'elements de l'attribut si OK, 0 sinon
    */
    unsigned long       get_nbs_element_attribut_num(const std::string &name, unsigned long num) const;

    /**
    ** \fn std::string get_type(const std::string &name, unsigned long offset=0)
    ** \brief Gere a recuperation du type d'une definition
    **
    ** \param name Nom de la variable (long, Elf32_Ehdr, Elf32_Ehdr.e_flags)
    ** \return Retourne le type de la variable (int, char[2], Elf32_Ehdr) si OK, "" sinon
    */
    std::string    get_type(const std::string &name) const;

    /**
    ** \fn std::string get_name(const std::string &name)
    ** \brief Gere a recuperation du nom d'une definition
    **
    ** \param name Nom de la variable (long, Elf32_Ehdr, Elf32_Ehdr.e_flags)
    ** \return Retourne le nom de la variable (x, poney) si OK, "" sinon
    */
    std::string    get_name(const std::string &name) const;


    /**
    ** \fn unsigned long get_nbs_type() const
    ** \brief Permet de connaitre le nombre de types de variables definis
    **
    ** \return Retourne le nombre de types de variables definis
    */
    unsigned long     get_nbs_type() const;

    /**
    ** \fn std::string get_type_num(unsigned long num)
    ** \brief Permet de connaitre le type (long, int, ...) d'une defintion du gestionnaire 
    **
    ** \param num Numero de la definition
    ** \return Retourne retourne le type de la definition si OK, "" sinon
    */
    std::string       get_type_num(unsigned long num) const;

protected:
    
    /**
    ** \fn int can_be_an_attribute_of_struct_unsafe(const std::string &type_base,
    **                                       const std::string &typa_attr,
    **                                       std::set<std::string> *liste_type=NULL) const
    ** \brief Permet de verifier si un attribut peut faire partie d'une structure de donnees (non thread-safe)
    **
    ** \param type_base Type de la structure de donnees
    ** \param type_attr Type de l'attribut a verifier
    ** \param liste_type Liste des type pour savoir quel types sont interdit car deja utilise
    ** \return Retourne 1 si OK, 0 sinon
    */
    int    can_be_an_attribute_of_struct_unsafe(const std::string &type_base,
                                                const std::string &typa_attr,
                                                std::set<std::string> *liste_type=NULL) const;
                                         
protected:
    /** Map contenant les prototypes de variables/structure identifies par leur type */
    std::map<std::string, PrototypeT::ProtoType*>    _proto;
    /** Mutex permettant de rendre la classe thread-safe */
    Mutex                                            _mutex;
};

#endif

