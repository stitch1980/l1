#ifndef    BNF_CALCUL_HPP_
#define    BNF_CALCUL_HPP_

#include    <string>
#include    <map>

#include    "Info.hpp"


/**
** \namespace BNFcalcul
** \brief Fonctions de la BNF des calculs
** (les tokens sont enregistres dans la map grace a leur nom: "essociation", "operateur", ...)
*/
namespace    BNFcalcul
{
    /**
    ** \fn unsigned long    is_association(const std::string &s, std::map<std::string, std::string> *m,
    **                                     const IASM *a=NULL, unsigned long off=0, int save=0)
    ** \brief Fonction de la BNF verifiant si la chaine contient une association valide
    **
    ** \param s String a analyser (sans espaces ni retour a la ligne)
    ** \param m Map ou mettre le token si on le trouve et si le parametre "save" != 0
    ** \param a Gestionnaire de l'assembleur pour pouvoir gerer les registres
    ** \param off Offset a partir duquel chercher le token
    ** \param save Doit valoir 1 si on veut enregistrer le token dans la map
    ** \return Retourne la taille du token si on le trouve, 0 sinon
    */
    unsigned long    is_association(const std::string &s, std::map<std::string, std::string> *m,
                                    const IASM *a=NULL, unsigned long off=0, int save=0);

    /**
    ** \fn unsigned long    is_expression(const std::string &s, std::map<std::string, std::string> *m,
    **                                    const IASM *a=NULL, unsigned long off=0, int save=0)
    ** \brief Fonction de la BNF verifiant si la chaine contient une expression valide
    **
    ** \param s String a analyser (sans espaces ni retour a la ligne)
    ** \param m Map ou mettre le token si on le trouve et si le parametre "save" != 0
    ** \param a Gestionnaire de l'assembleur pour pouvoir gerer les registres
    ** \param off Offset a partir duquel chercher le token
    ** \param save Doit valoir 1 si on veut enregistrer le token dans la map
    ** \return Retourne la taille du token si on le trouve, 0 sinon
    */
    unsigned long    is_expression(const std::string &s, std::map<std::string, std::string> *m,
                                   const IASM *a=NULL, unsigned long off=0, int save=0);

    /**
    ** \fn unsigned long    is_operateur(const std::string &s, std::map<std::string, std::string> *m,
    **                                   const IASM *a=NULL, unsigned long off=0, int save=0)
    ** \brief Fonction de la BNF verifiant si la chaine contient un operateur valide
    **
    ** \param s String a analyser (sans espaces ni retour a la ligne)
    ** \param m Map ou mettre le token si on le trouve et si le parametre "save" != 0
    ** \param a Gestionnaire de l'assembleur pour pouvoir gerer les registres
    ** \param off Offset a partir duquel chercher le token
    ** \param save Doit valoir 1 si on veut enregistrer le token dans la map
    ** \return Retourne la taille du token si on le trouve, 0 sinon
    */
    unsigned long    is_operateur(const std::string &s, std::map<std::string, std::string> *m,
                                  const IASM *a=NULL, unsigned long off=0, int save=0);

    /**
    ** \fn unsigned long    is_operande(const std::string &s, std::map<std::string, std::string> *m,
    **                                  const IASM *a=NULL, unsigned long off=0, int save=0)
    ** \brief Fonction de la BNF verifiant si la chaine contient un operande valide
    **
    ** \param s String a analyser (sans espaces ni retour a la ligne)
    ** \param m Map ou mettre le token si on le trouve et si le parametre "save" != 0
    ** \param a Gestionnaire de l'assembleur pour pouvoir gerer les registres
    ** \param off Offset a partir duquel chercher le token
    ** \param save Doit valoir 1 si on veut enregistrer le token dans la map
    ** \return Retourne la taille du token si on le trouve, 0 sinon
    */
    unsigned long    is_operande(const std::string &s, std::map<std::string, std::string> *m,
                                 const IASM *a=NULL, unsigned long off=0, int save=0);

    /**
    ** \fn unsigned long    is_dest(const std::string &s, std::map<std::string, std::string> *m,
    **                              const IASM *a=NULL, unsigned long off=0, int save=0)
    ** \brief Fonction de la BNF verifiant si la chaine contient une dest valide
    **
    ** \param s String a analyser (sans espaces ni retour a la ligne)
    ** \param m Map ou mettre le token si on le trouve et si le parametre "save" != 0
    ** \param a Gestionnaire de l'assembleur pour pouvoir gerer les registres
    ** \param off Offset a partir duquel chercher le token
    ** \param save Doit valoir 1 si on veut enregistrer le token dans la map
    ** \return Retourne la taille du token si on le trouve, 0 sinon
    */
    unsigned long    is_dest(const std::string &s, std::map<std::string, std::string> *m,
                             const IASM *a=NULL, unsigned long off=0, int save=0);

    /**
    ** \fn unsigned long    is_nbs(const std::string &s, std::map<std::string, std::string> *m,
    **                             const IASM *a=NULL, unsigned long off=0, int save=0)
    ** \brief Fonction de la BNF verifiant si la chaine contient un nbs valide
    **
    ** \param s String a analyser (sans espaces ni retour a la ligne)
    ** \param m Map ou mettre le token si on le trouve et si le parametre "save" != 0
    ** \param a Gestionnaire de l'assembleur pour pouvoir gerer les registres
    ** \param off Offset a partir duquel chercher le token
    ** \param save Doit valoir 1 si on veut enregistrer le token dans la map
    ** \return Retourne la taille du token si on le trouve, 0 sinon
    */
    unsigned long    is_nbs(const std::string &s, std::map<std::string, std::string> *m,
                            const IASM *a=NULL, unsigned long off=0, int save=0);

    /**
    ** \fn unsigned long    is_registre(const std::string &s, std::map<std::string, std::string> *m,
    **                                  const IASM *a=NULL, unsigned long off=0, int save=0)
    ** \brief Fonction de la BNF verifiant si la chaine contient un registre valide
    **
    ** \param s String a analyser (sans espaces ni retour a la ligne)
    ** \param m Map ou mettre le token si on le trouve et si le parametre "save" != 0
    ** \param a Gestionnaire de l'assembleur pour pouvoir gerer les registres
    ** \param off Offset a partir duquel chercher le token
    ** \param save Doit valoir 1 si on veut enregistrer le token dans la map
    ** \return Retourne la taille du token si on le trouve, 0 sinon
    */
    unsigned long    is_registre(const std::string &s, std::map<std::string, std::string> *m,
                                 const IASM *a=NULL, unsigned long off=0, int save=0);

    /**
    ** \fn unsigned long    is_memoire(const std::string &s, std::map<std::string, std::string> *m,
    **                                 const IASM *a=NULL, unsigned long off=0, int save=0)
    ** \brief Fonction de la BNF verifiant si la chaine contient une adresse memoire valide
    **
    ** \param s String a analyser (sans espaces ni retour a la ligne)
    ** \param m Map ou mettre le token si on le trouve et si le parametre "save" != 0
    ** \param a Gestionnaire de l'assembleur pour pouvoir gerer les registres
    ** \param off Offset a partir duquel chercher le token
    ** \param save Doit valoir 1 si on veut enregistrer le token dans la map
    ** \return Retourne la taille du token si on le trouve, 0 sinon
    */
    unsigned long    is_memoire(const std::string &s, std::map<std::string, std::string> *m,
                                const IASM *a=NULL, unsigned long off=0, int save=0);

    /**
    ** \fn unsigned long    is_decimal(const std::string &s, std::map<std::string, std::string> *m,
    **                                 const IASM *a=NULL, unsigned long off=0, int save=0)
    ** \brief Fonction de la BNF verifiant si la chaine contient un decimal valide
    **
    ** \param s String a analyser (sans espaces ni retour a la ligne)
    ** \param m Map ou mettre le token si on le trouve et si le parametre "save" != 0
    ** \param a Gestionnaire de l'assembleur pour pouvoir gerer les registres
    ** \param off Offset a partir duquel chercher le token
    ** \param save Doit valoir 1 si on veut enregistrer le token dans la map
    ** \return Retourne la taille du token si on le trouve, 0 sinon
    */
    unsigned long    is_decimal(const std::string &s, std::map<std::string, std::string> *m,
                                const IASM *a=NULL, unsigned long off=0, int save=0);

    /**
    ** \fn unsigned long    is_udecimal(const std::string &s, std::map<std::string, std::string> *m,
    **                                  const IASM *a=NULL, unsigned long off=0, int save=0)
    ** \brief Fonction de la BNF verifiant si la chaine contient un udecimal valide
    **
    ** \param s String a analyser (sans espaces ni retour a la ligne)
    ** \param m Map ou mettre le token si on le trouve et si le parametre "save" != 0
    ** \param a Gestionnaire de l'assembleur pour pouvoir gerer les registres
    ** \param off Offset a partir duquel chercher le token
    ** \param save Doit valoir 1 si on veut enregistrer le token dans la map
    ** \return Retourne la taille du token si on le trouve, 0 sinon
    */
    unsigned long    is_udecimal(const std::string &s, std::map<std::string, std::string> *m,
                                 const IASM *a=NULL, unsigned long off=0, int save=0);

    /**
    ** \fn unsigned long    is_hexadecimal(const std::string &s, std::map<std::string, std::string> *m,
    **                                     const IASM *a=NULL, unsigned long off=0, int save=0)
    ** \brief Fonction de la BNF verifiant si la chaine contient un hexadecimal valide
    **
    ** \param s String a analyser (sans espaces ni retour a la ligne)
    ** \param m Map ou mettre le token si on le trouve et si le parametre "save" != 0
    ** \param a Gestionnaire de l'assembleur pour pouvoir gerer les registres
    ** \param off Offset a partir duquel chercher le token
    ** \param save Doit valoir 1 si on veut enregistrer le token dans la map
    ** \return Retourne la taille du token si on le trouve, 0 sinon
    */
    unsigned long    is_hexadecimal(const std::string &s, std::map<std::string, std::string> *m,
                                    const IASM *a=NULL, unsigned long off=0, int save=0);

    /**
    ** \fn unsigned long    is_hexa_sans_0x(const std::string &s, std::map<std::string, std::string> *m,
    **                                      const IASM *a=NULL, unsigned long off=0, int save=0)
    ** \brief Fonction de la BNF verifiant si la chaine contient un hexa_sans_0x valide
    **
    ** \param s String a analyser (sans espaces ni retour a la ligne)
    ** \param m Map ou mettre le token si on le trouve et si le parametre "save" != 0
    ** \param a Gestionnaire de l'assembleur pour pouvoir gerer les registres
    ** \param off Offset a partir duquel chercher le token
    ** \param save Doit valoir 1 si on veut enregistrer le token dans la map
    ** \return Retourne la taille du token si on le trouve, 0 sinon
    */
    unsigned long    is_hexa_sans_0x(const std::string &s, std::map<std::string, std::string> *m,
                                     const IASM *a=NULL, unsigned long off=0, int save=0);
}

#endif

