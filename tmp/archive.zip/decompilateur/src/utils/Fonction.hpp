#ifndef    FONCTION_HPP_
#define    FONCTION_HPP_

#include    <string>
#include    <list>
#include    <vector>
#include    <set>

#include    "IASM.hpp"
#include    "IBlocSource.hpp"
#include    "Mutex.h"

/**
** \class Fonction
** \brief Classe representant une fonction
** (pas thread-safe mais dispose d'un mutex interne)
*/
class    Fonction
{
public:
    /**
    ** \fn static std::string get_name_function(const Fonction *f, const Info *info)
    ** \brief Fonction permettant de recuperer ou de generer le nom d'une fonction a partir des symboles
    **
    ** \param f Fonction dont le nom est a trouver
    ** \param info Structure contenant les infos du programme a analyser
    ** \return Retourne le nom de la fonction si on le trouve dans les symboles, "func_<adress>" sinon
    */
    static std::string    get_name_function(const Fonction *f, const Info *info);
    
    /**
    ** \fn static std::string get_name_function(unsigned long addr, const Info *info)
    ** \brief Fonction permettant de recuperer ou de generer le nom d'une fonction a partir des symboles
    **
    ** \param addr adresse de la fonction dont le nom est a trouver
    ** \param info Structure contenant les infos du programme a analyser
    ** \return Retourne le nom de la fonction si on le trouve dans les symboles, "func_<adress>" sinon
    */
    static std::string    get_name_function(unsigned long addr, const Info *info);
    
public:
    /**
    ** \class Bloc
    ** \Brief Classe representant un bloc d'instruction dans une fonction
    ** (pas thread-safe mais dispose d'un mutex interne)
    */
    class    Bloc
    {
    public:
        /**
        ** \fn Bloc()
        ** \brief Constructeur par defaut d'un bloc
        */
        Bloc();

        /**
        ** \fn ~Bloc()
        ** \brief Destructeur par defaut d'un bloc
        */
        ~Bloc();

    protected:
        /**
        ** \fn Bloc(const Fonction::Bloc &)
        ** \brief Constructeur par copie d'un bloc (inutilisable)
        */
        Bloc(const Fonction::Bloc &b);

        /**
        ** \fn Fonction::Bloc &operator = (const Fonction::Bloc &)
        ** \brief Surcharge de l'operateur = pour les blocs (inutilisable)
        */
        Fonction::Bloc    &operator = (const Fonction::Bloc &b);

    public:
        /**
        ** \fn std::string get_description() const
        ** \brief Assesseur permettant de recuperer la description du bloc
        **
        ** \return Retourne une string contenant la description du bloc
        */
        std::string       get_description() const;
        
        /**
        ** \fn void get_description(const std::string &str)
        ** \brief Assesseur permettant de modifier la description du bloc
        **
        ** \param str Nouvelle description du bloc
        ** \return Retourne rien
        */
        void              set_description(const std::string &str);
        
        /**
        ** \fn unsigned long get_addr() const
        ** \brief Assesseur permettant de connaitre l'adresse de debut du bloc
        **
        ** \return Retourne l'adresse de la premiere instruction du bloc si OK, 0 sinon
        */
        unsigned long     get_addr() const;

        /**
        ** \fn InstrASM *get_instr_entry() const
        ** \brief Assesseur parmettant d'acceder a la premiere instruction du bloc
        **
        ** \return Retourne un pointeur sur la première instruction si OK, NULL sinon
        */
        InstrASM          *get_instr_entry() const;

        /**
        ** \fn void set_instr_entry(InstrASM *i)
        ** \brief Assesseur permettant de modifier la premiere instruction du bloc
        **
        ** \param i Nouvelle premiere instruction (ajoute l'instruction a la liste si besoin est)
        ** \return Retourne rien
        */
        void              set_instr_entry(InstrASM *i);

        /**
        ** \fn InstrASM *get_instr(unsigned long addr) const
        ** \brief Assesseur permettant d'acceder a une instruction a partir de son adresse
        **
        ** \param addr Adresse de l'instruction a trouver
        ** \return Retourne un pointeur sur l'instruction si elle est dans le bloc, NULL sinon
        */
        InstrASM          *get_instr(unsigned long addr) const;


        /**
        ** \fn int add_instr(InstrASM *i)
        ** \brief Gere l'ajout d'une instruction ASM dans la liste des instructions du bloc
        **
        ** \param i instruction a ajouter
        ** \return Retourne 1 si l'ajout s'est bien passe, 0 sinon
        */
        int               add_instr(InstrASM *i);

        /**
        ** \fn int del_instr(InstrASM *i)
        ** \brief Gere l'enlevement d'une instruction ASM de la liste des instructions du bloc
        **
        ** \param i instruction a enlever (ne delete pas l'instruction)
        ** \return Retourne 1 si l'enlevement s'est bien passe, 0 sinon
        */
        int               del_instr(InstrASM *i);

        /**
        ** \fn int del_instr(unsigned long addr)
        ** \brief Gere l'enlevement d'une instruction ASM de la liste des instructions du bloc
        **
        ** \param i instruction a enlever (ne delete pas l'instruction)
        ** \return Retourne 1 si l'enlevement s'est bien passe, 0 sinon
        */
        int               del_instr(unsigned long addr);

        /**
        ** \fn Fonction::Bloc *split(unsigned long addr)
        ** \brief Permet de diviser un bloc en deux a partir d'une adresse
        **
        ** \param addr Toutes les instructions suivant cette adresse seront dans le nouveau bloc
        ** \return Retourne un pointeur sur le bloc ainsi cree si OK, NULL sinon
        */
        Fonction::Bloc    *split(unsigned long addr);

        /**
        ** \fn Fonction::Bloc *split(InstrASM *instr)
        ** \brief Permet de diviser un bloc en deux a partir d'une instruction
        **
        ** \param instr Cette instruction et les suivantes seront dans le nouveau bloc
        ** \return Retourne un pointeur sur le bloc ainsi cree, NULL sinon
        */
        Fonction::Bloc    *split(InstrASM *instr);

        /**
        ** \fn Fonction::Bloc *concate(Bloc *b)
        ** \brief Gere la concatenation d'un bloc avec un autre
        **
        ** \param b Bloc a concatener a la fin de "this" (il ne sera PAS supprime)
        ** \return Retourne un pointeur sur "this"
        */
        Fonction::Bloc    *concate(Bloc *b);


        /**
        ** \fn void lock()
        ** \brief Permet de verrouiller le mutex du bloc
        **
        ** \return Retourne rien
        */
        void              lock();

        /**
        ** \fn void unlock()
        ** \brief Permet de deverrouiller le mutex du bloc
        **
        ** \return Retourne rien
        */
        void              unlock();

    protected:
        /** Description de la fonction */
        std::string             _description;
    
        /** Pointeur vers le premier bloc de la fonction */
        InstrASM                *_entry;
        /** Liste contenant les blocs de la fonction */
        std::list<InstrASM*>    _list_instr;

        /** Mutex chargee de rendre le bloc thread-safe */
        Mutex                   _mutex;
    };



public:
    /**
    ** \fn Fonction()
    ** \brief Constructeur par defaut d'une fonction
    */
    Fonction();

    /**
    ** \fn ~Fonction()
    ** \brief Destructeur par defaut d'une fonction
    */
    ~Fonction();

protected:
    /**
    ** \fn Fonction(const Fonction &f)
    ** \brief Constructeur par copie de la fonction (inutilisable)
    */
    Fonction(const Fonction &);

    /**
    ** \fn Fonction &operator = (const Fonction &)
    ** \brief Surcharge de l'operateur = pour les fonctions (inutilisable)
    **
    ** \return Retourne une reference sur la fonction
    */
    Fonction    &operator = (const Fonction &);

public:
    /**
    ** \fn std::string get_description() const
    ** \brief Assesseur permettant de recuperer la description du bloc
    **
    ** \return Retourne une string contenant la description du bloc
    */
    std::string       get_description() const;
        
    /**
    ** \fn void get_description(const std::string &str)
    ** \brief Assesseur permettant de modifier la description du bloc
    **
    ** \param str Nouvelle description du bloc
    ** \return Retourne rien
    */
    void              set_description(const std::string &str);
    
    /**
    ** \fn unsigned long get_addr() const
    ** \brief Assesseur permettant de connaitre l'adresse de la fonction
    **
    ** \return Retourne l'adresse de la fonction si OK, 0 sinon
    */
    unsigned long     get_addr() const;


    /**
    ** \fn Fonction::Bloc    *get_bloc_entry() const
    ** \brief Assesseur permettant d'acceder au bloc d'entree de la fonction
    **
    ** \return Retourne un pointeur sur le bloc d'entree de la fonction ou NULL
    */
    Fonction::Bloc    *get_bloc_entry() const;

    /**
    ** \fn void set_bloc_entry(Fonction::Bloc *bloc)
    ** \brief Assesseur permettant de definir quel est le bloc d'entree de la fonction
    **
    ** \param bloc Bloc d'entree (est ajoutee a la liste des blocs s'il n'y etait pas)
    ** \return Retourne rien
    */
    void              set_bloc_entry(Fonction::Bloc *bloc);

    /**
    ** \fn Fonction::Bloc *get_bloc(unsigned long addr) const
    ** \brief Assesseur permettant d'acceder au bloc contenant une instruction
    **
    ** \param addr Adresse de l'instruction contenue dans le bloc a trouver
    ** \return Retourne un pointeur sur le bloc si on le trouve, NULL sinon
    */
    Fonction::Bloc    *get_bloc(unsigned long addr) const;

    /**
    ** \fn const std::list<Fonction::Bloc*> get_list_bloc() const
    ** \brief Assesseur parmettant d'acceder a la liste des blocs
    **
    ** \return Retourne une reference sur la liste des blocs de la fonction
    */
    const std::list<Fonction::Bloc*>    &get_list_bloc() const;


    /**
    ** \fn int add_bloc(Fonction::Bloc *bloc)
    ** \brief Permet d'ajouter un bloc a la fonction
    **
    ** \param bloc Bloc a ajouter a la fonction
    ** \return Retourne 1 si OK, 0 si le bloc etait deja dans la liste de blocs
    */
    int               add_bloc(Fonction::Bloc *bloc);

    /**
    ** \fn int del_bloc(Fonction::Bloc *bloc, int del=0)
    ** \brief Gere la suppression d'un bloc de la liste de blocs
    **
    ** \param bloc Bloc a supprimer
    ** \param del Vaut 1 si le bloc a ete alloue via "new" et qu'il faut le "delete"
    ** \return Retourne 1 si on a trouver et supprimer le bloc, 0 sinon
    */
    int               del_bloc(Fonction::Bloc *bloc, int del=0);


    /**
    ** \fn const std::set<unsigned long> &get_addr_call() const
    ** \brief Assesseur permettant d'acceder a la liste des sous-fonctions appelees
    **
    ** \return Retourne une reference sur le tabeau contenant les adresses des sous-fonctions
    */
    const std::set<unsigned long>    &get_addr_call() const;

    /**
    ** \fn void add_addr_call(unsigned long a)
    ** \brief Permet d'ajouter une adresse a la liste des sous-fonctions appelees
    **
    ** \param a Adresse de la sous-fonction
    ** \return Retourne rien
    */    
    void              add_addr_call(unsigned long a);

    /**
    ** \fn void del_addr_call(unsigned long a)
    ** \brief Permet de supprimer une adresse de la liste des sous-fonctions appelees
    **
    ** \param a Adresse de la sous-fonction
    ** \return Retourne rien
    */   
    void              del_addr_call(unsigned long a);


    /**
    ** \fn IBlocSource *get_source_code() const
    ** \brief Assesseur parmettant d'acceder au code-source de la fonction
    **
    ** \return Retourne un pointeur sur le code-source de la fonction
    */
    IBlocSource    *get_source_code() const;

    /**
    ** \fn set set_source_code(IBlocSource *s)
    ** \brief Assesseur parmettant de modifier le code-source de la fonction
    **
    ** \return Pointeur sur le nouveau code-source de la fonction
    ** \return Retourne rien
    */
    void            set_source_code(IBlocSource *s);


    /**
    ** \fn void unlock()
    ** \brief Permet de verrouiller le mutex de la fonction
    **
    ** \return Retourne rien
    */
    void              lock();

    /**
    ** \fn void unlock()
    ** \brief Permet de deverrouiller le mutex de la fonction
    **
    ** \return Retourne rien
    */
    void              unlock();

protected:
    /** Description de la fonction */
    std::string                   _description;

    /** Pointeur vers le premier bloc de la fonction */
    Fonction::Bloc                *_entry;
    /** Liste contenant les blocs de la fonction */
    std::list<Fonction::Bloc*>    _list_bloc;
    
    /** Tableau contenant toutes les adresses des sous-fonctions appelees */
    std::set<unsigned long>       _addr_call;
    
    /** Classe Contenant le code-source de la fonction */
    IBlocSource                   *_code_source;

    /** Mutex chargee de rendre la fonction thread-safe */
    Mutex                         _mutex;
};

#endif

