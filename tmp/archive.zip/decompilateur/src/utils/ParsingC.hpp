#ifndef    PARSING_C_HPP_
#define    PARSING_C_HPP_

#include    <string>
#include    <vector>
#include    <list>
#include    <map>
#include    <fstream>
#include    <iostream>

#include    <stdio.h>
#include    <stdlib.h>
#include    <string.h>

/**
** \namespace ParsingC
** \brief Namespace permettant de parser du code C
*/
namespace    ParsingC
{
	/**
	** \class Node
	** \brief Classe permettant de decrire un element de code C
	*/
	class    Node
	{
	public:
		/**
		** \enum eType
		** \brief Enum permettant d'identifier le type des nodes
		*/
		enum eType
		{
			TYPE_PROTOTYPE,
			TYPE_FONCTION,
			TYPE_TYPEDEF,
			TYPE_DEFINITION,
		};

	public:
		/**
		** \fn Node()
		** \brief Constructeur par defaut du Node
		*/
		Node();

		/**
		** \fn Node()
		** \brief Detructeur du Node
		*/
		~Node();

	public:
	        /** Type du Node */
		ParsingC::Node::eType        _type;
		/** Nom du Node */
		std::string                  _name;
		/** Node fille */
		std::list<ParsingC::Node>    _son;
	};
	
	
	/**
	** \fn int parse(std::list<ParsingC::Node*> &node, const std::string &content, unsigned long offset=0)
	** \brief Gere le parsing de code C pour en extraire les elements
	**
	** \param node Liste des nodes parsee
	** \param content String content le code C
	** \param offset Offset a partir duquel commencer le parsing du code C
	** \reutn Retourne 1 si OK, 0 sinon
	*/
	int    parse(std::list<ParsingC::Node*> &node, const std::string &content, unsigned long offset=0);
}

#endif

