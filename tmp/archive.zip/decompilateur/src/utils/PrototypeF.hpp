#ifndef    PROTOTYPE_F_HPP_
#define    PROTOTYPE_F_HPP_

#include    <string>
#include    <vector>
#include    <list>
#include    <map>
#include    <utility>

#include    "IASM.hpp"
#include    "Mutex.h"


/**
** \class PrototypeF
** \brief Classe servant de gestionnaire de definition de fonction (thread-safe)
*/
class    PrototypeF
{
protected:
    /**
    ** \class ProtoFonction
    ** \brief Classe definissant un prototype de fonction
    */
    class    ProtoFonction
    {
    public:
        ProtoFonction(): _name(), _ret(), _param() {}
        ProtoFonction(const std::string &name, const std::string &ret,
                      const std::vector< std::pair<std::string, std::string> > &param): _name(name), _ret(ret), _param(param) {}

    public:
        /** Nom de la fonction */
        std::string                                           _name;
        /** Type de retour (Si "", cela signifie que la fonction ne retourne pas (ex: exit() ) */
        std::string                                           _ret;
        /** Type et noms des parametres <type, nom> */
        std::vector< std::pair<std::string, std::string> >    _param;
    };

public:
    /**
    ** \fn PrototypeF()
    ** \brief Constructeur d'un gestionnaire de prototype de fonctions
    */
    PrototypeF();

    /**
    ** \fn ~PrototypeF()
    ** \brief Desctructeur d'un gestionnaire de prototype de fonctions
    */
    ~PrototypeF();


    /**
    ** \fn void clear()
    ** \brief Gere la suppression des prototypes contenu dans la liste
    **
    ** \return Retourne rien
    */
    void                 clear();
    
    /**
    ** \fn int exist(const std::string &name) const;
    ** \brief Permet de savoir si un prototype de fonction ayant ce nom est deja declare
    **
    ** \param name Nom de la fonction
    ** \return Retourne 1 si le prototype est dans la liste, 0 sinon
    */
    int                  exist(const std::string &name) const;


    /**
    ** \fn void add_function(const std::string &name, const std::string &t_ret="",
    **                       const std::string &t_p1="", const std::string &t_p2="",
    **                       const std::string &t_p3="", const std::string &t_p4="",
    **                       const std::string &t_p5="", const std::string &t_p6="",
    **                       const std::string &t_p7="", const std::string &t_p8="",
    **                       const std::string &t_p9="", const std::string &t_p10="",
    **                       const std::string &t_p11="", const std::string &t_p12="")
    ** \brief Gere l'ajout d'un prototype de fonction dans la liste
    **
    ** \param name Nom de la fonction
    ** \param t_ret Type de retour de la fonction
    ** \param t_p1 Type du 1er parametre de la fonction
    ** \param t_p2 Type du 2eme parametre de la fonction
    ** \param t_p3 Type du 3eme parametre de la fonction
    ** \param t_p4 Type du 4eme parametre de la fonction
    ** \param t_p5 Type du 5eme parametre de la fonction
    ** \param t_p6 Type du 6eme parametre de la fonction
    ** \param t_p7 Type du 7eme parametre de la fonction
    ** \param t_p8 Type du 8eme parametre de la fonction
    ** \param t_p9 Type du 9eme parametre de la fonction
    ** \param t_p10 Type du 10eme parametre de la fonction
    ** \param t_p11 Type du 11eme parametre de la fonction
    ** \param t_p12 Type du 12eme parametre de la fonction
    ** \return Retourne rien
    */
    void                 add_function(const std::string &name, const std::string &t_ret="",
                                      const std::string &t_p1="", const std::string &t_p2="",
                                      const std::string &t_p3="", const std::string &t_p4="",
                                      const std::string &t_p5="", const std::string &t_p6="",
                                      const std::string &t_p7="", const std::string &t_p8="",
                                      const std::string &t_p9="", const std::string &t_p10="",
                                      const std::string &t_p11="", const std::string &t_p12="");

    /**
    ** \fn void add_function(const std::string &name, const std::string &t_ret,
    **                       const std::vector<std::string> &param)
    ** \brief Gere l'ajout d'un prototype de fonction dans la liste
    **
    ** \param name Nom de la fonction
    ** \param t_ret Type de retour de la fonction
    ** \param param Tableau contenant les types des parametres
    ** \return Retourne rien
    */
    void                 add_function(const std::string &name, const std::string &t_ret,
                                      const std::vector<std::string> &param);

    /**
    ** \fn void add_function(const std::string &name, const std::string &t_ret,
    **                       const std::vector< std::pair<std::string, std::string> > &param)
    ** \brief Gere l'ajout d'un prototype de fonction dans la liste
    **
    ** \param name Nom de la fonction
    ** \param t_ret Type de retour de la fonction
    ** \param param Tableau contenant les types et nom des parametres <type, nom>
    ** \return Retourne rien
    */
    void                 add_function(const std::string &name, const std::string &t_ret,
                                      const std::vector< std::pair<std::string, std::string> > &param);

    /**
    ** \fn void del_function(unsigned int num)
    ** \brief Gere la suppression d'un prototype de fonction
    **
    ** \param name Nom de la fonction
    ** \return Retourne rien
    */
    void                 del_function(const std::string &name);


    /**
    ** \fn std::string get_ret(const std::string &name) const
    ** \brief Assesseur permettant d'acceder au type de retour d'une fonction
    **
    ** \param name Nom de la fonction
    ** \return Retourne le type de retour de la fonction si OK, "" sinon
    */
    std::string    get_ret(const std::string &name) const;

    /**
    ** \fn unsigned long get_nbs_param(const std::string &name, unsigned int num_param) const
    ** \brief Assesseur permettant d'acceder au nombre de parametres d'une fonction
    **
    ** \param name Nom de la fonction
    ** \param num Numero du parametre (commence a 0)
    ** \return Retourne le nombre de parametres de la fonction si OK, 0 sinon
    */
    unsigned long    get_nbs_param(const std::string &name) const;

    /**
    ** \fn std::string get_type_param(const std::string &name, unsigned int num_param) const
    ** \brief Assesseur permettant d'acceder au type d'un parametre d'une fonction
    **
    ** \param name Nom de la fonction
    ** \param num Numero du parametre (commence a 0)
    ** \return Retourne le type du parametre de la fonction si OK, "" sinon
    */
    std::string    get_type_param(const std::string &name, unsigned int num_param) const;

    /**
    ** \fn std::string get_name_param(const std::string &name, unsigned int num_param) const
    ** \brief Assesseur permettant d'acceder au nom d'un parametre d'une fonction
    **
    ** \param name Nom de la fonction
    ** \param num Numero du parametre (commence a 0)
    ** \return Retourne le type du parametre de la fonction si OK, "" sinon
    */
    std::string    get_name_param(const std::string &name, unsigned int num_param) const;

    
    /**
    ** \fn std::string get_nbs() const
    ** \brief Assesseur permettant de connaitre le nombre de prototypes
    **
    ** \return Retourne le nombre de prototypes
    */
    unsigned long    get_nbs() const;

    /**
    ** \fn std::string get_num_nbs(unsigned long n) const
    ** \brief Assesseur permettant de connaitre le numero du syscall
    **
    ** \param n Numero du prototype
    ** \return Retourne le numero du syscall
    */
    unsigned long    get_num_nbs(unsigned long n) const;

    /**
    ** \fn unsigned long get_name_nbs(unsigned long n) const
    ** \brief Assesseur permettant de connaitre le nom d'un prototype
    **
    ** \param n Numero du prototype
    ** \return Retourne le nom d'un prototype si OK, "" sinon
    */
    std::string    get_name_nbs(unsigned long n) const;

    /**
    ** \fn std::string get_ret_nbs(unsigned long n) const
    ** \brief Assesseur permettant de connaitre le type de retour d'un prototype
    **
    ** \param n Numero du prototype
    ** \return Retourne le type de retour d'un prototype si OK, "" sinon
    */
    std::string    get_ret_nbs(unsigned long n) const;

    /**
    ** \fn unsigned long get_nbs_param_nbs(unsigned long n) const
    ** \brief Assesseur permettant de connaitre le nombre de parametres d'un prototype
    **
    ** \param n Numero du prototype
    ** \return Retourne le nombre de parametres d'un prototype si OK, 0 sinon
    */
    unsigned long    get_nbs_param_nbs(unsigned long n) const;

    /**
    ** \fn std::string get_type_param_nbs(unsigned long n, unsigned long param) const
    ** \brief Assesseur permettant de connaitre le type d'un parametre de prototype
    **
    ** \param n Numero du prototype
    ** \param param Numero du parametre
    ** \return Retourne le type d'un parametre de prototype si OK, "" sinon
    */
    std::string    get_type_param_nbs(unsigned long n, unsigned long param) const;

    /**
    ** \fn std::string get_name_param_nbs(unsigned long n, unsigned long param) const
    ** \brief Assesseur permettant de connaitre le nom d'un parametre de prototype
    **
    ** \param n Numero du prototype
    ** \param param Numero du parametre
    ** \return Retourne le type d'un parametre de prototype si OK, "" sinon
    */
    std::string    get_name_param_nbs(unsigned long n, unsigned long param) const;

protected:
    /** Liste des prototypes de fonctions */
    std::list<PrototypeF::ProtoFonction*>    _proto;
    /** Mutex permettant de rendre la classe thread-safe */
    Mutex                                    _mutex;
};

#endif

