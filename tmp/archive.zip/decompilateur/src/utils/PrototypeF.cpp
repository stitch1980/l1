#include    "PrototypeF.hpp"
#include    "Calcul.hpp"

/**
** \fn PrototypeF()
** \brief Constructeur d'un gestionnaire de prototype de fonctions
*/
PrototypeF::PrototypeF():
    _proto(),
    _mutex()
{
}

/**
** \fn ~PrototypeF()
** \brief Desctructeur d'un gestionnaire de prototype de fonctions
*/
PrototypeF::~PrototypeF()
{
    this->clear();
}



/**
** \fn void clear()
** \brief Gere la suppression des prototypes contenu dans la liste
**
** \return Retourne rien
*/
void                 PrototypeF::clear()
{
    this->_mutex.lock();

    for (std::list<PrototypeF::ProtoFonction*>::iterator it=this->_proto.begin();
         it!=this->_proto.end();
         it++)
        delete (*it);
    this->_proto.clear();
    
    this->_mutex.unlock();
}
    
/**
** \fn int exist(const std::string &name) const;
** \brief Permet de savoir si un prototype de fonction ayant ce nom est deja declare
**
** \param name Nom de la fonction
** \return Retourne 1 si le prototype est dans la liste, 0 sinon
*/
int                  PrototypeF::exist(const std::string &name) const
{
    int    ret;

    const_cast<Mutex*>(&(this->_mutex))->lock();

    ret = 0;
    for (std::list<PrototypeF::ProtoFonction*>::const_iterator it=this->_proto.begin();
         (it!=this->_proto.end()) && (ret==0);
         it++)
    {
        if ((*it)->_name == name)
            ret = 1;
    }
    
    const_cast<Mutex*>(&(this->_mutex))->unlock();
    return (ret);
}



/**
** \fn void add_function(const std::string &name, const std::string &t_ret,
**                       const std::string &t_p1, const std::string &t_p2,
**                       const std::string &t_p3, const std::string &t_p4,
**                       const std::string &t_p5, const std::string &t_p6,
**                       const std::string &t_p7, const std::string &t_p8,
**                       const std::string &t_p9, const std::string &t_p10,
**                       const std::string &t_p11, const std::string &t_p12)
** \brief Gere l'ajout d'un prototype de fonction dans la liste
**
** \param name Nom de la fonction
** \param t_ret Type de retour de la fonction
* \param t_p1 Type du 1er parametre de la fonction
** \param t_p2 Type du 2eme parametre de la fonction
** \param t_p3 Type du 3eme parametre de la fonction
** \param t_p4 Type du 4eme parametre de la fonction
** \param t_p5 Type du 5eme parametre de la fonction
** \param t_p6 Type du 6eme parametre de la fonction
** \param t_p7 Type du 7eme parametre de la fonction
** \param t_p8 Type du 8eme parametre de la fonction
** \param t_p9 Type du 9eme parametre de la fonction
** \param t_p10 Type du 10eme parametre de la fonction
** \param t_p11 Type du 11eme parametre de la fonction
** \param t_p12 Type du 12eme parametre de la fonction
** \return Retourne rien
*/
void                 PrototypeF::add_function(const std::string &name, const std::string &t_ret,
                                      const std::string &t_p1, const std::string &t_p2,
                                      const std::string &t_p3, const std::string &t_p4,
                                      const std::string &t_p5, const std::string &t_p6,
                                      const std::string &t_p7, const std::string &t_p8,
                                      const std::string &t_p9, const std::string &t_p10,
                                      const std::string &t_p11, const std::string &t_p12)
{
    std::vector<std::string>    param;
    
    param.push_back(t_p1);
    param.push_back(t_p2);
    param.push_back(t_p3);
    param.push_back(t_p4);
    param.push_back(t_p5);
    param.push_back(t_p6);
    param.push_back(t_p7);
    param.push_back(t_p8);
    param.push_back(t_p9);
    param.push_back(t_p10);
    param.push_back(t_p11);
    param.push_back(t_p12);
    this->add_function(name, t_ret, param);
}

/**
** \fn void add_function(const std::string &name, const std::string &t_ret,
**                       const std::vector<std::string> &param)
** \brief Gere l'ajout d'un prototype de fonction dans la liste
**
** \param name Nom de la fonction
** \param t_ret Type de retour de la fonction
** \param param Tableau contenant les types des parametres
** \return Retourne rien
*/
void                 PrototypeF::add_function(const std::string &name, const std::string &t_ret,
                                              const std::vector<std::string> &param)
{
    std::vector< std::pair<std::string, std::string> >    type_and_name;
    
    for (unsigned long i=0; i<param.size(); i++)
        type_and_name.push_back(std::pair<std::string, std::string>(param[i], "p" + Calcul::ltos(i)));
    
    this->add_function(name, t_ret, type_and_name);
}

/**
** \fn void add_function(const std::string &name, const std::string &t_ret,
**                       const std::vector< std::pair<std::string, std::string> > &param)
** \brief Gere l'ajout d'un prototype de fonction dans la liste
**
** \param name Nom de la fonction
** \param t_ret Type de retour de la fonction
** \param param Tableau contenant les types et nom des parametres <type, nom>
** \return Retourne rien
*/
void                 PrototypeF::add_function(const std::string &name, const std::string &t_ret,
                                              const std::vector< std::pair<std::string, std::string> > &param)
{
    PrototypeF::ProtoFonction    *ptr;

    this->_mutex.lock();

    /* On ajoute le prototype que s'il a un nom */
    if (name.size() > 0)
    {
        /* Si une fonction ayant ce nom existe, on la supprime */
        for (std::list<PrototypeF::ProtoFonction*>::iterator it=this->_proto.begin();
             it!=this->_proto.end(); )
        {
            if ((*it)->_name == name)
            {
                delete (*it);
                this->_proto.erase(it);
                it = this->_proto.begin();
            }
            else
                it++;
        }
    
        /* Creation du nouveau prototype */
        if ((ptr = new PrototypeF::ProtoFonction) != NULL)
        {
            this->_proto.push_back(ptr);
            ptr->_name = name;
            ptr->_ret = t_ret;
            ptr->_param = param;

            /* Enleve les parametres vides */
            for (std::vector<std::pair<std::string, std::string> >::iterator it=ptr->_param.begin();
                 it!=ptr->_param.end(); )
            {
                if (it->first.size() <= 0)
                {
                    ptr->_param.erase(it);
                    it = ptr->_param.begin();
                }
                else
                    it++;
            }
        }
    }
        
    this->_mutex.unlock();
}

/**
** \fn void del_function(unsigned int num)
** \brief Gere la suppression d'un prototype de fonction
**
** \param name Nom de la fonction
** \return Retourne rien
*/
void                 PrototypeF::del_function(const std::string &name)
{
    this->_mutex.lock();

    for (std::list<PrototypeF::ProtoFonction*>::iterator it=this->_proto.begin();
         it!=this->_proto.end(); )
    {
        if ((*it)->_name == name)
        {
            delete (*it);
            this->_proto.erase(it);
            it = this->_proto.begin();
        }
        else
            it++;
    }

    this->_mutex.unlock();
}



/**
** \fn std::string get_ret(const std::string &name) const
** \brief Assesseur permettant d'acceder au type de retour d'une fonction
**
** \param name Nom de la fonction
** \return Retourne le type de retour de la fonction si OK, "" sinon
*/
std::string    PrototypeF::get_ret(const std::string &name) const
{
    std::string    ret;
    int            ok;
    
    const_cast<Mutex*>(&(this->_mutex))->lock();

    ok = 0;
    for (std::list<PrototypeF::ProtoFonction*>::const_iterator it=this->_proto.begin();
         (it!=this->_proto.end()) && (ok==0);
         it++)
    {
        if ((*it)->_name == name)
        {
            ret = (*it)->_ret;
            ok = 1;
        }
    }
    
    const_cast<Mutex*>(&(this->_mutex))->unlock();
    return (ret);
}

/**
** \fn unsigned long get_nbs_param(const std::string &name, unsigned int num_param) const
** \brief Assesseur permettant d'acceder au nombre de parametres d'une fonction
**
** \param name Nom de la fonction
** \param num Numero du parametre (commence a 0)
** \return Retourne le nombre de parametres de la fonction si OK, 0 sinon
*/
unsigned long    PrototypeF::get_nbs_param(const std::string &name) const
{
    unsigned long    ret;
    int              ok;
    
    const_cast<Mutex*>(&(this->_mutex))->lock();

    ok = 0;
    ret = 0;
    for (std::list<PrototypeF::ProtoFonction*>::const_iterator it=this->_proto.begin();
         (it!=this->_proto.end()) && (ok==0);
         it++)
    {
        if ((*it)->_name == name)
        {
            ret = (*it)->_param.size();
            ok = 1;
        }
    }
    
    const_cast<Mutex*>(&(this->_mutex))->unlock();
    return (ret);
}

/**
** \fn std::string get_type_param(const std::string &name, unsigned int num_param) const
** \brief Assesseur permettant d'acceder au type d'un parametre d'une fonction
**
** \param name Nom de la fonction
** \param num Numero du parametre (commence a 0)
** \return Retourne le type du parametre de la fonction si OK, "" sinon
*/
std::string    PrototypeF::get_type_param(const std::string &name, unsigned int num_param) const
{
    std::string    ret;
    int            ok;
    
    const_cast<Mutex*>(&(this->_mutex))->lock();

    ok = 0;
    for (std::list<PrototypeF::ProtoFonction*>::const_iterator it=this->_proto.begin();
         (it!=this->_proto.end()) && (ok==0);
         it++)
    {
        if ((*it)->_name == name)
        {
            if (num_param < (*it)->_param.size())
                ret = (*it)->_param[num_param].first;

            ok = 1;
        }
    }
    
    const_cast<Mutex*>(&(this->_mutex))->unlock();
    return (ret);
}

/**
** \fn std::string get_name_param(const std::string &name, unsigned int num_param) const
** \brief Assesseur permettant d'acceder au nom d'un parametre d'une fonction
**
** \param name Nom de la fonction
** \param num Numero du parametre (commence a 0)
** \return Retourne le type du parametre de la fonction si OK, "" sinon
*/
std::string    PrototypeF::get_name_param(const std::string &name, unsigned int num_param) const
{
    std::string    ret;
    int            ok;
    
    const_cast<Mutex*>(&(this->_mutex))->lock();

    ok = 0;
    for (std::list<PrototypeF::ProtoFonction*>::const_iterator it=this->_proto.begin();
         (it!=this->_proto.end()) && (ok==0);
         it++)
    {
        if ((*it)->_name == name)
        {
            if (num_param < (*it)->_param.size())
                ret = (*it)->_param[num_param].second;

            ok = 1;
        }
    }
    
    const_cast<Mutex*>(&(this->_mutex))->unlock();
    return (ret);
}


  
/**
** \fn std::string get_nbs() const
** \brief Assesseur permettant de connaitre le nombre de prototypes
**
** \return Retourne le nombre de prototypes
*/
unsigned long    PrototypeF::get_nbs() const
{
    unsigned long    ret;
    
    const_cast<Mutex*>(&(this->_mutex))->lock();
    
    ret = this->_proto.size();
    
    const_cast<Mutex*>(&(this->_mutex))->unlock();
    return (ret);
}
    
/**
** \fn unsigned long get_name_nbs(unsigned long n) const
** \brief Assesseur permettant de connaitre le nom d'un prototype
**
** \param n Numero du prototype
** \return Retourne le nom d'un prototype si OK, "" sinon
*/
std::string    PrototypeF::get_name_nbs(unsigned long n) const
{
    std::list<PrototypeF::ProtoFonction*>::const_iterator    it;
    std::string                                              ret;
    
    const_cast<Mutex*>(&(this->_mutex))->lock();
    
    ret = "";
    if (n < this->_proto.size())
    {
        it = this->_proto.begin();
        std::advance(it, n);
        
        ret = (*it)->_name;
    }
    
    const_cast<Mutex*>(&(this->_mutex))->unlock();
    return (ret);
}

/**
** \fn std::string get_ret_nbs(unsigned long n) const
** \brief Assesseur permettant de connaitre le type de retour d'un prototype
**
** \param n Numero du prototype
** \return Retourne le type de retour d'un prototype si OK, "" sinon
*/
std::string    PrototypeF::get_ret_nbs(unsigned long n) const
{
    std::list<PrototypeF::ProtoFonction*>::const_iterator    it;
    std::string                                              ret;
    
    const_cast<Mutex*>(&(this->_mutex))->lock();
    
    ret = "";
    if (n < this->_proto.size())
    {
        it = this->_proto.begin();
        std::advance(it, n);
        
        ret = (*it)->_ret;
    }
    
    const_cast<Mutex*>(&(this->_mutex))->unlock();
    return (ret);
}

/**
** \fn unsigned long get_nbs_param_nbs(unsigned long n) const
** \brief Assesseur permettant de connaitre le nombre de parametres d'un prototype
**
** \param n Numero du prototype
** \return Retourne le nombre de parametres d'un prototype si OK, 0 sinon
*/
unsigned long    PrototypeF::get_nbs_param_nbs(unsigned long n) const
{
    std::list<PrototypeF::ProtoFonction*>::const_iterator    it;
    unsigned long                                            ret;
    
    const_cast<Mutex*>(&(this->_mutex))->lock();
    
    ret = 0;
    if (n < this->_proto.size())
    {
        it = this->_proto.begin();
        std::advance(it, n);
        
        ret = (*it)->_param.size();
    }
    
    const_cast<Mutex*>(&(this->_mutex))->unlock();
    return (ret);
}

/**
** \fn std::string get_type_param_nbs(unsigned long n, unsigned long param) const
** \brief Assesseur permettant de connaitre le type d'un parametre de prototype
**
** \param n Numero du prototype
** \param param Numero du parametre
** \return Retourne le type d'un parametre de prototype si OK, "" sinon
*/
std::string    PrototypeF::get_type_param_nbs(unsigned long n, unsigned long param) const
{
    std::list<PrototypeF::ProtoFonction*>::const_iterator    it;
    std::string                                              ret;
    
    const_cast<Mutex*>(&(this->_mutex))->lock();
    
    ret = "";
    if (n < this->_proto.size())
    {
        it = this->_proto.begin();
        std::advance(it, n);
        
        if (param < (*it)->_param.size())
            ret = (*it)->_param[param].first;
    }
    
    const_cast<Mutex*>(&(this->_mutex))->unlock();
    return (ret);
}

/**
** \fn std::string get_name_param_nbs(unsigned long n, unsigned long param) const
** \brief Assesseur permettant de connaitre le nom d'un parametre de prototype
**
** \param n Numero du prototype
** \param param Numero du parametre
** \return Retourne le type d'un parametre de prototype si OK, "" sinon
*/
std::string    PrototypeF::get_name_param_nbs(unsigned long n, unsigned long param) const
{
    std::list<PrototypeF::ProtoFonction*>::const_iterator    it;
    std::string                                              ret;
    
    const_cast<Mutex*>(&(this->_mutex))->lock();
    
    ret = "";
    if (n < this->_proto.size())
    {
        it = this->_proto.begin();
        std::advance(it, n);
        
        if (param < (*it)->_param.size())
            ret = (*it)->_param[param].second;
    }
    
    const_cast<Mutex*>(&(this->_mutex))->unlock();
    return (ret);
}

