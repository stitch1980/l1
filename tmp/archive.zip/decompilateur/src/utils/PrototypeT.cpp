#include    "PrototypeT.hpp"


PrototypeT::ProtoType::AttributType::AttributType(): _type(""), _name(""), _nbs(0) {}
PrototypeT::ProtoType::AttributType::AttributType(const std::string &t, const std::string &n, unsigned long nbs): _type(t), _name(n), _nbs(nbs) {}
PrototypeT::ProtoType::AttributType::AttributType(const AttributType &a): _type(a._type), _name(a._name), _nbs(a._nbs) {}
        
        
        
        
/**
** \fn ProtoType()
** \brief Constructeur par defaut d'un descripteur de type
*/
PrototypeT::ProtoType::ProtoType():
    _attribut(),
    _size(0)
{
}

/**
** \fn ProtoType(unsigned long size)
** \brief Constructeur d'un descripteur de type simple (int, long, ...)
**
** \param size Taille du type
*/
PrototypeT::ProtoType::ProtoType(unsigned long size):
    _attribut(),
    _size(size)
{
}
        
/**
** \fn ProtoType(const std::vector<PrototypeT::ProtoType::AttributType> &attribut)
** \brief Constructeur d'un descripteur de type complexe (structure)
**
** \param attribut Tableau contenant le type des attributs et leur nom
*/
PrototypeT::ProtoType::ProtoType(const std::vector<PrototypeT::ProtoType::AttributType> &attribut):
    _attribut(attribut),
    _size(0)
{
}

        
/**
** \fn int is_valid(const std::map<std::string, PrototypeT::ProtoType*> &proto) const
** \brief Fonction permettant de savoir si un type est valide (taille correct, attribut definis...)
**
** \param proto Map contenant les definition de variables (pour les variables complexe)
** \return Retourne 1 si la definition de type est valide, 0 sinon
*/
int    PrototypeT::ProtoType::is_valid(const std::map<std::string, PrototypeT::ProtoType*> &proto) const
{
    std::map<std::string, PrototypeT::ProtoType*>::const_iterator    it_proto;

    /* Si c'est une structure, on verifie la validite de ses attributs */
    if (this->_attribut.size() > 0)
    {
        for (std::vector<PrototypeT::ProtoType::AttributType>::const_iterator it=this->_attribut.begin();
             it!=this->_attribut.end();
             it++)
        {
            if ((it_proto = proto.find(it->_type)) == proto.end())
                return (0);
            else if (it_proto->second->is_valid(proto) <= 0)
                return (0);
        }
    }
    else if (this->_size <= 0)
        return (0);

    return (1);
} 

        
/**
** \fn unsigned long get_size(const std::map<std::string, PrototypeT::ProtoType*> &proto) const
** \brief Fonction permettant de connaitre la taille de la variable en octets
**
** \param proto Map contenant les definition de variables (pour les variables complexe)
** \return Retourne la taille de la variable
*/
unsigned long    PrototypeT::ProtoType::get_size(const std::map<std::string, PrototypeT::ProtoType*> &proto) const
{
    std::map<std::string, PrototypeT::ProtoType*>::const_iterator    it_proto;
    unsigned long                                                    size;
    
    /* Taille de la variable en memoire */
    size = this->_size;
    
    /* Ajoute la taille de tous les attributs de la variables */
    for (std::vector<PrototypeT::ProtoType::AttributType>::const_iterator it=this->_attribut.begin();
         it!=this->_attribut.end();
         it++)
    {
        if ((it_proto = proto.find(it->_type)) != proto.end())
            size += (it_proto->second->get_size(proto) * it->_nbs);
    }
    
    return (size);
}
        
/**
** \fn unsigned long get_nbs_attribut() const
** \brief Permet de connaitre le nombre d'attribut d'une definition de variables complexe
**
** \return Retourne le nombre d'attributs de la dclaration si elle en a, 0 sinon
*/
unsigned long    PrototypeT::ProtoType::get_nbs_attribut() const
{
    return (this->_attribut.size());
}
        
/**
** \fn std::string get_type_attribut(unsigned long offset) const
** \brief Permet de connaitre le type d'un attribut (long, int)
**
** \param num Numero de l'attribut
** \return Retourne le type de l'attribut s'il existe, "" sinon 
*/
std::string      PrototypeT::ProtoType::get_type_attribut(unsigned long num) const
{
    if (num >= this->_attribut.size())
        return ("");
    return (this->_attribut[num]._type);
}
        
/**
** \fn std::string get_type_attribut(const std::string &name) const
** \brief Permet de connaitre le type d'un attribut (long, int)
**
** \param nom de l'attribut a identifier (x, poney)
** \return Retourne le type de l'attribut s'il existe, "" sinon 
*/
std::string      PrototypeT::ProtoType::get_type_attribut(const std::string &name) const
{
    for (std::vector<PrototypeT::ProtoType::AttributType>::const_iterator it=this->_attribut.begin();
         it!=this->_attribut.end();
         it++)
    {
        if (it->_name == name)
            return (it->_type);
    }
    return ("");
}
                                           
/**
** \fn std::string get_name_attribut(unsigned long offset) const
** \brief Permet de connaitre le nom d'un attribut (x, poney)
**
** \param num Numero de l'attribut
** \return Retourne le type de l'attribut s'il existe, "" sinon 
*/
std::string     PrototypeT::ProtoType::get_name_attribut(unsigned long num) const
{
    if (num >= this->_attribut.size())
        return ("");
    return (this->_attribut[num]._name);
}
                                           
/**
** \fn unsigned long get_nbs_element_attribut(unsigned long offset) const
** \brief Permet de connaitre le nombre d'element de l'attribut (utile pour les tableaux)
**
** \param num Numero de l'attribut
** \return Retourne le nombre d'element de l'attribut
*/
unsigned long     PrototypeT::ProtoType::get_nbs_element_attribut(unsigned long num) const
{
    if (num >= this->_attribut.size())
        return (0);
    return (this->_attribut[num]._nbs);
}




/**
** \fn PrototypeT()
** \brief Constructeur par defeut du gestionnaire de definition de variables
*/
PrototypeT::PrototypeT():
    _proto(),
    _mutex()
{
}

/**
** \fn ~PrototypeT()
** \brief Destructeur du gestionnaire de definition de variables
*/
PrototypeT::~PrototypeT()
{
    this->clear();
}


/**
** \fn void clear()
** \brief Gere la suppression de toutes les definitions
**
** \return Retourne rien
*/
void     PrototypeT::clear()
{
    this->_mutex.lock();
    
    for (std::map<std::string, PrototypeT::ProtoType*>::iterator it=this->_proto.begin();
         it!=this->_proto.end();
         it++)
        delete it->second;
    this->_proto.clear();

    this->_mutex.unlock();
}


/**
** \fn int exist(const std::string &name) const
** \brief Permet de savoir si un type existe
**
** \param name Type de la variable
** \return Retourne 1 si le type existe, 0 sinon
*/
int      PrototypeT::exist(const std::string &name) const
{
    int            ret;

    const_cast<Mutex*>(&(this->_mutex))->lock();

    ret = 0;
    if (PrototypeT::find(name, this->_proto, NULL) != NULL)
        ret = 1;

    const_cast<Mutex*>(&(this->_mutex))->unlock();
    return (ret);
}

/**
** \fn int is_valid(const std::string &name) const
** \brief Permet de savoir si un type est valide (taille correct, attribut definis...)
**
** \param name Type de la variable
** \return Retourne 1 si le type existe, 0 sinon
*/
int      PrototypeT::is_valid(const std::string &name) const
{
    PrototypeT::ProtoType    *ptr;
    int                      ret;

    const_cast<Mutex*>(&(this->_mutex))->lock();

    ret = 0;
    if ((ptr = PrototypeT::find(name, this->_proto, NULL)) != NULL)
    {
        if (ptr->is_valid(this->_proto))
            ret = 1;
    }

    const_cast<Mutex*>(&(this->_mutex))->unlock();
    return (ret);
}
    
/**
** \fn int can_be_an_attribute_of_struct(const std::string &type_base,
**                                       const std::string &typa_attr,
**                                       std::set<std::string> *liste_type=NULL) const
** \brief Permet de verifier si un attribut peut faire partie d'une structure de donnees
**
** \param type_base Type de la structure de donnees
** \param type_attr Type de l'attribut a verifier
** \param liste_type Liste des type pour savoir quel types sont interdit car deja utilise
** \return Retourne 1 si OK, 0 sinon
*/
int    PrototypeT::can_be_an_attribute_of_struct(const std::string &type_base,
                                     const std::string &type_attr,
                                     std::set<std::string> *liste_type) const
{
    int    ret;

    const_cast<Mutex*>(&(this->_mutex))->lock();
    ret = this->can_be_an_attribute_of_struct_unsafe(type_base, type_attr, liste_type);
    const_cast<Mutex*>(&(this->_mutex))->unlock();

    return (ret);
}


/**
** \fn void add_definition(const std::string &name, unsigned long size)
** \brief Gere l'ajout d'un definition de variable simple
**
** \param name Type de la variable (int, long, ...)
** \param size Taille de la variable en octet
** \return Retourne rien 
*/
void    PrototypeT::add_definition(const std::string &name, unsigned long size)
{
    PrototypeT::ProtoType    *ptr;

    this->_mutex.lock();

    /* Il faut que le nom soit valide */
    if (PrototypeT::get_token_name(name, 0).size() == name.size())
    {
        /* Suppression de la definition si elle existe deja */
        if (this->_proto.find(name) != this->_proto.end())
        {
            delete this->_proto.find(name)->second;
            this->_proto.erase(this->_proto.find(name));
        }
        
        /* Creation de la nouvelle definition */
        if ((ptr = new PrototypeT::ProtoType(size)) != NULL)
            this->_proto[name] = ptr;        
    }

    this->_mutex.unlock();
}
    
/**
** \fn void add_definition(const std::string &name,
**                                  const std::string &type0="", const std::string &name0="",
**                                  const std::string &type1="", const std::string &name1="",
**                                  const std::string &type2="", const std::string &name2="",
**                                  const std::string &type3="", const std::string &name3="",
**                                  const std::string &type4="", const std::string &name4="",
**                                  const std::string &type5="", const std::string &name5="",
**                                  const std::string &type6="", const std::string &name6="")
** \brief Gere l'ajout d'une definition de variable complexe (structure)
**
** \param name Type de la variable (int, long, ...)
** \param type0 Type du 1er attribut de la variable (int, Elf32_Ehdr, ...)
** \param name0 Nome du 1er attribut de la variable (x, poney, ...)
** \param type1 Type du 2eme attribut de la variable (int, Elf32_Ehdr, ...)
** \param name1 Nome du 2eme attribut de la variable (x, poney, ...)
** \param type2 Type du 3eme attribut de la variable (int, Elf32_Ehdr,  ...)
** \param name2 Nome du 3eme attribut de la variable (x, poney, ...)
** \param type3 Type du 4eme attribut de la variable (int, Elf32_Ehdr, ...)
** \param name3 Nome du 4eme attribut de la variable (x, poney, ...)
** \param type4 Type du 5eme attribut de la variable (int, Elf32_Ehdr, ...)
** \param name4 Nome du 5eme attribut de la variable (x, poney, ...)
** \param type5 Type du 6eme attribut de la variable (int, Elf32_Ehdr, ...)
** \param name5 Nome du 6eme attribut de la variable (x, poney, ...)
** \param type6 Type du 7eme attribut de la variable (int, Elf32_Ehdr, ...)
** \param name6 Nome du 7eme attribut de la variable (x, poney, ...)
** \return Retourne rien
*/
void                 PrototypeT::add_definition(const std::string &name,
                                        const std::string &type0, const std::string &name0,
                                        const std::string &type1, const std::string &name1,
                                        const std::string &type2, const std::string &name2,
                                        const std::string &type3, const std::string &name3,
                                        const std::string &type4, const std::string &name4,
                                        const std::string &type5, const std::string &name5,
                                        const std::string &type6, const std::string &name6)
{
    this->add_definition(name, type0, name0, 1,
                               type1, name1, 1,
                               type2, name2, 1,
                               type3, name3, 1,
                               type4, name4, 1,
                               type5, name5, 1,
                               type6, name6, 1);
}

/**
** \fn void add_definition(const std::string &name,
**                                  const std::string &type0="", const std::string &name0="", unsigned long nbs_elem0=1,
**                                  const std::string &type1="", const std::string &name1="", unsigned long nbs_elem1=1,
**                                  const std::string &type2="", const std::string &name2="", unsigned long nbs_elem2=1,
**                                  const std::string &type3="", const std::string &name3="", unsigned long nbs_elem3=1,
**                                  const std::string &type4="", const std::string &name4="", unsigned long nbs_elem4=1,
**                                  const std::string &type5="", const std::string &name5="", unsigned long nbs_elem5=1,
**                                  const std::string &type6="", const std::string &name6="", unsigned long nbs_elem6=1)
** \brief Gere l'ajout d'une definition de variable complexe (structure)
**
** \param name Type de la variable (int, long, ...)
** \param type0 Type du 1er attribut de la variable (int, Elf32_Ehdr, ...)
** \param name0 Nome du 1er attribut de la variable (x, poney, ...)
** \param nbs_elem0 Nombre d'element du 1er attribut
** \param type1 Type du 2eme attribut de la variable (int, Elf32_Ehdr, ...)
** \param name1 Nome du 2eme attribut de la variable (x, poney, ...)
** \param nbs_elem1 Nombre d'element du 2eme attribut
** \param type2 Type du 3eme attribut de la variable (int, Elf32_Ehdr,  ...)
** \param name2 Nome du 3eme attribut de la variable (x, poney, ...)
** \param nbs_elem2 Nombre d'element du 3eme attribut
** \param type3 Type du 4eme attribut de la variable (int, Elf32_Ehdr, ...)
** \param name3 Nome du 4eme attribut de la variable (x, poney, ...)
** \param nbs_elem3 Nombre d'element du 4eme attribut
** \param type4 Type du 5eme attribut de la variable (int, Elf32_Ehdr, ...)
** \param name4 Nome du 5eme attribut de la variable (x, poney, ...)
** \param nbs_elem4 Nombre d'element du 5eme attribut
** \param type5 Type du 6eme attribut de la variable (int, Elf32_Ehdr, ...)
** \param name5 Nome du 6eme attribut de la variable (x, poney, ...)
** \param nbs_elem5 Nombre d'element du 6eme attribut
** \param type6 Type du 7eme attribut de la variable (int, Elf32_Ehdr, ...)
** \param name6 Nome du 7eme attribut de la variable (x, poney, ...)
** \param nbs_elem6 Nombre d'element du 7eme attribut
** \return Retourne rien
*/
void                 PrototypeT::add_definition(const std::string &name,
                                        const std::string &type0, const std::string &name0, unsigned long nbs_elem0,
                                        const std::string &type1, const std::string &name1, unsigned long nbs_elem1,
                                        const std::string &type2, const std::string &name2, unsigned long nbs_elem2,
                                        const std::string &type3, const std::string &name3, unsigned long nbs_elem3,
                                        const std::string &type4, const std::string &name4, unsigned long nbs_elem4,
                                        const std::string &type5, const std::string &name5, unsigned long nbs_elem5,
                                        const std::string &type6, const std::string &name6, unsigned long nbs_elem6)
{
    std::vector<std::string>      type_attr;
    std::vector<std::string>      name_attr;
    std::vector<unsigned long>    nbs_elem_attr;

    /* Preparation des listes de type et de nom pour les attributs */
    if (type0.size() > 0)    { type_attr.push_back(type0); nbs_elem_attr.push_back(nbs_elem0); }
    if (type1.size() > 0)    { type_attr.push_back(type1); nbs_elem_attr.push_back(nbs_elem1); }
    if (type2.size() > 0)    { type_attr.push_back(type2); nbs_elem_attr.push_back(nbs_elem2); }
    if (type3.size() > 0)    { type_attr.push_back(type3); nbs_elem_attr.push_back(nbs_elem3); }
    if (type4.size() > 0)    { type_attr.push_back(type4); nbs_elem_attr.push_back(nbs_elem4); }
    if (type5.size() > 0)    { type_attr.push_back(type5); nbs_elem_attr.push_back(nbs_elem5); }
    if (type6.size() > 0)    { type_attr.push_back(type6); nbs_elem_attr.push_back(nbs_elem6); }
    
    if (type0.size() > 0)    name_attr.push_back(name0);
    if (type1.size() > 0)    name_attr.push_back(name1);
    if (type2.size() > 0)    name_attr.push_back(name2);
    if (type3.size() > 0)    name_attr.push_back(name3);
    if (type4.size() > 0)    name_attr.push_back(name4);
    if (type5.size() > 0)    name_attr.push_back(name5);
    if (type6.size() > 0)    name_attr.push_back(name6);

    PrototypeT::add_definition(name, type_attr, name_attr);
}

/**
** \fn void add_definition(const std::string &name,
**                         const std::vector<std::string> &type_attr,
**                         const std::vector<std::string> &name_attr)
** \brief Gere l'ajout d'une definition de variable complexe (structure)
**
** \param name Type de la variable (int, long, ...)
** \param type0 Tableau contenant le type des attributs de la variable (int, Elf32_Ehdr, ...)
** \param name0 Tableau contenant le nom attributs de la variable (x, poney, ...)
** \return Retourne rien
*/
void                 PrototypeT::add_definition(const std::string &name,
                                        const std::vector<std::string> &type_attr,
                                        const std::vector<std::string> &name_attr)
{
    std::vector<unsigned long>    nbs_elem_attr;
    
    nbs_elem_attr.resize(type_attr.size(), 1);
    this->add_definition(name, type_attr, name_attr, nbs_elem_attr);
}
                                        
/**
** \fn void add_definition(const std::string &name,
**                         const std::vector<std::string> &type_attr,
**                         const std::vector<std::string> &name_attr,
**                         const std::vector<unsigned long> &nbs_elem_attr)
** \brief Gere l'ajout d'une definition de variable complexe (structure)
**
** \param name Type de la variable (int, long, ...)
** \param type0 Tableau contenant le type des attributs de la variable (int, Elf32_Ehdr, ...)
** \param name0 Tableau contenant le nom attributs de la variable (x, poney, ...)
** \pram nbs_elem_attr Tableau contenant le nombre d'elements des attributs de la variable (x, poney, ...)
** \return Retourne rien
*/
void                 PrototypeT::add_definition(const std::string &name,
                                    const std::vector<std::string> &type_attr,
                                    const std::vector<std::string> &name_attr,
                                    const std::vector<unsigned long> &nbs_elem_attr)
{
    std::vector<std::string>::const_iterator             it_type;
    std::vector<std::string>::const_iterator             it_name;
    std::vector<unsigned long>::const_iterator           it_nbs_elem;
    std::vector<PrototypeT::ProtoType::AttributType>     attr;
    PrototypeT::ProtoType                                *ptr;

    this->_mutex.lock();

    /* Il faut que le nom soit valide */
    if (PrototypeT::get_token_name(name, 0).size() == name.size())
    {
        /* Suppression de la definition si elle existe deja */
        if (this->_proto.find(name) != this->_proto.end())
        {
            delete this->_proto.find(name)->second;
            this->_proto.erase(this->_proto.find(name));
        }
        
        /* Tous les types et noms des attributs doivent etre valide */
        if ((type_attr.size() == name_attr.size()) && (type_attr.size() == nbs_elem_attr.size()))
        {
            it_type = type_attr.begin();
            it_name = name_attr.begin();
            it_nbs_elem = nbs_elem_attr.begin();
            for ( ; it_type!=type_attr.end(); it_type++, it_name++, it_nbs_elem++)
            {
                /*
                ** Si un des noms est invalide -> erreur
                ** Si le nombre d'elements d'un des attributs < 1 -> erreur
                ** Si un des types est invalide -> erreur 
                ** Si un des types est egal au type de la definition -> erreur
                */
                if ((it_type->size() <= 0) || (BNFc::is_type_name(*it_type) != it_type->size()) ||
                    (it_name->size() <= 0) || (BNFc::is_var_name(*it_name) != it_name->size()) ||
                    ((*it_nbs_elem) <= 0) ||
                    (PrototypeT::get_token_name((*it_type), 0).size() != (*it_type).size()) ||
                    (this->_proto.find(*it_type) == this->_proto.end()) ||
                    (this->can_be_an_attribute_of_struct_unsafe(name, *it_type, NULL) <= 0))
                {
                    this->_mutex.unlock();
                    return ;
                }

                attr.push_back( PrototypeT::ProtoType::AttributType((*it_type), (*it_name), (*it_nbs_elem)) );
            }

            /* Creation de la nouvelle definition */
            if ((ptr = new PrototypeT::ProtoType(attr)) != NULL)
                this->_proto[name] = ptr;        
        }
    }

    this->_mutex.unlock();
}

/**
** \fn void del_definition(const std::string &name)
** \brief Gere la suppression de la definition d'une variable
**
** \param name Nom de la variable a supprimer (long, Elf32_Ehdr, Elf32_Ehdr)
** \return Retourne rien
*/
void           PrototypeT::del_definition(const std::string &name)
{
    std::map<std::string, PrototypeT::ProtoType*>::iterator    it;

    this->_mutex.lock();

    if ((it = this->_proto.find(name)) != this->_proto.end())
    {
        delete it->second;
        this->_proto.erase(it);
    }

    this->_mutex.unlock();
}


/**
** \fn unsigned long get_size(const std::string &name)
** \brief Gere la recuperation de la taille d'une variable
**
** \param name Nom de la variable (long, Elf32_Ehdr, Elf32_Ehdr.e_flags)
** \return Retourne la taille de la variable ou le l'attribut si OK, 0 sinon
*/
unsigned long        PrototypeT::get_size(const std::string &name) const
{
    PrototypeT::ProtoType    *ptr;
    unsigned long            ret;

    const_cast<Mutex*>(&(this->_mutex))->lock();
    
    ret = 0;
    if ((ptr = PrototypeT::find(name, this->_proto, NULL)) != NULL)
        ret = ptr->get_size(this->_proto);

    const_cast<Mutex*>(&(this->_mutex))->unlock();
    return (ret);
}

/**
** \fn unsigned long get_nbs_attribut(const std::string &name)
** \brief Gere la recuperation du nombre d'attributs d'une structure
**
** \param name Nom de la variable (long, Elf32_Ehdr, Elf32_Ehdr.e_flags)
** \return Retourne le nombre d'attribut de la structure si OK, 0 sinon
*/
unsigned long        PrototypeT::get_nbs_attribut(const std::string &name) const
{
    PrototypeT::ProtoType    *ptr;
    unsigned long            ret;

    const_cast<Mutex*>(&(this->_mutex))->lock();
    
    ret = 0;
    if ((ptr = PrototypeT::find(name, this->_proto, NULL)) != NULL)
        ret = ptr->get_nbs_attribut();

    const_cast<Mutex*>(&(this->_mutex))->unlock();
    return (ret);
}

/**
** \fn std::string get_type_attribut_num(const std::string &name, unsigned long num)
** \brief Gere la recuperation du type d'un attribut d'une structure
**
** \param name Nom de la variable (long, Elf32_Ehdr, Elf32_Ehdr.e_flags)
** \param num Numero de l'attribut dont le type nous interesse
** \return Retourne le type de l'attribut si OK, "" sinon
*/
std::string        PrototypeT::get_type_attribut_num(const std::string &name, unsigned long num) const
{
    PrototypeT::ProtoType    *ptr;
    std::string              ret;

    const_cast<Mutex*>(&(this->_mutex))->lock();

    if ((ptr = PrototypeT::find(name, this->_proto, NULL)) != NULL)
    {
        if (num < ptr->get_nbs_attribut())
            ret = ptr->get_type_attribut(num);
    }

    const_cast<Mutex*>(&(this->_mutex))->unlock();
    return (ret);
}

/**
** \fn std::string get_name_attribut_num(const std::string &name, unsigned long num)
** \brief Gere la recuperation du nom d'un attribut d'une structure
**
** \param name Nom de la variable (long, Elf32_Ehdr, Elf32_Ehdr.e_flags)
** \param num Numero de l'attribut dont le type nous interesse
** \return Retourne le type de l'attribut si OK, "" sinon
*/
std::string        PrototypeT::get_name_attribut_num(const std::string &name, unsigned long num) const
{
    PrototypeT::ProtoType    *ptr;
    std::string              ret;

    const_cast<Mutex*>(&(this->_mutex))->lock();

    if ((ptr = PrototypeT::find(name, this->_proto, NULL)) != NULL)
    {
        if (num < ptr->get_nbs_attribut())
            ret = ptr->get_name_attribut(num);
    }

    const_cast<Mutex*>(&(this->_mutex))->unlock();
    return (ret);
}

/**
** \fn unsigned long get_nbs_element_attribut_num(const std::string &name, unsigned long num)
** \brief Gere la recuperation du nombre d'elements d'un attribut d'une structure (utile pour les tableaux)
**
** \param name Nom de la variable (long, Elf32_Ehdr, Elf32_Ehdr.e_flags)
** \param num Numero de l'attribut dont le type nous interesse
** \return Retourne le nombre d'elements de l'attribut si OK, 0 sinon
*/
unsigned long        PrototypeT::get_nbs_element_attribut_num(const std::string &name, unsigned long num) const
{
    PrototypeT::ProtoType    *ptr;
    unsigned long            ret;

    const_cast<Mutex*>(&(this->_mutex))->lock();

    ret = 0;
    if ((ptr = PrototypeT::find(name, this->_proto, NULL)) != NULL)
    {
        if (num < ptr->get_nbs_attribut())
            ret = ptr->get_nbs_element_attribut(num);
    }

    const_cast<Mutex*>(&(this->_mutex))->unlock();
    return (ret);
}

/**
** \fn std::string get_type(const std::string &name)
** \brief Gere a recuperation du type d'une definition
**
** \param name Nom de la variable (long, Elf32_Ehdr, Elf32_Ehdr.e_flags)
** \return Retourne le type de la variable (int, char[2], Elf32_Ehdr) si OK, "" sinon
*/
std::string    PrototypeT::get_type(const std::string &name) const
{
    PrototypeT::ProtoType    *ptr;
    std::string              ret;

    const_cast<Mutex*>(&(this->_mutex))->lock();
    
    ret = "";
    if ((ptr = PrototypeT::find(name, this->_proto, NULL)) != NULL)
        ret = "merde";

    const_cast<Mutex*>(&(this->_mutex))->unlock();
    return (ret);
}




/**
** \fn unsigned long get_nbs_type() const
** \brief Permet de connaitre le nombre de types de variables definis
**
** \return Retourne le nombre de types de variables definis
*/
unsigned long     PrototypeT::get_nbs_type() const
{
    unsigned long            ret;

    const_cast<Mutex*>(&(this->_mutex))->lock();
    ret = this->_proto.size();
    const_cast<Mutex*>(&(this->_mutex))->unlock();

    return (ret);
}

/**
** \fn std::string get_type_num(unsigned long num)
** \brief Permet de connaitre le type (long, int, ...) d'une defintion du gestionnaire 
**
** \param num Numero de la definition
** \return Retourne retourne le type de la definition si OK, "" sinon
*/
std::string       PrototypeT::get_type_num(unsigned long num) const
{
    std::map<std::string, PrototypeT::ProtoType*>::const_iterator    it;
    std::string                                                      ret;

    const_cast<Mutex*>(&(this->_mutex))->lock();
    
    it = this->_proto.begin();
    std::advance(it, num);
    if (it != this->_proto.end())
        ret = it->first;

    const_cast<Mutex*>(&(this->_mutex))->unlock();

    return (ret);
}



/**
** \fn static std::string get_token_name(std::string &name, unsigned long offset=0)
** \brief Gere la recuperation d'un token de nom (retourne "s", "->" puis "x" pour "s->x")
**
** \param name Nom complet d'une variable ou dun attribut (long, Elf32_Ehdr.e_flags)
** \param offset Offset a partir duquel effectuer la recherche
** \return Retourne un token de nom, "." ou "->" si OK, "" sinon
*/
std::string    PrototypeT::get_token_name(const std::string &name, unsigned long offset)
{
    unsigned long    pos1;
    unsigned long    pos2;

    if (offset >= name.size())
        return ("");

    /* Si on commence par trouver un lien entre deux nom ("." ou "->") ou le retourne */
    if (name.find(".", offset) == offset)
        return (".");
    else if (name.find("->", offset) == offset)
        return ("->");

    /* Sinon, on determine la taille du token */
    if ((pos1 = name.find(".", offset)) == std::string::npos)
        pos1 = name.size();
    if ((pos2 = name.find("->", offset)) == std::string::npos)
        pos2 = name.size();
    if (pos2 < pos1)
        pos1 = pos2;

    /* On retourne le token */
    return (name.substr(offset, pos1 - offset));
}

/**
** \fn PrototypeT::ProtoType*    find(const std::string &name,
**                                    const std::map<std::string, PrototypeT::ProtoType*> &list_proto,
**                                    PrototypeT::ProtoType *last) const
** \brief Gere l'identification d'une definition grace a son nom 
**
** \param name Nom complet d'une variable ou dun attribut (long, Elf32_Ehdr.e_flags)
** \param list_proto Liste des prototypes
** \param last Prototype a retourner si on ne trouve rien
** \return Retourne Un pointeur sur la definition si on la trouve, NULL sinon
*/
PrototypeT::ProtoType*    PrototypeT::find(const std::string &name,
                               const std::map<std::string, PrototypeT::ProtoType*> &list_proto,
                               PrototypeT::ProtoType *last)
{
    std::map<std::string, PrototypeT::ProtoType*>::const_iterator    it;
    std::string                                                      token;
    unsigned long                                                    size;

    /* Recupere le nom de la definition */
    token = PrototypeT::get_token_name(name, 0);
    if ((token == ".") || (token == "->") || (token == ""))
        return (last);
    size = token.size();

    /* Si la definition n'existe pas, on retourne NULL */
    if ((it = list_proto.find(token)) == list_proto.end())
        return (NULL);

    /* Si il n'y a rien apres le type c'est que c'est ce type que l'ion cherchait */
    token = PrototypeT::get_token_name(name, size);
    if (token == "")
        return (it->second);
    size += token.size();

    /* Recupere le nom de l'attribut */
    token = PrototypeT::get_token_name(name, size);
    if (token == "")
        return (it->second);
    size += token.size();

    /* Identifie le type de variable associe a ce nom d'attribut */
    if ((token = it->second->get_type_attribut(token)) == "")
        return (NULL);
    
    /* Identifie l'attribut */
    return (find(token + name.substr(size, -1), list_proto, it->second));
}


    
/**
** \fn int can_be_an_attribute_of_struct_unsafe(const std::string &type_base,
**                                              const std::string &typa_attr,
**                                              std::set<std::string> *liste_type=NULL) const
** \brief Permet de verifier si un attribut peut faire partie d'une structure de donnees (non thread-safe)
**
** \param type_base Type de la structure de donnees
** \param type_attr Type de l'attribut a verifier
** \param liste_type Liste des type pour savoir quel types sont interdit car deja utilise
** \return Retourne 1 si OK, 0 sinon
*/
int    PrototypeT::can_be_an_attribute_of_struct_unsafe(const std::string &type_base,
                                     const std::string &type_attr,
                                     std::set<std::string> *liste_type) const
{
    std::set<std::string>                                            forbiden_types;
    std::map<std::string, PrototypeT::ProtoType*>::const_iterator    it_type;
    PrototypeT::ProtoType                                            *attribut;

    /* Si la liste des types interdits est NULL, on doit d'abord la creer grace aux attributs de la structure */
    if (liste_type == NULL)
    {
         /* Si le sous-attribut n'existe pas, il ne peut pas etre valide */
        if (this->_proto.find(type_attr) == this->_proto.end())
            return (0);
    
        /* Si le type de l'attribut est le meme que le type de la structure, il ne peut pas etre valide */
        if (type_base == type_attr)
            return (0);
        
        /* Recupere tout les types d'attributs interdits */
        liste_type = &forbiden_types;
        this->can_be_an_attribute_of_struct_unsafe("", type_attr, liste_type);
        
        /* Si le type de la structure correspond a un type interdit -> il ne peut pas etre valide */
        if (liste_type->find(type_base) != liste_type->end())
            return (0);

        /* Pour tout les types */
        for (it_type=this->_proto.begin(); it_type!=this->_proto.end(); it_type++)
        {
            attribut = it_type->second;
        
            /* Si le type contient la structure qui doit etre modifiee et que son type est interdit -> erreur */
            for (unsigned long i=0; i<attribut->get_nbs_attribut(); i++)
            {
                if ((attribut->get_type_attribut(i) == type_base) &&
                    (liste_type->find(it_type->first) != liste_type->end()))
                    return (0);
            }
        }
    }
    
    /* Sinon, on recupere tout les sous-attributs de la structure type_attr en recursif */
    else if ((it_type = this->_proto.find(type_attr)) != this->_proto.end())
    {
        attribut = it_type->second;
        
        for (unsigned long i=0; i<attribut->get_nbs_attribut(); i++)
        {
            /* Si le type du sous-attribut n'est pas deja dans la liste des types interdit, on le traite */
            if (liste_type->find(attribut->get_type_attribut(i)) == liste_type->end())
            {
                /* On ajoute le type du sous attribut a la liste des interdits et on le traite en recursif */
                liste_type->insert(attribut->get_type_attribut(i));
                this->can_be_an_attribute_of_struct_unsafe("", attribut->get_type_attribut(i), liste_type);
            }
        }
    }
    
    return (1);
}
