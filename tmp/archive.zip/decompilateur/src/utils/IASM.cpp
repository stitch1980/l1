#include    "IASM.hpp"
#include    "Info.hpp"
#include    "Contexte.hpp"
#include    "Calcul.hpp"

/**
** \fn InstrASM()
** \brief Constructeur d'une instruction ASM
*/
InstrASM::InstrASM():
    _address(0),
    _size(0),
    _type(0),
    _opcode(),
    _effect(),
    _contexte(NULL),
//    _addr_next_instr(0),
    _addr_next_instr_jump(),
    _next_instr(NULL),
    _prev_instr(NULL),
    
    
    __name(""),
    __address(0),
    __size(0),
    __prefix(),
    __dst(),
    __operande(),
    __effect(),
    __func_exec(NULL)
{
}
    
/**
** \fn ~InstrASM()
** \brief Destructeur d'une instruction
*/
InstrASM::~InstrASM()
{
    if (this->_contexte != NULL)
        delete this->_contexte;
}

/**
** \fn InstrASM(const InstrASM &)
** \brief Constructeur par copie d'une instruction ASM (inutilisable)
**
** \param i Instruction ASM a copier
*/
InstrASM::InstrASM(const InstrASM &):
    _address(0),
    _size(0),
    _type(0),
    _opcode(),
    _effect(),
    _contexte(NULL),
//    _addr_next_instr(0),
    _addr_next_instr_jump(),
    _next_instr(NULL),
    _prev_instr(NULL),
    
    
    __name(""),
    __address(0),
    __size(0),
    __prefix(),
    __dst(),
    __operande(),
    __effect(),
    __func_exec(NULL)
{
}

/**
** \fn InstrASM& operator = (const InstrASM &)
** \brief Surcharge de l'operateur = pour les instructions ASM (inutilisable)
**
** \param i Instruction ASM a copier
** \return Retourne une reference sur l'instruction ASM
*/
InstrASM&    InstrASM::operator = (const InstrASM &)
{
    return (*this);
}


/**
** \fn std::string to_asm(const Info *info) const
** \brief Gere la preparation de l'instruction ASM
**
** \param info Structure contenant les infos du programme (peut etre NULL)
** \return Retourne une string decrivant l'instruction (peut egalement contenir des commentaires)
*/
std::string    InstrASM::to_asm(const Info *info) const
{
    std::string    s;
    int            first;
    
    /* Prefixe */
    for (std::vector<std::string>::const_iterator it=this->__prefix.begin();
         it!=this->__prefix.end();
         it++)
        s += (*it) + " ";

    /* Nom de l'instruction */
    s += this->_opcode;

    if (info != NULL)
    {
        /* On regarde si les operandes semblent correspondre a un symbole (0x...) */
        first = 1;
        for (unsigned long i=0; i<this->__operande.size(); i++)
        {
            if ((this->__operande[i]._name.find("0x") == 0) &&
                (Calcul::xtol(&(this->__operande[i]._name.c_str()[2])) != 0) &&
                (info->sym.get_name(Calcul::xtol(&(this->__operande[i]._name.c_str()[2]))) != ""))
            {
                if (first == 1)
                    s += "\t# ";
                else
                    s += ", ";
                s += info->sym.get_name(Calcul::xtol(&(this->__operande[i]._name.c_str()[2])));
            }
        }  
    }
    return (s);
}




/**
** \fn IASM()
** \brief Constructeur par defaut du deassembleur
*/
IASM::IASM():
    _mutex()
{
}

/**
** \fn ~IASM()
** \brief Constructeur par defaut du deassembleur
*/
IASM::~IASM()
{
}

/**
** \fn IASM(const IASM&)
** \brief Constructeur par copie du deassembleur (inutilisable)
*/
IASM::IASM(const IASM&):
    _mutex()
{
}

/**
** \fn IASM& operator = (const IASM&)
** \brief Surcharge de l'operateur = pour les deassembleur
**
** \return Retourne une reference sur le deassembleur
*/
IASM&    IASM::operator = (const IASM&)
{
    return (*this);
}


/**
** \fn void get_name_and_mask_getter(const std::string &name, std::string &begin_mask,
**                                   std::string &name_parent, std::string &end_mask)
** \brief Fonction permettant au contexte de savoir comment acceder aux sous-registres
**
** \param name Nom du registre auquel acceder
** \param begin_mask String ou mettre le debut du masque a utiliser pour extraire la valeur du sous-registre de son parent
** \param name_parent String ou mettre le nom du registre parent (vaudra name s'il ny a pas de parent)
** \param end_mask String ou mettre la fin du masque a utiliser pour extraire la valeur du sous-registre de son parent
** \return Retourne rien
*/
void    IASM::get_name_and_mask_getter(const std::string &name, std::string &begin_mask,
                                       std::string &name_parent, std::string &end_mask)
{
    begin_mask.clear();
    name_parent = name;
    end_mask.clear();
}

/**
** \fn void get_name_and_mask_setter(const std::string &name, std::string &begin_mask,
**                                   std::string &name_parent, std::string &end_mask)
** \brief Fonction permettant au contexte de savoir comment modifier les sous-registres
**
** \param name Nom du registre auquel acceder
** \param begin_mask String ou mettre le debut du masque a utiliser pour extraire la valeur du sous-registre de son parent
** \param name_parent String ou mettre le nom du registre parent (vaudra name s'il ny a pas de parent)
** \param end_mask String ou mettre la fin du masque a utiliser pour extraire la valeur du sous-registre de son parent
** \return Retourne rien
*/
void    IASM::get_name_and_mask_setter(const std::string &name, std::string &begin_mask,
                                       std::string &name_parent, std::string &end_mask)
{
    begin_mask.clear();
    name_parent = name;
    end_mask.clear();
}
                                                
                                                
/**
** \fn std::string get_type_registre(const std::string &name,
**                                   const std::map<std::string, ContentContexte> &reg)
** \brief Fonction permettant d'acceder au type de contenu d'un registre
**
** \param name Nom du registre
** \param reg Map contenant les registres
** \return Retourne le type de contenu du registre si on le trouve, "" sinon
*/
std::string      IASM::get_type_registre(const std::string &name,
                                         const std::map<std::string, ContentContexte*> &reg)
{
    std::string   dest;
    
    return (this->get_type_registre(dest, name, reg));
}


