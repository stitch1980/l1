#ifndef        INFO_HPP_
#define        INFO_HPP_

#include    <cstdlib>
#include    <iostream>
#include    <map>
#include    <set>

#include    "Analyse.hpp"
#include    "Fonction.hpp"
#include    "ContentContexte.hpp"
#include    "IASM.hpp"
#include    "Mutex.h"
#include    "Plugin.hpp"
#include    "PrototypeF.hpp"
#include    "PrototypeS.hpp"
#include    "PrototypeT.hpp"
#include    "Section.hpp"
#include    "Symbole.hpp"

/**
** \class Info
** \brief Classe contenant toutes les infos a passer aux plugins lors de leurs executions
*/
class    Info
{
public:
    /**
    ** \class PtrUsefulFunc
    ** \brief Classe contenant les pointeurs de fonctions utile au deassemblage et a l'analyse
    */
    class    PtrUsefulFunc
    {
    public:
        static const char    *f_param_default(unsigned long) { return (NAME_PC); }
        static const char    *f_ret_default() { return (NAME_PC); }
        static const char    *f_num_default() { return (NAME_PC); }
        
    public:
        PtrUsefulFunc():
            deasm(NULL),
            f_param_func(NULL), f_ret_func(NULL),
            f_num_int(NULL),     f_param_int(NULL),     f_ret_int(NULL),
            f_num_syscall(NULL), f_param_syscall(NULL), f_ret_syscall(NULL)
        {
            this->clear();
        }
            
        void    clear()
        {
            if (this->deasm != NULL)
                delete this->deasm;
            this->deasm = NULL;
                
            this->f_param_func = &f_param_default;
            this->f_ret_func = &f_ret_default;
            this->f_num_int = &f_num_default;
            this->f_param_int = &f_param_default;
            this->f_ret_int = &f_ret_default;
            this->f_num_syscall = &f_num_default;
            this->f_param_syscall = &f_param_default;
            this->f_ret_syscall = &f_ret_default;
        }

    public:
        /** Gestionnaire permettant de deassembler les instructions ASM */
        IASM          *deasm;
        
        /** Fonction permettant de connaitre l'emplacement d'un parametre de fonction */
        const char    *(*f_param_func)(unsigned long);
        /** Fonction permettant de connaitre l'emplacement de la valeur de retour d'une fonction */
        const char    *(*f_ret_func)();
        
        /** Fonction permettant de connaitre l'emplacement d'un numero d'interruption */
        const char    *(*f_num_int)();
        /** Fonction permettant de connaitre l'emplacement d'un parametre d'interruption */
        const char    *(*f_param_int)(unsigned long);
        /** Fonction permettant de connaitre l'emplacement de la valeur de retour d'une interruption */
        const char    *(*f_ret_int)();
        
        /** Fonction permettant de connaitre l'emplacement d'un numero d'interruption */
        const char    *(*f_num_syscall)();
        /** Fonction permettant de connaitre l'emplacement d'un parametre de syscall */
        const char    *(*f_param_syscall)(unsigned long);
        /** Fonction permettant de connaitre l'emplacement de la valeur de retour d'un syscall */
        const char    *(*f_ret_syscall)();
    };
    
    /**
    ** \enum eOS
    ** \brief Enum permettant de decrire le type d'OS prevu pour l'executable
    */
    enum    eOS
    {
        OS_NONE,
        OS_SYSV,
        OS_HPUX,
        OS_NETBSD,
        OS_GNU,
        OS_LINUX,
        OS_SOLARIS,
        OS_AIX,
        OS_IRIX,
        OS_FREEBSD,
        OS_TRU64,
        OS_MODESTO,
        OS_OPENBSD,
        OS_ARM_AEABI,
        OS_ARM,
        OS_STANDALONE,
    };

    /**
    ** \enum eArchi
    ** \brief Enum permettant de decrire l'architecture prevu pour l'executable
    */
    enum eArchi
    {
        ARCHI_COREWAR,        /* Assembleur du corewar EPITECH */
        ARCHI_BRAINFUCK,      /* Assembleur Brainfuck standard */
        ARCHI_I16,
        ARCHI_I32,
        ARCHI_I64,
        
        
        ARCHI_M32,            /* AT&T WE 32100 */
        ARCHI_SPARC,          /* SUN SPARC */
        ARCHI_68K,            /* Motorola m68k family */
        ARCHI_88K,            /* Motorola m88k family */
        ARCHI_860,            /* Intel 80860 */
        ARCHI_MIPS,           /* MIPS R3000 big-endian */
        ARCHI_S370,           /* IBM System/370 */
        ARCHI_MIPS_RS3_LE,    /* MIPS R3000 little-endian */
        ARCHI_PARISC,         /* HPPA */
        ARCHI_VPP500,         /* Fujitsu VPP500 */
        ARCHI_SPARC32PLUS,    /* Sun's "v8plus" */
        ARCHI_960,            /* Intel 80960 */
        ARCHI_PPC,            /* PowerPC */
        ARCHI_PPC64,          /* PowerPC 64-bit */
        ARCHI_S390,           /* IBM S390 */
        ARCHI_V800,           /* NEC V800 series */
        ARCHI_FR20,           /* Fujitsu FR20 */
        ARCHI_RH32,           /* TRW RH-32 */
        ARCHI_RCE,            /* Motorola RCE */
        ARCHI_ARM,            /* ARM */
        ARCHI_FAKE_ALPHA,     /* Digital Alpha */
        ARCHI_SH,             /* Hitachi SH */
        ARCHI_SPARCV9,        /* SPARC v9 64-bit */
        ARCHI_TRICORE,        /* Siemens Tricore */
        ARCHI_ARC,            /* Argonaut RISC Core */
        ARCHI_H8_300,         /* Hitachi H8/300 */
        ARCHI_H8_300H,        /* Hitachi H8/300H */
        ARCHI_H8S,            /* Hitachi H8S */
        ARCHI_H8_500,         /* Hitachi H8/500 */
        ARCHI_IA_64,          /* Intel Merced */
        ARCHI_MIPS_X,         /* Stanford MIPS-X */
        ARCHI_COLDFIRE,       /* Motorola Coldfire */
        ARCHI_68HC12,         /* Motorola M68HC12 */
        ARCHI_MMA,            /* Fujitsu MMA Multimedia Accelerator*/
        ARCHI_PCP,            /* Siemens PCP */
        ARCHI_NCPU,           /* Sony nCPU embeeded RISC */
        ARCHI_NDR1,           /* Denso NDR1 microprocessor */
        ARCHI_STARCORE,       /* Motorola Start*Core processor */
        ARCHI_ME16,           /* Toyota ME16 processor */
        ARCHI_ST100,          /* STMicroelectronic ST100 processor */
        ARCHI_TINYJ,          /* Advanced Logic Corp. Tinyj emb.fam*/
        ARCHI_X86_64,         /* AMD x86-64 architecture */
        ARCHI_PDSP,           /* Sony DSP Processor */
        ARCHI_FX66,           /* Siemens FX66 microcontroller */
        ARCHI_ST9PLUS,        /* STMicroelectronics ST9+ 8/16 mc */
        ARCHI_ST7,            /* STmicroelectronics ST7 8 bit mc */
        ARCHI_68HC16,         /* Motorola MC68HC16 microcontroller */
        ARCHI_68HC11,         /* Motorola MC68HC11 microcontroller */
        ARCHI_68HC08,         /* Motorola MC68HC08 microcontroller */
        ARCHI_68HC05,         /* Motorola MC68HC05 microcontroller */
        ARCHI_SVX,            /* Silicon Graphics SVx */
        ARCHI_ST19,           /* STMicroelectronics ST19 8 bit mc */
        ARCHI_VAX,            /* Digital VAX */
        ARCHI_CRIS,           /* Axis Communications 32-bit embedded processor */
        ARCHI_JAVELIN,        /* Infineon Technologies 32-bit embedded processor */
        ARCHI_FIREPATH,       /* Element 14 64-bit DSP Processor */
        ARCHI_ZSP,            /* LSI Logic 16-bit DSP Processor */
        ARCHI_MMIX,           /* Donald Knuth's educational 64-bit processor */
        ARCHI_HUANY,          /* Harvard University machine-independent object files */
        ARCHI_PRISM,          /* SiTera Prism */
        ARCHI_AVR,            /* Atmel AVR 8-bit microcontroller */
        ARCHI_FR30,           /* Fujitsu FR30 */
        ARCHI_D10V,           /* Mitsubishi D10V */
        ARCHI_D30V,           /* Mitsubishi D30V */
        ARCHI_V850,           /* NEC v850 */
        ARCHI_M32R,           /* Mitsubishi M32R */
        ARCHI_MN10300,        /* Matsushita MN10300 */
        ARCHI_MN10200,        /* Matsushita MN10200 */
        ARCHI_PJ,             /* picoJava */
        ARCHI_OPENRISC,       /* OpenRISC 32-bit embedded processor */
        ARCHI_ARC_A5,         /* ARC Cores Tangent-A5 */
        ARCHI_XTENSA,         /* Tensilica Xtensa Architecture */
        ARCHI_NONE
    };

    /**
    ** \enum eFormat
    ** \brief Enum permettant de decrire le format de l'executable
    */
    enum eFormat
    {
        FORMAT_COREWAR,        /* Format d'executables du corewar EPITECH */
        FORMAT_BRAINFUCK,
        FORMAT_ELF32,
        FORMAT_ELF64,
        FORMAT_DOS,
        FORMAT_PE32,
        FORMAT_PE64,
        FORMAT_MBR,
        FORMAT_NONE
    };

    /**
    ** \enum eEndian
    ** \brief Enum permettant de decrire l'endian de l'executable
    */
    enum eEndian
    {
        ENDIAN_LITTLE,
        ENDIAN_BIG,
        ENDIAN_NONE
    };

public:
    /**
    ** \fn Info()
    ** \brief Constructeur par defaut de la classe Info
    */
    Info();

    /**
    ** \fn ~Info()
    ** \brief Destructeur par defaut de la classe Info
    */
    ~Info();

private:
    /**
    ** \fn Info(const Info &i)
    ** \brief Constructeur par copie de la classe Info (Inutilisable)
    */
    Info(const Info &);

    /**
    ** \fn Info& operator = (const Info &)
    ** \brief Surcharge de l'operateur = pour la classe Info (Inutilisable)
    */
    Info&    operator = (const Info &);

public:
    /**
    ** \fn void clear()
    ** \brief Gere la suppression des infos du fichier a analyser
    **
    ** \return Retourne rien
    */
    void    clear();

    /**
    ** \fn void clear_plugin()
    ** \brief Gere la suppression des plugins.
    **
    ** \return Retourne rien
    */
    void    clear_plugin();

    /**
    ** \fn void clear_file()
    ** \brief Gere la suppression du contenu du fichier
    **
    ** \return Retourne rien
    */
    void    clear_file();

    /**
    ** \fn void clear_segment()
    ** \brief Gere la suppression des segments, symboles et points d'entrees
    **
    ** \return Retourne rien
    */
    void    clear_segment();

    /**
    ** \fn void clear_function()
    ** \brief Gere la suppression des fonctions decompilees
    **
    ** \return Retourne rien
    */
    void    clear_function();

    /**
    ** \fn void clear_proto()
    ** \brief Gere la suppression des definitions, interruption, ...
    **
    ** \return Retourne rien
    */
    void    clear_proto();

    /**
    ** \fn void clear_analyse()
    ** \brief Gere la suppression des analyse ayant ete faites par les plugins
    **
    ** \return Retourne rien
    */
    void    clear_analyse();

public:
    /** Set des plugins a utiliser */
    std::map<std::string, Plugin*>                                plugin;
    /** Tableau contenant les options a faire passer aux plugins */
    std::map<std::string, std::map<std::string, std::string> >    option_plugin;

    /** Nom de l'executable a analyser */
    std::string                            filename;
    /** Contenu du fichier */
    unsigned char                          *data;
    /** Taille du fichier */
    unsigned long                          size;

    /** Systeme prevu pour l'executable */
    Info::eOS                              os;
    /** Architecture prevue pour l'executable */
    Info::eArchi                           archi;
    /** Format de l'executable */
    Info::eFormat                          format;
    /** Type d'endian de l'executable */
    Info::eEndian                          endian;
    /** Adresses des points d'entrees a partir dequels analyser le programme */
    std::set<unsigned long>                entry;
    /** Classe contenant les sections de l'executable une fois mappees en memoire */
    Section                                sec;
    /** Classe contenant les symboles de l'executable */
    Symbole                                sym;

    /** Tableau contenant les fonctions deassemblee indexee grace a leur adresse */
    std::map<unsigned long, Fonction *>    function;

    /** Map pouvant contenir la valeur, la taille et le type des registres au debut de chaque fonction */
    /** (cela permet de pouvoir "personnaliser" le contexte d'execution au lancement des fonctions) */
    std::map<unsigned long, std::map<std::string, ContentContexte> >    value_of_register_at_begining_of_function;

    /** Classe contenant les pointeurs de fonctions utile au deassemblage et a l'analyse */
    PtrUsefulFunc                          ptr_func;

    /** Classe contenant la table des interruptions SYSCALL */
    Syscall                                syscall;
    /** Classe contenant la table des interruptions INT */
    Syscall                                interrupt;
    /** Classe contenant la table des prototypes de fonctions */
    PrototypeF                             proto_func;
    /** Classe contenant la table des definitions de structures */
    PrototypeT                             proto_var;
    
    /** Gestionnaire de resultats d'analyse */
    Analyse                                analyses;
    
    /** Mutex permettant d'utiliser la structure de maniere plus sure */
    Mutex                                  mutex;
};

#endif

