#ifndef    CONTEXTE_HPP_
#define    CONTEXTE_HPP_

#include    <string>
#include    <map>

#include    "ContentContexte.hpp"
#include    "Info.hpp"
#include    "Mutex.h"


/**
** \class Contexte
** \brief Classe gerant le contexte d'execution lors de la pseudo-execution d'instructions ASM
** (tread-safe)
*/
class    Contexte
{
public:
    /**
    ** \fn Contexte()
    ** \brief Constructeur par defaut d'un contexte d'execution
    */
    Contexte();

    /**
    ** \fn Contexte(const Contexte &c)
    ** \brief Constructeur par copie d'un contexte d'execution
    **
    ** \param c Contexte d'execution a copier
    */
    Contexte(const Contexte &c);

    /**
    ** \fn ~Contexte()
    ** \brief Destructeur d'un contexte d'execution
    */
    ~Contexte();


    /**
    ** \fn Contexte &operator = (const Contexte &c);
    ** \brief Surcharge de l'operateur = pour les contextes d'execution
    **
    ** \param c Contexte d'execution a copier
    ** \return Retourne une reference sur le contexte d'execution
    */
    Contexte    &operator = (const Contexte &c);


    /**
    ** \fn void copy(const Contexte &c)
    ** \brief Gere la copie du contexte "c" (tout les content sont copies et les
    **        conexions sont faites avec les parents/enfants)
    **
    ** \param c Contexte d'execution a copier
    ** \return Retourne rien
    */
    void    copy(const Contexte &c);
    void    concatene(const Contexte &c);
    void    remove();
    int     is_it_different(const Contexte &c) const;

    /*
    ** - Les fonctions "set_content*(...)" cree un nouveau ContentContexte en
    **   supprimant le Content present a l'adresse indiquee s'il y en a un.
    ** - Les fonctions "del_content*(const std::string &addr)" supprime de Content
    **   present a l'adresse indiquee s'il y en a un.
    ** - Les fonctions "*_safe(...)" partent du principe que l'adresse indiquee
    **   est correcte: elle sont donc plus rapide que les autres qui doivent
    **   d'abord traiter l'adresse a utiliser pour localiser les Contents.
    */
    void               set_content(const std::string &addr,
                                   unsigned long size, const std::string &type,
                                   const std::set<std::string> &value,
                                   const std::set<std::string> &filter,
                                   const Info *info);
    void               del_content(const std::string &addr, const Info *info);

    /*
    ** Permet d'acceder a la liste des Contents du Contexte. Cette fonction ne lock pas de mutex.
    */
    const std::map<std::string, ContentContexte*>    &get_content() const;

    /*
    ** - Les fonctions "get_size*(...)" permettent de connaitre la taille d'un Content dans le contexte
    **   courant. Si le Content n'existe pas dans le contexte, il est cherche dans les Contexte-parents.
    **   S'il n'existe pas non plus dans les Contexte-parents, un Content est cree a partir du contenu des segments.
    **   S'il n'est pas dans les segments, retourne 0.
    ** - Les fonctions "get_type*(...)" permettent de connaitre le type d'un Content dans le contexte
    **   courant. Si le Content n'existe pas dans le contexte, il est cherche dans les Contexte-parents.
    **   S'il n'existe pas non plus dans les Contexte-parents, un Content est cree a partir du contenu des segments.
    **   S'il n'est pas dans les segments, retourne "".
    ** - Les fonctions "get_values*(...)" permettent de connaitre les valeurs possibles d'un Content dans le contexte
    **   courant. Si le Content n'existe pas dans le contexte, il est cherche dans les Contexte-parents.
    **   S'il n'existe pas non plus dans les Contexte-parents, un Content est cree a partir du contenu des segments.
    **   S'il n'est pas dans les segments, retourne un vector vide.
    ** - Les fonctions "get_filters*(...)" permettent de connaitre les filtres d'un Content dans le contexte
    **   courant. Si le Content n'existe pas dans le contexte, il est cherche dans les Contexte-parents.
    **   S'il n'existe pas non plus dans les Contexte-parents, un Content est cree a partir du contenu des segments.
    **   S'il n'est pas dans les segments, retourne un vector vide.
    ** - Les fonctions "*_safe(...)" partent du principe que l'adresse indiquee
    **   est correcte: elle sont donc plus rapide que les autres qui doivent
    **   d'abord traiter l'adresse a utiliser pour localiser les Contents.
    */
    unsigned long            get_size(const std::string &addr, const Info *info=NULL) const;
    std::string              &get_type(std::string &t, const std::string &addr, const Info *info=NULL) const;
    std::set<std::string>    &get_values(std::set<std::string> &v, const std::string &addr, const Info *info=NULL) const;
    std::set<std::string>    &get_filters(std::set<std::string> &f, const std::string &addr, const Info *info=NULL) const;

    /*
    ** - Les fonctions "set_size*(...)" modifie la taille d'un Content dans le contexte
    **   courant. Le content est cree s'il n'existait pas deja. S'il etait seulement
    **   definie dans les Contextes-parents, toutes ses autres informations sont copiees.
    ** - Les fonctions "set_type*(...)" modifie le type d'un Content dans le contexte
    **   courant. Le content est cree s'il n'existait pas deja. S'il etait seulement
    **   definie dans les Contextes-parents, toutes ses autres informations sont copiees.
    ** - Les fonctions "set_values*(...)" modifie les valeurs d'un Content dans le contexte
    **   courant. Le content est cree s'il n'existait pas deja. S'il etait seulement
    **   definie dans les Contextes-parents, toutes ses autres informations sont copiees.
    ** - Les fonctions "set_filters*(...)" modifie les filtres d'un Content dans le contexte
    **   courant. Le content est cree s'il n'existait pas deja. S'il etait seulement
    **   definie dans les Contextes-parents, toutes ses autres informations sont copiees.
    ** - Les fonctions "*_safe(...)" partent du principe que l'adresse indiquee
    **   est correcte: elle sont donc plus rapide que les autres qui doivent
    **   d'abord traiter l'adresse a utiliser pour localiser les Contents.
    */
    void    set_size(unsigned long s, const std::string &addr, const Info *info=NULL);
    void    set_type(const std::string &t, const std::string &addr, const Info *info=NULL);
    void    set_value(const std::string &v, const std::string &addr, const Info *info=NULL);
    void    set_values(const std::set<std::string> &v, const std::string &addr, const Info *info=NULL);
    void    set_filters(const std::set<std::string> &f, const std::string &addr, const Info *info=NULL);

    /*
    ** - Les fonctions "get_parent()" et "get_child()" permettent d'acceder a la liste
    **   des Contextes proches. Ces fonctions ne lock pas de mutex.
    ** - Les fonctions "add_parent(Contexte *c)" et "add_child(Contexte *c)"
    **   ajoutent le pointeur passe en parametre a la liste des Comtextes proches
    **   uniquement si le pointeur n'est pas NULL et n'est pas deje present dans la liste.
    ** - Les fonctions "del_parent(Contexte *c)" et "del_child(Contexte *c)" enelevent
    **   le pointeur passe en parametre de la liste des Contextes-proches. Le Contexte
    **   passe en parametre n'est pas reelement supprime
    ** - Les fonctions "del_all_parent()" et "del_all_child()" vident les liste de
    **   pointeur de Contextes-proches sans supprimer ces contextes.
    */
    const std::set<Contexte*>    &get_parent() const;
    const std::set<Contexte*>    &get_child() const;
    void                         add_parent(Contexte *c);
    void                         add_child(Contexte *c);
    void                         del_parent(Contexte *c);
    void                         del_child(Contexte *c);
    void                         del_all_parent();
    void                         del_all_child();

protected:

    /*
    ** - Les fonctions "set_content*(...)" cree un nouveau ContentContexte en
    **   supprimant le Content present a l'adresse indiquee s'il y en a un.
    ** - Les fonctions "del_content*(const std::string &addr)" supprime de Content
    **   present a l'adresse indiquee s'il y en a un.
    ** - Les fonctions "*_safe(...)" partent du principe que l'adresse indiquee
    **   est correcte: elle sont donc plus rapide que les autres qui doivent
    **   d'abord traiter l'adresse a utiliser pour localiser les Contents.
    */
    void               set_content_safe(const std::string &addr,
                                        unsigned long size, const std::string &type,
                                        const std::set<std::string> &value,
                                        const std::set<std::string> &filter);
    void               del_content_safe(const std::string &addr);

    /*
    ** - Les fonctions "get_size*(...)" permettent de connaitre la taille d'un Content dans le contexte
    **   courant. Si le Content n'existe pas dans le contexte, il est cherche dans les Contexte-parents.
    **   S'il n'existe pas non plus dans les Contexte-parents, un Content est cree a partir du contenu des segments.
    **   S'il n'est pas dans les segments, retourne 0.
    ** - Les fonctions "get_type*(...)" permettent de connaitre le type d'un Content dans le contexte
    **   courant. Si le Content n'existe pas dans le contexte, il est cherche dans les Contexte-parents.
    **   S'il n'existe pas non plus dans les Contexte-parents, un Content est cree a partir du contenu des segments.
    **   S'il n'est pas dans les segments, retourne "".
    ** - Les fonctions "get_values*(...)" permettent de connaitre les valeurs possibles d'un Content dans le contexte
    **   courant. Si le Content n'existe pas dans le contexte, il est cherche dans les Contexte-parents.
    **   S'il n'existe pas non plus dans les Contexte-parents, un Content est cree a partir du contenu des segments.
    **   S'il n'est pas dans les segments, retourne un vector vide.
    ** - Les fonctions "get_filters*(...)" permettent de connaitre les filtres d'un Content dans le contexte
    **   courant. Si le Content n'existe pas dans le contexte, il est cherche dans les Contexte-parents.
    **   S'il n'existe pas non plus dans les Contexte-parents, un Content est cree a partir du contenu des segments.
    **   S'il n'est pas dans les segments, retourne un vector vide.
    ** - Les fonctions "*_safe(...)" partent du principe que l'adresse indiquee
    **   est correcte: elle sont donc plus rapide que les autres qui doivent
    **   d'abord traiter l'adresse a utiliser pour localiser les Contents.
    */
    unsigned long            get_size_safe(const std::string &addr, const Info *info=NULL) const;
    std::string              &get_type_safe(std::string &t, const std::string &addr, const Info *info=NULL) const;
    std::set<std::string>    &get_values_safe(std::set<std::string> &v, const std::string &addr, const Info *info=NULL) const;
    std::set<std::string>    &get_filters_safe(std::set<std::string> &f, const std::string &addr, const Info *info=NULL) const;
    
    /*
    ** - Les fonctions "set_size*(...)" modifie la taille d'un Content dans le contexte
    **   courant. Le content est cree s'il n'existait pas deja. S'il etait seulement
    **   definie dans les Contextes-parents, toutes ses autres informations sont copiees.
    ** - Les fonctions "set_type*(...)" modifie le type d'un Content dans le contexte
    **   courant. Le content est cree s'il n'existait pas deja. S'il etait seulement
    **   definie dans les Contextes-parents, toutes ses autres informations sont copiees.
    ** - Les fonctions "set_values*(...)" modifie les valeurs d'un Content dans le contexte
    **   courant. Le content est cree s'il n'existait pas deja. S'il etait seulement
    **   definie dans les Contextes-parents, toutes ses autres informations sont copiees.
    ** - Les fonctions "set_filters*(...)" modifie les filtres d'un Content dans le contexte
    **   courant. Le content est cree s'il n'existait pas deja. S'il etait seulement
    **   definie dans les Contextes-parents, toutes ses autres informations sont copiees.
    ** - Les fonctions "*_safe(...)" partent du principe que l'adresse indiquee
    **   est correcte: elle sont donc plus rapide que les autres qui doivent
    **   d'abord traiter l'adresse a utiliser pour localiser les Contents.
    */
    void    set_size_safe(unsigned long s, const std::string &addr, const Info *info=NULL);
    void    set_type_safe(const std::string &t, const std::string &addr, const Info *info=NULL);
    void    set_values_safe(const std::set<std::string> &v, const std::string &addr, const Info *info=NULL);
    void    set_filters_safe(const std::set<std::string> &f, const std::string &addr, const Info *info=NULL);

protected:
    ContentContexte    *find_content(const std::string &addr, const Info *info, unsigned long profondeur) const;
    ContentContexte    *find_content_no_mutex(const std::string &addr, const Info *info, unsigned long profondeur) const;

protected:
    /** Map contenant les valeurs elements du contexte indexes par leur emplacement */
    std::map<std::string, ContentContexte*>    _content;
    
    /** Liste des parents du contexte */
    std::set<Contexte*>                        _parents;
    /** Liste des enfants du contexte */
    std::set<Contexte*>                        _child;
    

    /** Mutex permettant d'avoir un contexte thread-safe */
    Mutex                                       _mutex;
};

#endif

