#include    "BNFc.hpp"


/*
** Tableau contenant les mots-clef du langage
*/
const char    *keyword[] =
{
    "if", "do", "while", "until", "for",
    NULL
};


/**
** \fn unsigned long is_type_name(const std::string &s)
** \brief Gere l'identification des noms de types
**
** \param str Chaine a analyser
** \return Retourne la taille du token si on le trouve
*/
unsigned long    BNFc::is_type_name(const std::string &s)
{
    return (BNFc::is_var_name(s));
}

/**
** \fn unsigned long is_var_name(const std::string &s)
** \brief Gere l'identification des noms de variables
**
** \param str Chaine a analyser
** \return Retourne la taille du token si on le trouve
*/
unsigned long    BNFc::is_var_name(const std::string &s)
{
    unsigned long    i;

    if (BNFc::is_keyword(s) != 0)
        return (0);

    if ((isalpha(s[0]) == 0) && (s[0] != '_'))
        return (0);

    i = 1;
    while ((isalnum(s[i]) != 0) || (s[i] == '_'))
        i++;
    return (i);
}

/**
** \fn unsigned long is_keyword(const std::string &s)
** \brief Gere l'identification des mots-clef du langage
**
** \param str Chaine a analyser
** \return Retourne la taille du token si on le trouve
*/
unsigned long    BNFc::is_keyword(const std::string &s)
{
    unsigned long    size;

    for (unsigned long i=0; keyword[i]!=NULL; i++)
    {
        size = strlen(keyword[i]);
 
        if ((s.find(keyword[i]) == 0) && (isalnum(s[size]) == 0) && (s[size] != '_'))
            return (size);
    }
    
    return (0);
}

