#include	"Fonction.hpp"
#include	"Info.hpp"
#include	"Calcul.hpp"



/**
** \fn static std::string get_name_function(const Fonction *f, const Info *info)
** \brief Fonction permettant de recuperer ou de generer le nom d'une fonction a partir des symboles
**
** \param f Fonction dont le nom est a trouver
** \param info Structure contenant les infos du programme a analyser
** \return Retourne le nom de la fonction si on le trouve dans les symboles, "func_<adress>" sinon
*/
std::string    Fonction::get_name_function(const Fonction *f, const Info *info)
{
    if (f == NULL)
        return ("func_0");
    return (Fonction::get_name_function(f->get_addr(), info));
}
    
/**
** \fn static std::string get_name_function(unsigned long addr, const Info *info)
** \brief Fonction permettant de recuperer ou de generer le nom d'une fonction a partir des symboles
**
** \param addr adresse de la fonction dont le nom est a trouver
** \param info Structure contenant les infos du programme a analyser
** \return Retourne le nom de la fonction si on le trouve dans les symboles, "func_<adress>" sinon
*/
std::string    Fonction::get_name_function(unsigned long addr, const Info *info)
{
    std::string    str;

    if (info == NULL)
        return ("func_" + Calcul::ltox(addr));
        
    str = info->sym.get_name(addr);
    if (str.size() > 0)
       return (str);
    
    return ("func_" + Calcul::ltox(addr));
}
    
    
    
/**
** \fn Bloc()
** \brief Constructeur par defaut d'un bloc
*/
Fonction::Bloc::Bloc():
    _description(),
    _entry(NULL),
    _list_instr(),
    _mutex()
{
}

/**
** \fn ~Bloc()
** \brief Destructeur par defaut d'un bloc
*/
Fonction::Bloc::~Bloc()
{
    /* Destruction des blocs de la fonction */
    for (std::list<InstrASM*>::iterator it=this->_list_instr.begin();
         it!=this->_list_instr.end();
         it++)
        delete (*it);
    this->_list_instr.clear();
}


/**
** \fn Bloc(const Fonction::Bloc &)
** \brief Constructeur par copie d'un bloc (inutilisable)
*/
Fonction::Bloc::Bloc(const Fonction::Bloc &):
    _description(),
    _entry(NULL),
    _list_instr(),
    _mutex()
{
}

/**
** \fn Fonction::Bloc &operator = (const Fonction::Bloc &)
** \brief Surcharge de l'operateur = pour les blocs (inutilisable)
*/
Fonction::Bloc    &Fonction::Bloc::operator = (const Fonction::Bloc &)
{
    return (*this);
}


/**
** \fn std::string get_description() const
** \brief Assesseur permettant de recuperer la description du bloc
**
** \return Retourne une string contenant la description du bloc
*/
std::string       Fonction::Bloc::get_description() const
{
    return (this->_description);
}
        
/**
** \fn void get_description(const std::string &str)
** \brief Assesseur permettant de modifier la description du bloc
**
** \param str Nouvelle description du bloc
** \return Retourne rien
*/
void              Fonction::Bloc::set_description(const std::string &str)
{
    this->_description = str;
}

/**
** \fn unsigned long get_addr() const
** \brief Assesseur permettant de connaitre l'adresse de debut du bloc
**
** \return Retourne l'adresse de la premiere instruction du bloc si OK, 0 sinon
*/
unsigned long     Fonction::Bloc::get_addr() const
{
    if (this->_entry == NULL)
        return (0);
    return (this->_entry->_address);
}

/**
** \fn InstrASM *get_instr_entry() const
** \brief Assesseur parmettant d'acceder a la premiere instruction du bloc
**
** \return Retourne un pointeur sur la première instruction si OK, NULL sinon
*/
InstrASM          *Fonction::Bloc::get_instr_entry() const
{
    return (this->_entry);
}
        
/**
** \fn void set_instr_entry(InstrASM *i)
** \brief Assesseur permettant de modifier la premiere instruction du bloc
**
** \param i Nouvelle premiere instruction (ajoute l'instruction a la liste si besoin est)
** \return Retourne rien
*/
void              Fonction::Bloc::set_instr_entry(InstrASM *i)
{
    this->_entry = i;

    if (i != NULL)
    {
        /* Si on trouve le pointeur dans la liste on ne l'ajoute pas a nouveau */
        for (std::list<InstrASM*>::const_iterator it=this->_list_instr.begin();
             it!=this->_list_instr.end();
             it++)
        {
            if ((*it) == i)
                return ;
        }

        this->_list_instr.push_back(i);
    }
}
        
/**
** \fn InstrASM *get_instr(unsigned long addr) const
** \brief Assesseur permettant d'acceder a une instruction a partir de son adresse
**
** \param addr Adresse de l'instruction a trouver
** \return Retourne un pointeur sur l'instruction si elle est dans le bloc, NULL sinon
*/
InstrASM          *Fonction::Bloc::get_instr(unsigned long addr) const
{
    for (std::list<InstrASM*>::const_iterator it=this->_list_instr.begin();
         it!=this->_list_instr.end();
         it++)
    {
        if ((*it)->_address == addr)
            return (*it);
    }
    return (NULL);
}



/**
** \fn int add_instr(InstrASM *i)
** \brief Gere l'ajout d'une instruction ASM dans la liste des instructions du bloc
**
** \param i instruction a ajouter
** \return Retourne 1 si l'ajout s'est bien passe, 0 sinon
*/
int               Fonction::Bloc::add_instr(InstrASM *i)
{
    if (i != NULL)
    {
        /* Si on trouve le pointeur dans la liste on ne l'ajoute pas a nouveau */
        for (std::list<InstrASM*>::const_iterator it=this->_list_instr.begin();
             it!=this->_list_instr.end();
             it++)
        {
            if ((*it) == i)
                return (0);
        }
        
        this->_list_instr.push_back(i);
        return (1);
    }
    return (0);
}

/**
** \fn int del_instr(InstrASM *i)
** \brief Gere l'enlevement d'une instruction ASM de la liste des instructions du bloc
**
** \param i instruction a enlever (ne delete pas l'instruction)
** \return Retourne 1 si l'enlevement s'est bien passe, 0 sinon
*/
int               Fonction::Bloc::del_instr(InstrASM *i)
{
    /* Parcours la liste des instructions a la recherche de l'instruction a enlever */
    for (std::list<InstrASM*>::iterator it=this->_list_instr.begin();
         it!=this->_list_instr.end(); )
    {
        if ((*it) == i)
        {
            /* Si c'est la premiere instruction, on change le point d'entree de la fonction */
            if (this->_entry == i)
                this->_entry = i->_next_instr;
            
            /* On connecte les instructions suivante et precedente */
            if (i->_prev_instr != NULL)
                i->_prev_instr->_next_instr = i->_next_instr;
            if (i->_next_instr != NULL)
                i->_next_instr->_prev_instr = i->_prev_instr;
            
            /* On clear les liens de l'instruction pour eviter les emmerdes */
            i->_prev_instr = NULL;
            i->_next_instr = NULL;
            
            /* On termine en enlevant l'instruction de la liste */
            this->_list_instr.erase(it);
            
            it = this->_list_instr.begin();
        }
        else
            it++;
    }
    return (0);
}

/**
** \fn int del_instr(unsigned long addr)
** \brief Gere l'enlevement d'une instruction ASM de la liste des instructions du bloc
**
** \param i instruction a enlever (ne delete pas l'instruction)
** \return Retourne 1 si l'enlevement s'est bien passe, 0 sinon
*/
int               Fonction::Bloc::del_instr(unsigned long addr)
{
    InstrASM    *instr;
    
    if ((instr = this->get_instr(addr)) != NULL)
    {
        /* On supprime toutes les instructions du bloc ayant cette adresse */
        /* (normalement, il n'y en a q'une) */
        while ((instr = this->get_instr(addr)) != NULL)
        {
            this->del_instr(instr);
        }
        return (1);
    }
    
    return (0);
}

/**
** \fn Fonction::Bloc *split(unsigned long addr)
** \brief Permet de diviser un bloc en deux a partir d'une adresse
**
** \param addr Toutes les instructions suivants cette adresse seront dans le nouveau bloc
** \return Retourne un pointeur sur le bloc ainsi cree si OK, NULL sinon
*/
Fonction::Bloc    *Fonction::Bloc::split(unsigned long addr)
{
    InstrASM    *instr;
    InstrASM    *next;
    InstrASM    *prev;
    Bloc        *new_bloc;

    /* Si on trouve l'instruction, on va propablement devoir spliter le bloc */
    if ((instr = this->get_instr(addr)) != NULL)
    {
        /* Si l'adresse correspond a la premiere instruction, on ne splite rien */
        if (instr == this->_entry)
            return (this);

        /* Sinon, on cree le nouveau bloc */
        if ((new_bloc = new Bloc) != NULL)
        {
            /* La derniere instruction de l'ancien bloc devra "pointer" sur le debut du nouveau bloc */
            if (instr->_prev_instr != NULL)
            {
                instr->_prev_instr->_next_instr = NULL;/*
                instr->_prev_instr->_addr_next_instr = instr->_address;
                instr->_prev_instr->_addr_next_instr_jump.clear();*/
                instr->_prev_instr->_addr_next_instr_jump.clear();
                instr->_prev_instr->_addr_next_instr_jump.push_back(instr->_address);
            }
            
            /* L'instruction devient la premiere */
            instr->_prev_instr = NULL;
            new_bloc->_entry = instr;

            /* Pour l'instruction et les suivantes */
            while (instr != NULL)
            {
                /* Sauvegerde des instructions precedente et suivante */
                next = instr->_next_instr;
                prev = instr->_prev_instr;
                
                /* Changement de bloc */
                this->del_instr(instr);
                new_bloc->add_instr(instr);
                
                /* Reconnexion des instructions entre elles */
                instr->_prev_instr = prev;
                instr->_next_instr = next;
                if (prev != NULL)
                    prev->_next_instr = instr;
                if (next != NULL)
                    next->_prev_instr = instr;
                
                /* Passe a l'instruction suivante */
                instr = next;
            }
            
            return (new_bloc);
        }
    }
    return (NULL);
}

/**
** \fn Fonction::Bloc *split(InstrASM *instr)
** \brief Permet de diviser un bloc en deux a partir d'une instruction
**
** \param instr Cette instruction et les suivantes seront dans le nouveau bloc
** \return Retourne un pointeur sur le bloc ainsi cree, NULL sinon
*/
Fonction::Bloc    *Fonction::Bloc::split(InstrASM *instr)
{
    if (instr == NULL)
        return (NULL);
    return (this->split(instr->_address));
}
        
/**
** \fn Fonction::Bloc *concate(Bloc *b)
** \brief Gere la concatenation d'un bloc avec un autre
**
** \param b Bloc a concatener a la fin de "this" (il ne sera PAS supprime)
** \return Retourne un pointeur sur "this"
*/
Fonction::Bloc    *Fonction::Bloc::concate(Bloc *b)
{
    InstrASM	*instr;

    if ((b == NULL) || (b == this) || (b->_entry == NULL))
        return (this);

    /* Deplace toutes les instructions de "b" vers "this" */
    while (b->_list_instr.size() > 0)
    {
        this->_list_instr.push_back(b->_list_instr.back());
        b->_list_instr.pop_back();
    }
    
    /* Connecte les deux blocs */
    if (this->_entry == NULL)
        this->_entry = b->_entry;
    else
    {
        /* Cherche la fin des instructions du premier bloc */
        instr = this->_entry;
        while (instr->_next_instr != NULL)
            instr = instr->_next_instr;
  
        /* Connecte les deux chaines d'instructions */
        instr->_next_instr = b->_entry;
        if (b->_entry != NULL)
            b->_entry->_prev_instr = instr;
        
        /* L'ancienne fin n'est plus la fin */
        instr->_addr_next_instr_jump.clear();
    }

    /* Clear l'ancien bloc (il faudra le supprimer) */
    b->_entry = NULL;
    b->_list_instr.clear();
    
    return (this);
}

    
/**
** \fn void lock()
** \brief Permet de verrouiller le mutex du bloc
**
** \return Retourne rien
*/
void              Fonction::Bloc::lock()
{
    this->_mutex.lock();
}
    
/**
** \fn void unlock()
** \brief Permet de deverrouiller le mutex du bloc
**
** \return Retourne rien
*/
void              Fonction::Bloc::unlock()
{
    this->_mutex.unlock();
}
        
        
        
        
/**
** \fn Fonction()
** \brief Constructeur par defaut d'une fonction
*/
Fonction::Fonction():
    _description(),
    _entry(NULL),
    _list_bloc(),
    _addr_call(),
    _code_source(NULL),
    _mutex()
{
}

/**
** \fn ~Fonction()
** \brief Destructeur par defaut d'une fonction
*/
Fonction::~Fonction()
{
    /* Destruction des blocs de la fonction */
    for (std::list<Fonction::Bloc*>::iterator it=this->_list_bloc.begin();
         it!=this->_list_bloc.end();
         it++)
        delete (*it);
    this->_list_bloc.clear();
    
    /* Destruction du code source */
    if (this->_code_source != NULL)
        delete this->_code_source;
}

/**
** \fn Fonction(const Fonction &f)
** \brief Constructeur par copie de la fonction (inutilisable)
*/
Fonction::Fonction(const Fonction &):
    _description(),
    _entry(NULL),
    _list_bloc(),
    _addr_call(),
    _code_source(NULL),
    _mutex()
{
}

/**
** \fn Fonction &operator = (const Fonction &)
** \brief Surcharge de l'operateur = pour les fonctions (inutilisable)
**
** \return Retourne une reference sur la fonction
*/
Fonction    &Fonction::operator = (const Fonction &)
{
    return (*this);
}



/**
** \fn std::string get_description() const
** \brief Assesseur permettant de recuperer la description du bloc
**
** \return Retourne une string contenant la description du bloc
*/
std::string       Fonction::get_description() const
{
    return (this->_description);
}
        
/**
** \fn void get_description(const std::string &str)
** \brief Assesseur permettant de modifier la description du bloc
**
** \param str Nouvelle description du bloc
** \return Retourne rien
*/
void              Fonction::set_description(const std::string &str)
{
    this->_description = str;
}

/**
** \fn unsigned long get_addr() const
** \brief Assesseur permettant de connaitre l'adresse de la fonction
**
** \return Retourne l'adresse de la fonction si OK, 0 sinon
*/
unsigned long     Fonction::get_addr() const
{
    if (this->_entry == NULL)
        return (0);
    return (this->_entry->get_addr());
}


/**
** \fn Fonction::Bloc *get_bloc_entry() const
** \brief Assesseur permettant d'acceder au bloc d'entree de la fonction
**
** \return Retourne un pointeur sur le bloc d'entree de la fonction ou NULL
*/
Fonction::Bloc    *Fonction::get_bloc_entry() const
{
    return (this->_entry);
}

/**
** \fn void set_bloc_entry(Fonction::Bloc *bloc)
** \brief Assesseur permettant de definir quel est le bloc d'entree de la fonction
**
** \param bloc Bloc d'entree (est ajoutee a la liste des blocs s'il n'y etait pas)
** \return Retourne rien
*/
void              Fonction::set_bloc_entry(Fonction::Bloc *bloc)
{
    this->_entry = bloc;
}

/**
** \fn Fonction::Bloc *get_bloc(unsigned long addr) const
** \brief Assesseur permettant d'acceder au bloc contenant une instruction
**
** \param addr Adresse de l'instruction contenue dans le bloc a trouver
** \return Retourne un pointeur sur le bloc si on le trouve, NULL sinon
*/
Fonction::Bloc    *Fonction::get_bloc(unsigned long addr) const
{
    for (std::list<Fonction::Bloc*>::const_iterator it=this->_list_bloc.begin();
         it!=this->_list_bloc.end();
         it++)
    {
        if ((*it)->get_instr(addr) != NULL)
            return (*it);
    }
    return (NULL);
}

/**
** \fn const std::list<Fonction::Bloc*> get_list_bloc() const
** \brief Assesseur parmettant d'acceder a la liste des blocs
**
** \return Retourne une reference sur la liste des blocs de la fonction
*/
const std::list<Fonction::Bloc*>    &Fonction::get_list_bloc() const
{
    return (this->_list_bloc);
}


/**
** \fn int add_bloc(Fonction::Bloc *bloc)
** \brief Permet d'ajouter un bloc a la fonction
**
** \param bloc Bloc a ajouter a la fonction
** \return Retourne 1 si OK, 0 si le bloc etait deja dans la liste de blocs
*/
int               Fonction::add_bloc(Fonction::Bloc *bloc)
{
    if (bloc != NULL)
    {
        for (std::list<Fonction::Bloc*>::iterator it=this->_list_bloc.begin();
             it!=this->_list_bloc.end();
             it++)
        {
            if ((*it) == bloc)
                return (0);
        }
    
        this->_list_bloc.push_back(bloc);
        return (1);
    }    
    return (0);
}

/**
** \fn int del_bloc(Fonction::Bloc *bloc, int del=0)
** \brief Gere la suppression d'un bloc de la liste de blocs
**
** \param bloc Bloc a supprimer
** \param del Vaut 1 si le bloc a ete alloue via "new" et qu'il faut le "delete"
** \return Retourne 1 si on a trouver et supprimer le bloc, 0 sinon
*/
int               Fonction::del_bloc(Fonction::Bloc *bloc, int del)
{
    if (bloc != NULL)
    {
        for (std::list<Fonction::Bloc*>::iterator it=this->_list_bloc.begin();
             it!=this->_list_bloc.end();
             it++)
        {
            if ((*it) == bloc)
            {
                if (del == 1)
                    delete bloc;

                if (this->_entry == bloc)
                    this->_entry = NULL;
                
                this->_list_bloc.erase(it);
                return (1);
            }
        }
    }    
    return (0);
}


/**
** \fn const std::set<unsigned long> &get_addr_call() const
** \brief Assesseur permettant d'acceder a la liste des sous-fonctions appelees
**
** \return Retourne une reference sur le tabeau contenant les adresses des sous-fonctions
*/
const std::set<unsigned long>    &Fonction::get_addr_call() const
{
    return (this->_addr_call);
}

/**
** \fn void add_addr_call(unsigned long a)
** \brief Permet d'ajouter une adresse a la liste des sous-fonctions appelees
**
** \param a Adresse de la sous-fonction
** \return Retourne rien
*/    
void              Fonction::add_addr_call(unsigned long a)
{
    this->_addr_call.insert(a);
}

/**
** \fn void del_addr_call(unsigned long a)
** \brief Permet de supprimer une adresse de la liste des sous-fonctions appelees
**
** \param a Adresse de la sous-fonction
** \return Retourne rien
*/   
void              Fonction::del_addr_call(unsigned long a)
{
    this->_addr_call.erase(a);
}


/**
** \fn IBlocSource *get_source_code() const
** \brief Assesseur parmettant d'acceder au code-source de la fonction
**
** \return Retourne un pointeur sur le code-source de la fonction
*/
IBlocSource    *Fonction::get_source_code() const
{
    return (this->_code_source);
}

/**
** \fn set set_source_code(IBlocSource *s)
** \brief Assesseur parmettant de modifier le code-source de la fonction
**
** \return Pointeur sur le nouveau code-source de la fonction
** \return Retourne rien
*/
void            Fonction::set_source_code(IBlocSource *s)
{
    if ((this->_code_source != NULL) && (this->_code_source != s))
        delete this->_code_source;
    this->_code_source = s;
}


/**
** \fn void unlock()
** \brief Permet de verrouiller le mutex de la fonction
**
** \return Retourne rien
*/
void              Fonction::lock()
{
    this->_mutex.lock();
}

/**
** \fn void unlock()
** \brief Permet de deverrouiller le mutex de la fonction
**
** \return Retourne rien
*/
void              Fonction::unlock()
{
    this->_mutex.unlock();
}

