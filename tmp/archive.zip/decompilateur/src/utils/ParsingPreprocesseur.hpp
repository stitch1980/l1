#ifndef    PARSING_PREPROCESSEUR_HPP_
#define    PARSING_PREPROCESSEUR_HPP_

#include    <string>
#include    <vector>
#include    <list>
#include    <map>
#include    <fstream>
#include    <iostream>

#include    <stdio.h>
#include    <stdlib.h>
#include    <string.h>
#include    <libgen.h>

#include    "Calcul.hpp"

/* Dossier contenant les headers systeme */
#define    PARSING_PREPROCESSEUR_HEADER_DIRECTORY    "/usr/include/"

/**
** \namespace ParsingPreprocesseur
** \brief Namespace permettant de traiter les directives de preprocesseur d'un fichier C
**
** control-line: 
**    # define identifier token-sequence  
**    # define identifier( identifier , ... , 
**                      identifer) token-sequence  
**    # undef identifier  
**    # include <filename>  
**    # include "filename"  
**    # include token-sequence  
**    # line constant "filename"  
**    # line constant  
**    # error token-sequenceopt  
**    # pragma token-sequenceopt  
**    #  
**    preprocessor-conditional  
**
** preprocessor-conditional: 
**    if-line text elif-parts else-partopt # endif  
** 
** if-line: 
**    # if constant-expression  
**    # ifdef identifier  
**    # ifndef identifier  
** 
** elif-parts: 
**    elif-line text  
**    elif-partsopt  
** 
** elif-line: 
**    # elif constant-expression  
** 
** elif-part: 
**    else-line text  
** 
** else-line: 
**    # else
*/
namespace    ParsingPreprocesseur
{
	/**
	** \fn int open(const std::string &filename, std::vector<std::string> &lines)
	** \brief Gere l'ouverture d'un fichier source et la mise en forme de ses lignes
	**
	** \param filename Nom du fichier a parser
	** \param lines Tableau ou mettre les ligne du fichier
	** \return Retourne 1 si OK, 0 sinon
	*/
	int	open(const std::string &filename, std::vector<std::string> &lines);

	/**
	** \fn int open_and_parse(const std::string &filename, std::vector<std::string> &lines,
	**                        std::map<std::string, std::string> &def, int rec=0)
	** \brief Gere l'ouverture d'un fichier source et son parsing preprocesseur
	**
	** \param filename Nom du fichier a parser
	** \param lines Tableau ou mettre les ligne du fichier
	** \param def Tableau contenant les valeur des defines indexes par leur nom
	** \param rec Profondeur de l'analyse a faire dans les "include", "import"...
	** \return Retourne 1 si OK, 0 sinon
	*/
	int	open_and_parse(const std::string &filename, std::vector<std::string> &lines,
	                       std::map<std::string, std::string> &def, int rec=0);

	/**
	** \fn int parse(const std::string &filename, std::vector<std::string> &lines,
	**              std::map<std::string, std::string> &def, int rec=0)
	** \brief Gere le parsing preprocesseur des lignes d'un fichier
	**
	** \param filename Nom du fichier (pour gerer les includes)
	** \param lines Tableau ou mettre les ligne du fichier
	** \param def Tableau contenant les valeur des defines indexes par leur nom
	** \param rec Profondeur de l'analyse a faire dans les "include", "import"...
	** \return Retourne 1 si OK, 0 sinon
	*/
	int	parse(const std::string &filename, std::vector<std::string> &lines,
	              std::map<std::string, std::string> &def, int rec=0);

	/**
	** \fn int parse_rec(const std::string &filename, std::vector<std::string> &lines,
	**              std::map<std::string, std::string> &def, unsigned long &num_line, int rec=0)
	** \brief Gere le parsing preprocesseur des lignes d'un fichier jusqu'a renconter un "#endif"
	**
	** \param filename Nom du fichier (pour gerer les includes)
	** \param lines Tableau ou mettre les ligne du fichier
	** \param def Tableau contenant les valeur des defines indexes par leur nom
	** \param num_line Numero de la line actuelle
	** \param rec Profondeur de l'analyse a faire dans les "include", "import"...
	** \return Retourne 1 si OK, 0 sinon
	*/
	int	parse_rec(const std::string &filename, std::vector<std::string> &lines,
	              std::map<std::string, std::string> &def, unsigned long &num_line, int rec=0);

	/**
	** \fn int skip_rec(const std::string &filename, std::vector<std::string> &lines,
	**              std::map<std::string, std::string> &def, unsigned long &num_line, int rec=0)
	** \brief Gere l'effacement des lignes d'un fichier jusqu'a renconter un "#endif"
	**
	** \param lines Tableau ou mettre les ligne du fichier
	** \param num_line Numero de la line actuelle
	** \return Retourne 1 si OK, 0 sinon
	*/
	int	skip_rec(std::vector<std::string> &lines, unsigned long &num_line);

	/**
	** \fn int remove_comment(std::vector<std::string> &lines)
	** \brief Gere la suppression des commentaires des lignes du fichier a analyser
	**
	** \param lines Lignes du fichier a analyser
	** \return Retourne 1 si OK, 0 sinon
	*/
	int	remove_comment(std::vector<std::string> &lines);

	/**
	** \fn int epure_line(std::vector<std::string> &lines)
	** \brief Gere la suppression des espaces en fin de ligne et la concatenation des lignes finissant par un "\"
	**
	** \param lines Lignes du fichier a analyser
	** \return Retourne 1 si OK, 0 sinon
	*/
	int	epure_line(std::vector<std::string> &lines);

	/**
	** \fn int gestion_directive_define(std::vector<std::string> &lines,
	**                                  std::map<std::string, std::string> &def,
	**                                  unsigned long &current_line)
	** \brief Gere la directive "define"
	**
	** \param lines Tableau ou mettre les ligne du fichier
	** \param def Tableau contenant les valeur des defines indexes par leur nom
	** \param current_line Numero de la ligne actuelle
	** \return Retourne 1 si OK, 0 sinon
	*/
	int	gestion_directive_define(std::vector<std::string> &lines,
	                                 std::map<std::string, std::string> &def,
	                                 unsigned long &current_line);

	/**
	** \fn int gestion_directive_undef(std::vector<std::string> &lines,
	**                                  std::map<std::string, std::string> &def,
	**                                  unsigned long &current_line)
	** \brief Gere la directive "undef"
	**
	** \param lines Tableau ou mettre les ligne du fichier
	** \param def Tableau contenant les valeur des defines indexes par leur nom
	** \param current_line Numero de la ligne actuelle
	** \return Retourne 1 si OK, 0 sinon
	*/
	int	gestion_directive_undef(std::vector<std::string> &lines,
	                                 std::map<std::string, std::string> &def,
	                                 unsigned long &current_line);

	/**
	** \fn int gestion_directive_include(const std::string &filename,
	**                               const std::string &directive,
	**                               std::vector<std::string> &lines,
	**                               std::map<std::string, std::string> &def,
	**                               unsigned long &current_line,
	**                               int rec)
	** \brief Gere les directives "include", "import", "include_next"...
	**
	** \param filename Nom du fichier actuel (pour gerer l'include)
	** \param directive Directive de preprocesseur ("include", "import", ...)
	** \param lines Tableau ou mettre les ligne du fichier
	** \param def Tableau contenant les valeur des defines indexes par leur nom
	** \param current_line Numero de la ligne actuelle
	** \param rec Superieure a 0 s'il faut traiter le header recursivement
	** \return Retourne 1 si OK, 0 sinon
	*/
	int	gestion_directive_include(const std::string &filename,
	                                 const std::string &directive,
	                                 std::vector<std::string> &lines,
	                                 std::map<std::string, std::string> &def,
	                                 unsigned long &current_line,
	                                 int rec);

	/**
	** \fn int gestion_directive_ifndef(const std::string &filename,
	**                               std::vector<std::string> &lines,
	**                               std::map<std::string, std::string> &def,
	**                               unsigned long &current_line,
	**                               int rec)
	** \brief Gere la directive "ifndef"
	**
	** \param filename Nom du fichier actuel (pour gerer l'include)
	** \param lines Tableau ou mettre les ligne du fichier
	** \param def Tableau contenant les valeur des defines indexes par leur nom
	** \param current_line Numero de la ligne actuelle
	** \param rec Superieure a 0 s'il faut traiter le header recursivement
	** \return Retourne 1 si OK, 0 sinon
	*/
	int	gestion_directive_ifndef(const std::string &filename,
	                                 std::vector<std::string> &lines,
	                                 std::map<std::string, std::string> &def,
	                                 unsigned long &current_line,
	                                 int rec);

	/**
	** \fn int gestion_directive_ifdef(const std::string &filename,
	**                               std::vector<std::string> &lines,
	**                               std::map<std::string, std::string> &def,
	**                               unsigned long &current_line,
	**                               int rec)
	** \brief Gere la directive "ifdef"
	**
	** \param filename Nom du fichier actuel (pour gerer l'include)
	** \param lines Tableau ou mettre les ligne du fichier
	** \param def Tableau contenant les valeur des defines indexes par leur nom
	** \param current_line Numero de la ligne actuelle
	** \param rec Superieure a 0 s'il faut traiter le header recursivement
	** \return Retourne 1 si OK, 0 sinon
	*/
	int	gestion_directive_ifdef(const std::string &filename,
	                                 std::vector<std::string> &lines,
	                                 std::map<std::string, std::string> &def,
	                                 unsigned long &current_line,
	                                 int rec);

	/**
	** \fn int gestion_directive_if(const std::string &filename,
	**                               const std::string &directive,
	**                               std::vector<std::string> &lines,
	**                               std::map<std::string, std::string> &def,
	**                               unsigned long &current_line,
	**                               int rec)
	** \brief Gere la directive "if" et "elif"
	**
	** \param filename Nom du fichier actuel (pour gerer l'include)
	** \param directive Directive de preprocesseur ("if", "elif")
	** \param lines Tableau ou mettre les ligne du fichier
	** \param def Tableau contenant les valeur des defines indexes par leur nom
	** \param current_line Numero de la ligne actuelle
	** \param rec Superieure a 0 s'il faut traiter le header recursivement
	** \return Retourne 1 si OK, 0 sinon
	*/
	int	gestion_directive_if(const std::string &filename,
	                                 const std::string &directive,
	                                 std::vector<std::string> &lines,
	                                 std::map<std::string, std::string> &def,
	                                 unsigned long &current_line,
	                                 int rec);

	/**
	** \fn unsigned long skip_name(const std::string &line, const std::string &name)
	** \brief Permet de passer une directive de prerocesseur pour acceder a ses attributs
	**
	** \param line Line contenant la directive de preprocesseur
	** \param name Nom de la directive
	** \return Retourne la taille de la directive si OK, 0 sinon
	*/
	unsigned long	skip_name(const std::string &line, const std::string &name);

	/**
	** \fn int gestion_replace_define(std::string &line, const std::map<std::string, std::string> &def)
	** \brief Gere le remplacement des defines par leur valeur
	**
	** \param line Ligne a traiter
	** \param def Tableau contenant les defines indexes par leur nom
	** \return Retourne 1 si OK, 0 sinon
	*/
	int	gestion_replace_define(std::string &line, const std::map<std::string, std::string> &def);     
}

#endif

