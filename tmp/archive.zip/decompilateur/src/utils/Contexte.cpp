#include    "Contexte.hpp"
#include    "Calcul.hpp"


/**
** \fn Contexte()
** \brief Constructeur par defaut d'un contexte d'execution
*/
Contexte::Contexte():
    _content(),
    _parents(),
    _child(),
    _mutex()
{
}

/**
** \fn Contexte(const Contexte &c)
** \brief Constructeur par copie d'un contexte d'execution
**
** \param c Contexte d'execution a copier
*/
Contexte::Contexte(const Contexte &c):
    _content(),
    _parents(),
    _child(),
    _mutex()
{
    this->copy(c);
}

/**
** \fn ~Contexte()
** \brief Destructeur d'un contexte d'execution
*/
Contexte::~Contexte()
{
    this->remove();
}

/**
** \fn Contexte &operator = (const Contexte &c);
** \brief Surcharge de l'operateur = pour les contextes d'execution
**
** \param c Contexte d'execution a copier
** \return Retourne une reference sur le contexte d'execution
*/
Contexte    &Contexte::operator = (const Contexte &c)
{
    this->copy(c);
    return (*this);
}



/**
** \fn void copy(const Contexte &c)
** \brief Gere la copie du contexte "c" (tout les content sont copies et les
**        conexions sont faites avec les parents/enfants)
**
** \param c Contexte d'execution a copier
** \return Retourne rien
*/
void    Contexte::copy(const Contexte &c)
{
    ContentContexte    *ptr_content;

    this->_mutex.lock();

    /* Copie des ContentContexte */
    for (std::map<std::string, ContentContexte*>::const_iterator it=c.get_content().begin();
         it!=c.get_content().end();
         it++)
    {
        if ((ptr_content = new ContentContexte(*(it->second))) != NULL)
            this->_content[it->first] = ptr_content;
    }

    /* Connexion avec les parents */
    for (std::set<Contexte*>::const_iterator it=c.get_parent().begin();
         it!=c.get_parent().end();
         it++)
    {
        this->_parents.insert(*it);
        (*it)->add_child(this);
    }

    /* Connexion avec les enfants */
    for (std::set<Contexte*>::const_iterator it=c.get_child().begin();
         it!=c.get_child().end();
         it++)
    {
        this->_child.insert(*it);
        (*it)->add_parent(this);
    }

    this->_mutex.unlock();
}

void    Contexte::concatene(const Contexte &c)
{
    ContentContexte                                      *ptr_content;

    /* Ajout des parents de "c" */
    for (std::set<Contexte*>::const_iterator it=c.get_parent().begin();
         it!=c.get_parent().end();
         it++)
        this->add_parent(*it);

    /* Ajout des enfants de "c" */
    for (std::set<Contexte*>::const_iterator it=c.get_child().begin();
         it!=c.get_child().end();
         it++)
        this->add_child(*it);

    /* Ajout de tout les Contents de "c" */
    this->_mutex.lock();

    for (std::map<std::string, ContentContexte*>::const_iterator it=c.get_content().begin();
         it!=c.get_content().end();
         it++)
    {
        /* Si le Content existait deja, on doit fusionner les deux */
        if ((ptr_content = this->find_content_no_mutex(it->first, NULL, 0)) != NULL)
        {
// TODO: Fusion de ContentContexte
        }

        /* Si le Content n'existait pas, on le copie simplement */
        else if ((ptr_content = new ContentContexte(*(it->second))) != NULL)
            this->_content[it->first] = ptr_content;
    }

    this->_mutex.unlock();
}

void    Contexte::remove()
{
    this->_mutex.lock();

    /* Suppression de tout les ContentContexte */
    for (std::map<std::string, ContentContexte*>::iterator it=this->_content.begin();
         it!=this->_content.end();
         it++)
        delete it->second;
    this->_content.clear();
  
    /* Deconnecte tout les parents de this et les connecte aux enfants */
    for (std::set<Contexte*>::iterator it_parent=this->_parents.begin();
         it_parent!=this->_parents.end();
         it_parent++)
    {
        (*it_parent)->del_child(this);

        for (std::set<Contexte*>::iterator it_child=this->_child.begin();
             it_child!=this->_child.end();
             it_child++)
            (*it_parent)->add_child(*it_child);
    }

    /* Deconnecte tout les enfants de this et les connecte aux parents */
    for (std::set<Contexte*>::iterator it_child=this->_child.begin();
         it_child!=this->_child.end();
         it_child++)
    {
        (*it_child)->del_parent(this);
       
        for (std::set<Contexte*>::iterator it_parent=this->_parents.begin();
             it_parent!=this->_parents.end();
             it_parent++)
            (*it_child)->add_child(*it_parent);
    }
    
    this->_parents.clear();
    this->_child.clear();

    this->_mutex.unlock();
}


/*
** - Les fonctions "set_content*(...)" cree un nouveau ContentContexte en
**   supprimant le Content present a l'adresse indiquee s'il y en a un.
** - Les fonctions "del_content*(const std::string &addr)" supprime de Content
**   present a l'adresse indiquee s'il y en a un.
** - Les fonctions "*_safe(...)" partent du principe que l'adresse indiquee
**   est correcte: elle sont donc plus rapide que les autres qui doivent
**   d'abord traiter l'adresse a utiliser pour localiser les Contents.
*/
void               Contexte::set_content(const std::string &addr,
                                         unsigned long size, const std::string &type,
                                         const std::set<std::string> &value,
                                         const std::set<std::string> &filter,
                                         const Info *info)
{
    std::set<std::string>    result;

    if ((addr.size() > 2) && (BNFcalcul::is_memoire(addr, NULL, info->ptr_func.deasm, 0, 0) == addr.size()))
    {
        if (Calcul::evaluate(result, addr.substr(1, addr.size()-2), info, this).size() == 1)
            this->set_content_safe(*result.begin(), size, type, value, filter);
        else
            this->set_content_safe(addr, size, type, value, filter);
    }
    else
        this->set_content_safe(addr, size, type, value, filter);
}

void               Contexte::set_content_safe(const std::string &addr,
                                              unsigned long size, const std::string &type,
                                              const std::set<std::string> &value,
                                              const std::set<std::string> &filter)
{
    ContentContexte    *ptr_content;

    this->del_content_safe(addr);
    this->_mutex.lock();
    
    if ((ptr_content = new ContentContexte(size, type, value, filter)) != NULL)
        this->_content[addr] =  ptr_content;

    this->_mutex.unlock();
}

void               Contexte::del_content(const std::string &addr, const Info *info)
{
    std::set<std::string>    result;

    if ((addr.size() > 2) && (BNFcalcul::is_memoire(addr, NULL, info->ptr_func.deasm, 0, 0) == addr.size()))
    {
        if (Calcul::evaluate(result, addr.substr(1, addr.size()-2), info, this).size() == 1)
            this->del_content_safe(*result.begin());
        else
            this->del_content_safe(addr);
    }
    else
        this->del_content_safe(addr);
}

void               Contexte::del_content_safe(const std::string &addr)
{
    std::map<std::string, ContentContexte*>::iterator    it;

    this->_mutex.lock();
    
    if ((it = this->_content.find(addr)) != this->_content.end())
    {
        delete it->second;
        this->_content.erase(it);
    }

    this->_mutex.unlock();
}


/*
** Permet d'acceder a la liste des Contents du Contexte. Cette fonction ne lock pas de mutex.
*/
const std::map<std::string, ContentContexte*>    &Contexte::get_content() const
{
    return (this->_content);
}


/*
** - Les fonctions "get_size*(...)" permettent de connaitre la taille d'un Content dans le contexte
**   courant. Si le Content n'existe pas dans le contexte, il est cherche dans les Contexte-parents.
**   S'il n'existe pas non plus dans les Contexte-parents, un Content est cree a partir du contenu des segments.
**   S'il n'est pas dans les segments, retourne 0.
** - Les fonctions "get_type*(...)" permettent de connaitre le type d'un Content dans le contexte
**   courant. Si le Content n'existe pas dans le contexte, il est cherche dans les Contexte-parents.
**   S'il n'existe pas non plus dans les Contexte-parents, un Content est cree a partir du contenu des segments.
**   S'il n'est pas dans les segments, retourne "".
** - Les fonctions "get_values*(...)" permettent de connaitre les valeurs possibles d'un Content dans le contexte
**   courant. Si le Content n'existe pas dans le contexte, il est cherche dans les Contexte-parents.
**   S'il n'existe pas non plus dans les Contexte-parents, un Content est cree a partir du contenu des segments.
**   S'il n'est pas dans les segments, retourne un vector vide.
** - Les fonctions "get_filters*(...)" permettent de connaitre les filtres d'un Content dans le contexte
**   courant. Si le Content n'existe pas dans le contexte, il est cherche dans les Contexte-parents.
**   S'il n'existe pas non plus dans les Contexte-parents, un Content est cree a partir du contenu des segments.
**   S'il n'est pas dans les segments, retourne un vector vide.
** - Les fonctions "*_safe(...)" partent du principe que l'adresse indiquee
**   est correcte: elle sont donc plus rapide que les autres qui doivent
**   d'abord traiter l'adresse a utiliser pour localiser les Contents.
*/
unsigned long               Contexte::get_size(const std::string &addr, const Info *info) const
{
    std::set<std::string>    result;

    if ((addr.size() > 2) && (BNFcalcul::is_memoire(addr, NULL, info->ptr_func.deasm, 0, 0) == addr.size()))
    {
        if (Calcul::evaluate(result, addr.substr(1, addr.size()-2), info, this).size() == 1)
            return (this->get_size_safe(*result.begin(), info));
        else
            return (this->get_size_safe(addr, info));
    }
    else
        return (this->get_size_safe(addr, info));
}

unsigned long               Contexte::get_size_safe(const std::string &addr, const Info *info) const
{
    unsigned long      ret;
    ContentContexte    *ptr_content;

    const_cast<Mutex*>(&(this->_mutex))->lock();

    ret = 0;
    if ((ptr_content = this->find_content_no_mutex(addr, info, 2)) != NULL)
    {
        ret = ptr_content->get_size();
        if (ptr_content->get_must_be_delete() > 0)
            delete ptr_content;
    }

    const_cast<Mutex*>(&(this->_mutex))->unlock();    
    return (ret);
}

std::string                 &Contexte::get_type(std::string &t, const std::string &addr, const Info *info) const
{
    std::set<std::string>    result;

    if ((addr.size() > 2) && (BNFcalcul::is_memoire(addr, NULL, info->ptr_func.deasm, 0, 0) == addr.size()))
    {
        if (Calcul::evaluate(result, addr.substr(1, addr.size()-2), info, this).size() == 1)
            return (this->get_type_safe(t, *result.begin(), info));
        else
            return (this->get_type_safe(t, addr, info));
    }
    else
        return (this->get_type_safe(t, addr, info));
}

std::string                 &Contexte::get_type_safe(std::string &t, const std::string &addr, const Info *info) const
{
    ContentContexte    *ptr_content;

    const_cast<Mutex*>(&(this->_mutex))->lock();

    t.clear();
    if ((ptr_content = this->find_content_no_mutex(addr, info, 2)) != NULL)
    {
        t = ptr_content->get_type();
        if (ptr_content->get_must_be_delete() > 0)
            delete ptr_content;
    }

    const_cast<Mutex*>(&(this->_mutex))->unlock();    
    return (t);
}

std::set<std::string>    &Contexte::get_values(std::set<std::string> &v, const std::string &addr, const Info *info) const
{
    std::set<std::string>    result;

    v.clear();
    
    /* Si c'est un sous-registre, on doit recuperer le nom et le mask utile pour acceder a sa valeur */
    if ((info->ptr_func.deasm != NULL) && (BNFcalcul::is_registre(addr, NULL, info->ptr_func.deasm, 0, 0) == addr.size()))
    {
        std::string        begin_mask;
        std::string        name_parent;
        std::string        end_mask;
    
        info->ptr_func.deasm->get_name_and_mask_getter(addr, begin_mask, name_parent, end_mask);
        if ((!begin_mask.empty()) || (!end_mask.empty()))
        {
            this->get_values_safe(result, name_parent, info);
        
            for (std::set<std::string>::iterator it=result.begin();
                 it!=result.end();
                 it++)
                Calcul::evaluate_add_result(v, begin_mask + (*it) + end_mask, info, this);
            
            return (v);
        }
        else
           return (this->get_values_safe(v, addr, info));
    }
    
    else if ((addr.size() > 2) && (BNFcalcul::is_memoire(addr, NULL, info->ptr_func.deasm, 0, 0) == addr.size()))
    {
        if (Calcul::evaluate(result, addr.substr(1, addr.size()-2), info, this).size() == 1)
            return (this->get_values_safe(v, *result.begin(), info));
        else
            return (this->get_values_safe(v, addr, info));
    }
    else
        return (this->get_values_safe(v, addr, info));
}

std::set<std::string>    &Contexte::get_values_safe(std::set<std::string> &v, const std::string &addr, const Info *info) const
{
    ContentContexte    *ptr_content;

    const_cast<Mutex*>(&(this->_mutex))->lock(); 
    
    v.clear();
    if ((ptr_content = this->find_content_no_mutex(addr, info, 2)) != NULL)
    {
        v = ptr_content->get_values();
        if (ptr_content->get_must_be_delete() > 0)
            delete ptr_content;
    }

    const_cast<Mutex*>(&(this->_mutex))->unlock();    
    return (v);
}

std::set<std::string>    &Contexte::get_filters(std::set<std::string> &f, const std::string &addr, const Info *info) const
{
    std::set<std::string>    result;

    if ((addr.size() > 2) && (BNFcalcul::is_memoire(addr, NULL, info->ptr_func.deasm, 0, 0) == addr.size()))
    {
        if (Calcul::evaluate(result, addr.substr(1, addr.size()-2), info, this).size() == 1)
            return (this->get_filters_safe(f, *result.begin(), info));
        else
            return (this->get_filters_safe(f, addr, info));
    }
    else
        return (this->get_filters_safe(f, addr, info));
}

std::set<std::string>    &Contexte::get_filters_safe(std::set<std::string> &f, const std::string &addr, const Info *info) const
{
    ContentContexte    *ptr_content;

    const_cast<Mutex*>(&(this->_mutex))->lock();

    f.clear();
    if ((ptr_content = this->find_content_no_mutex(addr, info, 2)) != NULL)
    {
        f = ptr_content->get_filters();
        if (ptr_content->get_must_be_delete() > 0)
            delete ptr_content;
    }

    const_cast<Mutex*>(&(this->_mutex))->unlock();    
    return (f);
}


/*
** - Les fonctions "set_size*(...)" modifie la taille d'un Content dans le contexte
**   courant. Le content est cree s'il n'existait pas deja. S'il etait seulement
**   definie dans les Contextes-parents, toutes ses autres informations sont copiees.
** - Les fonctions "set_type*(...)" modifie le type d'un Content dans le contexte
**   courant. Le content est cree s'il n'existait pas deja. S'il etait seulement
**   definie dans les Contextes-parents, toutes ses autres informations sont copiees.
** - Les fonctions "set_values*(...)" modifie les valeurs d'un Content dans le contexte
**   courant. Le content est cree s'il n'existait pas deja. S'il etait seulement
**   definie dans les Contextes-parents, toutes ses autres informations sont copiees.
** - Les fonctions "set_filters*(...)" modifie les filtres d'un Content dans le contexte
**   courant. Le content est cree s'il n'existait pas deja. S'il etait seulement
**   definie dans les Contextes-parents, toutes ses autres informations sont copiees.
** - Les fonctions "*_safe(...)" partent du principe que l'adresse indiquee
**   est correcte: elle sont donc plus rapide que les autres qui doivent
**   d'abord traiter l'adresse a utiliser pour localiser les Contents.
*/
void    Contexte::set_size(unsigned long s, const std::string &addr, const Info *info)
{
    std::set<std::string>    result;

    if ((addr.size() > 2) && (BNFcalcul::is_memoire(addr, NULL, info->ptr_func.deasm, 0, 0) == addr.size()))
    {
        if (Calcul::evaluate(result, addr.substr(1, addr.size()-2), info, this).size() == 1)
            this->set_size_safe(s, *result.begin(), info);
        else
            this->set_size_safe(s, addr, info);
    }
    else
        this->set_size_safe(s, addr, info);
}

void    Contexte::set_size_safe(unsigned long s, const std::string &addr, const Info *info)
{
    std::map<std::string, ContentContexte*>::iterator    it_content;
    ContentContexte                                      *ptr_content;

    this->_mutex.lock();

    /* Si le Content existe deja, c'est tout simple */
    if ((it_content = this->_content.find(addr)) != this->_content.end())
        it_content->second->set_size(s);
    
    /* Sinon, il faut creer un nouveau content */
    else if ((ptr_content = this->find_content_no_mutex(addr, info, 2)) != NULL)
    {
        /* Si c'est un content temporaire, on peut simplement l'ajouter a la liste */
        if (ptr_content->get_must_be_delete() > 0)
        {
            ptr_content->set_must_be_delete(0);
            this->_content[addr] = ptr_content;
        }
        
        /* Sinon il faut le copier pour pouvoir l'ajouter au contexte */
        else if ((ptr_content = new ContentContexte(*ptr_content)) != NULL)
            this->_content[addr] = ptr_content;
        
        /* On peut enfin modifier la taille */
        if (ptr_content != NULL)
            ptr_content->set_size(s);
    }
    
    /* Si la recherche n'a rien donnee, il faut creer un Content */
    else if ((ptr_content = new ContentContexte(s, "int", std::set<std::string>(), std::set<std::string>())) != NULL)
        this->_content[addr] =  ptr_content;

    this->_mutex.unlock();
}

void    Contexte::set_type(const std::string &t, const std::string &addr, const Info *info)
{
    std::set<std::string>    result;

    if ((addr.size() > 2) && (BNFcalcul::is_memoire(addr, NULL, info->ptr_func.deasm, 0, 0) == addr.size()))
    {
        if (Calcul::evaluate(result, addr.substr(1, addr.size()-2), info, this).size() == 1)
            this->set_type_safe(t, *result.begin(), info);
        else
            this->set_type_safe(t, addr, info);
    }
    else
        this->set_type_safe(t, addr, info);
}

void    Contexte::set_type_safe(const std::string &t, const std::string &addr, const Info *info)
{
    std::map<std::string, ContentContexte*>::iterator    it_content;
    ContentContexte                                      *ptr_content;

    this->_mutex.lock();

    /* Si le Content existe deja, c'est tout simple */
    if ((it_content = this->_content.find(addr)) != this->_content.end())
        it_content->second->set_type(t);
    
    /* Sinon, il faut creer un nouveau content */
    else if ((ptr_content = this->find_content_no_mutex(addr, info, 2)) != NULL)
    {
        /* Si c'est un content temporaire, on peut simplement l'ajouter a la liste */
        if (ptr_content->get_must_be_delete() > 0)
        {
            ptr_content->set_must_be_delete(0);
            this->_content[addr] = ptr_content;
        }
        
        /* Sinon il faut le copier pour pouvoir l'ajouter au contexte */
        else if ((ptr_content = new ContentContexte(*ptr_content)) != NULL)
            this->_content[addr] = ptr_content;
        
        /* On peut enfin modifier la taille */
        if (ptr_content != NULL)
            ptr_content->set_type(t);
    }
    
    /* Si la recherche n'a rien donnee, il faut creer un Content */
    else if ((ptr_content = new ContentContexte(4, t, std::set<std::string>(), std::set<std::string>())) != NULL)
        this->_content[addr] =  ptr_content;

    this->_mutex.unlock();
}

void    Contexte::set_value(const std::string &v, const std::string &addr, const Info *info)
{
    std::set<std::string>    values;
    
    if (v.size() > 0)
        values.insert(v);
    this->set_values_safe(values, addr, info);
}

void    Contexte::set_values(const std::set<std::string> &v, const std::string &addr, const Info *info)
{
    std::set<std::string>    result;

    /* Si c'est un sous-registre, on doit recuperer le nom et le masque utile pour acceder a sa valeur */
    if ((info->ptr_func.deasm != NULL) && (BNFcalcul::is_registre(addr, NULL, info->ptr_func.deasm, 0, 0) == addr.size()))
    {
        std::string              begin_mask;
        std::string              name_parent;
        std::string              end_mask;
    
        info->ptr_func.deasm->get_name_and_mask_setter(addr, begin_mask, name_parent, end_mask);
        if ( ((!begin_mask.empty()) || (!end_mask.empty())) && 0)
        {
            std::set<std::string>    v_tmp;
        
            for (std::set<std::string>::const_iterator it=v.begin();
                 it!=v.end();
                 it++)
                Calcul::evaluate_add_result(v_tmp, begin_mask + (*it) + end_mask, info, this);
                
            this->set_values_safe(v_tmp, name_parent, info);
        }
        else
            this->set_values_safe(v, name_parent, info);
    }
    
    else if ((addr.size() > 2) && (BNFcalcul::is_memoire(addr, NULL, info->ptr_func.deasm, 0, 0) == addr.size()))
    {
        if (Calcul::evaluate(result, addr.substr(1, addr.size()-2), info, this).size() == 1)
            this->set_values_safe(v, *result.begin(), info);
        else
            this->set_values_safe(v, addr, info);
    }
    else
        this->set_values_safe(v, addr, info);
}
  
    
void    Contexte::set_values_safe(const std::set<std::string> &v, const std::string &addr, const Info *info)
{
    std::map<std::string, ContentContexte*>::iterator    it_content;
    ContentContexte                                      *ptr_content;

    this->_mutex.lock();

    /* Si le Content existe deja, c'est tout simple */
    if ((it_content = this->_content.find(addr)) != this->_content.end())
        it_content->second->set_values(v);
    
    /* Sinon, il faut creer un nouveau content */
    else if ((ptr_content = this->find_content_no_mutex(addr, info, 2)) != NULL)
    {
        /* Si c'est un content temporaire, on peut simplement l'ajouter a la liste */
        if (ptr_content->get_must_be_delete() > 0)
        {
            ptr_content->set_must_be_delete(0);
            this->_content[addr] = ptr_content;
        }
        
        /* Sinon il faut le copier pour pouvoir l'ajouter au contexte */
        else if ((ptr_content = new ContentContexte(*ptr_content)) != NULL)
            this->_content[addr] = ptr_content;
        
        /* On peut enfin modifier la taille */
        if (ptr_content != NULL)
            ptr_content->set_values(v);
    }
    
    /* Si la recherche n'a rien donnee, il faut creer un Content */
    else if ((ptr_content = new ContentContexte(4, "int", v, std::set<std::string>())) != NULL)
        this->_content[addr] =  ptr_content;

    this->_mutex.unlock();
}

void    Contexte::set_filters(const std::set<std::string> &f, const std::string &addr, const Info *info)
{
    std::set<std::string>    result;

    if ((addr.size() > 2) && (BNFcalcul::is_memoire(addr, NULL, info->ptr_func.deasm, 0, 0) == addr.size()))
    {
        if (Calcul::evaluate(result, addr.substr(1, addr.size()-2), info, this).size() == 1)
            this->set_filters_safe(f, *result.begin(), info);
        else
            this->set_filters_safe(f, addr, info);
    }
    else
        this->set_filters_safe(f, addr, info);
}

void    Contexte::set_filters_safe(const std::set<std::string> &f, const std::string &addr, const Info *info)
{
    std::map<std::string, ContentContexte*>::iterator    it_content;
    ContentContexte                                      *ptr_content;

    this->_mutex.lock();

    /* Si le Content existe deja, c'est tout simple */
    if ((it_content = this->_content.find(addr)) != this->_content.end())
        it_content->second->set_filters(f);
    
    /* Sinon, il faut creer un nouveau content */
    else if ((ptr_content = this->find_content_no_mutex(addr, info, 2)) != NULL)
    {
        /* Si c'est un content temporaire, on peut simplement l'ajouter a la liste */
        if (ptr_content->get_must_be_delete() > 0)
        {
            ptr_content->set_must_be_delete(0);
            this->_content[addr] = ptr_content;
        }
        
        /* Sinon il faut le copier pour pouvoir l'ajouter au contexte */
        else if ((ptr_content = new ContentContexte(*ptr_content)) != NULL)
            this->_content[addr] = ptr_content;
        
        /* On peut enfin modifier la taille */
        if (ptr_content != NULL)
            ptr_content->set_filters(f);
    }
    
    /* Si la recherche n'a rien donnee, il faut creer un Content */
    else if ((ptr_content = new ContentContexte(4, "int", std::set<std::string>(), f)) != NULL)
        this->_content[addr] =  ptr_content;

    this->_mutex.unlock();
}
    
    
/*
** - Les fonctions "get_parent()" et "get_child()" permettent d'acceder a la liste
**   des Contextes proches. Ces fonctions ne lock pas de mutex.
** - Les fonctions "add_parent(Contexte *c)" et "add_child(Contexte *c)"
**   ajoutent le pointeur passe en parametre a la liste des Comtextes proches
**   uniquement si le pointeur n'est pas NULL et n'est pas deje present dans la liste.
** - Les fonctions "del_parent(Contexte *c)" et "del_child(Contexte *c)" enlevent
**   le pointeur passe en parametre de la liste des Contextes-proches. Le Contexte
**   passe en parametre n'est pas reelement supprime
** - Les fonctions "del_all_parent()" et "del_all_child()" vident les liste de
**   pointeur de Contextes-proches sans supprimer ces contextes
*/

const std::set<Contexte*>    &Contexte::get_parent() const
{
    return (this->_parents);
}

const std::set<Contexte*>    &Contexte::get_child() const
{
    return (this->_child);
}

void                          Contexte::add_parent(Contexte *c)
{
    if ((c != NULL) && (this->_parents.find(c) == this->_parents.end()) && (c != this))
    {
        this->_mutex.lock();
    
        this->_parents.insert(c);

        this->_mutex.unlock();    
        c->add_child(this);
    }
}

void                          Contexte::add_child(Contexte *c)
{
    if ((c != NULL) && (this->_child.find(c) == this->_child.end()) && (c != this))
    {
        this->_mutex.lock();
    
        this->_child.insert(c);

        this->_mutex.unlock();    
        c->add_parent(this);
    }
}

void                          Contexte::del_parent(Contexte *c)
{
    std::set<Contexte*>::iterator    it;

    this->_mutex.lock();

    if ((it = this->_parents.find(c)) != this->_child.end())
        this->_parents.erase(it);

    this->_mutex.unlock();
}

void                          Contexte::del_child(Contexte *c)
{
    std::set<Contexte*>::iterator    it;

    this->_mutex.lock();

    if ((it = this->_child.find(c)) != this->_child.end())
        this->_child.erase(it);

    this->_mutex.unlock();
}

void                          Contexte::del_all_parent()
{
    this->_mutex.lock();
    this->_parents.clear();
    this->_mutex.unlock();
}

void                          Contexte::del_all_child()
{
    this->_mutex.lock();
    this->_child.clear();
    this->_mutex.unlock();
}


ContentContexte    *Contexte::find_content(const std::string &addr, const Info *info, unsigned long profondeur) const
{
    ContentContexte    *ptr_content;

    ptr_content = NULL;
    if (const_cast<Mutex*>(&(this->_mutex))->try_lock() > 0)
    {
        ptr_content = find_content_no_mutex(addr, info, profondeur);
        const_cast<Mutex*>(&(this->_mutex))->unlock();
    }
    
    return (ptr_content);
}

ContentContexte    *Contexte::find_content_no_mutex(const std::string &addr, const Info *info, unsigned long profondeur) const
{
    std::map<std::string, ContentContexte*>::const_iterator    it_content;
    ContentContexte                                            *ptr_content;
    ContentContexte                                            *ptr_content_tmp;
    
    ptr_content = NULL;
    
    /* Cherche le content dans le contexte courant */
    if ((it_content = this->_content.find(addr)) != this->_content.end())
        ptr_content = it_content->second;
    
    /* Si on ne l'a pas trouvee, on en construit un a partir des contextes parents */
    else if (profondeur > 0)
    {
        /* Si le contexte n'a qu'un parent, on cherche n'a pas besoin de creer un nouveau ContentContexte */
        if (this->_parents.size() == 1)
            ptr_content = (*this->_parents.begin())->find_content(addr, info, profondeur); // <---- Recursion en cas de boucle
        
        /* Si le contexte a plusieurs parents, on doit creer un ContentContexte contenant toute les possibilites */
        else if ((this->_parents.size() > 1) && ((ptr_content = new ContentContexte) != NULL))
        {
            ptr_content->set_must_be_delete(0);

            for (std::set<Contexte*>::const_iterator it=this->_parents.begin();
                 it!=this->_parents.end();
                 it++)
            {
                if ((ptr_content_tmp = (*it)->find_content(addr, info, profondeur)) != NULL)
                {
                    /* On utilise le premier Content pour le type et la taille */ // <---- Pas bien
                    if (it == this->_parents.begin())
                    {
                        ptr_content->set_size(ptr_content_tmp->get_size());
                        ptr_content->set_type(ptr_content_tmp->get_type());
                    }
                    
                    ptr_content->add_values(ptr_content_tmp->get_values());
                    ptr_content->add_filters(ptr_content_tmp->get_filters());
                    
                    /* Supprime le Content si besoin est */
                    if (ptr_content_tmp->get_must_be_delete() > 0)
                        delete ptr_content_tmp;
                }
            }
        }
        
        /* Si a ce stade, on a toujours pas de Content, on doit peut-etre en creer un */
        if ((ptr_content == NULL) && (BNFcalcul::is_hexadecimal(addr, NULL, NULL, 0, 0) == addr.size()))
        {
            if (info->sec.is_in_section(Calcul::Oxtol(addr.c_str())) > 0)
            {
                std::set<std::string>    value;
                std::set<std::string>    filter;
                
                value.insert(Calcul::lto0x(info->sec.get_int(Calcul::Oxtol(addr.c_str()), info->endian)));
                ptr_content = new ContentContexte(4, "int", value, filter);            // <---- Pas bien
            }
        }
    }

    return (ptr_content);
}

